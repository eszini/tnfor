!     Last change: msg 2/7/2021 12:09:24 PM
!			MSG 5/22/2016 1:05:41 PM
!			MSG 5/22/2016 12:45:39 PM
!			MSG 11/5/2015 3:19:44 PM
!			MSG 11/5/2015 3:14:39 PM
!			MSG 11/5/2015 3:13:44 PM
!			MSG 11/5/2015 3:11:02 PM
!			MSG 3/9/2015 2:23:19 PM
!			MSG 2/23/2015 2:39:11 PM
! SIZE_ARRAY_DIMENSIONS ADD 11/08/06 Dr.G
!     ******************************************************************
!-------
      MODULE  CONVERSTION_ROUTINES
         INTERFACE CONVERT_2_STR
            MODULE PROCEDURE INT2_CONVER_2_STR
            MODULE PROCEDURE STR_CONVER_2_STR
            MODULE PROCEDURE INT4_CONVER_2_STR
            MODULE PROCEDURE INT8_CONVER_2_STR
            MODULE PROCEDURE REAL_CONVER_2_STR
            MODULE PROCEDURE REAL8_CONVER_2_STR
            MODULE PROCEDURE INT2_CONVER_2_STR_W_LEN
            MODULE PROCEDURE REAL_CONVER_2_STR_W_DEC
         END INTERFACE
      CONTAINS
!--------
         FUNCTION INT2_CONVER_2_STR(VALUE_IN) RESULT(VALUE_OUT)
         CHARACTER (LEN=20) :: VALUE_OUT,TEMP_STR
         INTEGER (KIND=2) :: VALUE_IN
            WRITE(TEMP_STR,'(I6)') VALUE_IN
            VALUE_OUT = ADJUSTL(TEMP_STR)
         END FUNCTION
!--------
         FUNCTION INT2_CONVER_2_STR_W_LEN(VALUE_IN,STR_LEN) RESULT(VALUE_OUT)
         CHARACTER (LEN=20) :: VALUE_OUT,TEMP_STR
         INTEGER (KIND=2) :: VALUE_IN
         INTEGER (KIND=4) :: STR_LEN
            WRITE(TEMP_STR,'(I8.8)') VALUE_IN
            IF(STR_LEN <= 8) THEN
               VALUE_OUT = TEMP_STR(8-STR_LEN+1:8)
            ELSE
               VALUE_OUT = ADJUSTL(TEMP_STR)
            ENDIF
         END FUNCTION
!--------
         FUNCTION STR_CONVER_2_STR(VALUE_IN) RESULT(VALUE_OUT)
         CHARACTER (LEN=256) :: VALUE_OUT
         CHARACTER (LEN=*) :: VALUE_IN
            IF(INDEX(TRIM(VALUE_IN),' ') == 0) THEN
                VALUE_OUT = VALUE_IN
            ELSE
                VALUE_OUT = '"'//TRIM(VALUE_IN)//'"'
            ENDIF
         END FUNCTION
!--------
         FUNCTION INT4_CONVER_2_STR(VALUE_IN) RESULT(VALUE_OUT)
         CHARACTER (LEN=20) :: VALUE_OUT,TEMP_STR
         INTEGER (KIND=4) :: VALUE_IN
            WRITE(TEMP_STR,'(I11)') VALUE_IN
            VALUE_OUT = ADJUSTL(TEMP_STR)
         END FUNCTION
!--------
         FUNCTION INT8_CONVER_2_STR(VALUE_IN) RESULT(VALUE_OUT)
         CHARACTER (LEN=30) :: VALUE_OUT,TEMP_STR
         INTEGER (KIND=8) :: VALUE_IN
            WRITE(TEMP_STR,'(I22)') VALUE_IN
            VALUE_OUT = ADJUSTL(TEMP_STR)
         END FUNCTION
!--------
         FUNCTION REAL_CONVER_2_STR(VALUE_IN) RESULT(VALUE_OUT)
         CHARACTER (LEN=20) :: VALUE_OUT,TEMP_STR,TEMP_STR2
         REAL (KIND=4) :: VALUE_IN
         INTEGER (KIND=2) :: STR_LEN,I
            IF(ABS(VALUE_IN) < .00001) THEN
               WRITE(TEMP_STR,'(F19.11)') VALUE_IN
            ELSEIF(ABS(VALUE_IN) < .0001) THEN
               WRITE(TEMP_STR,'(F19.10)') VALUE_IN
            ELSEIF(ABS(VALUE_IN) < .001) THEN
               WRITE(TEMP_STR,'(F19.9)') VALUE_IN
            ELSEIF(ABS(VALUE_IN) < .01) THEN
               WRITE(TEMP_STR,'(F19.8)') VALUE_IN
            ELSEIF(ABS(VALUE_IN) < .1) THEN
               WRITE(TEMP_STR,'(F19.7)') VALUE_IN
            ELSEIF(ABS(VALUE_IN) < 1.) THEN
               WRITE(TEMP_STR,'(F19.6)') VALUE_IN
            ELSEIF(ABS(VALUE_IN) < 10.) THEN
               WRITE(TEMP_STR,'(F19.5)') VALUE_IN
            ELSEIF(ABS(VALUE_IN) < 100.) THEN
               WRITE(TEMP_STR,'(F19.4)') VALUE_IN
            ELSEIF(ABS(VALUE_IN) < 1000.) THEN
               WRITE(TEMP_STR,'(F19.3)') VALUE_IN
            ELSEIF(ABS(VALUE_IN) < 10000.) THEN
               WRITE(TEMP_STR,'(F19.2)') VALUE_IN
            ELSEIF(ABS(VALUE_IN) < 100000.) THEN
               WRITE(TEMP_STR,'(F19.1)') VALUE_IN
            ELSE
               WRITE(TEMP_STR,'(F19.0)') VALUE_IN
            ENDIF
            TEMP_STR2 = ADJUSTL(TEMP_STR)
            STR_LEN = LEN_TRIM(TEMP_STR2)
            DO I = STR_LEN,1,-1
               IF(TEMP_STR2(I:I) /= '0') EXIT
            ENDDO
            IF(TEMP_STR2(I:I) == '.') THEN
               VALUE_OUT = TEMP_STR2(1:I-1)
            ELSE
               VALUE_OUT = TEMP_STR2(1:I)
            ENDIF
         END FUNCTION
!--------
         FUNCTION REAL_CONVER_2_STR_W_DEC(VALUE_IN,DEC) RESULT(VALUE_OUT)
         CHARACTER (LEN=20) :: VALUE_OUT,TEMP_STR,TEMP_STR2
         REAL (KIND=4) :: VALUE_IN
         INTEGER (KIND=2) :: STR_LEN,I
         INTEGER (KIND=4) :: DEC
            IF(DEC == 11) THEN
               WRITE(TEMP_STR,'(F19.11)') VALUE_IN
            ELSEIF(DEC == 10) THEN
               WRITE(TEMP_STR,'(F19.10)') VALUE_IN
            ELSEIF(DEC == 9) THEN
               WRITE(TEMP_STR,'(F19.9)') VALUE_IN
            ELSEIF(DEC == 8) THEN
               WRITE(TEMP_STR,'(F19.8)') VALUE_IN
            ELSEIF(DEC == 7) THEN
               WRITE(TEMP_STR,'(F19.7)') VALUE_IN
            ELSEIF(DEC == 6) THEN
               WRITE(TEMP_STR,'(F19.6)') VALUE_IN
            ELSEIF(DEC == 5) THEN
               WRITE(TEMP_STR,'(F19.5)') VALUE_IN
            ELSEIF(DEC == 4) THEN
               WRITE(TEMP_STR,'(F19.4)') VALUE_IN
            ELSEIF(DEC == 3) THEN
               WRITE(TEMP_STR,'(F19.3)') VALUE_IN
            ELSEIF(DEC == 2) THEN
               WRITE(TEMP_STR,'(F19.2)') VALUE_IN
            ELSEIF(DEC == 1) THEN
               WRITE(TEMP_STR,'(F19.1)') VALUE_IN
            ELSE
               WRITE(TEMP_STR,'(F19.0)') VALUE_IN
            ENDIF
            TEMP_STR2 = ADJUSTL(TEMP_STR)
            STR_LEN = LEN_TRIM(TEMP_STR2)
            DO I = STR_LEN,1,-1
               IF(TEMP_STR2(I:I) /= '0') EXIT
            ENDDO
            IF(TEMP_STR2(I:I) == '.') THEN
               VALUE_OUT = TEMP_STR2(1:I-1)
            ELSE
               VALUE_OUT = TEMP_STR2(1:I)
            ENDIF
         END FUNCTION
!--------
         FUNCTION REAL8_CONVER_2_STR(VALUE_IN) RESULT(VALUE_OUT)
         CHARACTER (LEN=20) :: VALUE_OUT,TEMP_STR,TEMP_STR2
         REAL (KIND=8) :: VALUE_IN
         INTEGER (KIND=2) :: STR_LEN,I
            IF(ABS(VALUE_IN) < .00001) THEN
               WRITE(TEMP_STR,'(F19.11)') VALUE_IN
            ELSEIF(ABS(VALUE_IN) < .0001) THEN
               WRITE(TEMP_STR,'(F19.10)') VALUE_IN
            ELSEIF(ABS(VALUE_IN) < .001) THEN
               WRITE(TEMP_STR,'(F19.9)') VALUE_IN
            ELSEIF(ABS(VALUE_IN) < .01) THEN
               WRITE(TEMP_STR,'(F19.8)') VALUE_IN
            ELSEIF(ABS(VALUE_IN) < .1) THEN
               WRITE(TEMP_STR,'(F19.7)') VALUE_IN
            ELSEIF(ABS(VALUE_IN) < 1.) THEN
               WRITE(TEMP_STR,'(F19.6)') VALUE_IN
            ELSEIF(ABS(VALUE_IN) < 10.) THEN
               WRITE(TEMP_STR,'(F19.5)') VALUE_IN
            ELSEIF(ABS(VALUE_IN) < 100.) THEN
               WRITE(TEMP_STR,'(F19.4)') VALUE_IN
            ELSEIF(ABS(VALUE_IN) < 1000.) THEN
               WRITE(TEMP_STR,'(F19.3)') VALUE_IN
            ELSEIF(ABS(VALUE_IN) < 10000.) THEN
               WRITE(TEMP_STR,'(F19.2)') VALUE_IN
            ELSEIF(ABS(VALUE_IN) < 100000.) THEN
               WRITE(TEMP_STR,'(F19.1)') VALUE_IN
            ELSE
               WRITE(TEMP_STR,'(F19.0)') VALUE_IN
            ENDIF
            TEMP_STR2 = ADJUSTL(TEMP_STR)
            STR_LEN = LEN_TRIM(TEMP_STR2)
            DO I = STR_LEN,1,-1
               IF(TEMP_STR2(I:I) /= '0') EXIT
            ENDDO
            IF(TEMP_STR2(I:I) == '.') THEN
               VALUE_OUT = TEMP_STR2(1:I-1)
            ELSE
               VALUE_OUT = TEMP_STR2(1:I)
            ENDIF
         END FUNCTION
      END MODULE CONVERSTION_ROUTINES
   MODULE INTERNAL_OPERATION_SWITCHES                 
      LOGICAL (KIND=4), PARAMETER :: GRX_RETIRE_THIS_YEAR=.TRUE., &
                                     USED_4_YR_EBITDA_TOTAL=.false., &
                                     USE_EACH_YR_EBITDA_NEG=.true.
   END MODULE
   MODULE BASE_FILE_NAMES_FROM_BFIL_OBJ  ! SOURCE IN MODULES95
      CHARACTER (LEN=256) :: COAL_NODE='NONE',              & ! 354
                             COAL_TRANSPORT='NONE',         & ! 355
                             COAL_SUPPLY_FORECAST='NONE',   & ! 356
                             PLANT_DEMAND_FORECAST='NONE',   & ! 357
                             COAL_CONTRACTS='NONE',          & ! 361
                             COAL_MODEL_POINTER_FILE='NONE',  & ! 372
                             COAL_MODEL_SO2_INFO_FILE='NONE', & ! 373
                             COAL_MODEL_GENERIC_TRANSPORT_FILE='NONE', & ! 374
                             COAL_MODEL_GENERIC_DEMAND_FILE='NONE',  & ! 375
                             EXPENSE_NAMES_RESERVED='NONE' ! 7
   END MODULE BASE_FILE_NAMES_FROM_BFIL_OBJ
   MODULE IREC_ENDPOINT_CONTROL
      INTERFACE
         INTEGER FUNCTION RPTREC(UNITNO,SAVE_REC,REC_OPT,FILE_OPT,CURRENT_REC, &
                                 REC_LENGHT,FILE_NAME)
            INTEGER (KIND=2), OPTIONAL :: UNITNO,REC_LENGHT
            INTEGER (KIND=4), OPTIONAL :: SAVE_REC
            CHARACTER (LEN=1), OPTIONAL :: REC_OPT,FILE_OPT
            LOGICAL (KIND=4), OPTIONAL :: CURRENT_REC
            CHARACTER (LEN=*), OPTIONAL :: FILE_NAME
         END FUNCTION
         FUNCTION PRT_ENDPOINT()
            REAL (KIND=4) :: PRT_ENDPOINT
         END FUNCTION
         INTEGER FUNCTION GRX_HORIZON_REPORTING(YR_ITER)
            REAL (KIND=4):: YR_ITER(2)
         END FUNCTION
      END INTERFACE
      INTEGER (KIND=4) :: IREC_SAVED
      LOGICAL (KIND=4) :: HORIZONS_ACTIVE=.true. ! /.true./
      INTEGER (KIND=1) :: CR_HEX = z"0D"
      INTEGER (KIND=1) :: LF_HEX = z"0A"
      CHARACTER (LEN=1) :: CRLF_tEMP(2)
      CHARACTER (LEN=2) :: CRLF
      EQUIVALENCE (CRLF_tEMP(1),CR_HEX),(CRLF_tEMP(2),LF_HEX)
      EQUIVALENCE (CRLF,CRLF_tEMP)
      INTEGER (KIND=1) :: ENDFILE_MARK_HEX=z"1A"
      CHARACTER (LEN=1) :: ENDFILE_MARK
      EQUIVALENCE (ENDFILE_MARK,ENDFILE_MARK_HEX)
   END MODULE
       MODULE SIZE_ARRAY_DIMENSIONS
         INTEGER (KIND = 2), SAVE :: MAX_SIMULATION_YEARS = 30,&
                                     SYSTEM_CLASS_NUM = 7
         INTEGER (KIND=2), PARAMETER :: AVAIL_DATA_YEARS = 30,&
                                     MAX_PLANNING_YEARS=100,&
!                                    MAX_ESCALATION_VECTRS=100,&
                                     MAX_FINANCIAL_SIMULATION_YEARS=101
         LOGICAL (KIND=1), SAVE :: TESTING_PLAN=.FALSE.
         LOGICAL (KIND=1), SAVE :: MONTHLY_MIDAS_ACTIVE=.FALSE.
      END MODULE SIZE_ARRAY_DIMENSIONS
      MODULE PRODUCTION_ARRAYS_AND_DIMENSIONS
         INTEGER (KIND=2), PARAMETER :: MAX_EL_UNITS = 15000,&
                                        MAX_CL_UNITS = 25000, &
                                        MAX_RETIRMENT_UNITS = MAX_CL_UNITS
         INTEGER (KIND=4), PARAMETER :: MAX_DISPATCH_BLOCKS = 2*MAX_CL_UNITS

         INTEGER (KIND=2), PARAMETER :: MAX_CONTRACTS=150,&
                                        MAX_REPORTING_GROUPS=15,&
                                        MAX_LOAD_CLASSES = 6,&
                                        MAXIMUM_FUEL_TYPES=200,&
                                        CONVOLUTION_POINTS=1000,&
                                        LOAD_CURVE_POINTS=1000,&
                                        MAX_DSM_DEVICES= 100,&
                                         MAX_DSM_FINANCIAL_RECORDS= 100,&
                                        MAX_DSM_RESPONSE_CURVES=100,&
                                        MAX_EMISSION_REPORT_GROUPS=10,&
                                        MAX_EMISSION_DISPATCH_GROUPS=6,&
                                        NUMBER_OF_EMISSION_TYPES = 5,&
                                        MAX_STATE_LOOKUP_IDS = 400, & !310, &
                                        TOTAL_EMISSION_GROUPS = MAX_EMISSION_REPORT_GROUPS &
                                                                +MAX_EMISSION_DISPATCH_GROUPS
      END MODULE PRODUCTION_ARRAYS_AND_DIMENSIONS
!--------
      MODULE CAPACITY_OPTIONS_ALLOC_VARIABLES
      INTEGER (KIND=2) :: FOR_ALL_OPTIONS=0
      CHARACTER (LEN=20), ALLOCATABLE ::  UNIT_NAME(:)
      CHARACTER (LEN=10), ALLOCATABLE :: RESOURCE_TYPE(:)
      CHARACTER (LEN=40), ALLOCATABLE :: OVERNIGHT_CAPITAL_COST_STOCASTIC(:)
      CHARACTER (LEN=2), ALLOCATABLE :: FILE_SOURCE(:)
      CHARACTER (LEN=1), ALLOCATABLE :: YES_OR_NO_FILLER(:), &
                                        LOADING_TYPE(:)
      REAL (KIND=4), ALLOCATABLE :: UNIT_CAP(:), &
                                    MAX_UNIT_CAPACITY(:), &
!                                    CONSTRUCTION_COSTS(:), &
                                    CONSTRUCTION_COSTS(:,:), &
                                    CCR_FOR_SCREENING(:), &
                                    MRX_RISK_ADJUSTMENT(:), &
                                    COMPOUND_ESC(:), &
                                    THRESHOLD_CAPACITY(:,:), &
                                    RENEWABLE_ENERGY_PERCENT(:)
      INTEGER (KIND=2), ALLOCATABLE :: FIRST_YEAR_AVAILABLE(:), &
                                       RESOURCE_ID_NUM(:), &
                                       UNIT_IS_IDENTICAL_TO(:), &
                                       RESOURCE_GROUP_NUM(:), &
                                       LAST_YEAR_AVAILABLE(:), &
                                       OPERATION_LIFE(:), &
                                       LEAD_TIME(:), &
                                       ANNUAL_UNITS(:), &
                                       PRODUCTION_DATA_POINTER(:), &
                                       INVESTMENT_DATA_POINTER(:), &
                                       CUMULATIVE_UNITS(:), &
                                       ESCALATION_VECTOR(:), &
                                       DEPEND_UNIT_NO(:), &
                                       MUT_EXC_UNIT(:), &
                                       POINTER_TO_DEPENDENT_UNIT(:), &
                                       DEPENDENT(:), &
                                       INDEPENDENT(:), &
                                       DEPEND_RESOURCE_ID_2_I(:), &
                                       INDEPENDENT_UNIT_STATUS(:), &
                                       INDPENDENT_UNIT(:), &
                                       BASE_OPTION_LIST(:), &
                                       CYCL_OPTION_LIST(:), &
                                       PEAK_OPTION_LIST(:), &
                                       LOAD_OPTION_LIST(:), &
                                       FILL_OPTION_LIST(:), &
                                       ACTIVE_OPTION_LIST(:), &
                                       HARD_WIRED_LIST(:), &
                                       HARD_WIRED_ON_LINE_YEAR(:), &
                                       SAVED_CUMULATIVE_UNITS(:), &
                                       GRX_SAVED_CUMULATIVE_UNITS(:), &
                                       ANNUAL_UNITS_LEFT(:), &
                                       TOTAL_UNITS_ADDED(:), &
                                       ADDITIONAL_INVESTMENT_POINTER(:), &
                                       OVER_CAPACITY_TABLE(:), &
                                       UNDER_CAPACITY_TABLE(:), &
                                       PRIMARY_ASSET_CLASS(:), &
                                       PRIMARY_ALLOCATION_VECTOR(:), &
                                       ADDITIONAL_ASSET_CLASS(:), &
                                       ADDITIONAL_ALLOCATION_VECTOR(:), &
                                       SAVE_NO_CL_ADDITIONS(:), &
                                       SAVE_NO_EL_ADDITIONS(:), &
                                       ADDED_LM_PROGRAMS(:), &
                                       ADDED_CONTRACT_PROGRAMS(:), &
                                       GRX_RESOURCE_LINK_ID(:)
      LOGICAL (KIND=1), ALLOCATABLE :: CONTROLS_DEPEND(:), &
                                       IS_A_HARD_WIRED_UNIT(:), &
                                       HAS_BEEN_SELECTED(:), &
                                       HARD_WIRED_UNIT_AVAILABLE(:)
      REAL (KIND=4), ALLOCATABLE :: LOWEST_CONE_COST_BY_CM(:), &
                                    EAS_REVENUE_OFFSET_BY_CM(:)
      END MODULE CAPACITY_OPTIONS_ALLOC_VARIABLES
!--------
      MODULE CAPACITY_OPTIONS_FIXED_VARIALBES
!
! VARIABLES NEEDED ACROSS ROUTINES
!
      INTEGER (KIND=2) :: TOTAL_ALL_OPTIONS=0, &
                          BASE_OPTIONS=0, &
                          CYCLE_OPTIONS=0, &
                          PEAK_OPTIONS=0, &
                          PEAK_REDUC_OPTIONS=0, &
                          FILL_OPTIONS=0, &
                          HARD_WIRED_OPTIONS=0, &
                          DSM_ADDITIONS=0, &
                          DSM_OPTIONS=0, &
                          CONTRACT_ADDITIONS=0, &
                          CONTRACT_OPTIONS=0, &
                          RENEWABLE_OPTIONS=0, &
                          EFFICIENCY_OPTIONS=0, &
                          CL_OPTIONS=0, &
                          TOTAL_ACTIVE_OPTIONS=0, &
                          MAX_RESOURCE_ID=0, &
                          TOTAL_POSSIBLE_OPTIONS=0
      INTEGER (KIND=2) :: BC_BASE_OPTIONS=0, &
                          BC_CYCLE_OPTIONS=0, &
                          BC_PEAK_OPTIONS=0, &
                          BC_PEAK_REDUC_OPTIONS=0, &
                          BC_FILL_OPTIONS=0, &
                          BC_HARD_WIRED_OPTIONS=0, &
                          BC_TOTAL_ACTIVE_OPTIONS=0, &
                          BC_TOTAL_ALL_OPTIONS=0, &
                          BC_MAX_RESOURCE_ID=0, &
                          BC_TOTAL_POSSIBLE_OPTIONS=0
      INTEGER (KIND=2) :: MAX_ID_FOR_ALL_OPTIONS=0
      INTEGER (KIND=2) :: ON_LINE_MONTH=1
      LOGICAL (KIND=1) :: ALL_OPTIONS_GT_ZERO=.FALSE., &
                          OPTIONS_GT_ZERO=.FALSE.
      END MODULE CAPACITY_OPTIONS_FIXED_VARIALBES
!--------
      MODULE PROCSAVE_COMMON
         REAL (KIND=8), ALLOCATABLE, SAVE :: ENERGY(:),&
                                             TENRG(:),&
                                             TMMBTUS(:),&
                                             FUELCOST(:),&
                                             VARCOST(:)
!         USE SIZE_ARRAY_DIMENSIONS
!         REAL (KIND=8) :: ENERGY(MAX_SIMULATION_YEARS),&
!                          TENRG(MAX_SIMULATION_YEARS),&
!                          TMMBTUS(MAX_SIMULATION_YEARS),&
!                          FUELCOST(MAX_SIMULATION_YEARS),&
!                          VARCOST(MAX_SIMULATION_YEARS)
      END MODULE PROCSAVE_COMMON

      MODULE FINANCIAL_SWITCHES_COMMON
!
! WAS A COMMON BLOCK FOR FINANCIAL RUN SWITCHES
!
         CHARACTER (LEN=1), SAVE :: OPMETH,DVMETH,SRCNPV,ACMETH,TXMETHF,TXMETHS,&
                              PRICE_SOURCE,P_EQUITY_DEFINITION,  &
                              DEBT_ISSUE_TYPE
         INTEGER (KIND=2), SAVE :: OPYEAR,RBMETH
         LOGICAL (KIND=1), SAVE :: CALCULATE_BTL_TAXES
         INTEGER (KIND=2), SAVE:: COVERAGE_RATIO=5,PROPERTY_TAX_METHOD
      END MODULE FINANCIAL_SWITCHES_COMMON

      MODULE SPCapExVariables
! SPCapEx Additions Nov. 2005
         USE PRODUCTION_ARRAYS_AND_DIMENSIONS
         REAL (KIND=4), SAVE :: FIRST_YEAR_DECOMM_AVAIALABLE(MAX_CL_UNITS)
         REAL (KIND=4), SAVE :: DECOMMISSIONING_BASE_YR_COST(MAX_CL_UNITS),&
                                DECOMMISSIONING_COST_ESCALATION(MAX_CL_UNITS),&
                                ANNUAL_ENERGY_PLANNING_FACTOR(MAX_CL_UNITS),&
                                NAME_PLATE_CAPACITY(MAX_CL_UNITS),&
                                FuelRatio(5,MAX_CL_UNITS),&
                                BlendableFuelsPtr(4,MAX_CL_UNITS),&
                                FuelTransportationCost(4,MAX_CL_UNITS),&
                                BlendedEnthalpyUp(MAX_CL_UNITS),&
                                BlendedEnthalpyLo(MAX_CL_UNITS),&
                                BlendedSO2Up(MAX_CL_UNITS),&
                                BettermentProjectID(MAX_CL_UNITS),&
                                DECOM_CONTINUING_COST(MAX_CL_UNITS),&
                                DECOM_CONTINUING_COST_ESCALATION(MAX_CL_UNITS),&
                                EnrgPatternPointer(MAX_CL_UNITS),&
                                EmissRedRate(5,MAX_CL_UNITS),&
                                EmissMaxRate(5,MAX_CL_UNITS),&
                                MaxEnergyLimit(3,MAX_CL_UNITS)
         CHARACTER (LEN=10), SAVE :: FUEL_BLENDING_IS(MAX_CL_UNITS)
         CHARACTER (LEN=20), SAVE :: SP_NEWGEN_UNIT_STATUS(MAX_CL_UNITS)
         CHARACTER (LEN=20), SAVE :: TECH_TYPE(MAX_CL_UNITS)
         CHARACTER (LEN=1),  SAVE :: AGGREGATE_THIS_UNIT(MAX_CL_UNITS),&
                                     EMISSION_DATA_UNITS(MAX_CL_UNITS),&
                                     LINKED_BETTERMENT_OPTION(MAX_CL_UNITS)
         CHARACTER (LEN=48), SAVE :: SP_UNIT_NAME(MAX_CL_UNITS)
	 CHARACTER (LEN=20) :: MARKETSYM_UNIT_NAME(MAX_CL_UNITS)=" "
! SPCapEx Additions April 13, 2005.
! 062006. SPCAPEX ADDITION LINKED_BETTERMENT_OPTION
      END MODULE
      MODULE LH_GLOBAL_VARIABLES
         CHARACTER (LEN=1) :: SAVE_SCENARIO_MRX_PLANS='N'
         CHARACTER (LEN=2) :: MRX_EXPANSION_PLAN_FILE_CODE="CP",&
                              MRX_EXPANSION_PLAN_FILE_NAME="LH"
         INTEGER (KIND=2) ::  MRX_SEQUENCE_NUMBER=1
      END MODULE LH_GLOBAL_VARIABLES
      MODULE TRANS_GROUP_VARIALBES
         REAL (KIND=4), SAVE, ALLOCATABLE :: PRICE_ESCALATION_RATE(:), &
                                       MINIMUM_CAPACITY_TESTING_RATIO(:),& ! 72
                                       MAXIMUM_CAPACITY_TESTING_RATIO(:) ! 73
         INTEGER (KIND=2), ALLOCATABLE :: TGYrToUseExtensionPriceEscalation(:)
         CHARACTER (LEN=1), SAVE, ALLOCATABLE :: SAVE_MRX_EXPANSION_PLAN(:)
         CHARACTER (LEN=60), SAVE, ALLOCATABLE :: LONG_TRANS_GROUP_NAME(:)
         INTEGER (KIND=2), SAVE, ALLOCATABLE :: MRX_ICAP_UNIT_LINK(:) ! 78
         CHARACTER (LEN=50), SAVE, ALLOCATABLE :: TRANS_GROUP_FULL_NAME(:)
         CHARACTER (LEN=6), SAVE, ALLOCATABLE :: TG_BASECASE_MARKET_AREA_ID(:) ! MOVED FROM READ_TRANS_GROUPS_DATA
     END MODULE TRANS_GROUP_VARIALBES
     MODULE ANNUAL_MARG_COSTS_ALLOCAT_ARRAYS
! ARRAYS IN DEALLOC_ANNUAL
      INTEGER (KIND=4), ALLOCATABLE, SAVE ::             &
              OUTAGE_BLOCK_N_DB(:,:),                    &
              OUTAGE_BLOCK_REVERSE_INDEX(:,:),           &
              COST_CURVE_POINTER_BY(:,:)                  
      INTEGER (KIND=2), ALLOCATABLE, SAVE ::             &
              OUTAGE_BLOCKS_4_DB(:)
      REAL (KIND=4), ALLOCATABLE, SAVE ::                &
              BlockIncrCost(:),                          &
              TOT_EMBED_COST_BY_POINT(:,:),              &
              CURRENT_UNIT_UTIL(:,:),                    &
              CUM_UNIT_UTIL(:,:),                        &
              CUM_UNIT_UTIL_zero(:,:),                   &
              CURRENT_UNIT_UTIL_zero(:,:)
! ARRAYS IN DEALLO_MONTH_MARG_COST_ARRAYS
      INTEGER (KIND=2), ALLOCATABLE, SAVE ::             &
              SAVE_TRANS_FOR_DATA_BASE(:),               &
              OUTAGE_UNIT_INDEX(:),                      &
              OUTAGE_BLOCK_INDEX(:),                     &
              START_UP_UNIT_BY_TG(:),                    &
              OUTAGE_DB_USED(:),                         &
              COMMITMENT_DB(:),                          &
              CURRENT(:),                                &
              NEXT(:),                                   &
              POS(:),                                    &
              NATIVE_POS(:),                             &
              LAST_DB_POINT(:),                          &
              CumDbDx(:),                                &
              NEW_POINT_COUNT(:,:),                      &
              NEW_BLOCK_NUMBER(:,:,:),                   & 
              BLOCK_B4_MARKET(:,:),                      & 
              CUM_MUST_RUN_POSITION(:),                  & 
              ACTIVE_UNIT(:),                            &
              START_UP_POSITION(:,:),                    &
              UNIT_SAVE(:),BLKNO_SAVE(:)
     LOGICAL (KIND=1), ALLOCATABLE, SAVE ::              &
              ACTIVE_DATA_BASE(:),                       &
              DETAILED_OUTAGE_DATA_BASE(:)                
     REAL (KIND=4), ALLOCATABLE, SAVE ::                 &
              LODDUR_FOR_MC(:,:),                        &
              LPROB_FOR_MC(:,:,:),                       &
              CUM_CAP(:),                                &
              DB_ADJ_TOTAL_CAP(:),                       &
              DB_CAP_AFTER_OUTAGES(:),                   &
              DB_DX(:),                                  &
              PREVIOUS_INTERVAL(:),                      &
              I_CORRECT(:),                              &
              NEW_LODDUR(:,:),                           &
              NEW_MARGINAL_DATA_BASE(:,:,:),             &
              EXPECTED_MARGINAL_COST(:,:),               &
              CUM_COST(:),                               &
              CUM_PROB(:),                               &
              NATIVE_POS_PERCENT(:),                     &
              REMAINING_CONTRIBUTION_MW(:,:),            &
              SALES_B4_AFTER(:,:,:),                     &
              WHOLESALE_REV_AND_EXP(:,:,:),              &
              WHOLESALE_SAL_AND_PUR(:,:,:),              &
              RETAIL_REV_AND_EXP(:,:,:),                 &
              RETAIL_SAL_AND_PUR(:,:,:),                 &
              CUM_SALES_AFTER(:),                        &
              CUM_INTERVAL_CAPACITY(:,:),                &
              CUM_MUST_RUN_MW(:),                        & 
              HOURLY_OUTAGE_STATE(:,:),                  &
              TRANS_BLOCK_CAPACITY(:),                   &
              SCARCITY_MULT(:,:),                        &
              CUM_TC_UNIT_MWH(:),                        &
              UNIT_DISP_COST(:,:),                       &
              OUTAGE_ENERGY(:),                          &
              UNIT_ENERGY_B4_AFTER(:,:,:),               &
              FIRST_ECONOMY_COST(:),                     &
              MW_AFTER_OUTAGES(:,:),                     &
              MW_DIFF(:,:),                              &
              MARGINAL_UNIT_BY_TECH(:,:)
     REAL (KIND=8), ALLOCATABLE, SAVE ::                 &
          SAVE_LOAD(:),                                  &
          TRANSITION_MARGINAL_COST(:,:,:),               &
          CAPACITY_GIVEN_MARKET(:,:)
! ARRAYS NOT DEALLOCATED BY ANNUAL OR MONTHLY
    INTEGER (KIND=2), ALLOCATABLE, SAVE ::             &
              TEMP_TRANSFER_ARRAY1(:),                   &
              TEMP_TRANSFER_ARRAY2(:)
     REAL (KIND=4), ALLOCATABLE, SAVE ::                 &
              OUTAGE_SINGULAR(:),                        &
              ADJUST_BLOCK(:),                           &
              DERATE_BLOCK(:),                           &
              OUTAGE_TYPE(:),                            &
              HOURLY_OUTAGE_TYPE(:,:),                   &
              HOURLY_LAST_STATE(:),                      &
              HOURLY_LAST_DERATE(:),                     &
              HOURLY_LAST_TYPE(:),                       &
              DEPTH_PRICE(:,:),                          &
              TRANS_DEPTH_PRICE(:,:,:),                  &
              BLOCK_DISP_COST(:),                        &
              OUTAGE_WHOLESALE_ENERGY(:,:),              &
              OUTAGE_WHOLESALE_REVENUE(:,:),             &
              MUST_RUN_COST(:),                          &
              TEMP_TRANSFER_ARRAY3(:)
     END MODULE ANNUAL_MARG_COSTS_ALLOCAT_ARRAYS

!
! 072119. NEW CODE FOR HOURLY LOAD SHAPE.
!
!***************************************************************
      MODULE HourlyProductsData
         CHARACTER (LEN=256), ALLOCATABLE :: HourlyProdFileNames(:)
         INTEGER (KIND=2), ALLOCATABLE :: HourlyProdRefNumber(:,:)
         REAL (KIND=4), ALLOCATABLE :: HourlyProductValue(:,:,:), &
                                       HourlyCFProductValues(:,:), &
                                       MONTHLY_HOURLY_CF(:)
         INTEGER (KIND=2), ALLOCATABLE :: HourlyProductFilePtr(:), & ! 1:NUM_TRANSACTIONS
                                          HourlyProdPtrToCFLoc(:), & ! 1:NUM_TRANSACTIONS
                                          HourlyProdPtrCFLocToProd(:)! 1:NUM_TRANSACTIONS
         INTEGER (KIND=4) :: ActiveProdFiles,NumOfHourlyCFProducts
         INTEGER (KIND=2) :: SMLoadShapeYears(31), &
                             WindLoadShapeYears(31), &
                             SolarLoadShapeYears(31), &
                             LMP_LoadShapeYears(31)
         LOGICAl (KIND=1) :: UseSMLSYears,UseWindLSYears, &
                             UseSolarLSYears, &
                             UseLMP_LSYears,UseLoadLSYears
         CHARACTER (LEN=2), ALLOCATABLE :: RefUsed(:)
         INTERFACE 
            SUBROUTINE MakingCalendarAdjustments( &
                                           Calendar_Year,FileYear, &
                                           ValuesHourlyByMonth, &
                                           ValuesByMoDa,Normalize)
               LOGICAL (KIND=4), INTENT(IN), OPTIONAL :: Normalize
               REAL (KIND=4) :: ValuesByMoDa(24,12,31), &
                                ValuesHourlyByMonth(744,12)
               INTEGER (KIND=2) :: FileYear,Calendar_Year
            END SUBROUTINE      
         END INTERFACE
      END MODULE
!***************************************************************
      FUNCTION StoreHourlyProductFiles(ProductHourlyRefName,    &
                                       ProductHourlyRefNumber,  &
                                       ScenarioLoadPattern) &
                                                         RESULT(FilePrt)   
         USE HourlyProductsData
         use end_routine, only: end_program, er_message 
         CHARACTER (LEN=5) :: ProductHourlyRefName,TempHourlyRefName
         CHARACTER (LEN=2) :: ScenarioType,ScenarioLoadPattern 
         INTEGER (KIND=2) :: ProductHourlyRefNumber,FilePrt,I,J
         CHARACTER (LEN=2) :: LOAD_FILE_CHAR_EXT
!
         CALL UPC(ProductHourlyRefName,ProductHourlyRefName)
         CALL UPC(ScenarioLoadPattern,ScenarioType)
         IF(ScenarioType == 'WI' .AND. .NOT. UseWindLSYears) ScenarioType = 'HO'
         IF(ScenarioType == 'SO' .AND. .NOT. UseSolarLSYears) ScenarioType = 'HO'
         IF(ScenarioType == 'LM' .AND. .NOT. UseLMP_LSYears) ScenarioType = 'HO'
         IF(ScenarioType == 'LO' .AND. .NOT. UseLoadLSYears) ScenarioType = 'HO'
         DO I = 1, ActiveProdFiles
            TempHourlyRefName = TRIM(HourlyProdFileNames(I))
            IF(TRIM(TempHourlyRefName) == TRIM(ProductHourlyRefName)) THEN
!            IF(INDEX(TRIM(HourlyProdFileNames(I)),TRIM(ProductHourlyRefName))/=0) THEN
               IF(ScenarioType == 'HO') THEN
                  DO J= 1,30 
                     IF(HourlyProdRefNumber(I,J) /= ProductHourlyRefNumber) EXIT
                  ENDDO
                  IF(J < 31) CYCLE
                  EXIT
               ENDIF
               IF(RefUsed(I) == ScenarioType) EXIT
            ENDIF
         ENDDO
! 060520. TEST LIMIT.
         IF(ActiveProdFiles > 31000) THEN
            WRITE(9,*) "Active hourly files exceed limit ",ActiveProdFiles
            call end_program("Active hourly files exceed limit. MF1")
         ENDIF
         IF(I > ActiveProdFiles) THEN
            ActiveProdFiles = ActiveProdFiles + 1
            HourlyProdFileNames(I)= TRIM(ProductHourlyRefName)
            HourlyProdRefNumber(I,1:31) = ProductHourlyRefNumber
            RefUsed(I) = ScenarioType
            IF(ScenarioType == 'WI') THEN   
                  HourlyProdRefNumber(I,1:31) = WindLoadShapeYears(1:31)
            ELSEIF(ScenarioType == 'SO') THEN
                  HourlyProdRefNumber(I,1:31) = SolarLoadShapeYears(1:31)
            ELSEIF(ScenarioType == 'LM') THEN
                  HourlyProdRefNumber(I,1:31) = LMP_LoadShapeYears(1:31)
            ELSEIF(ScenarioType == 'LO') THEN
                  HourlyProdRefNumber(I,1:31) = SMLoadShapeYears(1:31)
            ENDIF
            
         ENDIF  
         FilePrt = I
      END FUNCTION
!***************************************************************
      SUBROUTINE READ_HOURLY_PRODUCT_FILES(Year)
         USE ArrayAllocationInterface
         USE HourlyProductsData
         INTEGER (KIND=2) :: Files,RefYr,Yr,BASE_YEAR
         CHARACTER (LEN=256) :: FileName,SHB_FILE_DIRECTORY
         INTEGER (KIND=2) :: DA,RefDaysInMonth(12),Month,CurrentHr,  &
                             ALINE_LOAD_DATA,Hr,Year, &
                             TimeZone,Temp,DeltaTemp,Mo,  &
                             DaOfWeek,I,Day,Calendar_Year, &
                             WIND_SHAPE_NUMBER,SOLAR_SHAPE_NUMBER
         LOGICAL (KIND=4) :: FILE_EXISTS
         CHARACTER (LEN=2) :: LOAD_FILE_CHAR_EXT
         CHARACTER (LEN=8) :: EEICODE
         INTEGER (KIND=4) :: IREC
!         INTEGER (KIND=4) :: Values(24)
         REAL (KIND=4) :: Values(24),SumOfValuesFor(12), &
                          ValuesByMoDa(24,12,31), &
                          CurValuesByMoDa(24,12,31),ScaleFactor, &
                          GET_SCENARIO_WIND_SHAPE, &
                          GET_SCENARIO_SOLAR_SHAPE
! Calendar correct variable         
         LOGICAL (KIND=1) :: YES_CALANDER_CORRECT, &
                             ADJUST_FOR_LEAP_YEAR, &
                             MakeCalendarAdjustment, &
                             WIND_SHAPE_ACTIVE,SOLAR_SHAPE_ACTIVE
         INTEGER (KIND=4) :: LREC
         INTEGER (KIND=2) :: RefDay,RefMo,RefDoWk,CurDoWk, &
                             CurDaysInMonth,MON/1/,TempExtension
         IF(ActiveProdFiles <= 0) RETURN
!
! 022015.
! 072119. REMOVED FOR BRANCHABB CODE.
!
!         WIND_SHAPE_NUMBER = INT2(GET_SCENARIO_WIND_SHAPE(Year,MON)-2000)
!         IF(WIND_SHAPE_NUMBER > 0 .AND. WIND_SHAPE_NUMBER < 80) THEN
!            WIND_SHAPE_ACTIVE = .TRUE.
!         ELSE
!            WIND_SHAPE_ACTIVE = .FALSE.
!         ENDIF
!         SOLAR_SHAPE_NUMBER = INT2(GET_SCENARIO_SOLAR_SHAPE(Year,MON)-2000)
!         IF(SOLAR_SHAPE_NUMBER > 0 .AND. SOLAR_SHAPE_NUMBER < 80) THEN
!            SOLAR_SHAPE_ACTIVE = .TRUE.
!         ELSE
!            SOLAR_SHAPE_ACTIVE = .FALSE.
!         ENDIF
!
         CALL AllocateArray(HourlyProductValue,1,744,1,12,   &
                                                     1,ActiveProdFiles)   ! months,hours,files
         HourlyProductValue = 0.
         I = 1
         Calendar_Year = BASE_YEAR() + Year
         DO Files = 1, ActiveProdFiles 
            IF(WIND_SHAPE_ACTIVE .AND. RefUsed(Files) == "WI") THEN
               TempExtension = WIND_SHAPE_NUMBER
            ELSEIF(SOLAR_SHAPE_ACTIVE .AND. RefUsed(Files) == "SO") THEN
               TempExtension = SOLAR_SHAPE_NUMBER
            ELSE
               TempExtension = HourlyProdRefNumber(Files,Year)
            ENDIF
            FileName = TRIM(SHB_FILE_DIRECTORY())//"SHB"//   &
                          TRIM(HourlyProdFileNames(Files))//".S"// &
                              LOAD_FILE_CHAR_EXT(TempExtension)
            INQUIRE(FILE=FileName,EXIST=FILE_EXISTS)
            IF(FILE_EXISTS) THEN
               OPEN(UNIT=2801,FILE=FileName,RECL=118,ACCESS="DIRECT",STATUS="OLD")
!
! ASSUMES 369 RECORD CONVENTION
!     
               IREC = 2
               READ(2801,REC=IREC) Mo,Da,RefYr,EEICODE,DaOfWeek,  &
                                   TimeZone,Temp,DeltaTemp,  &
                                   Values
               MakeCalendarAdjustment = &
                     RefYr /= Calendar_Year .AND. YES_CALANDER_CORRECT()
               IF(MakeCalendarAdjustment) THEN
                  ValuesByMoDa = 0. 
               ENDIF
               DO Month = 1, 12
                  IREC = ALINE_LOAD_DATA(I,Month) 
                  RefDaysInMonth(Month) = &
                                    ALINE_LOAD_DATA(I,Month+1_2) - IREC
                  CurrentHr = 1
                  DO Day = 1, RefDaysInMonth(Month)
                     READ(2801,REC=IREC) Mo,Da,Yr,EEICODE,DaOfWeek,  &
                                         TimeZone,Temp,DeltaTemp,  &
                                         Values
                     IREC = IREC + 1
                     IF(MakeCalendarAdjustment) THEN
                        ValuesByMoDa(1:24,Month,Day) = Values(1:24)
                     ENDIF
                     HourlyProductValue( &
                               CurrentHr:CurrentHr+23,Month,Files) =  &
                                                            Values(1:24)
                     CurrentHr = CurrentHr + 24
                  ENDDO
                  SumOfValuesFor(Month) = &
                                  SUM(HourlyProductValue(:,Month,Files))
               ENDDO
               CLOSE(2801)
               IF(MakeCalendarAdjustment) THEN
                  CALL MakingCalendarAdjustments(Calendar_Year,RefYr, &
                                       HourlyProductValue(:,:,Files), &
                                       ValuesByMoDa,Normalize=.FALSE.)
               IF(.FALSE.) THEN
                  HourlyProductValue = 0.
                  ADJUST_FOR_LEAP_YEAR = &
                                      MOD(Calendar_Year-1964.,4.) < .001
                  CALL DAYWEEK(1_2,2_2,RefYr,RefDoWk)
                  CALL DAYWEEK(1_2,2_2,Calendar_Year,CurDoWk)
                  IF(RefDoWk > CurDoWk) THEN
                     RefDay = 7- (RefDoWk - CurDoWk) + 2
                  ELSE
                     RefDay = CurDoWk - RefDoWk + 2
                  ENDIF
                  RefMo = 1
                  DO Month = 1, 12
                     CurrentHr = 1
                     IF(Month == 2) THEN
                        CurDaysInMonth = 28
                        IF(ADJUST_FOR_LEAP_YEAR) CurDaysInMonth = 29
                     ELSE
                        CurDaysInMonth = RefDaysInMonth(Month)
                     ENDIF
                     DO Day = 1, CurDaysInMonth
                        IF(Month == 1 .AND. Day == 1) THEN
                           CurValuesByMoDa(1:24,1,1) = &
                                                  ValuesByMoDa(1:24,1,1)
                           HourlyProductValue(1:24,Month,Files) = &
                                               CurValuesByMoDa(1:24,1,1)
                           CurrentHr = 25
                           CYCLE
                        ENDIF
                        CurValuesByMoDa(1:24,Month,Day) = &
                                         ValuesByMoDa(1:24,RefMo,RefDay)
                        RefDay = RefDay + 1
                        IF(RefDay > RefDaysInMonth(RefMo)) THEN
                           IF(RefMo+1 > 12) THEN
                              RefMo = 12 
                              RefDay = RefDay - 7 ! need to realine Days
                           ELSE
                              RefMo = RefMo + 1
                              RefDay = 1
                           ENDIF
                        ENDIF
                        HourlyProductValue( &
                                CurrentHr:CurrentHr+23,Month,Files) =  &
                                         CurValuesByMoDa(1:24,Month,Day)
                        CurrentHr = CurrentHr + 24
                     ENDDO
                     ScaleFactor = SumOfValuesFor(Month)/ &
                            SUM(HourlyProductValue(:,Month,Files))
                                           
                     HourlyProductValue(:,Month,Files) = ScaleFactor * &
                                       HourlyProductValue(:,Month,Files)
                     ScaleFactor = &
                                  SUM(HourlyProductValue(:,Month,Files))
                  ENDDO
              ENDIF
               ENDIF ! MakeCalendarAdjustment
            ENDIF ! FILE EXISTS
         ENDDO      
         
      END SUBROUTINE
!***********************************************************************
      SUBROUTINE MakingCalendarAdjustments(Calendar_Year,FileYear, &
                                           ValuesHourlyByMonth, &
                                           ValuesByMoDa,Normalize)
!***********************************************************************
         USE HourlyProductsData
         LOGICAL (KIND=1) :: ADJUST_FOR_LEAP_YEAR
         LOGICAL (KIND=4), INTENT(IN), OPTIONAL :: Normalize
         LOGICAL (KIND=4) :: AdjustValues
         REAL (KIND=4) :: SumOfValuesFor(12),ValuesByMoDa(24,12,31), &
                          CurValuesByMoDa(24,12,31),ScaleFactor, &
                          ValuesHourlyByMonth(744,12)
         INTEGER (KIND=2) :: RefDay,RefMo,RefDoWk,CurDoWk,CurDaysInMonth
         INTEGER (KIND=2) :: FileYear,Calendar_Year, &
                             DAYS_IN_EACH_MONTH, &
                             Month,CurrentHr,Day,HrsInMo

            ADJUST_FOR_LEAP_YEAR = MOD(Calendar_Year-1964.,4.) < .001
            CALL DAYWEEK(1_2,2_2,FileYear,RefDoWk)
            CALL DAYWEEK(1_2,2_2,Calendar_Year,CurDoWk)
            IF(RefDoWk > CurDoWk) THEN
               RefDay = 7- (RefDoWk - CurDoWk) + 2
            ELSE
               RefDay = CurDoWk - RefDoWk + 2
            ENDIF
            RefMo = 1

!            WRITE(39,*) " Source Year",FileYear,"Run Year",Calendar_Year
!            WRITE(39,*)&
!                      "SourceMonth,SourceDay,CalendarMonth,CalendarDay,"
            SumOfValuesFor = 0. 
            DO Month = 1, 12
!               SumOfValuesFor(Month) = SUM(ValuesHourlyByMonth(:,Month))
               CurrentHr = 1
               IF(Month == 2) THEN
                  CurDaysInMonth = 28
                  IF(ADJUST_FOR_LEAP_YEAR) CurDaysInMonth = 29
               ELSE
                  CurDaysInMonth = DAYS_IN_EACH_MONTH(Month)
               ENDIF
               HrsInMo = 24*CurDaysInMonth
               SumOfValuesFor(Month) = &
                               SUM(ValuesHourlyByMonth(1:HrsInMo,Month))
               ValuesHourlyByMonth(:,Month) = 0.
               DO Day = 1, CurDaysInMonth
                  IF(Month == 1 .AND. Day == 1) THEN
!                     WRITE(39,*)"1 , 1 , 1 , 1 ,"
                     CurValuesByMoDa(1:24,1,1) = ValuesByMoDa(1:24,1,1)
                     ValuesHourlyByMonth(1:24,Month) = &
                                               CurValuesByMoDa(1:24,1,1)
                     CurrentHr = 25
                     CYCLE
                  ENDIF
!                  WRITE(39,*) RefMo,",",RefDay,",",Month,",",Day,","
                  CurValuesByMoDa(1:24,Month,Day) = &
                                         ValuesByMoDa(1:24,RefMo,RefDay)
                  RefDay = RefDay + 1
                  IF(RefDay > DAYS_IN_EACH_MONTH(RefMo)) THEN
                     IF(RefMo+1 > 12) THEN
                        RefMo = 12 
                        RefDay = RefDay - 7 ! need to realine Days
                     ELSE
                        RefMo = RefMo + 1
                        RefDay = 1
                     ENDIF
                  ENDIF
                  
                  ValuesHourlyByMonth(CurrentHr:CurrentHr+23,Month) =  &
                                         CurValuesByMoDa(1:24,Month,Day)
                  CurrentHr = CurrentHr + 24
               ENDDO
               AdjustValues = .TRUE.
               IF(PRESENT(Normalize)) AdjustValues = Normalize
               IF(AdjustValues) THEN
                  ScaleFactor = SumOfValuesFor(Month)/ &
                      SUM(ValuesHourlyByMonth(:,Month))
                                     
                  ValuesHourlyByMonth(:,Month) = ScaleFactor *  &
                                            ValuesHourlyByMonth(:,Month)
               ENDIF
               ScaleFactor = SUM(ValuesHourlyByMonth(:,Month))
            ENDDO
      END SUBROUTINE                        
!***************************************************************
      FUNCTION GET_HOURLY_PRODUTION_DATA( &
                     ProductPos,Month,Hour,CFactor) RESULT(Hourly_Value)
         USE HourlyProductsData
         REAL (KIND=4) :: Hourly_Value
         INTEGER (KIND=2) :: Month,Hour,FilePrt,ProductPos,CFactor
         IF(ActiveProdFiles <= 0) THEN
            Hourly_Value = 1.
         ELSEIF(CFactor > 0) THEN
            FilePrt = HourlyProdPtrToCFLoc(ProductPos)
            Hourly_Value = HourlyCFProductValues(Hour,FilePrt)
         ELSE
            FilePrt = HourlyProductFilePtr(ProductPos)
            Hourly_Value = HourlyProductValue(Hour,Month,FilePrt)   
         ENDIF         
      END FUNCTION
!***************************************************************
      FUNCTION GET_DAILY_PRODUTION_DATA( &
                              ProductPos,Day,Month,CFactor,Daily_Values)
         USE HourlyProductsData
         LOGICAL (KIND=1) GET_DAILY_PRODUTION_DATA
         REAL (KIND=4) :: Daily_Values(24)
         INTEGER (KIND=2) :: Day,Month,Hour,FilePrt, &
                             ProductPos,CFactor,HourInMonth
         HourInMonth = (Day-1)*24
         GET_DAILY_PRODUTION_DATA = .TRUE.
         IF(ActiveProdFiles <= 0) THEN
            Daily_Values = 1.
         ELSEIF(CFactor > 0) THEN
            FilePrt = HourlyProdPtrToCFLoc(ProductPos)
            DO Hour = 1, Hour + 23
               Daily_Values(Hour) = HourlyCFProductValues(Hour,FilePrt)
            ENDDO
         ELSE
            FilePrt = HourlyProductFilePtr(ProductPos)
            DO Hour = 1, 24
               Daily_Values(Hour) = &
                      HourlyProductValue(HourInMonth+Hour,Month,FilePrt)
            ENDDO
         ENDIF
      END FUNCTION
      FUNCTION ResetActiveHourlyProducts()
         USE HourlyProductsData
         INTEGER (KIND=2) :: ResetActiveHourlyProducts
         ActiveProdFiles = 0
         ResetActiveHourlyProducts = 0
      END FUNCTION

