!     ******************************************************************
!     AlanRoutines.F90
!     Copyright(c)  2000
!
!     Created: 12/8/2010 11:37:00 AM
!     Author : MARK S GERBER
!     Last change: MSG 12/8/2010 4:04:18 PM
!     ******************************************************************

c-----
      subroutine UPC(s,n)
      integer*4 n,i
      character*(*) s ! len(s) is undependable
      character*1 c
!
      do i=1,n
        c=s(i:i) ! convert ith char to upper-case
        if(('a'<=c).and.(c<='z')) s(i:i)=char(ichar(c)-32)
      end do
      end
c-----
      subroutine OpenFmFile(iUnit,iFS,iCC,iStat,
     +  MustUsePrefix,DirPrefix,FileParm)
      integer*4 iUnit,iFS,iCC,iStat
      integer*2 iCh,j
      logical*1 MustUsePrefix,StopIfAbsent
      character*255 DirPrefix,FilePath
      character*255 FileParm,FileName
      character*7
     +  FSType(0:2)/'Old','New','Replace'/, ! Replace is same as Unknown
     +  CCType(2)/'List','Fortran'/
!
      StopIfAbsent=(iStat==0) ! else caller will inspect iStat
      iStat=0 ! default valid if file is extant
      FileName=FileParm
      if(Len_Trim(FileName)<=0) then
        iStat=-1
        goto 200
      end if
      if(MustUsePrefix) goto 100
    ! look first in current dir
c     write(*,'(i3,2(1x,a))') Len_Trim(FileName),trim(FileName),FileName
      do j=255,1,-1 ! blank any control characters, since stack-var's tail ...
        iCh=iChar(FileName(j:j))
        if((32<iCh).and.(iCh<123)) exit ! accept ASCII chars on [33,122]
        FileName(j:j)=' ' ! ... from concatenation may contain garbage bytes
      end do
c     write(*,'(i5,3(i3,1x,a),a)') iUnit,Len_Trim(FileName),FileName,
c    +  iFS,FSType(iFS),iCC,CCType(iCC),' before open()'
      open(iUnit,FileName,form='formatted',status=FSType(iFS),
     +  CarriageControl=CCType(iCC),err=100)
      return
    ! look next in directory specified
  100 if(Len_Trim(DirPrefix)>0) then
        FilePath=trim(DirPrefix)//FileName
      else ! path prefix is blank
        FilePath=FileName
      end if
      open(iUnit,FilePath,form='formatted',status=FSType(iFS),
     +  CarriageControl=CCType(iCC),err=200,ioStat=iStat)
      return
  200 if(.not.StopIfAbsent) return ! with iStat/=0 implying 'file not found'
      call ps(1,'Error opening formatted file: '//FilePath)
      end ! subroutine OpenFmFile
c-----
      subroutine ps(ErrorLevel,message) ! ps is a mnemonic for Print and Stop
!     message codes per GAT on 20060926:
!       14       => user terminated (N.A. to this subroutine)
!       15 or 16 => bomb/crash/error
!       17 or 18 => successful execution
      logical*1 CurrentBatModeState,BatchMode/.false./ ! default implying 'pause to read message'
      logical*4 UnitInUse
      integer*4 ErrorLevel,iStat
      integer*2 ExitCode
      character*(*) message
!
!     opening unit 4 inside a .DLL does not make it writable outside the .DLL;
!     .EXE-caller of .DLL finds UnitInUse below false on 20040628, so the .DLL
!     must write message and flush(4) just before returning to the caller
      inquire(unit=4,opened=UnitInUse,err=100,ioStat=iStat)
      if((iStat==0).and.UnitInUse) then ! file is open
        write(4,'(1x  )',advance='yes') ! terminate prior messages
        write(4,'(1x,a)',advance='yes') message
        close(4)
      end if
  100 continue
c     pause message ! rejected by compiler
      write(*,'(1x  )',advance='yes') ! terminate prior messages
      write(*,'(1x,a)',advance='yes') message
      if(ErrorLevel/=0) then ! allow operator to read the diagnostic message
c       call WriteStrAt(25,1," Strike <Enter> to continue ...")
c       read(*,*)
        if((ErrorLevel==1).and.(.not.BatchMode)) pause ! else don't wait for operator response
        ExitCode=15 ! failure due to error
      else
        ExitCode=17 ! success
      end if
c     continue ! call cls0()
c     stop ! replaced by code adapted from ErrorMsg.for:
c     FILE_SEARCH = trim(CURRENT_DIRECTORY)//"SIMDONE"
c     OPEN(10,FILE=FILE_SEARCH)
      OPEN(10,FILE='SIMDONE') ! with default CarriageControl='list'
c     IF(MESSAGE) THEN
c        IF(WARNING_MESSAGES/=0) THEN
c           ExitCode=15
c        ELSE
c           ExitCode=16
c        ENDIF
c     ELSEIF(USER_TERMINATED) THEN
c        ExitCode=14
c     ELSE
c        IF(WARNING_MESSAGES/=0) THEN
c          ExitCode=18
c        ELSE
c          ExitCode=17
c          WRITE(10,*) '17 Exit Code'
c          CLOSE(10)
c          CALL EXIT(17)
c        ENDIF
c     ENDIF
      WRITE(10,'(i2,a)') ExitCode,' Exit Code'
      CLOSE(10)
c     if(ErrorLevel==0) return ! allow caller to return to its caller or stop
    ! above disabled 20060717 to allow the ExitCode assigned above to be useful
      CALL EXIT(ExitCode)
      return ! pro-forma; unnecessary here
c-----
      entry SetBatchMode
      BatchMode=.true. ! implying 'do not pause to read error message'
      return ! entry SetBatchMode
c-----
      entry GetBatchMode(CurrentBatModeState)
      CurrentBatModeState=BatchMode
      end ! subroutine ps
c-----
      subroutine GetArgs(ArgV,ArgC)
!     use SpinFuncLocals
      character*(*) ArgV(ArgC) ! was *16 ArgV(*), conflicted with caller
      integer*4 ArgC,nOfInt
      character*1 ABlank,AQuote
      parameter(ABlank=' ',AQuote='"')
      character*2048 CmdString
      character*1 ThisChar,PrevChar
      integer*2 j,jBat,jFirstB,jFinalB,j1stChar,jMax,LenArg,nQuoteMarks
      logical*1 InsideQuotes,BatchProcessing
!
      nOfInt=ArgC ! upper bound on number of arguments of interest to caller
c     write(*,*) nOfInt,' args expected or allocated for GetArgs'
      call GetCL(CmdString) ! converts each null-string ("") found into ABlank
c     write(*,'(i5,3a)') nOfInt,'[',trim(CmdString),']'
      jBat=index(CmdString,'/BAT')
      BatchProcessing=(jBat/=0)
c     BatchProcessing=(index(CmdString,'/BAT')/=0)
c    +  .or.          (index(CmdString,'/QUICKSILVER')/=0) ! N.A. per TS 20061201
      if(BatchProcessing) then
        call SetBatchMode()
        CmdString(jBat:jBat+3)='    ' ! needed in case nOfInt is not fully used
      end if
!
!     LF95v7p1 compresses runs of blanks to 1 between counted arguments
      ArgC=0
      nQuoteMarks=0
      ThisChar=ABlank
      jMax=len_trim(CmdString)
      do j=1,jMax
        PrevChar=ThisChar
        ThisChar=CmdString(j:j)
        if(ThisChar==AQuote) then
          nQuoteMarks=nQuoteMarks+1 ! possible with LF95v7p1
          cycle ! do not retain any AQuote characters
        end if
        InsideQuotes=(mod(nQuoteMarks,2)>0)
        if((ThisChar/=ABlank).or.InsideQuotes) then
          if(((PrevChar==ABlank).and.(.not.InsideQuotes)).or.
     +       ( PrevChar==AQuote)) then ! count another argument
c           if(ArgC>0) write(*,'(2i5," [",a,"]")') ! useful during debugging
c    +        ArgC,j,trim(ArgV(ArgC))
            if(ArgC>=nOfInt) exit ! ignore trailing parameters not of interest
            ArgC=ArgC+1 ! if only blanks delimit parameters
            ArgV(ArgC)=''
            j1stChar=j
            LenArg=0
          end if
          if(ArgC<=nOfInt) then ! test was strict inequality before 20061113
!           ArgV(ArgC)=trim(ArgV(ArgC))//ThisChar ! if embedded blanks are disallowed
            if(LenArg==0) then
              ArgV(ArgC)=ThisChar
            else
              ArgV(ArgC)=ArgV(ArgC)(1:LenArg)//ThisChar
            end if
            LenArg=LenArg+1 ! needed since embedded blanks are allowed after 20060705
        ! after 20061113, do not presume that CmdString has no extra keywords,
        ! so do not take the balance of the CmdString as a single (last) Arg
c         else ! ArgC==nOfInt
c           if(InsideQuotes.and.(CmdString(jMax:jMax))==AQuote)
c    +        jMax=jMax-1
c           ArgV(ArgC)=trim(CmdString(j1stChar:jMax))
c           exit ! with final arg containing the entire tail of CmdString
          end if
c         write(*,'(2i5,3(1x,a))') ArgC,j,ThisChar,
c    +      trim(ArgV(ArgC)),trim(CmdString)
        end if
      end do
c     write(*,'(2i5," [",a,"]")') ArgC,j,trim(ArgV(ArgC)) ! useful during debugging
      end ! subroutine GetArgs
c-----
      subroutine WriteStrAt(Row,Col,Message)
      integer*4 Row,Col,iStat
      integer*2 jF
      logical*4 UnitInUse
      character*(*) Message
!
      write(*,'(1x,a)',advance='yes') trim(Message)
      inquire(unit=4,opened=UnitInUse,err=100,ioStat=iStat)
  100 if((iStat==0).and.UnitInUse) ! file is open
     +  write(4,'(1x,a)') trim(Message)
      end
c-----
      subroutine EnumerateFields(s,jSupFoI,jOfs,OutUnit) ! useful on lines of DSF files
      character*(*) s
      character*255 Field(385) ! one more than necessary on 20060908
      character*1 DummyCh
      integer*4 i,j,jSupFoI,jOfs,OutUnit,jLimit,nTrunc
!
    ! jSupFoI is the nominal upper-limit on field-indices of interest
    ! jOfs is the number of leading fields to skip in the count
      jLimit=385 ! to force reading beyond the last field of possible interest
      do j=1,jLimit
        Field(j)='<>'
      end do
!
    ! since read(s,*) evidently counts fields before entering the implicit-do
    ! loop, we determine the feasible limit on readable fields by experimentation
      do nTrunc=0,385
        j=0
        read(s,*,err=101,end=101) (DummyCh,i=1,jOfs),
     +    (Field(j),j=1,385-nTrunc)
  101   write(OutUnit,'(3i5,a,i3.3)')jOfs,jSupFoI,j,
     +    ' Ofs,Sup,Max in Enum with #Truncated=',nTrunc
        if(j>0) exit ! with the lowest feasible nTrunc (trailing fields missing)
        if(jLimit<=0) exit
        jLimit=jLimit-1 ! j==0 above => s had too few fields, => error or EoF
      end do
!
      j=0
      read(s,*,err=102,end=102) (DummyCh,i=1,jOfs),(Field(j),j=1,jLimit)
  102 continue ! with (j) expected to be neither in error nor beyond end-of-string
c     jLimit=j-1 ! if the above loop exited with error or EoF
      write(OutUnit,'(3i5,a)')jOfs,jSupFoI,jLimit,' Ofs,Sup,Lim in Enum'
      if(jLimit>jSupFoI) jLimit=jSupFoI ! possibly < 385
      write(OutUnit,'(i4,1x,a)') (j,Field(j),j=1,jLimit)
      end
c-----
      subroutine ExpleteWithCommasUpTo(s,nFields) ! limited to nFields
      character*(*) s
      integer*2 sLen,nFields,nCommas,jInf,jCh
!
      sLen=len(s)
      nCommas=0
      do jCh=1,sLen ! count existing commas
        if(s(jCh:jCh)==',') nCommas=nCommas+1
      end do
      jInf=Len_trim(s)+1
      do jCh=jInf,sLen
        if(nCommas>=nFields) exit
        nCommas=nCommas+1
        s(jCh:jCh)=','
      end do
      end
c-----
      integer*2 function nCommaDelims(s)
      character*(*) s
      character*1 c
      integer *2 j,sLeng,nCommas,nQuotes
!
      nCommas=0
      nQuotes=0
      sLeng=Len_trim(s)
      do j=sLeng,1,-1
        c=s(j:j)
        if(c=='"') then ! count only DoubleQuotes, not Apostrophes
          nQuotes=nQuotes+1
        else if(c==',') then
          if(j==sLeng) cycle ! discount the terminating comma as a delimiter
          if(mod(nQuotes,2)==0) nCommas=nCommas+1 ! discount those within strings
        end if
      end do
      nCommaDelims=nCommas
      end
c-----
      subroutine AppendFloat9(u,rOrg) ! for use in RPTtoCSV per TS 20060227
      real*4 MaxMagR4,MinMagR4
      real*8 MaxMagR8,MinMagR8
      parameter(MaxMagR4=1.0e36,MinMagR4=1.0e-36,
     +          MaxMagR8=1.0d36,MinMagR8=1.0d-36) ! 0.38e38 was seen in test loop
!     end of parameters
      integer*4 u
      integer*2 iExpo
      integer*4 iMant
      real*4 rOrg
      real*8 r,t
!
      t=dble(rOrg)
      if(t<0.0d0) t=-10.0d0*t ! allow one more place for the minus-sign
      if(t<MinMagR8) then ! as if t were zero
c       if(rOrg<0.0d0) then
c         write(u, 6 ,advance='no') rOrg ! but no leading minus was evident in testing
c       else
          write(u, 7 ,advance='no') rOrg
c       end if
      elseif(t<0.0999995d0) then
        r=dble(rOrg) ! preclude modifying rOrg
        do iExpo=1,98 ! 4 is minimum needed to express nint(t) as iiiiE-n
          t=10.0d0*t
          r=10.0d0*r
          iMant=idnint(t)
          if((iMant>=10000).or.((iExpo>8).and.(iMant>=1000))) exit
        end do
        iMant=idnint(r)
        if(iExpo<=9) then
          write(u,12 ,advance='no') iMant,-iExpo
        else
          write(u,13 ,advance='no') iMant,-iExpo
        end if
      elseif(t<9.9999995d0) then
        write(u, 7 ,advance='no') rOrg
      elseif(t<99.999995d0) then
        write(u, 6 ,advance='no') rOrg
      elseif(t<999.99995d0) then
        write(u, 5 ,advance='no') rOrg
      elseif(t<9999.9995d0) then
        write(u, 4 ,advance='no') rOrg
      elseif(t<99999.995d0) then
        write(u, 3 ,advance='no') rOrg
      elseif(t<999999.95d0) then
        write(u, 2 ,advance='no') rOrg
      elseif(t<9999999.5d0) then
        write(u, 1 ,advance='no') rOrg
      elseif(t<=9999999.4d0) then
        write(u,10 ,advance='no') nint(rOrg)
      else
!       sacrifice significant figures in output to gain fixed field-width
        r=dble(rOrg) ! preclude modifying rOrg
      ! preclude problems with rOrg near overflow in magnitude
        if(rOrg>MaxMagR4) then
          r=MaxMagR8
          t=r
        else if(rOrg<-MaxMagR4) then
          r=-MaxMagR8
          t=-10.0d0*r
        end if
        do iExpo=1,98 ! 2 is minimum needed to express nint(t) as iiiiiEn
          t=0.1d0*t
          r=0.1d0*r
        ! preclude NDP error taking idnint of large #s
          if(t<2.147484d9) then ! idnint() can handle up to 2**31
            iMant=idnint(t)
            if(((iMant<=999999).and.(iExpo<=9)).or.(iMant<=99999)) exit
          end if
        end do
        iMant=idnint(r)
        call flush(u)
        if(iExpo<=9) then
          write(u,11 ,advance='no') iMant,iExpo
        else
          write(u,12 ,advance='no') iMant,iExpo
        end if
      end if
      return
    ! ampersand usage under F77L3 requires CarriageControl=fortran
    1 format( f9.1,',')
    2 format( f9.2,',')
    3 format( f9.3,',')
    4 format( f9.4,',')
    5 format( f9.5,',')
    6 format( f9.6,',')
    7 format( f9.7,',')
   10 format( i9,  ',')
   11 format( i6,'.E',i1,',') ! note wasteful decimal point as requested
   12 format( i5,'.E',i2,',')
   13 format( i4,'.E',i3,',')
      end ! subroutine AppendFloat9
c-----
      subroutine AppendStr(u,s) ! enclose s in double-quotes, add a trailing comma
      integer*4 u
      character*(*) s
!
      write(u,'( 4a)',advance='no') '"',trim(s),'"',","
      end

