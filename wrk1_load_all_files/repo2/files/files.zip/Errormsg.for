C     Last change: MSG 9/23/2009 2:02:46 PM
C***********************************************************************
C
C     SUBROUTINE TO PRINT ABNORMAL PROGRAM EXIT
C
C***********************************************************************
C
      SUBROUTINE ERROR_MESSAGE
      USE REALWIN
      INCLUDE 'SPINLIB.MON'
      INCLUDE 'SIZECOM.MON'
      CHARACTER*256 FILE_IN,FILE_SEARCH,CURRENT_DIRECTORY*256
      INTEGER*4 FILSIZ,IOS
      INTEGER*2 START_LINE,ISERROR
      INTEGER*2 ROW,COL
      INTEGER*4 CURRENT_SCREEN(1024)
      LOGICAL*1 MESSAGE,DEBUG_ON,NO_WARNING_WINDOW,WARNING_MESSAGES
      INTEGER*2 INVERSE_VIDEO,I
      LOGICAL*1 USER_TERMINATED
      COMMON /ERRORS/ INVERSE_VIDEO,MESSAGE,DEBUG_ON,USER_TERMINATED
      INTEGER*2 BASE_YEAR,MAX_YEARS
      CHARACTER*2  DATA_DRIVE
      COMMON /WORLD/ BASE_YEAR,MAX_YEARS
      COMMON /DATA_DRIVE_LOCATION/ DATA_DRIVE
      INTEGER*2 RETURN_DRILLING_REPORT_STATUS,VOID_INT2
      LOGICAL*1 DATA_NOT_IN_CASH_DRILLING,
     +          DATA_NOT_IN_BALANCE_DRILLING,
     +          DATA_NOT_IN_INCOME_DRILLING,
     +          DATA_NOT_IN_TAX_DRILLING,
     +          SP_CAPEX_ACTIVE
      LOGICAL*4 OPEN_LOGICAL
      CHARACTER*5 GET_SCENAME
      INTEGER*4 SIMDONE_HANDLE,NUMBER_OF_BYTES
      CHARACTER*15 EXIT_CODE
      LOGICAL*4 SIMDONE_DELETED
C
      VOID_INT2=RETURN_DRILLING_REPORT_STATUS(DATA_NOT_IN_CASH_DRILLING,
     +                                     DATA_NOT_IN_BALANCE_DRILLING,
     +                                     DATA_NOT_IN_INCOME_DRILLING,
     +                                     DATA_NOT_IN_TAX_DRILLING)
      IF(DATA_NOT_IN_TAX_DRILLING) THEN
         CALL ERASE('MSG'//TRIM(GET_SCENAME())//'.XDD')
         CALL ERASE('MSGTXDRL.RPT')
      ENDIF
      IF(DATA_NOT_IN_CASH_DRILLING) THEN
         CALL ERASE('MSG'//TRIM(GET_SCENAME())//'.CDD')
         CALL ERASE('MSGCHDRL.RPT')
      ENDIF
      IF(DATA_NOT_IN_BALANCE_DRILLING) THEN
         CALL ERASE('MSG'//TRIM(GET_SCENAME())//'.BDD')
         CALL ERASE('MSGBLDRL.RPT')
      ENDIF
      IF(DATA_NOT_IN_INCOME_DRILLING) THEN
         CALL ERASE('MSG'//TRIM(GET_SCENAME())//'.DID')
         CALL ERASE('MSGINDRL.RPT')
      ENDIF
C
      IF(MESSAGE .AND. .NOT. USER_TERMINATED) THEN
      CALL CAPTSCN(CURRENT_SCREEN)
      CALL SETATTRW(int2(4),INVERSE_VIDEO)
C      CALL GETPOS(ROW,COL)
C      IF(ROW > 11) ROW = 0
      ROW = 8
      CALL LOCATEW(4,ROW,14)
      CALL PRINTW(4,"�����������������������������������������������ͻ")
      CALL LOCATEW(4,ROW+1,14)
      CALL PRINTW(4,"�           MIDAS GOLD ended abnormally!        �")
      CALL LOCATEW(4,ROW+2,14)
      CALL PRINTW(4,"�  Press any key.  Then use Print Screen to     �")
      CALL LOCATEW(4,ROW+3,14)
      CALL PRINTW(4,"�  record the problem.  Call M.S. Gerber &      �")
      CALL LOCATEW(4,ROW+4,14)
      CALL PRINTW(4,"�  Associates at (614) 486-6711 to report it.   �")
      CALL LOCATEW(4,ROW+5,14)
      CALL PRINTW(4,"�  Once recorded, press any key to continue.    �")
      CALL LOCATEW(4,ROW+6,14)
      CALL PRINTW(4,"�����������������������������������������������ͼ")
      CALL ANYKEY
      CALL DISPSCN(CURRENT_SCREEN)
      CALL ANYKEY
      CALL LOCATEW(4,ROW+7,0)
      ENDIF
      WARNING_MESSAGES = FILSIZ(DATA_DRIVE//'MIDAS.ERR') > 10
      IF(WARNING_MESSAGES .AND. .NOT. MESSAGE .AND. .NOT.USER_TERMINATED
     +                                   .AND. NO_WARNING_WINDOW()) THEN
         START_LINE = 8
         COL = 14
         CALL SETATTRW(int2(4),INVERSE_VIDEO)
         CALL LOCATEW(4,START_LINE,COL)
         CALL PRINTW(4,"�����������������������������������������ͻ")
         CALL LOCATEW(4,START_LINE+1,COL)
         IF(DEBUG_ON) THEN
            CALL PRINTW(4,"�    Debug information was generated.     �")
         ELSE
            CALL PRINTW(4,"�    Warning messages were generated.     �")
         ENDIF
         CALL LOCATEW(4,START_LINE+2,COL)
         CALL PRINTW(4,"�    Select Warning Messages in the       �")
         CALL LOCATEW(4,START_LINE+3,COL)
         IF(DEBUG_ON) THEN
            CALL PRINTW(4,"�    Simulation sub-menu to review it.    �")
         ELSE
            CALL PRINTW(4,"�    Simulation sub-menu to review them.  �")
         ENDIF
         CALL LOCATEW(4,START_LINE+4,COL)
         CALL PRINTW(4,"�        Press any key to continue.       �")
         CALL LOCATEW(4,START_LINE+5,COL)
         CALL PRINTW(4,"�����������������������������������������ͼ")
         CALL ANYKEY
         CALL LOCATE(START_LINE+6,0)
      ENDIF
C
C ERASE OVERLAY BINARY FILES
C
C
C IN LAHEY 3.x THE ARGUMENT LIST IS AS BELOW
C      CALL CURDIR(CURRENT_DIRECTORY,DATA_DRIVE(1:1))
      CALL CURDIR(DATA_DRIVE(1:1),CURRENT_DIRECTORY)
      IF(LEN(TRIM(CURRENT_DIRECTORY)) .GT. 3) CURRENT_DIRECTORY =
     +                                    TRIM(CURRENT_DIRECTORY)//'\'
      FILE_SEARCH = TRIM(CURRENT_DIRECTORY)//"OL*.BIN"
      CALL ERASEWC(FILE_SEARCH)
C
C ERASE BASE BINARY FILES
C
      FILE_SEARCH = TRIM(CURRENT_DIRECTORY)//"BC*.BIN"
      CALL ERASEWC(FILE_SEARCH)
C
C ERASE BASE BINARY FILES
C
      CLOSE(8800,STATUS='DELETE',IOSTAT=IOS)
      FILE_SEARCH = TRIM(CURRENT_DIRECTORY)//"MSGFUAST.BIN"
      CALL ERASE(FILE_SEARCH)
      FILE_SEARCH = TRIM(CURRENT_DIRECTORY)//"SIMSTART"
      CALL ERASE(FILE_SEARCH)
      IF(SP_CAPEX_ACTIVE()) CALL EXIT(17)
!
! 052908. RE-WROTE SIMDONE WITH EXTENSION.
!
!      INQUIRE(UNIT=10,OPENED=OPEN_LOGICAL)
!      IF(OPEN_LOGICAL) CLOSE(10)
!      FILE_SEARCH = TRIM(CURRENT_DIRECTORY)//"TOMTOM.TOM"
!      CALL ERASE(FILE_SEARCH)
!      OPEN(10,FILE=FILE_SEARCH,STATUS='NEW')
!      WRITE(10,*) 'THIS WORKS'
!      CLOSE(10)
!
      INQUIRE(UNIT=10,OPENED=OPEN_LOGICAL)
      IF(OPEN_LOGICAL) CLOSE(10)
      FILE_SEARCH = TRIM(CURRENT_DIRECTORY)//"SIMDONE.LOG"
      CALL ERASE(FILE_SEARCH)
      OPEN(10,FILE=FILE_SEARCH,STATUS='NEW')
!!      CALL SLEEP(5.0)
!

!      SIMDONE_HANDLE = RW_OPEN_FILE(FILE_NAME=FILE_SEARCH, ACCESS=0)
!
!      IF (SIMDONE_HANDLE .GT. 0) THEN
!         CALL RW_CLOSE_FILE (HANDLE=SIMDONE_HANDLE)
!         SIMDONE_DELETED = DELETE_FILE(FILE=FILE_SEARCH)
!      END IF
!
      SCREEN_MESSAGES = "SIMDONE DELETED"
      CALL MG_LOCATE_WRITE(18,70,TRIM(SCREEN_MESSAGES),3,2)
      CALL RW_PROCESS_MESSAGES()
!      CALL SLEEP(5.0)

!      SIMDONE_HANDLE = RW_OPEN_FILE(FILE_NAME=FILE_SEARCH,
!     +                 ACCESS=GENERIC_WRITE,
!     +                 SHARE=FILE_SHARE_WRITE,
!     +                 CREATION=CREATE_NEW,
!     +                 ATTRIBUTES=FILE_ATTRIBUTE_NORMAL)

!      SCREEN_MESSAGES = "Simdone Opened OK"

!      IF (SIMDONE_HANDLE .EQ. 0) THEN
!          SCREEN_MESSAGES = "Simdone Not Opened"
!      ENDIF
      CALL MG_LOCATE_WRITE(18,70,TRIM(SCREEN_MESSAGES),3,2)
      CALL RW_PROCESS_MESSAGES()
!      CALL SLEEP(5.0)

      SCREEN_MESSAGES = "Writing Log File"
      CALL MG_LOCATE_WRITE(18,70,TRIM(SCREEN_MESSAGES),3,2)
      CALL RW_PROCESS_MESSAGES()
!      CALL SLEEP(5.0)


      IF(USER_TERMINATED) THEN
         WRITE(10,*) '14 Exit Code'
         CLOSE(10)
          EXIT_CODE = '14 Exit Code'
!            CALL RW_WRITE_FILE (HANDLE=SIMDONE_HANDLE,BUFFER=EXIT_CODE,
!     +                           BYTES_WRITTEN = NUMBER_OF_BYTES)
         CALL EXIT(14)
      ELSEIF(MESSAGE) THEN
         IF(WARNING_MESSAGES) THEN
           WRITE(10,*) '15 Exit Code'
           CLOSE(10)
            EXIT_CODE = "15 Exit Code"
!            CALL RW_WRITE_FILE (HANDLE=SIMDONE_HANDLE,BUFFER=EXIT_CODE,
!     +                           BYTES_WRITTEN = NUMBER_OF_BYTES)
!            CALL RW_CLOSE_FILE (HANDLE=SIMDONE_HANDLE)
            CALL EXIT(15)
         ELSE
           WRITE(10,*) '16 Exit Code'
           CLOSE(10)
            EXIT_CODE = "16 Exit Code"
!            CALL RW_WRITE_FILE (HANDLE=SIMDONE_HANDLE,BUFFER=EXIT_CODE,
!     +                           BYTES_WRITTEN = NUMBER_OF_BYTES)
!            CALL RW_CLOSE_FILE (HANDLE=SIMDONE_HANDLE)
            CALL EXIT(16)
         ENDIF
      ELSE
         IF(WARNING_MESSAGES) THEN
           WRITE(10,*) '18 Exit Code'
           CLOSE(10)
            EXIT_CODE = "18 Exit Code"
 !           CALL RW_WRITE_FILE (HANDLE=SIMDONE_HANDLE,BUFFER=EXIT_CODE,
 !    +                           BYTES_WRITTEN = NUMBER_OF_BYTES)
 !           CALL RW_CLOSE_FILE (HANDLE=SIMDONE_HANDLE)
            CALL EXIT(18)
         ELSE
           WRITE(10,'(A)') '17 Exit Code'
           CLOSE(10)
!            EXIT_CODE = "17 Exit Code"

!            CALL RW_WRITE_FILE (HANDLE=SIMDONE_HANDLE,BUFFER=EXIT_CODE,
!     +                           BYTES_WRITTEN = NUMBER_OF_BYTES)
!            CALL RW_CLOSE_FILE (HANDLE=SIMDONE_HANDLE)
!
            SCREEN_MESSAGES = "Log File is Written"
            CALL MG_LOCATE_WRITE(18,70,TRIM(SCREEN_MESSAGES),3,2)
            CALL RW_PROCESS_MESSAGES()
!            CALL SLEEP(5.0)
            CALL EXIT(17)
         ENDIF
      ENDIF
!      CALL RW_PROCESS_MESSAGES()
!      SCREEN_MESSAGES = "Log File is Written"
!      CALL MG_LOCATE_WRITE(18,70,TRIM(SCREEN_MESSAGES),3,2)
!      CALL SLEEP(5.0)
      RETURN
      END
      SUBROUTINE CRITICAL_ERROR_MSG(ERR_NUM)
      use end_routine, only: end_program, er_message
C
      INCLUDE 'SPINLIB.MON'
      INCLUDE 'SIZECOM.MON'
      CHARACTER*(*) FILE_NAME
      CHARACTER*152 ISO_ERR_MESSAGE
      INTEGER*2 ENDYR,BASE_YEAR,NBLANK
      INTEGER ERR_NUM
      INTEGER IOS
c      INTEGER*4 ESTIMATED_DISK_SPACE,DISK_SPACE
C
      SELECT CASE(ERR_NUM)
      CASE (1)
c            CALL ERROR_BOX(11,17,5,43) !  LINE,COLUMN,LENGHT,WITHD
c            CALL LOCATE(13,20)
            WRITE(4,1010) 'No study name was specified.'
      CASE (2)
c            CALL ERROR_BOX(15,7,5,43) !  LINE,COLUMN,LENGHT,WITHD
c            CALL LOCATE(16,10)
            WRITE(4,1010) 'File MSGPARM.VAL was not found.'
c            CALL LOCATE(17,10)
            WRITE(4,1010) 'Select View/Set Parameters'
c            CALL LOCATE(18,10)
            WRITE(4,1010) 'to create this file.'
c     CASE (3)
c           CALL ERROR_BOX(15,7,4,43) !  LINE,COLUMN,LENGHT,WITHD
c           CALL LOCATE(16,9)
c           WRITE(6,1010) 'Estimated disc space ',
c    +                                 ESTIMATED_DISK_SPACE(),' kbytes.'
c           CALL LOCATE(17,9)
c           WRITE(6,1010) 'exceeds available space ',
c    +                                           DISK_SPACE(),' kbytes.'
      CASE (4)
c            CALL ERROR_BOX(15,7,4,43) !  LINE,COLUMN,LENGHT,WITHD
c            CALL LOCATE(17,10)
            WRITE(4,1010) 'The MSGPARM.VAL file is empty or bad.'
      CASE (5)
c            CALL ERROR_BOX(15,2,5,76) !  LINE,COLUMN,LENGHT,WITHD
c            CALL LOCATE(17,4)
            WRITE(4,'(A,I4,A,I4)') ' Last forecast year, ',ENDYR(),
     +           ' is less than or equal to base year, ',BASE_YEAR(),'.'
c            CALL LOCATE(18,4)
            WRITE(4,'(A)') ' Last forecast year '//
     +                             'MUST be greater than the base year.'
      CASE DEFAULT
c            CALL ERROR_BOX(15,7,4,43) !  LINE,COLUMN,LENGHT,WITHD
c            CALL LOCATE(17,10)
            WRITE(4,1010) 'Unidentified critical error.'
      END SELECT
      er_message='See WARNING MESSAGES'
      call end_program(er_message)
      ENTRY CRITICAL_ERROR_MSG6(FILE_NAME)
c         CALL ERROR_BOX(15,2,3,76) !  LINE,COLUMN,LENGHT,WITHD
c         CALL LOCATE(16,4)
         WRITE(4,1010) 'Missing base case file names in file: '//
     +                                                 TRIM(FILE_NAME)
      er_message='See WARNING MESSAGES'
      call end_program(er_message)
      ENTRY CRITICAL_ERROR_MSG7
c         CALL ERROR_BOX(15,2,3,76) !  LINE,COLUMN,LENGHT,WITHD
c         CALL LOCATE(16,4)
         WRITE(4,1010) 'System forecast chosen.  '//
     +                                     'No forecast file specified.'
      er_message='See WARNING MESSAGES'
      call end_program(er_message)
      ENTRY CRITICAL_ERROR_MSG8
c         CALL ERROR_BOX(15,2,7,76) !  LINE,COLUMN,LENGHT,WITHD
c         CALL LOCATE(16,4)
         WRITE(4,1010) 'A Run Specs file for this version of MIDAS'//
     +                 ' Gold was not specified. Version'
c         CALL LOCATE(17,4)
         WRITE(4,1010) '4A2 and later has split the Run Specs and '//
     +                 'Detail Reports file of earlier'
c         CALL LOCATE(18,4)
         WRITE(4,1010) 'versions into separate files and moved other'//
     +                 ' items to the Production'
c         CALL LOCATE(19,4)
         WRITE(4,1010) 'Parameters file. Creating these new files '//
     +                 'takes 15-20 minutes.'
c         CALL LOCATE(20,4)
         WRITE(4,1010) 'Call for help when doing this. Thank you.'
c         CALL MG_LOCATE_WRITE(16,4,
c     +                    'A Run Specs file for this version of MIDAS'//
c     +                    ' Gold was not specified. Version',
c     +                    ALL_VERSIONS,0)
c         CALL MG_LOCATE_WRITE(17,4,
c     +                  '4A2 and later has split the Run Specs and '//
c     +                  'Detail Reports file of earlier',
c     +                     ALL_VERSIONS,0)
c         CALL MG_LOCATE_WRITE(18,4,
c     +                  'versions into separate files and moved other'//
c     +                  ' items to the Production',
c     +                     ALL_VERSIONS,0)
c         CALL MG_LOCATE_WRITE(19,4,
c     +                 'Parameters file. Creating these new files '//
c     +                 'takes 15-20 minutes.',
c     +                     ALL_VERSIONS,0)
c         CALL MG_LOCATE_WRITE(20,4,
c     +                  'Call for help when doing this. Thank you.',
c     +                     ALL_VERSIONS,0)
      er_message='See WARNING MESSAGES'
      call end_program(er_message)
      ENTRY CRITICAL_ERROR_FORECAST_FILE(FILE_NAME,IOS)
         CALL IOSTAT_MSG(IOS,ISO_ERR_MESSAGE)
c         CALL ERROR_BOX(14,0,8,80)
c         CALL LOCATE(16,2)
         WRITE(4,1010) 'There is a problem reading file: '//
     +                   TRIM(FILE_NAME)//'.'
c         CALL LOCATE(17,2)
         WRITE(4,'(A,I3,A)')' The run-time error code is ',MOD(IOS,246),
     +                      '.  The run-time error message is:'
c         CALL LOCATE(18,2)
         IF(NBLANK(ISO_ERR_MESSAGE) <= 76) THEN
            WRITE(4,1010) TRIM(ISO_ERR_MESSAGE)
         ELSE
            WRITE(4,1010) ISO_ERR_MESSAGE(1:76)
c            CALL LOCATE(19,2)
            WRITE(4,1010) TRIM(ISO_ERR_MESSAGE(76:))
         ENDIF
         CALL LOCATE(3,50)
c        CALL ERROR('Traceback')
         PAUSE
      er_message='See WARNING MESSAGES'
      call end_program(er_message)
c 1000 FORMAT('&',A,I8,A)
 1010 FORMAT(1X,A,I8,A)
      END
      SUBROUTINE SEE_WARNING_MESSAGES()
         CHARACTER (LEN=30) :: ERROR_MESSAGE
         CALL FLUSH(9)
         CALL FLUSH(4)
         ERROR_MESSAGE = "See Warning Messages"
         CALL ERROR(ERROR_MESSAGE)
      END SUBROUTINE

