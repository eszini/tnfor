c-----
      program CNWcalls
! program uses LP to minimize cost subject to supply/demand balance
! Author:  Alan Thielke
! 20090525 adapted from GasNetwk.fpp
!
      integer*4 nCLArgs,ZeroIfExtant
      integer*2 j
c     logical*1 B0/.false./,B1/.true./ ! ,AmortizeUE
c     integer*4 nLbvMax,nUbvMax,nLnkMax
      logical*1 LimitTypesAt2
      real*4 MaxContFr,TestFactor
      character*1 YesIfLimitTypes
      character*255 CmdLineArg(6),DirPath/' '/
      character*255 FileName,InpCsvFN(5),
c    +  'HNB2008.dat','HSB2008.dat',
c    +  'HDB2008.dat','HTB2008.dat','FTBColCt.dat'/,
     +  StudyName,PrjctName,BasFilFam
!
      open(4,'CoalNtwk.dbg',status='replace',CarriageControl='fortran') ! to satisfy ps() expectations
      continue ! (WhiteChr+DBluBkg+Brite) from SpinAttr.hdr file
      continue ! call cls0() ! clear the screen to the assigned bkg color
      call WriteStrAt(1,5,
     +  'North-America Coal Network LP')
      call WriteStrAt(2,5,'Copyright (C) 2009-2010'//
     +  ' Ventyx Energy LLC, All Rights Reserved')
      continue ! call cls4(3,0,24,79) ! clear the screen below row 2
!
      nCLArgs=6 ! # of args of interest
      call GetArgs(CmdLineArg,nCLArgs) ! from SpinFunc under LF95
c     if(nCLArgs<3) call ps(1,'too few command-line arguments')
      do j=1,nCLArgs
        call MakeUpper(CmdLineArg(j),255)
        if(trim(CmdLineArg(j))=='N.A.') CmdLineArg(j)=' '
        write(4,'(i2,3a)') j,' CLA:  [',trim(CmdLineArg(j)),']'
      end do
      if(nCLArgs<3) call ps(1,'CoalNtwk requires at least 3 CLArgs')
    ! assign defaults
      PrjctName=' '
      BasFilFam=' '
c     MaxContFr=1.0 ! default 'allow contract to comprise entire CT-supply or Plnt-demand'
      MaxContFr=0.35 ! default; 0.4 caused infeasibility
      YesIfLimitTypes='N'
      TestFactor=1.01
c     nLnkMax= 0
c     nLbvMax=-1
c     nUbvMax=-1
      StudyName=CmdLineArg(1)
      PrjctName=CmdLineArg(2)
      BasFilFam=CmdLineArg(3)
      if(nCLArgs>=4) read(CmdLineArg(4),*) MaxContFr
      if(nCLArgs>=5) read(CmdLineArg(5),*) YesIfLimitTypes
      if(nCLArgs>=6) read(CmdLineArg(6),*) TestFactor
c     if(nCLArgs>=8) read(CmdLineArg(8),*) nLnkMax
c     if(nCLArgs>=8) read(CmdLineArg(8),*) nLbvMax
c     if(nCLArgs>=9) read(CmdLineArg(9),*) nUbvMax
      LimitTypesAt2=(YesIfLimitTypes=='Y').or.(YesIfLimitTypes=='y')
!
c     FileName='MSG'//trim(StudyName)//'.BIN'
c   ! LF95 errs if double concatenation is performed within OpenFmFile() call
c     ZeroIfExtant=0
cc    call VerifyPath(ZeroIfExtant,DirPath) ! not needed if DirPath==' '
c     call OpenFmFile(DsfU,2,2,ZeroIfExtant,B1,DirPath,FileName)
c     write(DsfU,*) 'dummy-text placeholder'
c     close(DsfU) ! 20070518 GAT averred that this file is necessary
!
    ! DSF-file is expected in current ('project') directory
      FileName='DSF'//trim(PrjctName)//'.dat'
      call SetDsfParams(DirPath,FileName,BasFilFam,InpCsvFN) ! last is pro-forma
      call CoalNetworkOwner(InpCsvFN, ! owner of interface arrays
     _  StudyName,MaxContFr,TestFactor,LimitTypesAt2) ! ,nLbvMax,nUbvMax,nLnkMax)
!
c     call WriteStrAt(22,0,
c    +  'Program CoalNtwk ended; details are in CoalNtwk.dbg')
      call ps(0,'Execution of program CoalNtwk ended normally.')
      end ! program CNWcalls
c-----
      recursive subroutine SetDsfParams(
     +  DirPathParm,FileNameParm,BasFilFamParm,InpCsvFN)
      integer*2 jOsfMaxim
      parameter(jOsfMaxim=384)
!     end of parameters
!
      integer*4 ZeroIfExtant,DsfU/1/
      integer*2 j,nCommaDelims
      logical*1 FoundTgtBff,B0/.false./,B1/.true./
      character*4095 DsfLine
      character*255 DirPathParm,DirPath
      character*255 FileNameParm,FileName,
     +  BasFilFamParm,BasFilFam,NameRead,InpCsvFN(5) ! read from the DSF-file
      character*4 Suffix4Ch(5)/
     +  '.dat', ! 01 Basin data
     +  '.dat', ! 02 network Supply-Node data
     +  '.dat', ! 03 network Demand-Node data
     +  '.dat', ! 04 network Link data
     +  '.dat'/ ! 05 Contract data
      character*3 Prefix3Ch(5)/
     +  'HNB', ! 01
     +  'HSB', ! 02
     +  'HDB', ! 03
     +  'HTB', ! 04
     +  'FTB'/ ! 05
      character*1 cDummy
      save DirPath,FileName,BasFilFam ! for use by the entry
!
      DirPath=DirPathParm
      FileName=FileNameParm
      BasFilFam=BasFilFamParm
      return ! subroutine SetDsfParams
c-----
      entry GetCNWInpFNames(InpCsvFN)
!
      write(4,'(2a)') ' opening old DSF-file ',trim(FileName)
      ZeroIfExtant=-1 ! OpenFmFile caller will handle absence
      call OpenFmFile(DsfU,0,2,ZeroIfExtant,B0,DirPath,FileName)
      if(ZeroIfExtant/=0) goto 999
      FoundTgtBff=B0
      read(DsfU,'(a)',err=93,end=94) DsfLine ! skip over the header record
      do
        read(DsfU,'(a)',err=93,end=94) DsfLine
c       call ExpleteWithCommas(DsfLine) ! TS objected 20021001 to long output lines
        if(nCommaDelims(DsfLine)<jOsfMaxim) ! explete all short lines after 20050912
     +    call ExpleteWithCommasUpTo(DsfLine,jOsfMaxim) ! int2(256)) before 20060725
        read(DsfLine,*,err=93,end=94) cDummy,NameRead
        if(cDummy>='7') cycle
        call MakeUpper(NameRead,255)
        write(4,'(2(1x,a))') trim(BasFilFam),trim(NameRead)
        if(trim(NameRead)==trim(BasFilFam)) then
          FoundTgtBff=B1
          call EnumerateFields(DsfLine,362,2,4)
          read(DsfLine,*,err=93,end=94) cDummy,NameRead,
     +      (cDummy,j=  1,353),InpCsvFN(1), ! HNB is item 354
     +                         InpCsvFN(4), ! HTB is item 355
     +                         InpCsvFN(2), ! HSB is item 356
     +                         InpCsvFN(3), ! HDB is item 357
     +      (cDummy,j=358,360),InpCsvFN(5)  ! FTB is item 361
          exit
        end if
      end do ! read(DsfU) until error or EoF
   93 if(.not.FoundTgtBff) call ps(1,
     +  'Error reading text lines from DSF[project-name].dat file.')
   94 if(.not.FoundTgtBff) call ps(1,
     +  'EoF before reaching BasFilFam in DSF[project-name].dat file.')
      close(DsfU)
!
      do j=1,5
        InpCsvFN(j)=Prefix3Ch(j)//trim(InpCsvFN(j))
        InpCsvFN(j)=trim(InpCsvFN(j))//Suffix4Ch(j)
        write(4,'(i2,1x,a)') j,trim(InpCsvFN(j))
      end do
      call flush(4)
      return ! entry GetCNWInpFNames
c-----
  999 call ps(1,'Error opening file in old-mode:  '//trim(FileName))
      end ! subroutine SetDsfParams
c-----
c include "GregsRtn.fpp"
      recursive subroutine CoalNetworkOwner(InpCsvFN, ! owner of interface arrays
     _  StudyName,MaxContFr,TestFactor,LimitTypesAt2) ! ,nLbvMax,nUbvMax,nLnkMax)
      character*255 StudyName,InpCsvFN(*)
      logical*1 LimitTypesAt2
c     integer*4 nLbvMax,nUbvMax,nLnkMax
      real*4 MaxContFr,TestFactor
!
    ! declarations for interface variables and arrays
      integer*2
     +  iYr,BegYr,nNode,nLink,nBasn,nCCSegs,iFocus,
     +  NodeID  (    :),
     +  LinkID  (    :),
     +  LinkNdID(  :,:),
     +  LinkNdSN(  :,:),
     +  BasnID  (    :),
     +  BnOfNode(    :),
     +  HPntID  (    :),
     +  PnOfNode(    :)
      logical*1 Feasible,Focussed
      real*4
     +  NodeQtyLB (  :),
     +  NodeQtyUB (  :),
     +  NodeQty   (  :),
     +  fUnscNode (  :),
     +  NodePri (    :),
c    +  NodeMgC (    :),
     +  MineFunc(:,:,:),
     +  LinkChg (    :),
     +  BasnQtyLB (  :),
     +  BasnQtyUB (  :),
     +  HeatConLB (  :),
     +  HeatConUB (  :),
     +  SulphurCon(  :),
     +  SulphurCst, ! /0.10/, ! $/LbS => $200/T coefficient in objective function
     +  Sulphur_UB ! /9000.0/ ! kTon => 9MegaT annual limit on SO2 emissions
      character*27
     +  BasnName(    :),
     +  NodeName(    :)
      allocatable
     +  NodeID      ,
     +  LinkID      ,
     +  LinkNdID    ,
     +  LinkNdSN    ,
     +  BasnID      ,
     +  BnOfNode    ,
     +  HPntID      ,
     +  PnOfNode    ,
     +  NodeQtyLB   ,
     +  NodeQtyUB   ,
     +  NodeQty     ,
     +  fUnscNode   ,
     +  NodePri     ,
c    +  NodeMgC     ,
     +  MineFunc    ,
     +  LinkChg     ,
     +  BasnQtyLB   ,
     +  BasnQtyUB   ,
     +  HeatConLB   ,
     +  HeatConUB   ,
     +  SulphurCon  ,
     +  BasnName    ,
     +  NodeName
!     end of interface declarations
!
      logical*1 B0/.false./,B1/.true./
      save ! critically nNode,nLink,nCCSegs
!
      call OpenCNWOutFiles(StudyName,B1)
      call GetCNWInpFNames(InpCsvFN) ! from DSF-file read in Alan's main program
      call OpenCNWInpFiles(InpCsvFN)
      call GetBasnCount(nBasn) ! defines nBasn
      call AllocateCNWBasnArrays()
      call GetNodeCount(nNode,nBasn,nCCSegs, ! defines nNode and nCCSegs
     +  BasnID,BasnQtyLB,BasnQtyUB,BasnName)
      call AllocateCNWNodeArrays()
      call GetLinkCount(nNode,nLink,nBasn, ! deinfes nLink
     +  BasnID,BnOfNode,NodeID,HPntID,PnOfNode,
     +  NodePri,NodeQty,NodeQtyLB,NodeQtyUB,MineFunc,
     +  HeatConLB,HeatConUB,SulphurCon,fUnscNode,
     +  SulphurCst,Sulphur_UB,NodeName)
      call AllocateCNWLinkArrays()
      call ReadCNWLinkData(nNode,nLink,nBasn, ! nLnkMax,
     +  NodeID,BasnID,BnOfNode,HPntID,PnOfNode,
     +  LinkID,LinkNdID,LinkNdSN,TestFactor,
     +  NodePri,NodeQty,NodeQtyLB,NodeQtyUB,MineFunc,
     +  HeatConLB,HeatConUB,SulphurCon,fUnscNode,
     +  LinkChg,NodeName,LimitTypesAt2)
      call ReadCNWContData(MaxContFr,HPntID,PnOfNode,
     +  NodeQty,NodeQtyUB,HeatConLB)
      call CloseCNWInpFiles()
      call AllocateCNWOptimizingArrays()
      call OpenCNWOutFiles(StudyName,B0)
!
      iYr=1 ! eventually a do-loop variable
      BegYr=2008
c     call AllocateContracts(iYr,BegYr,NodeQty)
      call MinCNWCosts(iYr,BegYr,TestFactor, ! nLbvMax,nUbvMax,
     +  NodeID,BnOfNode,PnOfNode,
     +  LinkID,LinkNdID,LinkNdSN,
     +  NodeQtyLB,NodeQtyUB,
     +  NodeQty,HeatConLB,HeatConUB,SulphurCon,fUnscNode,MineFunc,
     +  BasnQtyUB,SulphurCst,Sulphur_UB,
     +  LinkChg,NodeName)
      do iFocus=1,3 ! AGT hopes that 2nd iteration is sufficient
        call SolveCNWLpUsingPcx(Feasible)
c       call CheckSolution(NodeName,NodeQty,LinkNdSN)
c       call ReleaseDbgCNWArrays() ! free memory ASAP
        call ReportCNWSolutionDetails(iYr, ! escalates cVect for Supply not Focussed
     +    BasnID,BnOfNode,NodeID,PnOfNode,LinkNdSN,iFocus,Focussed,
     +    NodeQty,NodeQtyUB,
c    +    NodePri,NodeMgC, ! perhaps of interest
     +    LinkChg,MineFunc,BasnName,NodeName)
        if(.not.Feasible) exit
        if(LimitTypesAt2.and.Focussed) exit
      end do
      call CheckSolution(NodeName,NodeQty,LinkNdSN)
!     proposed end of iYr-loop
!
      call ReleaseDbgCNWArrays() ! free memory ASAP
      call CloseCNWOutFiles()
      call ReleaseOtherCNWArrays()
      call ReleaseCNWLinkArrays()
      call ReleaseCNWNodeArrays()
      return ! recursive subroutine CoalNetworkOwner
c-----
      entry AllocateCNWBasnArrays
      allocate(BasnID(nBasn))
      allocate(BasnQtyLB(nBasn))
      allocate(BasnQtyUB(nBasn))
      allocate(BasnName(nBasn))
    ! assign default of -1, implying N.A.
      BasnID=-1
      BasnQtyLB=-1.0
      BasnQtyUB=-1.0
      return
c-----
      entry AllocateCNWNodeArrays
      allocate(BnOfNode(nNode))
      allocate(PnOfNode(nNode))
      allocate(HPntID  (nNode))
      allocate(NodeID  (nNode))
      allocate(NodeQtyLB(nNode)) ! min quantity at supply
      allocate(NodeQtyUB(nNode)) ! max quantity at supply
      allocate(NodeQty (nNode)) ! quantity demand or supply
      allocate(fUnscNode(nNode)) ! fraction of Demand not using sulphur scrubbers
      allocate(NodePri (nNode))
c     allocate(NodeMgC (nNode))
      allocate(MineFunc(nCCSegs,0:2,nNode)) ! segment x(EoS fract cap),MinedCost,DeltaX
      allocate(HeatConLB (nNode))
      allocate(HeatConUB (nNode))
      allocate(SulphurCon(nNode))
      allocate(NodeName(nNode))
    ! assign default of -1, implying N.A.
      BnOfNode=-1
      PnOfNode=-1
      HPntID=-1
      NodeID=-1
      NodeQtyLB=-1.0
      NodeQtyUB=-1.0
      fUnscNode=-1.0
      NodeQty=-1.0
      NodePri=-1.0
c     NodeMgC=-1.0
      MineFunc=-1.0
      HeatConLB=-1.0
      HeatConUB=-1.0
      SulphurCon=-1.0
      return
c-----
      entry ReleaseCNWNodeArrays
      deallocate(
     +  BasnID,BnOfNode,HPntID,PnOfNode,
     +  NodeID,NodeQtyLB,NodeQtyUB,
     +  NodeQty,fUnscNode,NodePri, ! NodeMgC,
     +  BasnQtyLB,BasnQtyUB,HeatConLB,HeatConUB,SulphurCon,MineFunc,
     +  BasnName,NodeName)
      return
c-----
      entry AllocateCNWLinkArrays
      allocate(LinkID (nLink))
      allocate(LinkNdID(0:1,nLink)) ! A-to-B IDs
      allocate(LinkNdSN(0:1,nLink)) ! A-to-B IDs' serial numbers (contiguous)
      allocate(LinkChg(nLink)) ! A-to-B commodity charge at 100%
    ! assign default of -1, implying N.A.
      LinkID=-1
      LinkNdID=-1
      LinkNdSN=-1
      LinkChg=-1.0
      return
c-----
      entry ReleaseCNWLinkArrays
      deallocate(LinkID,LinkNdID,LinkNdSN,LinkChg)
      return
!
      end ! subroutine CoalNetworkOwner
c-----
      character*4 function R4toA4(r)
      real*4 r,t
      logical*1 FixedForm,IntegerForm
      character*4 Str4 ! 12345678
      character*8 Str8 ! S0.mEsnn
      character*5 Str5 ! 0.123
!
      FixedForm=.false.
      IntegerForm=.false.
      t=abs(r)
c     if((0.01051<=t).and.(t<=9.9949)) then
c     if((0.01051<=mod(t,1.0)).and.(t<=9.9949)) then
      if((0.00095<=mod(r,1.0)).and.(t<=9.9949)) then
        if(t>0.999499) then
          if(r>0.0) then
            write(Str4,'(f4.2)') r
          else
            write(Str4,'(f4.1)') r
          end if
        else ! delete the leading '0'
          if(r>0.0) then
            write(Str5,'(f5.3)') r
            Str4=Str5(2:5)
          else
            write(Str5,'(f5.2)') r
            Str4='-'//Str5(3:5)
          end if
        end if
        FixedForm=.true.
      elseif((t==0.0).or.(t>=0.95)) then ! exponent sign s is positive (hence redundant)
        if(r<0) t=10.0*t ! allow room for the leading sign
        if(t<=9999.49) then ! nint(r) is no more than 4 chars
          write(Str4,'(i4)') nint(r)
          IntegerForm=.true.
        end if
      end if
      if(.not.(FixedForm.or.IntegerForm)) then ! t is small, or nint(r) is 0 or large
        write(Str8,'(e8.1)') r*0.1 ! to account for skipping the leading '0.'
        if(Str8(7:7)/='0') then ! exponent has 2 NZ digits => t is very large or small
          Str4=Str8(4:5)//Str8(7:8) ! mEnn
          if(Str8(6:6)=='-') Str4(2:2)='n' ! to signify 'E-'
          if(r<0.0) Str4(1:1)='-' ! overwrite m to show the number is negative
        else ! exponent has at most 1 NZ digit
          Str4=Str8(5:5)//Str8(8:8) ! En
          if(Str8(6:6)=='-') Str4(1:1)='n' ! to signify 'E-'
          Str4=Str8(4:4)//Str4 ! prefix the mantissa digit m
          Str4=Str8(1:1)//Str4 ! prefix the sign char S
        end if
      end if
      R4toA4=Str4
      end ! function R4toA4
c-----
      subroutine AppendFixed9(u,r) ! suitable for percentages through 100.0
      integer*4 u
      real*4 r
      if(r<0.0) then ! display negative arg as if zero, but signed
        write(u,'( a9,",")',advance='no') ' -0      '
      elseif(r==0.0) then ! display arg as zero
        write(u,'( a9,",")',advance='no') '  0      '
      elseif(r<=999.95) then
        write(u,'( f9.5,",")',advance='no') r
      else
        write(u,'( f9.4,",")',advance='no') r
      end if
      end
c-----
      subroutine AppendInt9(u,r)
      integer*4 u,i
      real*4 r
!
    ! preclude field-width (and integer*4) overflow
      if    (r<-998998.4e3) then
        i=-998998998
      elseif(r> 998998.4e3) then
        i= 998998998
      else
        i=nint(r)
      end if
      write(u,'( i9,",")',advance='no') i
      end
c-----
      subroutine AppendI2w5(u,i) ! adapted from AppendInt5()
      integer*4 u
      integer*2 i
!
      if(    i<10) then
        write(u,'( i1,",")',advance='no') i
      elseif(i<100) then
        write(u,'( i2,",")',advance='no') i
      elseif(i<1000) then
        write(u,'( i3,",")',advance='no') i
      elseif(i<10000) then
        write(u,'( i4,",")',advance='no') i
      else ! i<=32767 by assumption [else these format codes may be extended]
        write(u,'( i5,",")',advance='no') i
      end if
    ! ampersand usage under F77L3 requires CarriageControl=fortran
      return
      end ! subroutine AppendI2w5
c-----
      subroutine AppendF9p3(u,r) ! suitable only for limited-range r
      integer*4 u
      real*4 r
      character*9 s9
!
      if(abs(r)<0.0005) then ! use a minimal-noise placeholder
        s9='     .0  '
      else
        write(s9,'(f9.3)') r
      end if
      write(u,'( a9,",")',advance='no') s9
      end
c-----
      subroutine AppendF8p2(u,r,DLB) ! suitable only for limited-range r
      integer*4 u
      logical*1 DLB ! DeleteLeadingBlanks
      real*4 r
      character*8 s8
!
      if(DLB) then
        write(s8,'(f8.2)') r
        do while(s8(1:1)==' ')
          s8=s8(2:8)
        end do
        if(s8(1:1)=='*') then ! use more width to preclude overflow
          call AppendFloat9(u,r)
        else
          write(u,'(    a,",")',advance='no') trim(s8)
        end if
      else
        write(u,'( f8.2,",")',advance='no') r
      end if
      end
c-----
      subroutine AssignR4Array(n,Sour,Dest)
      integer*2 n,i
      real*4 Sour(*),Dest(*)
!
      Dest(1:n)=Sour(1:n)
      end
c-----
      subroutine SkipLines(u,n)
      integer*4 u
      integer*2 n,i
!
      do i=1,n
        read(u,*,err=100,end=100)
      end do
  100 continue
      end
c-----
c     real*4 function SupValue(n,a)
c   ! returns the largest algebraic value in array a
c     integer*2 n,i
c     real*4 aSup,a(*)
!
c     aSup=-1.0e32
c     do i=1,n
c       if(aSup<a(i)) aSup=a(i)
c     end do
c     SupValue=aSup
c     end
c-----
      integer*2 function IndexIn(i2Array,n,ThisItem)
      integer*2 n,ThisItem,i,i2Array(n)
!
      do i=1,n
c       write(4,'(4i6,a)') i,n,i2Array(i),ThisItem,' II'
        if(i2Array(i)==ThisItem) exit
      end do
c     if(i>n) call ps(1,'specified index not found on list (IndexIn)')
    ! caller must decide how to handle the case of index not found
      IndexIn=i
      end
c-----
      real*4 function FuncCNWAMtx(j,i)
      integer*4 j,i
      real*4 r4
!
      call ReturnCNWAMtx(j,i,r4)
      FuncCNWAMtx=r4
      end
c-----
      logical*1 function Negat(c)
      character*1 c
!
      if ((c/='T').and.(c/='Y')) then
        Negat=.true.
      else
        Negat=.false.
      end if
      end
c-----
      subroutine SortByAscendingKey(nItems,MajorKey,MinorKey,Val)
!     sorts nItems items of Val array per ascending order of Key arrays,
!     where the result is to vary most rapidly by MajorKey, then by MinorKey
      integer*4 nItems,i,j,k,Gap,MajorKey(*),MinorKey(*),iHold,iHalf
      integer*8 jFull,kFull,FullKey,ShiftFactor/1000000000/ ! <1073741824=2**30
      real*4 Val(*),rHold
      FullKey(iHalf)=MinorKey(iHalf)*ShiftFactor+MajorKey(iHalf)
    ! FullKey could also be cast as real*8
!
      Gap=nItems/2
      do while(Gap>0)
        do i=Gap+1,nItems
          j=i-Gap
          do while(j>0)
            k=j+Gap
c           write(4,'(9i9,a)') nItems,Gap,i,j,k,
c    +        MinorKey(j),MajorKey(j),MinorKey(k),MajorKey(k),' SBAKbef'
c           jFull=FullKey(j)
c           kFull=FullKey(k)
c           if(jFull<=kFull) then
            if(FullKey(j)<=FullKey(k)) then
              j=0 ! break the while loop (assign j=-1 for 0-based arrays)
            else ! interchange pairs within ~Key vectors, and within Val
              iHold=MajorKey(j)
              MajorKey(j)=MajorKey(k)
              MajorKey(k)=iHold
              iHold=MinorKey(j)
              MinorKey(j)=MinorKey(k)
              MinorKey(k)=iHold
              rHold=Val(j)
              Val(j)=Val(k)
              Val(k)=rHold
c           write(4,'(9i9,a)') nItems,Gap,i,j,k,
c    +        MinorKey(j),MajorKey(j),MinorKey(k),MajorKey(k),' SBAKaft'
            end if
            j=j-Gap
          end do
        end do
        Gap=Gap/2
      end do
      end ! subroutine SortByAscendingKey
c-----
      real*8 function DotProd8(x,y,n)
      integer*4 n,i
      real*4 x(n),y(n)
      real*8 xySum
!
      xySum=0.0d0
      do i=1,n
        xySum=xySum+x(i)*y(i)
      end do
      DotProd8=xySum
      end
c-----
      character*1 function QuestionIf(p)
      logical p
      if(p) then
        QuestionIf='?'
      else
        QuestionIf=' '
      end if
      end
c-----
      character*1 function AsteriskIf(j) ! useful in crude bar-graphs
      integer*2 j
      if(j>0) then
        AsteriskIf='*'
      else
        AsteriskIf='|'
      end if
      end
c-----
      subroutine DeleteUS(s,n) ! delete underscores; adapted from MakeUpper()
      integer*4 m,n,i
      character*(*) s ! len(s) is undependable
!
      m=n ! avoid attempt to change n, which may be a constant
      do i=n,1,-1 ! delete ith char if previously '_'
        if(s(i:i)=='_') then
          if(i>=m) then
            m=m-1
            s=s(1:m)
          else
            s=s(1:i-1)//s(i+1:m)
          end if
        end if
      end do
      end
c-----
      integer*2 function MilliFrac(x,y) ! assumes 0<=x<=y
      real*4 x,y
      if((y<0.001).or.(y<x)) then
        MilliFrac=0
      elseif(x>=y) then
        Millifrac=1000
      else
        MilliFrac=nint(1000.0*x/y)
      end if
      end
c-----
      logical*1 function CharIsNumeric(c)
      character*1 c
      CharIsNumeric=(('0'<=c).and.(c<='9')).or.
     +  (c=='.').or.
     +  (c=='+').or.
     +  (c=='-')
      end
c-----
c-----
cdefine contrived 1
    ! this version assumes that units can be aggregated by plant
!note:  NumSegs herein limits # of mine-cost curve segments to be used;
!reduce NumSegs to at least 1 to reduce size of constraint matrix;
!note:  nSegsIn is the # of curve segments that must be read from input file
cdefine NumSegs 2  during debugging
! MaxUperP limits the # of units per plant to (that-1), mPlnt to 32k/(that)
      recursive subroutine CoalNtwkMain(LimitTypesAt2,iYr,BegYr,
     +  nNode,nLink,nBasn,nCCSegs, ! nLbvMax,nUbvMax,nLnkMax,
     +  NodeID,
     +  LinkID,LinkNdID,LinkNdSN,BasnID,BnOfNode,HPntID,PnOfNode,
     +  NodeQtyLB,NodeQtyUB,NodeQty,fUnscNode,
     +  NodePri, ! NodeMgC,
     +  SulphurCst,Sulphur_UB,MaxContFr,
     +  MineFunc,BasnQtyLB,BasnQtyUB,
     +  HeatConLB,HeatConUB,SulphurCon,LinkChg,
     +  StudyName,BasnName,NodeName,InpCsvFN)
!
    ! declarations for interface variables and arrays
      logical*1 LimitTypesAt2,Focussed
c     integer*4 nLbvMax,nUbvMax,nLnkMax
      integer*2 iYr,BegYr,
     +  nNode,nBasn,nLink,nCCSegs,iFocus,
     +  NodeID  (    *),
     +  LinkID  (    *),
     +  LinkNdID(0:1,*),
     +  LinkNdSN(0:1,*),
     +  BasnID  (    *),
     +  BnOfNode(    *),
     +  HPntID  (    *),
     +  PnOfNode(    *)
      real*4 SulphurCst,Sulphur_UB,MaxContFr,TestFactor,
     +  NodeQtyLB (  *),
     +  NodeQtyUB (  *),
     +  NodeQty   (  *),
     +  fUnscNode(   *),
     +  NodePri (    *),
c    +  NodeMgC (    *),
     +  LinkChg (    *),
     +  MineFunc(17,0:2,*),
     +  BasnQtyLB (  *),
     +  BasnQtyUB (  *),
     +  HeatConLB (  *),
     +  HeatConUB (  *),
     +  SulphurCon(  *)
      character*255 StudyName
      character*27
     +  BasnName(    *),
     +  NodeName(    *)
!
    ! declarations for internal variables and arrays
      character*511 OneLine
      character*255 DirPath/' '/
      character*255 FileName,InpCsvFN(*)
      character*28 ReqDesc(:)
      character*27 ThisNdName,CoalName(:),VarDesc(:)
c     character*25 SDAccums/' Supply & Demand accums, '/
      character*9 BaseFileName
      character*4 bVa4,R4toA4,A4Equiv(:),OutSuffix/'.out'/
      character*1 cDummy,FirstCh,AComma/','/,AHyphen/'-'/,
     +  AlarmCh,RelChar(0:2)/'=','<','>'/,QuestionIf,AsteriskIf
      logical*1 B0/.false./,B1/.true./, ! MinimizingObj/.true./,
     +  nTypesLtd,OpenDbgU,nzDivisor,
     +  Negat, ! HeaderAbsent,
     +  Optimal, ! InTolerance,OrigBounds,
     +  OnTgtCol,OnTgtRow
      integer*1 ReVec(:),LinkFrTo(:,:),PossFrTo(:,:),ContFrTo(:,:)
    ! note that mNode,mLink,nVpLk,nVpDn,nRpLk,nRpDn,nContMax,nContLoB,mBasn,mPlnt are saved local vars unknown to
      integer*2 i,j,k,m,cYr,jSeg,nNzSegs,iInpCsv,nWd,nNSP,
     +  iNode,jNode,mNode,iSNod,nSNod,iDNod,nDNod,iNodeP1,nNodeM1,
     +  iLink,jLink,mLink,nVpLk,nVpDn,nRpLk,nRpDn,
     +  mRank1st,mRank2nd,iSNrank1,iSNrank2,
     +  nContMax,nContLoB,
     +  mPlnt1SN,mPlnt2SN,
     +  iBasn,mBasn,iBnUB,
     +  iPlnt,mPlnt,HiPlntID,HiUnitID,mPlntMax,pHPlntID,piSNod,
     +  nNzQty,nInB2LogQty(0:15),
     +  PrtDetail,iSc/1/,PriID,SecID,i2_0/0/,
     +  nCTGeqSThr,jBin,QuintBinCount(0:5),DecimBinCount(0:10),
     +  PctBinCount(0:100),DnOfPlnt(:),AvailSN(:),
     +  IndexIn,MilliFrac ! ,CI_index,LengNB
      integer*4 i4,j1st,j2nd,jPos,jNeg,
     +  ZeroIfExtant,GcPlntID,GPntID(:),
     +  InpU,InpCsvU(:),
     +  DbgU/4/,TxtU/8/,
     +  BnvU/9005/,MnvU/9006/,MdcU/9007/,AdcU/9008/,CtvU/9009/,
     +  OutU,OrgCentiSec,EndCentiSec,ExecET,
     +  mReq,iReq,nVar,nNdVar,jVar,iCol,jCol,iRqkTn,iRqfBt,
     +  iUbV,nUbV,jUbVec(:),
     +  iLbV,nLbV,jLbVec(:), ! okay to pass allocatables even if never allocated
      ! use the PCX default to MINimize its objective
     +  MinObj/1/,WrtDetail/5/, ! nLZ,
     +  zbColOfNze(:),zbRowOfNze(:),zbColHold(:),zbRowHold(:),
     +  ConsMtSize,ConsMtSLim,iNze,
     +  OneBasedCol,OneBasedRow,zbCol,zbRow,
c    +  IndexGap,GlbIndex,LubIndex,MidIndex,
     +  PCX_ret_code,PCX_main
      real*8 OFV,SO2Penalty,ContraCost,ContraValu,DotProd8,nCTObjBias
      real*4 f4Prev,f4,h4,r4,
     +  QtySum,CstSum,SumSupplyMax,SumDemandGBt,
     +  SupDmndQty, ! SupContQty,
     +  SNodACst,SNodMCst,DNodACst,DNodMCst,WtdCost(0:4), ! SimAvgPri,SupSourMC,
     +  MeanQty,EstMeanQty,VnceQty,StDvQty,
     +  MeanLog,EstMeanLog,VnceLog,StDvLog,LogQty,
c    +  SpAlloQty,SpAlloCst,
     +  ThisQtySeg(17),
     +  ThisPriSeg(17),
     +  qInYr(LimnYr),pInYr(LimnYr),
     +  FullSignif,
     +  ContQty(:,:,:),ContCst(:,:,:),fPlntUnit(:),kTpFB(:),kTpMB(:),
     +  ShCst(:),InfDvdCst(:),SupDvdCst(:),
     +  UbValu(:),LbValu(:), ! okay to pass even if never allocated
     +  cVOrg(:),cVect(:),bVect(:),xVect(:),ConsMtxNze(:),ConsEHold(:),
     +  MineMCst(:),MineACst(:),MineCost(:),TransCst(:),TransQty(:),
     +  StatsQty(:),LkQtyAtN(:),BasinQty(:),PlntQty(:),fUnscPlnt(:),
c    +  NodeSrcQty(:,:),NodeSrcCst(:,:),
     +  FuncCNWAMtx,ACMvalue,RCMvalue ! ,ioReal
c    +  ,xVsm(:),AMat(:,:) ! useful only with SMsolver
      allocatable CoalName,VarDesc,ReqDesc,A4Equiv,InpCsvU,
     +  cVOrg,cVect,bVect,xVect,ReVec,LinkFrTo,PossFrTo,ContFrTo,
     +  jUbVec,UbValu,
     +  jLbVec,LbValu,ConsMtxNze,ConsEHold,
     +  zbColOfNze,zbRowOfNze,zbColHold,zbRowHold,DnOfPlnt,AvailSN,
     +  GPntID,ContQty,ContCst,fPlntUnit,kTpFB,kTpMB,
     +  ShCst,InfDvdCst,SupDvdCst,
     +  MineMCst,MineACst,MineCost,TransCst,TransQty,
     +  StatsQty,LkQtyAtN,BasinQty,PlntQty,fUnscPlnt
c    +  ,NodeSrcQty,NodeSrcCst
c    +  ,xVsm,AMat
      save InpU,InpCsvU,nTypesLtd,OutU,OneLine, ! OrigBounds,
c    +  iSc,DbgU,TxtU,BnvU,MnvU,MdcU,AdcU, ! probably redundant
     +  OrgCentiSec,EndCentiSec,ExecET,
     +  iReq,mReq,jVar,nVar,nNdVar,
     +  iUbV,nUbV,iLbV,nLbV,cYr,
     +  PrtDetail,WrtDetail,
     +  mBasn,mNode,iSNod,nSNod,nDNod,iNode,
     +  iLink,jLink,mLink,nVpLk,nVpDn,nRpLk,nRpDn,
     +  nContMax,nContLoB,
     +  mPlnt,mPlnt1SN,mPlnt2SN,iBnUB,
     +  DnOfPlnt,AvailSN,
     +  ThisNdName,ReVec,LinkFrTo,PossFrTo,ContFrTo,
     +  cVOrg,cVect,bVect,xVect,CoalName,VarDesc,ReqDesc,A4Equiv,
     +  jUbVec,UbValu,
     +  jLbVec,LbValu,ConsMtxNze,
     +  zbColOfNze,zbRowOfNze,
     +  ConsMtSize,ConsMtSLim,
     +  FullSignif,
     +  GPntID,ContQty,ContCst,fPlntUnit,kTpFB,kTpMB,
     +  ShCst,InfDvdCst,SupDvdCst,
     +  MineMCst,MineACst,MineCost,TransCst,TransQty,
     +  StatsQty,LkQtyAtN,BasinQty,PlntQty,fUnscPlnt,
     +  OFV,SO2Penalty,ContraCost,ContraValu,nCTObjBias
c    +  NodeSrcQty,NodeSrcCst
!
      return ! recursive subroutine CoalNtwkMain (declarations only)
c-----
      entry GetLinkCount(nNode,nLink,nBasn,
     +  BasnID,BnOfNode,NodeID,HPntID,PnOfNode,
     +  NodePri,NodeQty,NodeQtyLB,NodeQtyUB,MineFunc,
     +  HeatConLB,HeatConUB,SulphurCon,fUnscNode,
     +  SulphurCst,Sulphur_UB,NodeName)
      allocate(CoalName(nSNod)) ! this array is local, not useful to caller
      InpU=InpCsvU(2) ! Supply-node data
      rewind(InpU)
      iNode=0
      do
        read(InpU,'(a)',err=416,end=416) OneLine
        write(DbgU,'(i4,1x,a)') InpU,trim(OneLine)
        read(OneLine,*,err=416,end=416) FirstCh,ThisNdName,cDummy
        if((FirstCh/='1').or.Negat(cDummy)) cycle
        read(OneLine,*,err=416,end=416) FirstCh,ThisNdName,cDummy,j
        k=IndexIn(BasnID,nBasn,j)
        if(k>nBasn) cycle ! inactive/disabled
        iNode=iNode+1
        if(iNode>nNode) call ps(1,'excessive iNode')
        NodeName(iNode)=ThisNdName
c     ! input list valid while using contrived data:
c       read(OneLine,*,err=416,end=416) FirstCh,ThisNdName,cDummy,j,
c    +    NodeID(iNode),NodePri(iNode),HeatConLB(iNode), ! avg. heat spec.
c    +    SulphurCon(iNode),NodeQtyLB(iNode),NodeQtyUB(iNode)
        read(OneLine,*,err=416,end=416) FirstCh,ThisNdName,cDummy,j,
     +    NodeID(iNode),HeatConLB(iNode),SulphurCon(iNode), ! Btu/Lb,LbS/MBtu
     +    cDummy, ! skip SGbi (Carbon pollutants in LbC/MBtu)
     +    cDummy, ! skip SQbi2008 (historic production Qty in kT)
     +    NodeQtyLB(iNode),NodeQtyUB(iNode), ! in kT
     +    nNzSegs,ThisQtySeg,ThisPriSeg ! in kT and $/T
      ! skip non-extreme points while debugging
        if(nNzSegs>17) then
          ThisQtySeg(17)=ThisQtySeg(nNzSegs)
          ThisPriSeg(17)=ThisPriSeg(nNzSegs)
          nNzSegs=17
        end if
        call MakeUpper(ThisNdName,27)
        call DeleteUS (ThisNdName,27)
        CoalName(iNode)=ThisNdName ! now UPPERCASE and without underscores
        NodeID(iNode)=NodeID(iNode)+j*100 ! merge CoalType in NodeID with BasnID in j
c       HPntID(mPlnt)=-1 ! N.A. until mPlnt>0
c       PnOfNode(iNode)=-1 ! N.A.
        BnOfNode(iNode)=k ! IndexIn(BasnID,nBasn,j) ! contiguous SN on [1,nBasn]
c       NodeQty(iNode)=-1.0 ! kT TBD by the LP, initialized after allocation
        HeatConUB(iNode)=HeatConLB(iNode) ! Btu/Lb; model allows no variance here
c       fUnscNode(iNode)=-1.0 ! N.A.
!
c     ! assignments valid while using contrived data with nNzSegs=1:
c       MineFunc(1,0,iNode)=1.0 ! fraction of NodeQtyUB(iNode)
c       MineFunc(1,1,iNode)=NodePri(iNode) ! $/T
c       MineFunc(1,2,iNode)=1.0 ! change across segment in (,0,)
        r4=ThisQtySeg(nNzSegs) ! highest rate of production envisioned
        NodePri(iNode)=ThisPriSeg(nNzSegs) ! highest price (at the highest rate of prod.)
        if(NodeQtyUB(iNode)>r4) NodeQtyUB(iNode)=r4 ! lest cost be undefined
        f4Prev=0.0
        do jSeg=1,17
          if(jSeg<=nNzSegs) then
            f4=ThisQtySeg(jSeg)/r4 ! fraction of max
            MineFunc(jSeg,0,iNode)=f4 ! fraction of max
            MineFunc(jSeg,1,iNode)=ThisPriSeg(jSeg) ! $/T
            MineFunc(jSeg,2,iNode)=f4-f4Prev ! fractional change across segment in (,0,)
            f4Prev=f4 ! =1.0 at jSeg==nNzSegs
          else ! the curve saturates at nNzSegs
            MineFunc(jSeg,0,iNode)=
     +      MineFunc(jSeg-1,0,iNode)+0.01 ! useful in detecting Out-of-Bounds
            MineFunc(jSeg,1,iNode)=NodePri(iNode) ! $/T; consider escalating
     +     *MineFunc(jSeg,0,iNode) ! escalate price to retain ordered use
            MineFunc(jSeg,2,iNode)=0.01 ! preclude 0-valued UbValu
          end if
        end do
        write(DbgU,'(i5,2i5,1x,a15,6f12.2,i3,17f5.2,17f5.0)') iNode,
     +    BnOfNode(iNode),
     +    NodeID(iNode),
     +    ThisNdName,
c    +    NodeQty(iNode),
     +    NodeQtyLB(iNode),
     +    NodeQtyUB(iNode),
     +    NodePri(iNode),
     +    HeatConLB(iNode),
     +    HeatConUB(iNode),
     +    SulphurCon(iNode),nNzSegs,
     +    (MineFunc(jSeg,0,iNode),jSeg=1,17),
     +    (MineFunc(jSeg,1,iNode),jSeg=1,17)
      end do
  416 write(DbgU,'(i4," EoF"/)') InpU
!
!
      InpU=InpCsvU(3) ! Demand-node data
      rewind(InpU)
      mPlntMax=32767/25
      mPlnt=0
      allocate(GPntID(mPlntMax)) ! should be less wasteful than (nDNod)
      do
        read(InpU,'(a)',err=417,end=417) OneLine
        write(DbgU,'(i4,1x,a)') InpU,trim(OneLine)
        read(OneLine,*,err=417,end=417) FirstCh,ThisNdName,cDummy
        if((FirstCh/='1').or.Negat(cDummy)) cycle
        iNode=iNode+1
        if(iNode>nNode) call ps(1,'excessive iNode')
        NodeName(iNode)=ThisNdName
c     ! input list valid while using contrived data:
c       read(OneLine,*,err=417,end=417) FirstCh,ThisNdName,cDummy,
c    +    NodeID(iNode),HeatConLB(iNode),HeatConUB(iNode),
c    +    NodeQty(iNode), ! i.e., MegaBtu quantity demanded this year
c    +    fUnscNode(iNode)
        read(OneLine,*,err=417,end=417) FirstCh,ThisNdName,
     +    (cDummy,j=1,2), ! skip Active,Unit
     +    GcPlntID,cDummy, ! skip Unit_ID
     +    HiPlntID,HiUnitID,HeatConLB(iNode),HeatConUB(iNode), ! (Btu/Lb)
     +    NodeQty(iNode), ! MegaBtu quantity demanded this year
     +    fUnscNode(iNode)
c       if(UserMult>0.0) NodeQty(iNode)=NodeQty(iNode)*UserMult ! to allow feasibility
        if((HiPlntID==0).and.(HiUnitID==0)) then
          SulphurCst=fUnscNode(iNode) ! ($/LbS) in objective, not in fuel-cost
          Sulphur_UB=NodeQty(iNode) ! (kT)
          write(DbgU,'(i5,f12.3,f9.1,a)') iNode,SulphurCst,Sulphur_UB,
     +      ' SO2 emission cost/Lb and limiit/kTon'
          iNode=iNode-1 ! implies this record cannot be last, else iNode>nNode
          cycle
        end if
        if(HiUnitID>=25) call ps(1,'Demand-node HiUnitID>limit')
        NodeID(iNode)=HiUnitID+HiPlntID*25 ! code HPntID as MS, HiUnitID as LS
        iPlnt=IndexIn(HPntID,mPlnt,HiPlntID) ! contiguous SN on [1,mPlnt]
        if(iPlnt>mPlnt) then ! log the instance of an unprecedented HPntID
          mPlnt=mPlnt+1 ! mPlnt<=nDNod<nNode
          if(mPlnt>mPlntMax) call ps(1,'# of plants exceeds limit')
          GPntID(mPlnt)=GcPlntID ! generic plant ID
          HPntID(mPlnt)=HiPlntID ! exclusive of the HiUnitID in NodeID above
          iPlnt=mPlnt
          write(DbgU,'(i5,2a)') mPlnt,' [unprec. plant] ',ThisNdName
        end if
        PnOfNode(iNode)=iPlnt
c       BnOfNode(iNode)=-1 ! => N.A.
c       NodeQtyLB(iNode)=-1.0 ! N.A.
c       NodeQtyUB(iNode)=-1.0 ! N.A.
c       NodePri(iNode)=-1.0 ! TBD after running the LP
c       SulphurCon(iNode)=-1.0 ! N.A.
        write(DbgU,'(i5,3i6,1x,a15,f12.2,3f9.1)') iNode,
c    +    BnOfNode(iNode),
     +    PnOfNode(iNode),
     +    HPntID(iPlnt),
     +    NodeID(iNode),
     +    ThisNdName,
     +    NodeQty(iNode),
c    +    NodeQtyLB(iNode),
c    +    NodeQtyUB(iNode),
c    +    NodePri(iNode),
     +    HeatConLB(iNode),
     +    HeatConUB(iNode),
c    +    SulphurCon(iNode)
     +    fUnscNode(iNode)
      end do
  417 write(DbgU,'(i4," EoF"/)') InpU
!
      write(DbgU,'(10i5)') (BasnID(iBasn),iBasn=1,nBasn)
      write(DbgU,'(10i6)') (NodeID(iNode),iNode=1,nNode)
!
!
      InpU=InpCsvU(4) ! Link data
      nLink=0
      nContMax=0
      do
        read(InpU,'(a)',err=425,end=425) OneLine
        write(DbgU,'(i4,1x,a)') InpU,trim(OneLine)
        read(OneLine,*,err=425,end=425) FirstCh
        if(FirstCh/='1') cycle
        read(OneLine,*,err=425,end=425) FirstCh,cDummy,cDummy
        if(Negat(cDummy)) cycle
        read(OneLine,*,err=425,end=421) FirstCh,(cDummy,j=1,3),
     +    iBasn,HiPlntID ! skip Yes,LinkID
  421   continue
        iBasn=IndexIn(BasnID,nBasn,iBasn)
        iPlnt=IndexIn(HPntID,mPlnt,HiPlntID)
        if((iBasn>nBasn).or.(iPlnt>mPlnt)) then
          write(DbgU,'(a)') ' inactive/invalid Basin or plant'
          cycle
        end if
      ! count the CoalTypes available from this link's Supply basin
        j=0
        do iSNod=1,nSNod ! Supply-nodes are contiguous at lower indices
          if(BnOfNode(iSNod)==iBasn) j=j+1
        end do
        nContMax=nContMax+j ! augment count of max CoalTypeToPlant contracts
        nLink=nLink+j ! allow any CoalType at iBasn to reach iPlnt
        write(DbgU,'(i6,i3,2i5,a)') nLink,j,iBasn,iPlnt,
     +    ' links,nCT@B,B,P'
      end do
  425 continue
      write(DbgU,'(i6,a)') nLink,' links to be allocated'
      write(DbgU,'(i6,a)') nContMax,' max CoalTypeToPlant contracts'
      write(DbgU,'(i4," EoF"/)') InpU
      if(nLink==0) call ps(1,'Zero links; problem is undefined')
      return ! entry GetLinkCount
c-----
      entry ReadCNWLinkData(nNode,nLink,nBasn, ! nLnkMax,
     +  NodeID,BasnID,BnOfNode,HPntID,PnOfNode,
     +  LinkID,LinkNdID,LinkNdSN,TestFactor,
     +  NodePri,NodeQty,NodeQtyLB,NodeQtyUB,MineFunc,
     +  HeatConLB,HeatConUB,SulphurCon,fUnscNode,
     +  LinkChg,NodeName,LimitTypesAt2)
      rewind(InpU) ! Link data
      iLink=0
      do while(iLink<nLink)
        read(InpU,'(a)',err=440,end=440) OneLine
        write(DbgU,'(i4,1x,a)') InpU,trim(OneLine)
        read(OneLine,*,err=440,end=440) FirstCh
        if(FirstCh/='1') cycle
        read(OneLine,*,err=440,end=440) FirstCh,cDummy,cDummy
        if(Negat(cDummy)) cycle
c       if(iLink==0) call EnumerateFields(OneLine,50,1,DbgU)
        read(OneLine,*,err=440,end=431) FirstCh,cDummy,cDummy,k, ! skip Yes
     +    i,HiPlntID,r4,f4 ! LinkChg,LinkCap
  431   continue
        iBasn=IndexIn(BasnID,nBasn,i)
        iPlnt=IndexIn(HPntID,mPlnt,HiPlntID)
        if((iBasn>nBasn).or.(iPlnt>mPlnt)) then
          write(DbgU,'(a)') ' inactive/invalid Basin or plant'
          cycle
        end if
      ! count paralell links from all CoalTypes in same basin
        do iSNod=1,nSNod ! Supply-nodes are contiguous at lower indices
          if(BnOfNode(iSNod)/=iBasn) cycle
          j=0
          do iDNod=nSNod+1,nNode ! Demand-nodes are contiguous at higher indices
          ! count paralell links to all units in same plant
            if(PnOfNode(iDNod)/=iPlnt) cycle
c           if(j==1) then ! modify some values for the Cont-aggregate link
c             LinkNdID(1,iLink)=-HPntID(iPlnt) ! useful only in VarDesc
c           ! LinkNdSN(1,iLink) retains value
c             LinkChg(iLink)=0.0
c             j=j+1
c             iLink=iLink+1
c             goto 432 ! without advancing iDNod
c           end if
            j=j+1
            iLink=iLink+1
            LinkID(iLink)=k ! invariant with iSNod
            LinkNdID(0,iLink)=NodeID(iSNod) ! NOT iBasn*100+iSNod ! OK if equal to some NodeID(iDNod)
            LinkNdID(1,iLink)=NodeID(iDNod) ! of dubious usefulness
            LinkChg(iLink)=r4
c           LinkCap(iLink)=f4 ! UB will be imposed on the basin-aggregate also
            LinkNdSN(0,iLink)=iSNod
            LinkNdSN(1,iLink)=PnOfNode(iDNod)
            write(DbgU,'(i6,a,5i6,f7.2)') iLink,' link',LinkID(iLink),
     +        (LinkNdID(i,iLink),i=0,1),
     +        (LinkNdSN(i,iLink),i=0,1),LinkChg(iLink)
            exit ! after the first iDNod connected via iLink
          end do
        end do
      end do ! iLink
  440 if(iLink/=nLink) call ps(1,'error counting active links')
c     if(nLnkMax>0) then
c     ! facilitate debugging by reducing size of problem
c       nLink=nLnkMax
c       write(DbgU,'(/a/i6,a)') ' NOTE:  imposing CmdLineArg limits',
c    +    nLnkMax,' limits links usable'
c     end if
      write(DbgU,'(i6,a)') nLink,' links used'
      write(DbgU,'(i4," EoF"/)') InpU
!
    ! prune Supply nodes untouched by active links
      iNode=nSNod
      do while(iNode>0)
        do iLink=1,nLink
          if(LinkNdSN(0,iLink)==iNode) exit
        end do
        if(iLink>nLink) then ! iNode has no active links therefrom
          do iLink=1,nLink
            if(LinkNdSN(0,iLink)>iNode)
     +         LinkNdSN(0,iLink)=
     +         LinkNdSN(0,iLink)-1
               LinkNdSN(1,iLink)=
     +         LinkNdSN(1,iLink)-1 ! unqualified since all iDNod>iNode
          end do
          k=NodeID(iNode) ! before shifting
          iNodeP1=iNode+1
          nNodeM1=nNode-1
          nWd=nNode-iNode
          if(nWd>0) then
            NodeName  (iNode:nNodeM1)=NodeName  (iNodeP1:nNode)
            NodeID    (iNode:nNodeM1)=NodeID    (iNodeP1:nNode)
            BnOfNode  (iNode:nNodeM1)=BnOfNode  (iNodeP1:nNode) ! retain BasnID
            PnOfNode  (iNode:nNodeM1)=PnOfNode  (iNodeP1:nNode) ! retain HPntID
            NodePri   (iNode:nNodeM1)=NodePri   (iNodeP1:nNode)
            NodeQty   (iNode:nNodeM1)=NodeQty   (iNodeP1:nNode) ! N.A. only for SNodes
            NodeQtyLB(iNode:nNodeM1)=NodeQtyLB(iNodeP1:nNode)
            NodeQtyUB(iNode:nNodeM1)=NodeQtyUB(iNodeP1:nNode)
            HeatConLB (iNode:nNodeM1)=HeatConLB (iNodeP1:nNode)
            HeatConUB (iNode:nNodeM1)=HeatConUB (iNodeP1:nNode)
            SulphurCon(iNode:nNodeM1)=SulphurCon(iNodeP1:nNode)
            fUnscNode (iNode:nNodeM1)=fUnscNode (iNodeP1:nNode)
            MineFunc(:,:,iNode:nNodeM1)=MineFunc(:,:,iNodeP1:nNode)
          end if
          nNode=nNodeM1
          write(DbgU,'(i5,a,i6,i4,i2)') nNode,
     +      ' nodes after pruning SNod',k,k/100,mod(k,100)
        end if
        iNode=iNode-1
      end do
      nSNod=nNode-nDNod
      if(nNode<100)
     +  write(DbgU,'(5i6,a)') (iLink,(LinkNdID(j,iLink),j=0,1),
     +  (LinkNdSN(j,iLink),j=0,1),' after Pruning SNod',iLink=1,nLink)
      write(DbgU,'(i5,a)') nSNod,' Supply-nodes after pruning:'
      allocate(kTpMB(nSNod))
!
      SumSupplyMax=0.0
      write(DbgU,'(a)') ' SNod NodID Bsn T iBn CTMaxkTn SumMxkTn'
      write(DbgU,'(a)') ' ---- ----- --- - --- -------- --------'
      do iSNod=1,nSNod
        k=NodeID(iSNod)
        iBasn=BnOfNode(iSNod)
        r4=NodeQtyUB(iSNod)
        SumSupplyMax=SumSupplyMax+r4
        kTpMB(iSNod)=1000.0/(HeatConUB(iSNod)*2000.0) ! (MBtu)*(k/M)/((Btu/Lb)*(Lb/T)) => (kT)
        write(DbgU,'(i5,i6,i4,i2,i4,2f9.0)') iSNod,k,k/100,mod(k,100),
     +    iBasn,r4,SumSupplyMax
      end do
!
!
    ! prune Demand nodes untouched by active links
      iNode=nNode
      do while(iNode>nSNod)
        iPlnt=PnOfNode(iNode)
        do iLink=1,nLink
          if(LinkNdSN(1,iLink)==iPlnt) exit
        end do
        if(iLink>nLink) then ! iNode has no active links thereto
          k=NodeID(iNode) ! before shifting
          iNodeP1=iNode+1
          nNodeM1=nNode-1
          nWd=nNode-iNode
          if(nWd>0) then
            NodeName  (iNode:nNodeM1)=NodeName  (iNodeP1:nNode)
            NodeID    (iNode:nNodeM1)=NodeID    (iNodeP1:nNode)
cNA         BnOfNode  (iNode:nNodeM1)=BnOfNode  (iNodeP1:nNode) ! retain BasnID
            PnOfNode  (iNode:nNodeM1)=PnOfNode  (iNodeP1:nNode) ! retain HPntID
cTBD        NodePri   (iNode:nNodeM1)=NodePri   (iNodeP1:nNode)
            NodeQty   (iNode:nNodeM1)=NodeQty   (iNodeP1:nNode)
cNA         NodeQtyLB (iNode:nNodeM1)=NodeQtyLB (iNodeP1:nNode)
cNA         NodeQtyUB (iNode:nNodeM1)=NodqQtyUB (iNodeP1:nNode)
            HeatConLB (iNode:nNodeM1)=HeatConLB (iNodeP1:nNode)
            HeatConUB (iNode:nNodeM1)=HeatConUB (iNodeP1:nNode)
            SulphurCon(iNode:nNodeM1)=SulphurCon(iNodeP1:nNode)
            fUnscNode (iNode:nNodeM1)=fUnscNode (iNodeP1:nNode)
cNA         MineFunc(:,:,iNode:nNodeM1)=MineFunc(:,:,iNodeP1:nNode)
          end if
          nNode=nNodeM1
          write(DbgU,'(i5,a,i6,i4,i2)') nNode,
     +      ' nodes after pruning DNod',k,k/25,mod(k,25)
        end if
        iNode=iNode-1
      end do
      nDNod=nNode-nSNod
      if(nNode<100)
     +  write(DbgU,'(5i6,a)') (iLink,(LinkNdID(j,iLink),j=0,1),
     +  (LinkNdSN(j,iLink),j=0,1),' after Pruning DNod',iLink=1,nLink)
      write(DbgU,'(i5,a)') nDNod,' Demand-nodes after pruning:'
!
      SumDemandGBt=0.0
      write(DbgU,'(a)') ' DNod NodID Pnt U NdReqGBtu  SumReqGBtu'
      write(DbgU,'(a)') ' ---- ----- --- - --------- -----------'
      do iDNod=nSNod+1,nNode
        k=NodeID(iDNod)
        r4=NodeQty(iDNod)*0.001 ! 0.001=nGperM
        SumDemandGBt=SumDemandGBt+r4
        write(DbgU,'(i5,i6,i4,i2,f10.0,f12.0,a)') iDNod,k,k/25,
     +    mod(k,25),r4,SumDemandGBt
      end do
!
      mNode=nNode ! final value after pruning
      mLink=nLink ! preclude need for redundant entry parameters
      nTypesLtd=LimitTypesAt2 ! make accessible to other entry points
      call AllocLocalsPostPruning() ! using nSNod,mNode,mPlnt,mLink
c     call ProbePlantLinks() ! defines PlntQty,kTpFB, etc.
c     entry ProbePlantLinks
    ! check feasibility of limiting CoalTypes per plant (instead of per unit)
      mPlnt1SN=0
      mPlnt2SN=0
      write(DbgU,'(a)') ' Plnt DNod SNod  Link CT HeatLB HeatUB kfUn'
      write(DbgU,'(a)') ' ---- ---- ---- ----- -- ------ ------ ----'
      nNSP=0
      do iPlnt=1,mPlnt
        AvailSN=0
        k=0
        do iLink=1,mLink
          if(LinkNdSN(1,iLink)/=iPlnt) cycle
          iSNod=LinkNdSN(0,iLink)
          k=k+1 ! count CoalTypes possible at iPlnt (no duplicate iSNod)
          if((AvailSN(iSNod)==0) ! iSNod touches iPlnt, and is unprecedented
     +      .and.(PlntQty(iPlnt)==0.0)) then ! get PlntQty and fUnscPlnt
          ! if,  (PlntQty(iPlnt)/=0.0), this branch is redundant (harmless)
            i=0
            j=0
            m=0
            f4=1e12
            h4=1e12
            r4=0.0
            QtySum=0.0
            CstSum=0.0
            iNode=0
            do iDNod=nSNod+1,mNode
              if(PnOfNode(iDNod)/=iPlnt) cycle
              if(iNode==0) then ! save data for 1st unit of iPlnt
                DnOfPlnt(iPlnt)=iDNod
                h4=HeatConLB(iDNod)
                r4=HeatConUB(iDNod)
                f4=fUnscNode(iDNod)
              end if
              iNode=iNode+1 ! count units of iPlnt
              QtySum=QtySum+NodeQty(iDNod)
              CstSum=CstSum+NodeQty(iDNod)*fUnscNode(iDNod) ! Btu-weighted average
              if(h4/=HeatConLB(iDNod)) i=i+1 ! count discrepancies
              if(r4/=HeatConUB(iDNod)) j=j+1
              if(f4/=fUnscNode(iDNod)) m=m+1
              write(DbgU,'(3i5,i6,i3,2f7.0,i5)') iPlnt,iDNod,iSNod,
     +          iLink,k,HeatConLB(iDNod),HeatConUB(iDNod),
     +          nint(fUnscNode(iDNod)*1000.)
            end do
            PlntQty(iPlnt)=QtySum ! MegaBtu demanded
            if(QtySum>0.0) fUnscPlnt(iPlnt)=CstSum/QtySum ! average frac unscrubbed
          ! abort if assumption about scalability of plant to units is invalid
            if(i+j>0) call ps(1,
     +        'HeatContent differs among units of plant')
            if(i+j+m>0) nNSP=nNSP+1 ! count plants whose units differ in fUnscNode
            write(DbgU,
     +        '(i5," plant_aggregate",i3,2i7,i5," #diff",2f12.1)')
     +        iPlnt,k,i,j,m,CstSum,QtySum
          else
            write(DbgU,'(3i5,i6,i3)') iPlnt,iDNod,iSNod,iLink,k
          end if
          kTpFB(iLink)=PlntQty(iPlnt)*kTpMB(iSNod) ! (MBtu)*(kT/MBtu) => (kT)
          ShCst(iLink)= ! ($/MBtu)
     +      SulphurCst*SulphurCon(iSNod)*fUnscPlnt(iPlnt)+ ! ($/LbS)*(LbS/MBtu) => ($/MBtu)
     +      LinkChg(iLink)*1000.0*kTpMB(iSNod) ! ($/T)*(n/k)*(kT/MBtu) => ($/MBtu)
        ! ShCst above is cost of shipping & emissions, excludes coal FOB
          AvailSN(iSNod)=1
          LinkFrTo(iSNod,iPlnt)=1
        end do ! iLink
        if(k<=0) call ps(1,'No supply is linked to this plant')
        LinkFrTo(0,iPlnt)=k
        k=0
        do iSNod=1,nSNod ! count unique CoalTypes possible at iPlnt
          k=k+AvailSN(iSNod)
        end do
        if(k/=LinkFrTo(0,iPlnt)) call ps(1,'error counting SN-P links')
      ! if(k==1) no pair is possible; no additional constraint is necessary
        if(k==1) mPlnt1SN=mPlnt1SN+1
        if(k==2) mPlnt2SN=mPlnt2SN+1
      ! max() is needed above to keep a (pseudo-)constraint when only 1 CT is possible
      end do ! iPlnt
c     return ! entry ProbePlantLinks
!
      do iNode=nSNod+1,mNode
        iPlnt=PnOfNode(iNode)! assign fraction of MBtu demand
        if(PlntQty(iPlnt)>0.0) fPlntUnit(iNode)=NodeQty(iNode)
     +    /PlntQty(iPlnt)
c       write(DbgU,'(i6,i4,2f12.1,f9.6,a)') iNode,iPlnt,NodeQty(iNode),
c    +    PlntQty(iPlnt),fPlntUnit(iNode),' fPU'
      end do
!
c     jCol=int4(nNode)
    ! list all nodes connected by a single link
      write(DbgU,'(/61x,a)') 'costs at 1st mine segment $/T'
      write(DbgU,'(i6,a,41x,a)') mLink,' active links:',
     +  '-----------------------------'
      write(DbgU,'(3a)') ' iLink iLkID SnID  DnID SnSN DnSN Cont',
     +   ' SupplyNode DemandNode',
     +  ' SNodeCost TransCost DelvdCost ($/MBtu)'
      write(DbgU,'(7a)') ' ----- ----- ---- ----- ---- ---- ----',
     +  (' ----------',j=0,1),(' ---------',j=1,3),' --------'
      HiPlntID=-1
      iSNod=-1
      nContMax=0 ! UB after pruning
      do iLink=1,mLink
        piSNod=iSNod
        iSNod=LinkNdSN(0,iLink)
        iPlnt=LinkNdSN(1,iLink)
        f4=MineFunc(1,1,iSNod) ! first-segment cost FOB
        h4=MineFunc(17,1,iSNod) ! final-segment cost FOB
        r4=ShCst(iLink)/(1000.0*kTpMB(iSNod)) ! ($/MBtu)/((n/k)*(kT/MBtu))) => ($/T)
        SNodACst=ShCst(iLink)+f4*1000.0*kTpMB(iSNod) ! ($/T)*(n/k)*(kT/MBtu)) /(Lb/T) => ($/MBtu)
        SNodMCst=ShCst(iLink)+h4*1000.0*kTpMB(iSNod) ! ($/MBtu)
        if(InfDvdCst(iPlnt)>SNodACst) InfDvdCst(iPlnt)=SNodACst ! ($/MBtu)
        if(SupDvdCst(iPlnt)<SNodMCst) SupDvdCst(iPlnt)=SNodMCst ! ($/MBtu)
        k=LinkNdID(1,iLink)
        pHPlntID=HiPlntID
        HiPlntID=k/25
        if((iSNod/=piSNod).or.(HiPlntID/=pHPlntID)) nContMax=nContMax+1 ! UB on plant-agg contracts
c       write(DbgU,'(2i6,i5,i6,3i5,2(1x,a))')
        write(DbgU,'(2i6,i5,i4,i2,3i5,2(1x,a10),3f10.2,3f9.5)')
     +    iLink,LinkID(iLink),
c    +    (LinkNdID(j,iLink),j=0,1),
     +     LinkNdID(0,iLink),HiPlntID,mod(k,25),
     +    (LinkNdSN(j,iLink),j=0,1),nContMax,
     +    (NodeName(LinkNdSN(j,iLink)),j=0,1),
     +    f4,r4,f4+r4, ! costs ($/T) for 1st Segment only
     +    SNodACst,SNodMCst,SnodMCst-SNodACst ! CstDiff
      end do ! iLink
c     write(DbgU,'(a,57x,f9.5)') ' smallest delivered cost ($/MBTu)',
c    +  PriceSoFR
      do iPlnt=1,mPlnt
        write(DbgU,'(i5,2f9.5,a)') iPlnt,
     +    InfDvdCst(iPlnt),SupDvdCst(iPlnt),' Inf,Sup DvdCst'
      end do
      return ! entry ReadCNWLinkData
c-----
      entry ReadCNWContData
      InpU=InpCsvU(5) ! Contract data
      if(InpU<0) goto 520
      do
        read(InpU,'(a)',err=510,end=510) OneLine
        write(DbgU,'(i4,1x,a)') InpU,trim(OneLine)
        read(OneLine,*,err=510,end=510) FirstCh,(cDummy,j=1,3)
        if((FirstCh/='1').or.Negat(cDummy)) cycle
        read(OneLine,*,err=510,end=510) FirstCh,(cDummy,j=1,6), ! MineID is useless
     +    ThisNdName,GcPlntID,cDummy,qInYr,pInYr
        do k=1,nSNod
          if(CoalName(k)==ThisNdName) exit
        end do
c       if(k>nSNod) call ps(1,'Unmatched Coal Type in Contracts file')
        if(k>nSNod) then
          write(OneLine,'(1x,2a)') trim(ThisNdName),
     +      ' Coal Type in Contracts-file is unmatched in Supply-file'
          call WriteStrAt(9,5,OneLine)
          cycle
        end if
        do iPlnt=1,mPlnt ! IndexIn() is for integer*2 only
c         write(DbgU,'(i6,2i7)') iPlnt,GPntID(iPlnt),GcPlntID
          if(GPntID(iPlnt)==GcPlntID) exit ! GcPlntID does not match HPntID
        end do
c       if(iPlnt>mPlnt) call ps(1,'Unmatched GPntID in Contracts file')
        if(iPlnt>mPlnt) then
          write(OneLine,'(i6,a)') GcPlntID,
     +      ' Plant ID in Contracts-file is unmatched in Demand-file'
          call WriteStrAt(9,5,OneLine)
          cycle
        end if
        do j=1,LimnYr ! accumulate across parallel contracts
c         if(nzQMult) qInYr(j)=qInYr(j)*MaxContFr ! for feasibility
          ContQty(j,k,iPlnt)=ContQty(j,k,iPlnt)+qInYr(j) ! (kT)
          ContCst(j,k,iPlnt)=ContCst(j,k,iPlnt)+qInYr(j)*pInYr(j)*1000.0 ! (kT)*($/T)*(n/k) => ($)
        end do
      end do ! reading lines of Contract data
  510 write(DbgU,'(i4," EoF"/)') InpU
  520 continue
!
c     PrtDetail=0 ! for normal operation of the model by a customer
c     PrtDetail=1 ! for debugging details (some)
      PrtDetail=2 ! for debugging details (more)
!
      call WriteStrAt(1,1,'after reading ContractData')
      call RefreshSizes()
      call timer(OrgCentiSec)
      return ! entry ReadCNWContData
c-----
      entry AdjustCNWContracts(iYr,MaxContFr,HPntID,PnOfNode,
     +  NodeQty,NodeQtyUB,HeatConLB)
    ! reduce contract data to allow feasibility (until data are fixed)
      j=iYr
c     do j=1,LimnYr ! Lneeds some work in preserving the unaltered arrays, eh?
        do iPlnt=1,mPlnt ! scan each aggregate demand
          r4=0.0 ! sum the maximum (@HeatConLB) kT demanded at each unit of iPlnt
          do iDNod=nSNod+1,mNode
            if(PnOfNode(iDNod)==iPlnt) r4=r4+NodeQty(iDNod) ! (MBtu)
     +        /HeatConLB(iDNod) ! (MBtu)/(Btu/Lb) => (MLb)
          end do
          r4=(r4/0.001)/2000.0 ! ((MLb)/(M/k))/(Lb/T) => (kT)
          QtySum=0.0
          do iSNod=1,nSNod
            QtySum=QtySum+ContQty(j,iSNod,iPlnt)
          end do
          f4=QtySum/amax1(r4,0.01) ! some demand may be tiny
          if(f4<=MaxContFr) cycle
          write(OneLine,'(a,i3,2i7,2(a,f6.3))')
     +      'WARNING: model-year',j,iPlnt,
     +      HPntID(iPlnt),
     +      ' contracts/demand ratio',f4,' is reduced to',MaxContFr
c         call WriteStrAt(8,5,OneLine)
          write(DbgU,'(1x,a)') trim(OneLine)
          r4=MaxContFr/f4
          do iSNod=1,nSNod
            ContQty(j,iSNod,iPlnt)=ContQty(j,iSNod,iPlnt)*r4
            ContCst(j,iSNod,iPlnt)=ContCst(j,iSNod,iPlnt)*r4
          end do
        end do ! iPlnt
        do iSNod=1,nSNod ! scan each aggregate supply
          QtySum=0.0
          do iPlnt=1,mPlnt
            QtySum=QtySum+ContQty(j,iSNod,iPlnt)
          end do
          f4=QtySum/NodeQtyUB(iSNod)
          if(f4<=MaxContFr) cycle
          write(OneLine,'(a,2i3,2(1x,a),2(f6.3,a))')
     +      'WARNING:  model-year',j,iSNod,
     +      CoalName(iSNod)(1:10), ! trim() misaligns columns
     +      'contracts/supply ratio',f4,' is reduced to',MaxContFr
c         call WriteStrAt(8,5,OneLine)
          write(DbgU,'(1x,a)') trim(OneLine)
          r4=MaxContFr/f4
          do iPlnt=1,mPlnt
            ContQty(j,iSNod,iPlnt)=ContQty(j,iSNod,iPlnt)*r4
            ContCst(j,iSNod,iPlnt)=ContCst(j,iSNod,iPlnt)*r4
          end do
        end do ! iSNod
        if(nTypesLtd) then
          do iPlnt=1,mPlnt ! check for excessivly binding contracts
            do
              f4=1e12
              iNode=0
              k=0
              do iSNod=1,nSNod
                r4=ContQty(j,iSNod,iPlnt)
                if(r4==0.0) cycle
                if(f4>r4) then
                  f4=r4
                  iNode=iSNod ! retain the index of the smallest ContQty
                end if
                k=k+1
              end do
              if((k<=2).or.(iNode==0)) exit
            ! zero the contract with least ContQty
              write(DbgU,'(i3,a,i4/i3,a)') k,'>2 contracts for plant',
     +          iPlnt,iNode,'-Supply contract (min.) will be ignored'
              ContQty(j,iNode,iPlnt)=0.0
            end do
          end do ! iPlnt
        end if
c     end do ! loop over model years
      return ! entry AdjustCNWContData
c-----
      entry RefreshSizes
    ! n?pDn => # of ? per destination (plant)
      if(nTypesLtd) then
        nRpDn=2 ! �kT,�fBtu
      ! mPlnt1SN=0 ! nonzero only if using nRpDn>2 above
      ! mPlnt2SN=0
      else
        nRpDn=2 ! �kT,�fBtu
      end if
      nVpDn=1 ! �kT
      nVpLk=1 ! fBtu
      nRpLk=0
      nNdVar=nSNod*(1+17)+mPlnt*nVpDn
      nLbV  =nSNod            +mPlnt*nVpDn+nContMax ! +mLink ! each SNod,kTnRcvd, and CT-plant-contract-used var is lower-bou
      nUbV  =nSNod*(1+17)+mPlnt*nVpDn+nContMax+1 ! *3 cNS; all segments are upper-bounded
     +  +mLink*nVpLk
      nVar=nNdVar+mLink*nVpLk+1 ! final var aggregates SO2
      mReq=nSNod*2+mLink*nRpLk+
     +  mPlnt*nRpDn+1 ! -mPlnt1SN-mPlnt2SN; final row aggregates x<Sulphur_UB
      if(iBnUB>0) mReq=mReq+1
      nContLoB=nContMax ! default until revised lower
      ContFrTo=0
      PossFrTo=LinkFrTo
      return ! entry RefreshSizes
c-----
      entry ReportSizes
      write(DbgU,'(2a/6i5,5i6,i9/)') ' SNod DNod Plnt P1SN P2SN Cont',
     + ' Links ARows ACols LoBnd UpBnd AMtxSize',
     +  nSNod,nDNod,mPlnt,mPlnt1SN,mPlnt2SN,nContLoB,
     +  mLink,mReq,nVar,nLbV,nUbV,ConsMtSize  ,nNdVar
      return
c-----
      entry MinCNWCosts(iYr,BegYr,TestFactor, ! nLbvMax,nUbvMax,
     +  NodeID,BnOfNode,PnOfNode,
     +  LinkID,LinkNdID,LinkNdSN,
     +  NodeQtyLB,NodeQtyUB,
     +  NodeQty,HeatConLB,HeatConUB,SulphurCon,fUnscNode,MineFunc,
     +  BasnQtyUB,SulphurCst,Sulphur_UB,
     +  LinkChg,NodeName)
      FullSignif=TestFactor ! below which fBtu is considered negligible wrt count
      ConsMtSize=0 ! count of elements used in above arrays
      call WriteStrAt(1,1,'before defining LP vars:')
      call ReportSizes()
!
      cYr=BegYr+iYr-1
      call RefreshSizes() ! these may have been modified below in prior iYr
      iReq=0
      jVar=0
      iLbV=0
      iUbV=0
      ReVec=99 ! default to catch logic errors
    ! explete the arrays on the LP interface:  cVect,bVect,ReVec,ConsMtxNze
!
    ! each Supply node has 1 variable (bilaterally-bounded) for
    ! the aggregate across segmens, and 17 upper-bounded variables
      do iNode=1,nSNod ! mNode if test below is useful
        call CNWIncrVar()
        call CNWIncrLB()
        LbValu(iLbV)=NodeQtyLB(iNode)
      ! without the following, PCX infers that UbValu is zero when LbValu is specified above
        call CNWIncrUB()
        r4=NodeQtyUB(iNode)
        UbValu(iUbV)=r4 ! *MineFunc(17,0,iNode) ! MF>1 possibly
        write(VarDesc(jVar),'(a,i4.4)') 'kTon_mined_from_Supply_',
     +    NodeID(iNode)
c       write(DbgU,'(3i6,1x,a)') jVar,iLbV,iUbV,VarDesc(jVar)
cNOT:   cVect(jVar)=NodePri(iNode)*1000.0 ! in ($/T)
c       write(DbgU,'(3i4,f9.3,2(1x,a))') iNode,jVar,nSNod,cVect(jVar),
c    +    VarDesc(jVar),NodeName(iNode)
!
        do j=1,17
          call CNWIncrVar() ! incremented jVar is needed by CNWIncrUB()
          write(VarDesc(jVar),'(a,i2.2,a,i4.4)') 'Seg_',j,
     +      '_kTon_mined_from_',NodeID(iNode)
          call CNWIncrUB()
c         write(DbgU,'(3i6,1x,a)') jVar,iLbV,iUbV,VarDesc(jVar)
          UbValu(iUbV)=MineFunc(j,2,iNode)*r4 ! segment-width in kT
          cVect(jVar)=MineFunc(j,1,iNode)*1000.0 ! ($/T)*(n/k) => ($/kT)
c         write(DbgU,'(3i4,f9.1,2(1x,a))') jVar,iNode,j,cVect(jVar),
c    +      VarDesc(jVar),NodeName(iNode)
        end do ! j
      end do ! iNode
      if(jVar/=nNdVar-mPlnt*nVpDn) call ps(1,
     +  'error assigning vars for Supply nodes')
!
    ! each plant has nVpDn variables
      do iPlnt=1,mPlnt
c     ! CstDiff is the largest possible $/fBtu gained by switching iSNod
c       CstDiff=(SupDvdCst(iPlnt)-InfDvdCst(iPlnt))*PlntQty(iPlnt)
        m=PossFrTo(0,iPlnt)
! 1
        call CNWIncrVar() ! SumkT
        write(VarDesc(jVar),'(a,i3.3)') 'Sum_kTon_Rcvd__at_Plant_',iPlnt
      ! bounds are implied by HeatConLB and HeatConUB
        r4=PlntQty(iPlnt)/0.001 ! (MegaBtu demanded)/(M/k) => (kBtu)
        call CNWIncrLB()
        iDNod=DnOfPlnt(iPlnt)
        LbValu(iLbV)=(r4/HeatConUB(iDNod))/2000.0 ! ((kBtu)/(Btu/Lb))/(Lb/T) => (kT)
        call CNWIncrUB()
        UbValu(iUbV)=(r4/HeatConLB(iDNod))/2000.0 ! kT
c       write(DbgU,'(3i6,1x,a,2f9.1,i5)') jVar,iLbV,iUbV,VarDesc(jVar)
c    +    ,LbValu(iLbV),UbValu(iUbV),iDNod
c       if(nVpDn<2) cycle
      end do
      if(jVar/=nNdVar) call ps(1,
     +  'error assigning vars for Demand plants')
!
    ! each of nContLoB generates bounds on 1 fBtu variable
    ! by here, jVar=nNdVar
      nContLoB=0
      HiPlntID=-1
      iSNod=-1
      do iLink=1,mLink
        jVar=jVar+1 ! to match loop below
        piSNod=iSNod
        iSNod=LinkNdSN(0,iLink)
        pHPlntID=HiPlntID
        HiPlntID=LinkNdID(1,iLink)/25
        if((iSNod==piSNod).and.(HiPlntID==pHPlntID)) cycle
        iPlnt=LinkNdSN(1,iLink)
        r4=ContQty(iYr,iSNod,iPlnt) ! (kT)
        if(r4==0.0) cycle
        nContLoB=nContLoB+1 ! count only contracts used this year
        ContFrTo(iSNod,iPlnt)=1
        ContFrTo(0,iPlnt)=ContFrTo(0,iPlnt)+1 ! # SNod under contract to iPlnt
        call CNWIncrLB()
        LbValu(iLbV)=r4/kTpFB(iLink) ! (kT)/(kT) => (1)
      ! without the following, PCX infers that UbValu is zero when LbValu is specified above
        call CNWIncrUB()
        UbValu(iUbV)=1.0
c       write(DbgU,'(3i6,1x,a,3i4,f9.1,f6.3,a)') jVar,iLbV,iUbV,
c    +    VarDesc(jVar),nContLoB,iSNod,iPlnt,r4,
c    +    LbValu(iLbV),' C2P_LB'
      end do
    ! expedite execution by reducing size of the LP
      k=nContMax-nContLoB
      nLbV=nLbV-k
      nUbV=nUbV-k
      jVar=nNdVar ! regress to pre-iLink-loop value; above loop did not IncrVar
!
    ! each link has nVpLk variables (fraction of iPlnt-demanded Btu shipped), (~P�), (~N�)
    1 format(a,i4.4,a,i3.3)
      do iLink=1,mLink
        iSNod=LinkNdSN(0,iLink)
        iPlnt=LinkNdSN(1,iLink)
cc      iDNod=DnOfPlnt(iPlnt)
        m=PossFrTo(0,iPlnt)
        r4=1.0/float(m)
c     ! CstDiff is the largest possible $/fBtu gained by switching iSNod
c       CstDiff=(SupDvdCst(iPlnt)-InfDvdCst(iPlnt))*PlntQty(iPlnt)
! 1
        call CNWIncrVar() ! fBtu
        write(VarDesc(jVar),1) 'Link_fBtu_from_',iSNod,'_Plnt',iPlnt
c       write(DbgU,'(3i6,1x,a)') jVar,iLbV,iUbV,VarDesc(jVar)
        cVect(jVar)=ShCst(iLink)*PlntQty(iPlnt) ! (($/MBtu)*(MBtu) => ($)
        call CNWIncrUB()
        UbValu(iUbV)=1.0
c       if(nVpLk<2) cycle
      end do ! iLink
!
    ! final variable is aggregate SO2 emissions (upper-bounded)
      call CNWIncrVar()
      write(VarDesc(jVar),'(a)') 'total_SO2_emissions_kTon/yr'
      call CNWIncrUB()
      UbValu(iUbV)=Sulphur_UB ! (kT)
c     if(UserMult>0.0) UbValu(iUbV)=UbValu(iUbV)*UserMult ! to allow feasibility
      write(DbgU,'(3i6,e12.5,1x,a)') jVar,iLbV,iUbV,
     +  UbValu(iUbV),VarDesc(jVar)
      call WriteStrAt(1,1,'after  defining LP vars:')
      call ReportSizes() ! after possible changes above
      if(jVar/=nVar) call ps(1,'error assigning vars for links')
      if(iLbV/=nLbV) call ps(1,'error counting LB-vars')
      if(iUbV/=nUbV) call ps(1,'error counting UB-vars')
!
!
    ! each Supply-node generates 2 constraints (row in ConsMtx)
      jCol=0
      do iSNod=1,nSNod
        call CNWIncrReq() ! net sum across segments of kT I/O at iSNod
        ReVec(iReq)=0 ! for EQL
        write(ReqDesc(iReq),'(a,i4.4)') ' Segment_sum_kTonIO_SNd_',
     +    NodeID(iSNod)
        jCol=jCol+1
        iCol=jCol ! save for use below
        call AssignCNWAMtx(jCol,iReq,-1.0) ! sum in kT supplied by iSNod
        do jSeg=1,17
          jCol=jCol+1
          call AssignCNWAMtx(jCol,iReq,1.0) ! segment kT mined at iSNod
        end do
!
        call CNWIncrReq() ! sum of kT supplied at iSNod equals kT shipped via links
        ReVec(iReq)=0 ! for EQL
        write(ReqDesc(iReq),'(a,i4.4)') ' Sum/Link_kTon_IO_SNode_',
     +    NodeID(iSNod)
        call AssignCNWAMtx(iCol,iReq,-1.0) ! kT sum supplied by iSNod
        do iLink=1,mLink
          if(LinkNdSN(0,iLink)/=iSNod) cycle
c         iPlnt=LinkNdSN(1,iLink)
          iCol=nNdVar+(iLink-1)*nVpLk+1 ! +nContLoB
          call AssignCNWAMtx(iCol,iReq,kTpFB(iLink)) ! kT shipped from iSNod via iLink
        end do
      end do ! iSNod
      if((jCol/=nNdVar-mPlnt*nVpDn).or.(iReq/=nSNod*2)) call ps(1,
     +  'error forming constraints for Supply nodes')
!
!
    ! each plant generates nRpDn constraints (row in ConsMtx)
      jCol=nNdVar-mPlnt*nVpDn-(nVpDn-1)
      do iPlnt=1,mPlnt
        jCol=jCol+nVpDn
        m=PossFrTo(0,iPlnt)
        do i=1,nRpDn
          call CNWIncrReq()
          ReVec(iReq)=0 ! for EQL
          if(i==1) then ! x(jCol) kTn is lower- and upper-bounded by Btu requirements
          ! sum across links the kTn received at iPlnt
cRed        bVect(iReq)=0.0 ! net sum across links of kT I/O at iPlnt
            write(ReqDesc(iReq),'(a,i3.3)') ' Sum/Link_kTon_Rcvd_Plant',
     +        iPlnt
            call AssignCNWAMtx(jCol,iReq,-1.0) ! expect x(jCol) to be positive
            iRqkTn=iReq
          elseif(i==2) then
          ! sum across links the fBtu received at iPlnt
            bVect(iReq)=1.0 ! NOT PlntQty(iPlnt) ! MegaBtu demanded
            write(ReqDesc(iReq),'(a,i3.3)') ' Sum/Link_fBtu_Rcvd_Plant',
     +        iPlnt
            iRqfBt=iReq
          end if
c         write(DbgU,'(4i6,2a)') i,iReq,jCol,nNdVar,' jCol nNdVar',
c    +      ReqDesc(iReq)
        end do ! i-loop
!
        k=0
        do iLink=1,mLink
          if(LinkNdSN(1,iLink)/=iPlnt) cycle
          k=k+1
          iSNod=LinkNdSN(0,iLink)
          iCol=nNdVar+(iLink-1)*nVpLk+1 ! +nContLoB
          call AssignCNWAMtx(iCol  ,iRqkTn,kTpFB(iLink)) ! link kTn received at iPlnt
          call AssignCNWAMtx(iCol  ,iRqfBt,1.0) ! link fBtu received at iPlnt
        end do
        if(k==0) call ps(1,'iPlnt has no active links thereto')
c       write(DbgU,'(5i6,f12.1,a)') iPlnt,iReq,jCol,k,iRqkTn,
c    +    PlntQty(iPlnt),' iPlnt,iReq,jCol,links,iRqkTn,MBt'
      end do ! iPlnt
      if((jCol+nVpDn-1/=nNdVar).or.(iReq/=nSNod*2+mLink*nRpLk
     +  +mPlnt*nRpDn)) ! -mPlnt1SN-mPlnt2SN))
     +  call ps(1,'error forming constraints for Demand plants')
!
      if(iBnUB>0) then ! limit the sum of Supply nodes' kT from this basin
        call CNWIncrReq()
        ReVec(iReq)=1 ! for LEQ
        bVect(iReq)=BasnQtyUB(iBnUB)
        write(ReqDesc(iReq),'(a,i2.2)') ' Node_sum_kTon_from_basin_',
     +    iBnUB
        do iSNod=1,nSNod
          if(BnOfNode(iSNod)==iBnUB) then
            jCol=1+(iSNod-1)*(1+17)
            call AssignCNWAMtx(jCol,iReq,1.0) ! iSNod kT supplied from basin
          end if
        end do
      end if
!
    ! final constraint aggregates SO2 emissions
      call CNWIncrReq()
      ReVec(iReq)=0 ! for EQL
      write(ReqDesc(iReq),'(a)') ' Sum/Link_kTon_SO2_emissions'
      call AssignCNWAMtx(jVar,iReq,-1.0)
      f4=0.0
      do iLink=1,mLink
        iSNod=LinkNdSN(0,iLink)
        iPlnt=LinkNdSN(1,iLink)
        r4=(SulphurCon(iSNod)*HeatConUB(iSNod)/(1.0e6)) ! (LbS/MegaBtu)*(Btu/LbC)/(n/M) => (S/C)
     +    *fUnscPlnt(iPlnt)*kTpFB(iLink) ! (S/C)*(kTC/1) => (kTS)
        f4=f4+r4 ! sum (kTSulphur) across mLink coefficients
        jCol=nNdVar+(iLink-1)*nVpLk+1 ! +nContLoB ! index of fBtu shipped via iLink
        call AssignCNWAMtx(jCol  ,iReq,r4)
c       write(DbgU,'(3i6,f7.0,2f9.6,e12.5,a)') iLink,
c    +    iSNod,iPlnt,HeatConUB(iSNod),
c    +    SulphurCon(iSNod),r4/(1.0e6),f4,' AMtxReSO2'
      end do
      write(DbgU,'(i6,f9.6,a)') mLink,f4/((1.0e6)*float(mLink)),
     +  ' mean AMtxReSO2'
      if(iReq/=mReq) call ps(1,
     +  'error forming constraints for links(2)')
!
!
      call WriteStrAt(8,5,'after filling constraint matrix:')
      call ReportSizes()
c     call WriteStrAt(8,5,'before sorting constraint matrix')
c     write(DbgU,'(3i7,f12.3)') (iNze,zbColOfNze(iNze),zbRowOfNze(iNze),
c    +  ConsMtxNze(iNze),iNze=1,ConsMtSize)
    ! sort to facilitate search within ReturnCNWAMtx and for order within PCX
      call SortByAscendingKey(
     +  ConsMtSize,zbRowOfNze,zbColOfNze,ConsMtxNze)
c     call WriteStrAt(8,5,'after sorting constraint matrix')
c     write(DbgU,'(3i7,f12.3)') (iNze,zbColOfNze(iNze),zbRowOfNze(iNze),
c    +  ConsMtxNze(iNze),iNze=1,ConsMtSize)
      call WriteStrAt(9,5,' ') ! anticipate 'preprocessor Pass 1' message from PCX
!
      if((PrtDetail>1).and.(mReq<1000)) then
c     ! display upper-bounds
c       do iUbV=1,nUbV
c         write(DbgU,'(2i6,f17.3,a)') iUbV,jUbVec(iUbV),
c    +      UbValu(iUbV),' UBV'
c       end do
!
        write(DbgU,'(13x,a)') 'ConsMtx'
        write(DbgU,'(a,100i4.3/(12x,100i4.3))')
     +    ' iRq Re bVec',(jVar,jVar=1,nVar)
        if(iBnUB==0) then
          i4=mReq-1
        else
          i4=mReq-2
        end if
        do iReq=1,mReq ! display entire constraint matrix
          do jVar=1,nVar
          ! needed to preclude 'initiating I/O during I/O' error
            A4Equiv(jVar)=R4toA4(FuncCNWAMtx(jVar,iReq)) ! very slow
          end do
          bVa4=R4toA4(bVect(iReq))
          write(DbgU,'(i4,i3,a5,100a/(12x,100a))') iReq,ReVec(iReq),
     +      bVa4,(A4Equiv(jVar),jVar=1,nVar),ReqDesc(iReq)
          if((iReq==nSNod*2).or. ! (iReq==i4-nContLoB).or.
     +       ((iBnUB>0).and.(iReq==i4))) write(DbgU,'(1x)')
        end do ! iReq
        write(DbgU,'(1x)')
!
        do jVar=1,nVar
        ! needed to preclude 'initiating I/O during I/O' error
          A4Equiv(jVar)=R4toA4(cVect(jVar))
        end do
        write(DbgU,'(a,100a4/(12x,100a4))') '        cVec',
     +    (A4Equiv(jVar),jVar=1,nVar)
c       write(DbgU,'(1x)')
!
        iUbV=1
        do jVar=1,nVar
          if(jUbVec(iUbV)==jVar) then
            A4Equiv(jVar)=R4toA4(UbValu(iUbV))
            if(iUbV<nUbV) iUbV=iUbV+1
          else
            A4Equiv(jVar)='   _'
          end if
        end do
        write(DbgU,'(a,100a4/(12x,100a4))') '       UbVal',
     +    (A4Equiv(jVar),jVar=1,nVar)
!
        iLbV=1
        do jVar=1,nVar
          if(jLbVec(iLbV)==jVar) then
            A4Equiv(jVar)=R4toA4(LbValu(iLbV))
            if(iLbV<nLbV) iLbV=iLbV+1
          else
            A4Equiv(jVar)='   _'
          end if
        end do
        write(DbgU,'(a,100a4/(12x,100a4))') '       LbVal',
     +    (A4Equiv(jVar),jVar=1,nVar)
        write(DbgU,'(1x)')
!
        if(nVar<=100) then
          do jVar=nVar,2,-1
            write(DbgU,'(15x,100a)') ('|   ',j=2,jVar),VarDesc(jVar)
          end do
            write(DbgU,'(15x,100a)')                   VarDesc(1)
        end if
!
!
      elseif(PrtDetail>2) then ! for larger problems
        write(DbgU,'(a)') '   jVar  cVector(j)' !   cVector(j)'
        write(DbgU,'(a)') ' ------ -----------' ! ------------'
        do jVar=1,nVar
c         write(DbgU,'(i7,f12.2,e13.6,1x,a)') jVar,   cVect(jVar),
          write(DbgU,'(i7,f12.2,      1x,a)') jVar, ! cVect(jVar),
     +      cVect(jVar),VarDesc(jVar)
        end do
        write(DbgU,'(1x)')
!
        write(DbgU,'(a)') '   iReq Re  bVector(i)' !   bVector(i)'
        write(DbgU,'(a)') ' ------ -- -----------' ! ------------'
        do iReq=1,mReq
c         write(DbgU,'(i7,i3,f12.2,e13.6,a)') iReq,ReVec(iReq),
          write(DbgU,'(i7,i3,f12.2,      a)') iReq,ReVec(iReq),
c    +      bVect(iReq),
     +      bVect(iReq),ReqDesc(iReq)
        end do
        write(DbgU,'(1x)')
!
c       write(DbgU,'(i7,1x,a)') (j,VarDesc(j),j=1,jVar)
        write(DbgU,'(/a)') '   iLbV   jVar LoBndValue'
        write(DbgU,'(2i7,f11.2,2a)') (j,jLbVec(j),LbValu(j),' LB ',
     +    VarDesc(jLbVec(j)),j=1,iLbV)
        write(DbgU,'(/a)') '   iUbV   jVar UpBndValue'
        write(DbgU,'(2i7,f11.2,2a)') (j,jUbVec(j),UbValu(j),' UB ',
     +    VarDesc(jUbVec(j)),j=1,iUbV)
!
      end if
!
c   ! allow attainment of feasibility during debugging
c     if(nLbvMax>=0) nLbV=nLbvMax
c     if(nUbvMax>=0) nUbV=nUbvMax
c     if((nLbvMax>=0).or.(nUbvMax>=0)) then
c       write(DbgU,'(/a)') ' NOTE:  imposing CmdLineArg limits'
c       call ReportSizes()
c     end if
cinclude "SM_calls.fpp"
      write(DbgU,'(a)') ' before invoking PCX'
      call flush(DbgU)
      call timer(OrgCentiSec)
      return ! entry MinCNWCosts
c-----
!define call_AppendF8p2(u,r,b) write(u,'( f8.2,",")',advance='no') r
!
      entry SolveCNWLpUsingPcx(Optimal)
cdefine CheckArrays
      BaseFileName='PCX_file'//char(0) ! C-language string-terminator
      PCX_ret_code=PCX_main(MinObj,WrtDetail,BaseFileName,
     +  mReq,nVar,nUbV,nLbV,ConsMtSize,
     +  ReVec,jUbVec,jLbVec,
     +  zbColOfNze,zbRowOfNze,
     +  bVect,cVect,xVect,UbValu,LbValu,ConsMtxNze)
!
      call timer(EndCentiSec)
      ExecET=EndCentiSec-OrgCentiSec
      write(DbgU,'(f8.2,a,2i11)') float(ExecET)*0.01,
     +  ' seconds elapsed during PCX optimization' ! ,OrgCentiSec,EndCentiSec
!     Optimal=(xVect(1)>-0.5) ! 20070605 PCX returns xVect(1)=-1.0 if not OPTIMAL
      Optimal=(PCX_ret_code==0) ! 20090908 PCX returns Solution->Status
!     if(.not.Optimal) call ps(1,'not-optimal error; check *.dbg')
c     pause 'after PCx return'
      return
c-----
      entry CheckSolution(NodeName,NodeQty,LinkNdSN)
      if(PrtDetail==0) return
!
    ! check lower-bounded vars
      call WriteStrAt(5,5,'Checking LB-vars')
ccc   nLbV=mNode+mLink ! each node and link is lower-bounded
      do iLbV=1,nLbV
        jVar=jLbVec(iLbV)
ccc     write(DbgU,'(4i6,a)') iLbV,nLbV,jVar,nVar,' i&nLbV j&nVar'
ccc     call flush(DbgU)
        r4=xVect(jVar)
        f4=LbValu(iLbV)
        if(f4==0.0) cycle ! this LbValue is not of interest
        if(f4<0.01) then
          f4=1.0 ! preclude attempt to divide by 0
        else
          f4=r4/f4 ! should be >=1
        end if
        if(iLbV<=nSNod) then
          jCol=iLbV ! each node is lower-bounded
        elseif(iLbV<=nSNod+mPlnt) then
          jCol=iLbV-nSNod ! report the index on [1,mPlnt]
        else
          jCol=iLbV-(nSNod+mPlnt) ! report the index on [1,nContLoB]
        end if
        if((PrtDetail>1).or.(f4<0.999))
     +    write(DbgU,'(3i6,2f11.3,f9.3,a2,2a)') iLbV,jVar,jCol,
     +    r4,LbValu(iLbV),f4,QuestionIf(f4<0.999),' xj,LB,Xj/LB for ',
     +    trim(VarDesc(jVar))
      end do
      write(DbgU,'(1x)')
!
    ! check upper-bounded vars
      call WriteStrAt(5,5,'Checking UB-vars')
ccc   nUbV=nDNod+nSNod*(1+17)+mLink+1 ! all segments are upper-bounded
      do iUbV=1,nUbV
        jVar=jUbVec(iUbV)
ccc     write(DbgU,'(4i6,a)') iUbV,nUbV,jVar,nVar,' i&nUbV j&nVar'
ccc     call flush(DbgU)
        r4=xVect(jVar)
        f4=UbValu(iUbV)
        if(f4>0.5*1e12) cycle ! this UbValu was a dummy to keep PCX happy
        if(f4<0.01) then
          f4=r4 ! as if UbValu were 1.0
        else
          f4=r4/f4 ! should be <=1
        end if
        if(jVar<=nNdVar-mPlnt*nVpDn) then
          jCol=1+(jVar-1)/(1+17) ! for iSNod vars
        elseif(jVar<=nNdVar) then
          jCol=jVar-(nNdVar-mPlnt*nVpDn) ! for iPlnt vars
        elseif(jVar<=nNdVar+nContLoB) then
          jCol=jVar-nNdVar ! for Cont UB-vars
        else
          jCol=0 ! flag the final var for aggregate SO2
        end if
        if((PrtDetail>1).or.(f4>1.001))
     +    write(DbgU,'(3i6,2f11.3,f9.5,a2,2a)') iUbV,jVar,jCol,
     +    r4,UbValu(iUbV),f4,QuestionIf(f4>1.001),' xj,UB,Xj/UB for ',
     +    trim(VarDesc(jVar))
      end do
      write(DbgU,'(1x)')
!
      call WriteStrAt(5,5,'Checking inequalities')
      iReq=nSNod*2
      jCol=nNdVar-nVpLk
      do iLink=1,mLink
        if(mReq>=100) exit
        jCol=jCol+nVpLk
        do j=1,nRpLk
          iReq=iReq+1
          if(ReVec(iReq)/=1) cycle
          r4=bVect(iReq)
          QtySum=0.0
          do i=1,nVpLk
            jVar=jCol+i
            f4=FuncCNWAMtx(jVar,iReq)
            if(f4==0.0) cycle
            QtySum=QtySum+f4*xVect(jVar)
            write(DbgU,'(i6,3f12.4,1x,a)') jVar,QtySum,f4,xVect(jVar),
     +        VarDesc(jVar)
          end do
          if(r4<=0.0) then
            f4=1.0
          else
            f4=QtySum/r4
          end if
          write(DbgU,'(i6,f12.4,f6.3,f8.5,a2,i2,2a)') iReq,QtySum,
     +      r4,f4,QuestionIf(f4>1.001),ReVec(iReq),
     +      ' constraint',ReqDesc(iReq)
        end do ! j=1,nRpLk
        write(DbgU,'(1x)')
      end do ! iLink
!
      iReq=iReq+nRpDn-1
      jCol=nNdVar-nVpLk
c     do iLink=1,mLink
c       if(mReq>=100) exit
c       jCol=jCol+nVpLk
c       do j=1,nRpLk
c         iReq=iReq+1
c         if(ReVec(iReq)==0) cycle
          r4=bVect(iReq)
          QtySum=0.0
          do iLink=1,mLink
            jCol=jCol+nVpLk
          do i=1,nVpLk
            jVar=jCol+i
            f4=FuncCNWAMtx(jVar,iReq)
            if(f4==0.0) cycle
            QtySum=QtySum+f4*xVect(jVar)
            write(DbgU,'(i6,3f12.4,1x,a)') jVar,QtySum,f4,xVect(jVar),
     +        VarDesc(jVar)
          end do
          end do ! iLink
          if(r4<=0.0) then
            f4=1.0
          else
            f4=QtySum/r4
          end if
          write(DbgU,'(i6,f12.4,f6.3,f8.5,a2,i2,2a)') iReq,QtySum,
     +      r4,f4,QuestionIf(f4>1.001),ReVec(iReq),
     +      ' constraint',ReqDesc(iReq)
c       end do
        write(DbgU,'(1x)')
c     end do ! iLink
      call WriteStrAt(5,5,'Checking equalities')
      do iReq=nSNod*2+mLink*nRpLk+1,mReq
        if(mReq>=100) exit
        if(ReVec(iReq)/=0) cycle
        r4=bVect(iReq)
        QtySum=0.0
        jCol=nNdVar-nVpLk
        do iLink=1,mLink
          jCol=jCol+nVpLk
c         do j=1,nRpLk
c           iReq=iReq+1
c           if(ReVec(iReq)/=0) cycle
c           r4=bVect(iReq)
c           QtySum=0.0
            do i=1,nVpLk
              jVar=jCol+i
              f4=FuncCNWAMtx(jVar,iReq)
              if(f4==0.0) cycle
              QtySum=QtySum+f4*xVect(jVar)
              write(DbgU,'(i6,3f12.4,1x,a)') jVar,QtySum,f4,xVect(jVar),
     +          VarDesc(jVar)
            end do
          end do ! iLink
          if(r4<=0.0) then
            f4=1.0
          else
            f4=QtySum/r4
          end if
          write(DbgU,'(i6,f12.4,f6.3,f8.5,a2,i2,2a)') iReq,QtySum,
     +      r4,f4,QuestionIf(abs(f4-1.0)>0.01),ReVec(iReq),
     +      ' constraint',ReqDesc(iReq)
          write(DbgU,'(1x)')
      end do
!
      if(iBnUB>0) then
      QtySum=0.0
      do iSNod=1,nSNod
        if(BnOfNode(iSNod)==iBnUB)
     +    QtySum=QtySum+xVect(1+(iSNod-1)*(1+17))
      end do
      r4=bVect(mReq) ! assumed positive here
c     if(r4<=0.0) then
c       f4=QtySum
c     else
        f4=QtySum/r4
c     end if
      write(DbgU,'(i6,f7.3,f6.2,f8.5,a2,2a)') mReq,QtySum,
     +  r4,f4,QuestionIf(f4>1.01),' constraint LEQ',ReqDesc(mReq)
      write(DbgU,'(1x)')
      end if
!
      call flush(DbgU)
      return ! entry CheckSolution
c-----
      entry WriteCommonTitles
      write(OutU,'(a)',advance='no') ' '
      call AppendStr(OutU,'Endpoint')
      call AppendStr(OutU,'Year')
      call AppendStr(OutU,'Unit Name')
      call AppendStr(OutU,'HI Plant ID')
      call AppendStr(OutU,'HI Unit ID')
      return
c-----
      entry WriteCsvPrefix(PriID,SecID)
      write(OutU,'(1x)',advance='no') ! expect advance=no to follow
      call AppendI2w5(OutU,iSc)
      call AppendI2w5(OutU,cYr)
      call AppendStr (OutU,ThisNdName)
      call AppendI2w5(OutU,PriID)
      call AppendI2w5(OutU,SecID)
      return
c-----
      entry ExpleteFinal4Col
      do j=1,4
        call AppendF8p2(OutU,0.0,B1)
      end do
      return
c-----
      entry ReportCNWSolutionDetails(iYr,
     +  BasnID,BnOfNode,NodeID,PnOfNode,LinkNdID,LinkNdSN,
     +  iFocus,Focussed,
     +  NodeQty,NodeQtyUB,
c    +  NodePri,NodeMgC, ! perhaps of interest to the caller
     +  LinkChg,MineFunc,BasnName,NodeName)
!
      write(DbgU,'(//i5,a/)') cYr,'-year Results'
      write(TxtU,'(//i5,a/)') cYr,'-year Results'
      if(nTypesLtd) then
        write(DbgU,'(//i2,a/)') iFocus,'=iteration on nTypesUsed'
        write(TxtU,'(//i2,a/)') iFocus,'=iteration on nTypesUsed'
        if(iFocus==1) then ! save the unescalated vector of costs
          allocate(cVOrg(nVar))
          cVOrg=cVect
        end if
      end if
!
    ! get total production, total cost, and marginal cost at each Mine
      write(TxtU,
     +  '(" SN Sg jVar NodeQty/kT NdQ/Lim CFOB/M$ AvgCFOB MrgCFOB")')
      write(TxtU,
     +  '(" -- -- ---- ---------- ------- ------- ------- -------")')
      MineACst(1:nSNod)=0.0
c     MineMCst(1:nSNod)=0.0
      do iSNod=1,nSNod
        CstSum=0.0
        jVar=1+(iSNod-1)*(1+17) ! for kT from Supply
        NodeQty(iSNod)=xVect(jVar)
        do jSeg=1,17
          jVar=jVar+1
          if(xVect(jVar)<0.1) exit ! with jVar beyond last segment used
          CstSum=CstSum+xVect(jVar)*MineFunc(jSeg,1,iSNod) ! (kT)*($/T) => (k$)
        end do
        if(jSeg<2) jSeg=2 ! marginal cost is that of the 1st segment (unlikely)
        MineMCst(iSNod)=MineFunc(jSeg-1,1,iSNod) ! ($/T)
        MineACst(iSNod)=MineMCst(iSNod) ! ($/T) default needed in case Qty=0
        MineCost(iSNod)=CstSum*1000.0 ! ($)
        if(NodeQty(iSNod)>0.1)
     +    MineACst(iSNod)=
     +    MineCost(iSNod)/(NodeQty(iSNod)*1000.0) ! ($)/((kT)*(1/k)) => ($/T)
        write(TxtU,'(2i3,i5,f11.2,f8.5,3f8.2,1x,a)') iSNod,jSeg-1,jVar,
     +    NodeQty(iSNod),
     +    NodeQty(iSNod)/NodeQtyUB(iSNod),CstSum/1000.0, ! note use of 1000.0 above
     +    MineACst(iSNod),MineMCst(iSNod),trim(NodeName(iSNod))
      end do
!
      OFV=0.0d0
      SO2Penalty=0.0d0
      nCTObjBias=0.0d0
      if(PrtDetail>0) then
        if(PrtDetail>1) write(DbgU,'(/a/a)')
     +    '   jVar      c(jVar)      x(jVar)= x(jVar) ObjctFunc',
c    +    ' SOPenalty',
     +    ' ------ ------------ ------------ -------- ---------'
c    +    ' ---------'
        iCol=nNdVar+mLink*nVpLk
        do jVar=1,nVar
          r4=cVect(jVar)*xVect(jVar)
          OFV=OFV+r4
          if(PrtDetail>1) then
            write(DbgU,'(i7,2e13.6,f9.4,e10.3,1x,a)')
     +        jVar,cVect(jVar),xVect(jVar),xVect(jVar),
     +        OFV, ! SO2Penalty, ! nCTObjBias,
     +        VarDesc(jVar)
            if((jVar>=nNdVar).and.((nVpLk>1).or.(jVar==nNdVar+1)).and.
     +        (mod(jVar-nNdVar,nVpLk)==0)) write(DbgU,'(1x)')
          end if
        end do
      else
        OFV=DotProd8(cVect,xVect,nVar)
      end if
!
      call WriteStrAt(1,1,'after accum OFV')
      if(PrtDetail>0) then
        ContraCost=0.0d0
        do iPlnt=1,mPlnt
          do iSNod=1,nSNod
            ContraCost=ContraCost+ContCst(iYr,iSNod,iPlnt)
          end do
        end do
        ContraValu=0.0d0
      ! accumulate OFV value attributable to shipping and SO2 costs
c       do iLbV=nSNod+mPlnt+1,nLbV ! sum sunk costs across contract amounts in LbValu
c         jVar=jLbVec(iLbV)
c       iContlnt=0
c       nContLoB=0
        HiPlntID=-1
        iSNod=-1
        iLbv=nSNod+mPlnt
      call WriteStrAt(1,1,'before iLink-loop')
        do iLink=1,mLink
          piSNod=iSNod
          iSNod=LinkNdSN(0,iLink)
          pHPlntID=HiPlntID
          HiPlntID=LinkNdID(1,iLink)/25
        write(DbgU,'(4i6,a)') iYr,iLink,iSNod,HiPlntID,' iLink@1'
          if((iSNod==piSNod).and.(HiPlntID==pHPlntID)) cycle
c         iContlnt=iContlnt+1 ! cpunt CoalTypeToPlant contracts possible
          iPlnt=LinkNdSN(1,iLink)
          r4=ContQty(iYr,iSNod,iPlnt) ! (kT)
        write(DbgU,'(4i6,a)') iYr,iLink,iSNod,iPlnt,' iLink@2'
          if(r4==0.0) cycle
c         nContLoB=nContLoB+1 ! count only Cont contracts used this year
c         FracBtuTokT=PlntQty(iPlnt)*1000.0/(HeatConUB(iSNod)*2000.0) ! (MBtu)*(k/M)/((Btu/Lb)*(Lb/T)) => (kT)
          jVar=nNdVar+iLink
          iLbV=iLbV+1
          ContraValu=ContraValu+LbValu(iLbV)*cVect(jVar) ! transport+SO2 penalty
        end do
      call WriteStrAt(1,1,'after  iLink-loop')
      ! accumulate OFV value attributable to coal-supply costs
        do iSNod=1,nSNod ! sum sunk costs across contract amounts in xVect
          QtySum=0.0
          CstSum=0.0
          do iPlnt=1,mPlnt ! sum iSNod contract quantity & price across plants
            do iLink=1,mLink ! scan for 1st link to iPlnt
              if(LinkNdSN(0,iLink)/=iSNod) cycle ! only iLink connects iDNod & iSNod
              if(LinkNdSN(1,iLink)==iPlnt) exit
            end do
            if(iLink>mLink) cycle ! no link exists from iSNod to iPlnt
            r4=ContQty(iYr,iSNod,iPlnt) ! (kT)
            f4=r4*LinkChg(iLink)*1000.0 ! (kT)*($/T)*(n/k) => ($) for shipping
            QtySum=QtySum+r4 ! (kT)
            CstSum=CstSum+ContCst(iYr,iSNod,iPlnt) ! ($) addend includes shipping
     +        -f4 ! CstSum excludes shipping
            ContraValu=ContraValu+f4 ! ($) addend for shipping only
          end do
        ! augment ContraValu with value of FOB coal in contract
          ContraValu=ContraValu+QtySum*MineACst(iSNod)*1000.0 ! (kT)*($/T)*(n/k) => ($)
c NOT     if(QtySum<=0.1) cycle
c NOT   ! report below the ex-contract average cost of each Supply CoalType
c NOT     MineACst(iSNod)=(MineCost(iSNod)-CstSum) ! ($)
c NOT+      /((NodeQty(iSNod)-QtySum)*1000.0) ! (kT)*(n/k) => (T)
c NOT-lines above disabled 20100901 until MineACst is better defined
        end do ! iSNod
        call WriteStrAt(1,1,'after iSNod-loop')
!
        write(DbgU,'(/(e14.6,a))')
     +    OFV,       ' objective-function value (OFV)',
     +    ContraValu," contracts' value in OFV",
     +    nCTObjBias,' nCT bias    in OFV',
     +    SO2Penalty,' SO2 penalties in OFV',OFV-ContraValu-nCTObjBias-
     +    SO2Penalty,' cost of non-contract coal+transport',
     +    ContraCost,' cost of     contract coal+transport'
        ! note:  unclear whether ContraCost excludes SO2 penalties
      end if ! PrtDetail>0
      call WriteStrAt(1,1,'after if PrtDetail')
!
!
      write(TxtU,'(/a)') ' Fractional Qty Allocated to Mines, in mills'
      write(TxtU,'(1x)',advance='no') ! expect advance=no to follow
      write(TxtU,'( 99i3)',advance='no') (iSNod,iSNod=1,nSNod)
      write(TxtU,'( 1x,6i2,a)',advance='no') (j,j=0,5), ! each of 6 bins has width 10%
c    +  ' #_in_non-0_bins DNode DNodeQty/kT AvCFOB MgCFOB AvCDvd MgCDvd'
     +  ' #InNzBins DNode DNodeQty/kT AvCFOB MgCFOB AvCDvd MgCDvd'
      write(TxtU,'(1x)',advance='yes') ! writes CrLf after blank
!
      write(TxtU,'(1x)',advance='no') ! expect advance=no to follow
      write(TxtU,'( 99a3)',advance='no') (' --',iSNod=1,nSNod)
      write(TxtU,'( 1x,11a)',advance='no') (' -',j=0,5),
     +  ' --------- ----- -----------',(' ------',j=1,4)
      write(TxtU,'(1x)',advance='yes') ! writes CrLf after blank
!
!
      do OutU=BnvU,CtvU ! presumes these unit numbers are contiguous
        call WriteCommonTitles()
      ! write file-specific column-titles
        if(OutU==BnvU) then
c         write(DbgU,'(a)') ' Quantity(kTon) from Basins to Units'
          do iBasn=1,mBasn
c           call AppendI2w5(OutU,BasnID(iBasn)) ! basin names are N.A.
            call AppendStr(OutU,BasnName(iBasn))
          end do
        else
c         write(DbgU,'(a)') ' Quantity or Cost from Mines to Units'
          do iSNod=1,nSNod
            call AppendStr(OutU,NodeName(iSNod))
          end do
        end if
        if    (OutU==MdcU) then
          call AppendStr(OutU,'WtdMrgCstDvd')
        elseif(OutU==AdcU) then
          call AppendStr(OutU,'WtdAvgCstFOB')
          call AppendStr(OutU,'WtdMrgCstFOB')
          call AppendStr(OutU,'WtdAvgCstDvd')
          call AppendStr(OutU,'WtdMrgCstDvd')
        end if
        write(OutU,'(1x)',advance='yes') ! writes CrLf after blank
c       call flush(OutU)
      end do
!
      LkQtyAtN(1:mNode)=0.0
      DecimBinCount=0
      nInB2LogQty=0
      PctBinCount=0
      Focussed=B1
      nNzQty=0
      MeanQty=0.0
      MeanLog=0.0
      VnceQty=0.0
      VnceLog=0.0
      EstMeanQty=0.0
      EstMeanLog=0.0
      SupDmndQty=0.0
      iCol=nNdVar ! +nContLoB
      do iDNod=nSNod+1,mNode
      ! get mine-specific quantity shipped and cost to iDNod
        iPlnt=PnOfNode(iDNod) ! needed in ContQty() below
        TransCst(1:nSNod)=0.0
      ! write common prefix for each record
        k=NodeID(iDNod)
        i=k/25 ! HiPlntID
        j=mod(k,25) ! HiUnitID
        ThisNdName=NodeName(iDNod)
        do OutU=BnvU,CtvU
          call WriteCsvPrefix(i,j)
        end do
!
      ! fill columns of basin-aggregate quantity
        BasinQty(1:mBasn)=0.0
        TransQty(1:nSNod)=0.0
        StatsQty(1:nSNod)=0.0
        do iLink=1,mLink
c         if(LinkNdSN(1,iLink)/=iDNod) cycle ! only iLink connects iDNod & iSNod
          if(LinkNdSN(1,iLink)/=iPlnt) cycle ! only iLink connects iPlnt & iSNod
          iSNod=LinkNdSN(0,iLink)
          iBasn=BnOfNode(iSNod)
          if((1>iBasn).or.(iBasn>mBasn)) call ps(1,'invalid iBasn')
          jCol=iCol+(iLink-1)*nVpLk+1 ! 1st of nVpLk is fBtu
c         FracBtuTokT=PlntQty(iPlnt)*1000.0/(HeatConUB(iSNod)*2000.0) ! (MBtu)*(k/M)/((Btu/Lb)*(Lb/T)) => (kT)
          r4=xVect(jCol)*kTpFB(iLink)*fPlntUnit(iDNod) ! allocate iPlnt to iDNod
          LkQtyAtN(iSNod)=LkQtyAtN(iSNod)+r4 ! (kT)
          LkQtyAtN(iDNod)=LkQtyAtN(iDNod)+r4 ! (kT)
          TransCst(iSNod)=LinkChg(iLink) ! exclusive of SO2 & CO2 penalties
          BasinQty(iBasn)=BasinQty(iBasn)+r4
          TransQty(iSNod)=amax1(0.0,r4) ! (kT) not accumulated since iSNod is unique
          StatsQty(iSNod)=TransQty(iSNod)
c         k=MilliFrac(TransQty(iSNod),LkQtyAtN(iDNod)) ! note (kT) not (fBtu)
c         write(DbgU,'(5i6,3f9.3,a)') iDNod,iLink,iSNod,iPlnt,k,
c    +      r4,LkQtyAtN(iDNod),TransQty(iSNod),' TQ'
        end do
ccc     write(TxtU,'(i6,99a4)') iDNod,(A4Equiv(iSNod),iSNod=1,nSNod)
        do iBasn=1,mBasn
          call AppendF8p2(BnvU,BasinQty(iBasn),B1)
        end do
!
      ! fill columns of type-specific quantity, A&M cost FOB, A&M cost Dvd
        WtdCost=0.0 ! WtdCost(0:4)=0.0
        do iSNod=1,nSNod
          QtySum=TransQty(iSNod) ! (kT)
c         f4=amin1(1.0,QtySum/amax1(1.0,NodeQty(iSNod))) ! fraction of Qty allocated to iDNod
          SNodMCst=MineMCst(iSNod)
c         if(QtySum<0.1) then
c           SNodACst=0.0
c         else
            SNodACst=MineACst(iSNod) ! average cost at the Mine
c         end if
c         write(DbgU,'(i6,i3,4f10.2,a)') iDNod,iSNod,
c    +      QtySum,NodeQty(iSNod),SNodACst,SNodMCst,' q,Q,A,M cost'
          if(TransCst(iSNod)>0.0) then
            DNodACst=SNodACst+TransCst(iSNod) ! addend is LinkChg(iLink)
            DNodMCst=SNodMCst+TransCst(iSNod)
          else
            DNodACst=0.0 ! implies 'no delivery path from iSNod to iDNod'
            DNodMCst=0.0
            QtySum=0.0 ! squelch any noise in the weights
          end if
          call AppendF8p2(MnvU,QtySum,B1)
          call AppendF8p2(MdcU,DNodMCst,B1) ! marginal cost Dvd ($/T) varies with iDNod
cNOT      call AppendF8p2(AdcU,SNodACst,B1) ! average cost FOB ($/T) invariant with iDNod
          call AppendF8p2(AdcU,DNodACst,B1) ! average cost Dvd ($/T) varies with iDNod
          call AppendF8p2(CtvU,ContQty(iYr,iSNod,iPlnt),B1) ! (kT)
          WtdCost(0)=WtdCost(0)+QtySum          ! sum of kT across iSNod for iDNod
          WtdCost(1)=WtdCost(1)+QtySum*SNodACst ! wtd average  cost FOB ($/T)
          WtdCost(2)=WtdCost(2)+QtySum*SNodMCst ! wtd marginal cost FOB ($/T)
          WtdCost(3)=WtdCost(3)+QtySum*DNodACst ! wtd average  cost Dvd ($/T)
          WtdCost(4)=WtdCost(4)+QtySum*DNodMCst ! wtd marginal cost Dvd ($/T)
c         write(DbgU,'(2i6,5f12.2,a)') iDNod,iSNod,WtdCost,' WtdCost'
        ! accumulate statistics for display only
          r4=StatsQty(iSNod)
          if(r4<1.0) cycle ! 0.1) cycle
          LogQty=alog(r4)
          MeanQty=MeanQty+ r4
          MeanLog=MeanLog+ LogQty
          if(MeanQty==0.0) then
            EstMeanQty=r4
            EstMeanLog=LogQty
          else
            VnceQty=VnceQty+(r4-EstMeanQty)**2
            VnceLog=VnceLog+(LogQty-EstMeanLog)**2
          end if
          i=nint(r4)
          do j=0,15
            if(i==0) exit ! with j>B2LogQty
            i=i/2
          end do
          j=j-1
          nInB2LogQty(j)=nInB2LogQty(j)+1
          nNzQty=nNzQty+1
        end do ! iSNod
      ! the upper-left body of the AdcU-file now contains ACDvd
        QtySum=WtdCost(0)
        nCTGeqSThr=0
        iSNrank1=0
        iSNrank2=0
        mRank1st=0
        mRank2nd=0
        QuintBinCount=0 ! QuintBinCount(0:5)=0 ! imagine a crude histogram
        write(TxtU,'(1x)',advance='no') ! expect advance=no to follow
        do iSNod=1,nSNod
          k=MilliFrac(TransQty(iSNod),LkQtyAtN(iDNod))
          write(TxtU,'( i3)',advance='no') k ! fractional usage/mills at iSNod
          if(k<1) cycle
          jBin=min(k/100,5) ! (jBin==5) => (k>=500) => (TQ(iSNod)>=LQ(iDNod)/2)
c         if(jBin>0) nCTGeq0pct=nCTGeq0pct+1
          if(k>=FullSignif*1000.0) then
            nCTGeqSThr=nCTGeqSThr+1 ! count significant suppliers
            if    (mRank1st<k) then
              mRank2nd=mRank1st
              mRank1st=k
              iSNrank2=iSNrank1
              iSNrank1=iSNod
            elseif(mRank2nd<k) then
              mRank2nd=k
              iSNrank2=iSNod
            end if
            write(DbgU,'(5i5,2i4,a)') iDNod,k,nCTGeqSThr,
     +        iSNrank1,iSNrank2,mRank1st,mRank2nd,' i&v of rank 1&2'
          end if
          QuintBinCount(jBin)=QuintBinCount(jBin)+1
          if(k>1000) call ps(1,'MilliFrac>1000')
          jBin=k/10
          PctBinCount(jBin)=PctBinCount(jBin)+1
        end do ! iSNod
        if(nTypesLtd.and.(nCTGeqSThr>2)) then
          r4=10.0**float(iFocus) ! escalation factor
          do iSNod=1,nSNod
            if((iSNod==iSNrank1).or.(iSNod==iSNrank2)) cycle ! focus on these 2
            k=MilliFrac(TransQty(iSNod),LkQtyAtN(iDNod))
            if(k>=FullSignif*1000.0) then ! preclude use by raising cost of iLink
            ! nCTGeqSThr=nCTGeqSThr+1 ! count significant suppliers
              do iLink=1,mLink
                if(LinkNdSN(1,iLink)/=iPlnt) cycle
                if(LinkNdSN(0,iLink)==iSNod) exit
              end do
              if(iLink>mLink) call ps(1,'error finding iLink for Esc')
              jVar=nNdVar+(iLink-1)*nVpLk+1
              cVect(jVar)=cVOrg(jVar)*r4
              write(DbgU,'(4i5,i6,e10.3,a)') iDNod,iSNod,iPlnt,iLink,
     +          jVar,cVect(jVar),' afterEsc'
              Focussed=B0
            end if
          end do
        end if
c       write(DbgU,'(1x,6i2,a,i1,    i6,a,f12.2)') (QuintBinCount(j),
c    +    j=0,5),'/',nCTGeqSThr,iDNod,' QamAM:',QtySum
        write(TxtU,'( a,6i2,a,i1,a5,i3,i6,f12.2)',advance='no') ';',
     +    (QuintBinCount(j),j=0,5),':',nCTGeqSThr,
     +    ' @Plt',iPlnt,iDNod,QtySum
        DecimBinCount(nCTGeqSThr)=DecimBinCount(nCTGeqSThr)+1
        if(SupDmndQty<QtySum) SupDmndQty=QtySum ! of interest for scaling Hp� & Hm�
!
        r4=0.0
        nzDivisor=(QtySum>0.1)
        do j=1,4 ! append columns of quantity-weighted-average prices
          if(nzDivisor) r4=WtdCost(j)/QtySum
          if(j==4)
     +    call AppendF8p2(MdcU,r4,B1)
          call AppendF8p2(AdcU,r4,B1)
          write(TxtU,'( f7.2)',advance='no') r4
        end do
        write(TxtU,'(1x)',advance='yes') ! writes CrLf after blank
!
        do OutU=BnvU,CtvU
          write(OutU,'(1x)',advance='yes') ! writes CrLf after blank
        end do
      end do ! iDNod
    ! finalize mean and s.d. of StatsQty
      r4=float(nNzQty)
      MeanQty=MeanQty/r4
      MeanLog=MeanLog/r4
      VnceQty=VnceQty/r4-(MeanLog-EstMeanQty)**2
      VnceLog=VnceLog/r4-(MeanLog-EstMeanLog)**2
      StDvQty=0.0
      StDvLog=0.0
      if(VnceQty>0.0) StDvQty=VnceQty**0.5
      if(VnceLog>0.0) StDvLog=VnceLog**0.5
      MeanLog=MeanLog/log(2.0) ! x=2**u=exp(u*ln(2)) => u=B2L(x)=ln(x)/ln(2)
      StDvLog=StDvLog/log(2.0)
!
    ! write summary lines
    ! write common prefix for each record
      ThisNdName='column total'
      do OutU=MnvU,AdcU ! write common fields
        if(OutU==MdcU) cycle
  700   call WriteCsvPrefix(i2_0,i2_0)
        do iSNod=1,nSNod
          if(OutU==MnvU) then
            if(ThisNdName(1:1)=='c') then
              r4=NodeQty (iSNod) ! 1st pass
            else
              r4=LkQtyAtN(iSNod) ! 2nd pass
            end if
            call AppendF8p2(MnvU,r4,B1)
          else
            call AppendF8p2(AdcU,MineACst(iSNod),B1)
          end if
        end do
        if(OutU==AdcU) call ExpleteFinal4Col()
        write(OutU,'(1x)',advance='yes') ! writes CrLf after blank
        if(ThisNdName(1:1)=='c') then ! write checksum to MnvU
          ThisNdName='sum to paths'
          goto 700
        end if
        ThisNdName='Unwtd Avg Cost FOB'
      end do
!
      OutU=MnvU
      ThisNdName='Unwtd Capacity Factor'
      call WriteCsvPrefix(i2_0,i2_0)
c     do iSNod=1,nSNod
c       call AppendF8p2(OutU,NodeQty(iSNod)/NodeQtyUB(iSNod),B1)
c     end do
cNOT  call ExpleteFinal4Col()
      write(OutU,'( 99(f8.6,","))',advance='no') (NodeQty(iSNod)/
     +  NodeQtyUB(iSNod),iSNod=1,nSNod)
      write(OutU,'(1x)',advance='yes') ! writes CrLf after blank
!
      ThisNdName='Unwtd Mrg Cost FOB'
      do OutU=MdcU,AdcU
        call WriteCsvPrefix(i2_0,i2_0)
        do iSNod=1,nSNod
          call AppendF8p2(OutU,MineMCst(iSNod),B1)
        end do
        if(OutU==MdcU) then
          call AppendF8p2(OutU,0.0,B1)
        else
          call ExpleteFinal4Col()
        end if
        write(OutU,'(1x)',advance='yes') ! writes CrLf after blank
      end do
!
      write(TxtU,'(/a,f6.3,a)')
     +  ' Number of Demand Units in #CT-used Bins @',
     +  FullSignif,'=Significance_Threshold'
      write(TxtU,'(11i5,a)')    (j,j=0,10),' SupDemandQty'
      write(TxtU,'(12a)') (' ----',j=0,10),' ------------'
      write(TxtU,'(11i5,f13.2/)') DecimBincount,SupDmndQty
!
      write(TxtU,'(/a)') ' Number of Demand Units in Base2LogQ Bins'
c     write(TxtU,'(16i4,a)')   (j,j=0,15),' nNzDemandQty'
c     write(TxtU,'(17a)') (' ---',j=0,15),' ------------'
c     write(TxtU,'(16i4,i13/)') nInB2LogQty,nNzQty
      do i=0,15
        k=nInB2LogQty(i)/5
        write(TxtU,'(i3,i5,1x,999a1)') i,nInB2LogQty(i),
     +    (AsteriskIf(j),j=0,k)
      end do
      write(TxtU,'(a2,i6)') ' �',nNzQty
!
c     write(TxtU,'(/3f9.2,a)') MeanQty,StDvQty,MeanQty-2.0*StDvQty,
c    +  ' mean & s.d. of      (Qty/kT), Q@(z=-2)'
      write(TxtU,'( 3f9.2,a)') MeanLog,StDvLog,exp((MeanLog-2.0*StDvLog)
     +  *log(2.0)),' mean & s.d. of B2Log(Qty/kT), Q@(z=-2)'
!
      write(TxtU,'(/a)') ' Histogram of MilliFraction>1 of Demand kTon'
      nNzQty=0
      do i=0,100
        k=PctBinCount(i)
        nNzQty=nNzQty+k
        k=k/7 ! for a peak around 500
c       if(k>998) call ps(1,'huge PctBinCount') ! cover pathological cases
        if(k>998) then ! cover pathological cases
          write(DbgU,'(3i9,a)') i,PctBinCount(i),k,' huge PctBinCount'
          k=998
        end if
        write(TxtU,'(2i4,1x,999a1)') i,PctBinCount(i),
     +    (AsteriskIf(j),j=0,k)
      end do
      write(TxtU,'(a2,i6)') ' �',nNzQty
!
      write(DbgU,'(a,99f9.3)')' MineACst',(MineACst(j),j=1,nSNod)
      write(DbgU,'(a,99f9.3)')' MineMCst',(MineMCst(j),j=1,nSNod)
      write(DbgU,'(a,99f9.1)')' Mine_Qty',(NodeQty (j),j=1,nSNod)
      write(DbgU,'(a,99f9.6)')' MineUtil',(NodeQty(j)/
     +  NodeQtyUB(j),j=1,nSNod)
!
      call timer(EndCentiSec)
      ExecET=EndCentiSec-OrgCentiSec
      write(DbgU,'(f8.2,a,2i11)') float(ExecET)*0.01,
     +  ' seconds elapsed during execution ' ! ,OrgCentiSec,EndCentiSec
      call flush(DbgU)
      return ! entry ReportCNWSolutionDetails
c-----
      entry OpenCNWOutFiles(StudyName,OpenDbgU)
      if(OpenDbgU) then
        FileName='CoalNtwk.dbg'
        ZeroIfExtant=-1 ! OpenFmFile caller will handle absence
c       enable next 2 lines when DbgU/9004/ is used above
c       call OpenFmFile(DbgU,2,2,ZeroIfExtant,B0,DirPath,FileName)
c       if(ZeroIfExtant/=0) goto 902
      else
        write(FileName,'(4a)') 'CnwUsage', ! output:  fraction of MineQty alloc to Units
     +    AHyphen,trim(StudyName),OutSuffix
        ZeroIfExtant=-1 ! OpenFmFile caller will handle absence
        call OpenFmFile(TxtU,2,2,ZeroIfExtant,B0,DirPath,FileName)
        if(ZeroIfExtant/=0) goto 902
!
        write(FileName,'(4a)') 'CnwBasnV', ! output:  Volume/kT from Basins to Units
     +    AHyphen,trim(StudyName),OutSuffix
        ZeroIfExtant=-1 ! OpenFmFile caller will handle absence
        call OpenFmFile(BnvU,2,2,ZeroIfExtant,B0,DirPath,FileName)
        if(ZeroIfExtant/=0) goto 902
!
        write(FileName,'(4a)') 'CnwMineV', ! output:  Volume/kT from Mines to Units
     +    AHyphen,trim(StudyName),OutSuffix
        ZeroIfExtant=-1 ! OpenFmFile caller will handle absence
        call OpenFmFile(MnvU,2,2,ZeroIfExtant,B0,DirPath,FileName)
        if(ZeroIfExtant/=0) goto 902
!
        write(FileName,'(4a)') 'CnwMCDvd', ! output:  Marginal Cost at Units, Delivered
     +    AHyphen,trim(StudyName),OutSuffix
        ZeroIfExtant=-1 ! OpenFmFile caller will handle absence
        call OpenFmFile(MdcU,2,2,ZeroIfExtant,B0,DirPath,FileName)
        if(ZeroIfExtant/=0) goto 902
!
        write(FileName,'(4a)') 'CnwACDvd', ! output:  Average Cost at Units, Delivered
     +    AHyphen,trim(StudyName),OutSuffix
        ZeroIfExtant=-1 ! OpenFmFile caller will handle absence
        call OpenFmFile(AdcU,2,2,ZeroIfExtant,B0,DirPath,FileName)
        if(ZeroIfExtant/=0) goto 902
!
        write(FileName,'(4a)') 'CnwContV', ! output:  contract Volume/kT shipped from Mines to Units
     +    AHyphen,trim(StudyName),OutSuffix
        ZeroIfExtant=-1 ! OpenFmFile caller will handle absence
        call OpenFmFile(CtvU,2,2,ZeroIfExtant,B0,DirPath,FileName)
        if(ZeroIfExtant/=0) goto 902
      end if
      return ! entry OpenCNWOutFiles
  902 call ps(1,'Error opening file in replace-mode:  '//
     +  trim(FileName))
      return ! entry OpenCNWOutFiles
c-----
    ! the following 3 entry blocks were originally the first in subroutine,
    ! but were moved to allow more room in the ReadCnwD.fpp source-file
c-----
      entry OpenCNWInpFiles(InpCsvFN)
      allocate(InpCsvU(5))
      do iInpCsv=1,5 ! open CSV files for reading
        InpCsvU(iInpCsv)=0 ! indicating not (yet) opened
        InpU=900+iInpCsv
        FileName=trim(InpCsvFN(iInpCsv))
        ZeroIfExtant=-1 ! OpenFmFile caller will handle absence
        call OpenFmFile(InpU,0,2,ZeroIfExtant,B0,DirPath,FileName)
        write(DbgU,'(3i5,1x,a)') iInpCsv,InpU,ZeroIfExtant,
     +    trim(FileName)
        if(ZeroIfExtant/=0) then
          if(iInpCsv<5) goto 901
          InpU=-InpU ! flag unit as unreadable
        end if
c       call SkipLines(InpU,1) ! the "9," line
        InpCsvU(iInpCsv)=InpU
      end do
      return
  901 call ps(1,'Error opening file in old-mode:  '//trim(FileName))
c-----
      entry GetBasnCount(nBasn)
      InpU=InpCsvU(1) ! Basin data
      nBasn=0
      do
        read(InpU,'(a)',err=405,end=405) OneLine
        write(DbgU,'(i4,1x,a)') InpU,trim(OneLine)
        read(OneLine,*,err=405,end=405) FirstCh
        if((FirstCh=='9').or.(FirstCh=='7')) cycle
        read(OneLine,*,err=405,end=405) FirstCh,ThisNdName,cDummy
        if((FirstCh/='1').or.Negat(cDummy)) cycle
        nBasn=nBasn+1
        write(DbgU,'(i3,2a)') nBasn,' [unprec. Basin] ',ThisNdName
      end do
  405 write(DbgU,'(i4," EoF"/)') InpU
      if(nBasn==0) call ps(1,'No Supply basin counted')
      if(nBasn>99) call ps(1,'Limit of 99 Supply-basins exceeded')
!
      mBasn=nBasn ! only mBasn should apper herein below ReadCNWLinkData
      return
c-----
      entry GetNodeCount(nNode,nBasn,nCCSegs,
     +  BasnID,BasnQtyLB,BasnQtyUB,BasnName)
      nCCSegs=17 ! inform caller of array sizes
      InpU=InpCsvU(1) ! Basin data
      rewind(InpU)
      iBasn=0
      iBnUB=0
      do
        read(InpU,'(a)',err=408,end=408) OneLine
        write(DbgU,'(i4,1x,a)') InpU,trim(OneLine)
        read(OneLine,*,err=408,end=408) FirstCh,ThisNdName,cDummy
        if((FirstCh/='1').or.Negat(cDummy)) cycle
        iBasn=iBasn+1
        if(iBasn>nBasn) call ps(1,'excessive iBasn')
        read(OneLine,*,err=408,end=408) FirstCh,ThisNdName,cDummy,
     +    cDummy,BasnID(iBasn),cDummy, ! skip Basin_Name and SQb2008 fields
     +    BasnQtyLB(iBasn),BasnQtyUB(iBasn)
        BasnName(iBasn)=ThisNdName
        write(DbgU,'(2i5,2f12.2,1x,a)') iBasn,BasnID(iBasn),
     +    BasnQtyLB(iBasn),BasnQtyUB(iBasn),trim(ThisNdName)
        if(BasnQtyUB(iBasn)<990000.0) then ! in kT
          if(iBnUB/=0) call ps(1,'Only 1 basin may be upper-bounded')
          iBnUB=iBasn ! assume that 999999 implies 'no upper bound'
        end if
      end do
  408 write(DbgU,'(i4," EoF"/)') InpU
!
!
      InpU=InpCsvU(2) ! Supply-Node data
      nSNod=0
      do
        read(InpU,'(a)',err=410,end=410) OneLine
        write(DbgU,'(i4,1x,a)') InpU,trim(OneLine)
        read(OneLine,*,err=410,end=410) FirstCh,ThisNdName,cDummy
        if((FirstCh/='1').or.Negat(cDummy)) cycle
        read(OneLine,*,err=410,end=410) FirstCh,ThisNdName,cDummy,j
        if(IndexIn(BasnID,nBasn,j)>nBasn) cycle ! inactive/disabled
        nSNod=nSNod+1
c       write(DbgU,'(i3,2a)') nSNod,' SupplyNode ',ThisNdName
      end do
  410 write(DbgU,'(i4," EoF"/)') InpU
      if(nSNod==0) call ps(1,'Zero active Supply-nodes counted')
      if(nSNod>99) call ps(1,'Limit of 99 Supply-nodes exceeded')
      nNode=nSNod
!
      InpU=InpCsvU(3) ! Demand-Node data
      nDNod=0
      do
        read(InpU,'(a)',err=412,end=412) OneLine
        write(DbgU,'(i4,1x,a)') InpU,trim(OneLine)
        read(OneLine,*,err=412,end=412) FirstCh,ThisNdName,cDummy
        if((FirstCh/='1').or.Negat(cDummy)) cycle
        nDNod=nDNod+1
c       write(DbgU,'(i5,2a)') nDNod,' DemandNode ',ThisNdName
      end do
  412 write(DbgU,'(i4," EoF"/)') InpU
      if(nDNod==0) call ps(1,'No Demand node counted')
      nDNod=nDNod-1 ! account for expected record appended (SO2 limit)
      nNode=nSNod+nDNod
!
      write(DbgU,'(3i5,a)') nSNod,nDNod,nNode,' nodes to be allocated'
      if(nDNod==0) call ps(1,'Zero active Demand-nodes counted')
      return ! entry GetNodeCount
c-----
      entry CloseCNWInpFiles
      do iInpCsv=1,5 ! close input files
        InpU=InpCsvU(iInpCsv)
        if(InpU>0) close(InpU)
      end do
      deallocate(InpCsvU)
      return
c-----
      entry CloseCNWOutFiles
      do OutU=BnvU,CtvU
        close(OutU)
      end do
      close(TxtU)
c     close(DbgU)
      return
c-----
      entry CNWIncrReq
c     if(iReq>0) write(DbgU,'(i6,a)') iReq,ReqDesc(iReq)
      iReq=iReq+1
      if(iReq>mReq) call ps(1,'allocation error:  insufficient mReq')
      return
c-----
      entry CNWIncrVar
c     if(jVar>0) write(DbgU,'(i6,1x,a)') jVar,VarDesc(jVar)
      jVar=jVar+1
      if(jVar>nVar) call ps(1,'allocation error:  insufficient nVar')
      return
c-----
      entry CNWIncrLB
      iLbV=iLbV+1
      if(iLbV>nLbV) call ps(1,'allocation error:  insufficient nLbV')
      jLbVec(iLbV)=jVar
      return
c-----
      entry CNWIncrUB
      iUbV=iUbV+1
      if(iUbV>nUbV) call ps(1,'allocation error:  insufficient nUbV')
      jUbVec(iUbV)=jVar
      return
c-----
      entry AssignCNWAMtx(OneBasedCol,OneBasedRow,ACMvalue)
      if(ConsMtSize==ConsMtSLim) then ! move vectors' contents into larger space
        write(4,'(i9,a)') ConsMtSLim,' < # of non-zeroes in ConsMtx'
        allocate(zbColHold(ConsMtSLim)) ! temporary swap-space
        allocate(zbRowHold(ConsMtSLim))
        allocate(ConsEHold(ConsMtSLim))
      ! save copies of full vectors in ~Hold
        zbColHold=zbColOfNze
        zbRowHold=zbRowOfNze
        ConsEHold=ConsMtxNze
        deallocate(zbColOfNze,zbRowOfNze,ConsMtxNze)
        ConsMtSLim=ConsMtSLim*2 ! double vectors' size-limit
        allocate(zbColOfNze(ConsMtSLim))
        allocate(zbRowOfNze(ConsMtSLim))
        allocate(ConsMtxNze(ConsMtSLim))
      ! restore saved values from ~Hold vectors
        zbColOfNze(1:ConsMtSize)=zbColHold ! (1:ConsMtSize)
        zbRowOfNze(1:ConsMtSize)=zbRowHold ! (1:ConsMtSize)
        ConsMtxNze(1:ConsMtSize)=ConsEHold ! (1:ConsMtSize)
        deallocate(zbColHold,zbRowHold,ConsEHold) ! free swap-space
      end if
      ConsMtSize=ConsMtSize+1
c     OneBasedOfs=OneBasedCol+(OneBasedRow-1)*nVar ! for column=major order
c     OneBasedOfs=OneBasedRow+(OneBasedCol-1)*mReq ! for row-major order
      zbColOfNze(ConsMtSize)=OneBasedCol-1 ! note that subscripts here ...
      zbRowOfNze(ConsMtSize)=OneBasedRow-1
c     ConsMtxOfs(ConsMtSize)=OneBasedOfs
      ConsMtxNze(ConsMtSize)=ACMvalue      ! ... are kept as 1-based
      return ! entry AssignCNWAMtx
c-----
      entry ReturnCNWAMtx(OneBasedCol,OneBasedRow,RCMvalue)
    ! use the fact that entries in ConsMtxNze are indexed iReq+(jVar-1)*mReq
      RCMvalue=0.0 ! default commonly valid
c     OneBasedOfs=OneBasedCol+(OneBasedRow-1)*nVar ! for column=major order
c     OneBasedOfs=OneBasedRow+(OneBasedCol-1)*mReq ! for row-major order
c     if(OneBasedOfs>ConsMtxOfs(ConsMtSize)) return
c     if(OneBasedOfs<ConsMtxOfs(1         )) return ! unlikely
c     do MidIndex=1,ConsMtSize
c       if(ConsMtxOfs(MidIndex)==OneBasedOfs) exit
c     end do
c     if(MidIndex<=ConsMtSize) RCMvalue=ConsMtxNze(MidIndex) ! e;se retain 0.0
    ! after 20070919 search separate row-major arrays for zbCol and zbRow
      zbCol=OneBasedCol-1
      zbRow=OneBasedRow-1
      OnTgtCol=B0
      OnTgtRow=B0
      do iNze=1,ConsMtSize
        if(zbColOfNze(iNze)==zbCol) then ! Nze for this column are contiguous
          OnTgtCol=B1
          if(zbRowOfNze(iNze)==zbRow) then ! (iNze) matching zbCol & zbRow
            OnTgtRow=B1
            exit
          end if
        else
          if(OnTgtCol) exit ! early, since loop has passed all possible matches
        end if
      end do
      if(OnTgtRow) RCMvalue=ConsMtxNze(iNze) ! else retain 0.0
    ! else no match implies ConsMtx(Col,Row) is void
      return ! entry ReturnCNWAMtx
c-----
      entry ReleaseDbgCNWArrays
      deallocate(VarDesc,ReqDesc,A4Equiv,CoalName,GPntID,
     +  ConsMtxNze,zbColOfNze,zbRowOfNze)
      return
c-----
      entry ReleaseOtherCNWArrays
      deallocate( ! VarDesc,ReqDesc,A4Equiv, ! moved above
     +  AvailSN,DnOfPlnt,PlntQty,fPlntUnit,fUnscPlnt,kTpFB,kTpMB,
     +  ShCst,InfDvdCst,SupDvdCst,
     +  cVect,bVect,xVect,ReVec,LinkFrTo,PossFrTo,
     +  jUbVec,UbValu,jLbVec,LbValu, ! UbVOrg,
c    +  ConsMtxNze,zbColOfNze,zbRowOfNze, ! moved above
     +  MineMCst,MineACst,MineCost,TransCst,TransQty,
     +  StatsQty,LkQtyAtN,BasinQty,ContQty,ContCst,ContFrTo) ! ,UnitContQty)
c    +  NodeSrcQty,NodeSrcCst)
      if(allocated(cVOrg)) deallocate(cVOrg)
      return
c-----
      entry AllocLocalsPostPruning
      allocate(LinkFrTo(0:nSNod,mPlnt))
      allocate(PossFrTo(0:nSNod,mPlnt))
      allocate(AvailSN(nSNod))
      allocate(DnOfPlnt(mPlnt))
      allocate(PlntQty(mPlnt))
      allocate(kTpFB(mLink))
c     allocate(kTpMB(nSNod)) ! necessarily done earlier
      allocate(ShCst(mLink))
      allocate(InfDvdCst(mPlnt))
      allocate(SupDvdCst(mPlnt))
      allocate(fPlntUnit(mNode))
      allocate(fUnscPlnt(mPlnt))
      allocate(ContQty(LimnYr,nSNod,mPlnt))
      allocate(ContCst(LimnYr,nSNod,mPlnt))
      allocate(ContFrTo(0:nSNod,mPlnt))
!
      LinkFrTo=0
      PlntQty=0.0
      kTpFB=0.0
      ShCst=0.0
      InfDvdCst=1e12
      SupDvdCst=0.0
      fPlntUnit=0.0
      fUnscPlnt=0.0
      DnOfPlnt=0
      ContQty=0.0
      ContCst=0.0
      return
c-----
      entry AllocateCNWOptimizingArrays
      ConsMtSLim=1024 ! initial limit on size of ConsMtxNze,zbColOfNze,zbRowOfNze
c     write(DbgU,'(//2i7,a/)') nVar,mReq,
c    +  ' # Var & Req in the LP formulation'
!
      allocate(A4Equiv(nVar))
      allocate(VarDesc(nVar))
      allocate(ReqDesc(mReq))
c     call WriteStrAt(1,1,'aft alloc(ReqDesc)')
      allocate(cVect(nVar))
c     call WriteStrAt(1,1,'aft alloc(cVect)')
      allocate(xVect(nVar))
c     call WriteStrAt(1,1,'aft alloc(xVect)')
      allocate(bVect(mReq))
      allocate(ReVec(mReq))
      allocate(ConsMtxNze(ConsMtSLim))
      allocate(zbColOfNze(ConsMtSLim))
      allocate(zbRowOfNze(ConsMtSLim))
      allocate(jUbVec(nUbV))
      allocate(UbValu(nUbV))
c     allocate(UbVOrg(nUbV))
c     if(nLbV>0) then
      allocate(jLbVec(nLbV))
      allocate(LbValu(nLbV))
c     end if
      allocate(MineMCst(nSNod))
      allocate(MineACst(nSNod))
      allocate(MineCost(nSNod))
      allocate(TransCst(nSNod))
      allocate(TransQty(nSNod))
      allocate(StatsQty(nSNod))
      allocate(LkQtyAtN(mNode))
      allocate(BasinQty(mBasn))
c     allocate(NodeSrcQty(mNode,nSNod))
c     allocate(NodeSrcCst(mNode,nSNod))
      cVect=0.0 ! default
      bVect=0.0 ! default
      return ! entry AllocateCNWOptimizingArrays
c-----
      end ! recursive subroutine CoalNetworkMain
c     end ! subroutine CoalNtwkMain
cinclude "SmSolver.FPP"
