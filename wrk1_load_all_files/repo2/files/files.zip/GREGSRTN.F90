!     ******************************************************************
!     GREGSRTN.F90
!     Copyright(c)  2000
!
!     Created: 12/29/2010 10:17:04 AM
!     Author : MARK S GERBER
!     Last change: MSG 12/29/2010 10:33:21 AM
!     ******************************************************************

! uses LP to minimize cost subject to supply/demand balance
! Author:  Alan Thielke
! 20090525 adapted from GasNetwk.fpp
! 20100908 incorporated call to GregsCNWRoutine containing iYr-loop
! 20100913 restricted LB on Ct/Pnt to <=1, modified AdjustCNWContData demand-loop
! 20101215 adapted from (Fortran main)  CNWCalls.fpp to be called by Midas
! 20101227 removed the loop on iYr to the caller per MSG directive
!
cinclude "cpp_defs.h" needed only if this file is not preceded by same in caller
cdefine nInpCsv 6
c#define LimnYr 30
      SUBROUTINE GregsCNWRoutine(BaseYr,RunFrYr,RunToYr) ! owner of interface arrays
c    +  StudyName,MaxContFr,TestFactor,LimitTypesAt2) ! now locally assigned
      use COAL_MODEL_INPUT_TO_cnw
      use CoalModelOutputsFromCNW
      character*5 StudyName,SCENAME
      logical*1 LimitTypesAt2
      integer*2 BaseYr,RunFrYr ! ,EndYr
c     integer*4 nLbvMax,nUbvMax,nLnkMax ! useful during debugging
      real*4 MaxContFr,TestFactor
!
    ! declarations for interface variables and arrays
      integer*2 iYr,nYr/30/, ! BegYr,
     +  nSNod,nDNod,nNode,nLink,nBasn,nCont,nCCSegs,iFocus,
     +  NodeID  (    :),
     +  LinkID  (    :),
     +  LinkNdID(  :,:),
     +  LinkNdSN(  :,:),
     +  BasnID  (    :),
     +  BnOfNode(    :),
     +  HPntID  (    :),
     +  PnOfNode(    :)
      logical*1 Feasible,Focussed
      real*4
     +  NodeQtyLB (  :),
     +  NodeQtyUB (  :),
cObs +  NodeQtyEsc(:,:),
     +  NodeQty   (  :),
     +  fUnscNode (  :),
     +  NodePri (    :),
c    +  NodeMgC (    :),
     +  MineFunc(:,:,:),
     +  LinkChg (    :),
     +  BasnQtyLB (  :),
     +  BasnQtyUB (  :),
     +  HeatConLB (  :),
     +  HeatConUB (  :),
     +  HeatConAv (:,:),
     +  HeatConID (:,:),
     +  SulphurCon(  :),
     +  SulphurCst, ! /0.10/, ! $/LbS => $200/T coefficient in objective function
     +  Sulphur_UB ! /9000.0/ ! kTon => 9MegaT annual limit on SO2 emissions
      character*27
     +  BasnName(    :),
     +  NodeName(    :)
      allocatable
     +  NodeID      ,
     +  LinkID      ,
     +  LinkNdID    ,
     +  LinkNdSN    ,
     +  BasnID      ,
     +  BnOfNode    ,
     +  HPntID      ,
     +  PnOfNode    ,
     +  NodeQtyLB   ,
     +  NodeQtyUB   ,
cObs +  NodeQtyEsc  ,
     +  NodeQty     ,
     +  fUnscNode   ,
     +  NodePri     ,
c    +  NodeMgC     ,
     +  MineFunc    ,
     +  LinkChg     ,
     +  BasnQtyLB   ,
     +  BasnQtyUB   ,
     +  HeatConLB   ,
     +  HeatConUB   ,
     +  HeatConAv   ,
     +  HeatConID   ,
     +  SulphurCon  ,
     +  BasnName    ,
     +  NodeName
!     end of interface declarations
!
      logical*1 B0/.false./,B1/.true./
      save ! critically:  nNode,nLink,nCCSegs
!
    ! assign input parameters to locals for use by entry's:
      nBasn=nBasin
      nSNod=nCoalSupply
      nDNod=nCoalDemand
      nLink=nTransportLinks
      nCont=nCoalContracts
      write(4,'(/a,5i6)') ' values passed from caller of GCR: ',
     +  nBasn,nSNod,nDNod,nLink,nCont
!
    ! assign defaults for unspecified (obsolete or debugging) arguments
      StudyName= SCENAME()  ! 'study'
      MaxContFr=1.0 ! default 'allow contract to comprise entire CT-supply or Plnt-demand'
c     MaxContFr=0.35 ! default; 0.4 caused infeasibility
      TestFactor=1.0
      LimitTypesAt2=B0
!
c     BegYr=BaseYr+1
c     nYr=EndYr-BaseYr
c     if((0>=nYr).or.(nYr>LimnYr)) call ps(2,
c    +  'Invalid span of years specified')
!
    ! allocate arrays for output results
      call InitCNWOutputsModule(nBasn,nSNod,nDNod,nLink,nYr)
!
      call OpenCNWOutFiles(StudyName,B1)
c     call GetCNWInpFNames(InpCsvFN) ! from DSF-file read in Alan's main program
c     call OpenCNWInpFiles(InpCsvFN)
      call GetBasnCount(nBasn) ! defines nBasn
      call AllocateCNWBasnArrays()
      call GetNodeCount(nSNod,nDNod,nNode,nBasn,nCCSegs, ! defines nNode and nCCSegs
     +  BasnID,BasnQtyLB,BasnQtyUB,BasnName)
      call AllocateCNWNodeArrays()
      call GetLinkCount(nNode,nLink,nBasn, ! deinfes nLink
     +  BasnID,BnOfNode,NodeID,HPntID,PnOfNode,TestFactor,
     +  NodePri,NodeQty,NodeQtyLB,NodeQtyUB,MineFunc,
     +  HeatConLB,HeatConUB,HeatConAv,HeatConID,SulphurCon,fUnscNode,
     +  SulphurCst,Sulphur_UB,NodeName)
      call AllocateCNWLinkArrays()
      call ReadCNWLinkData(nNode,nLink,nBasn, ! nLnkMax,
     +  NodeID,BasnID,BnOfNode,HPntID,PnOfNode,
     +  LinkID,LinkNdID,LinkNdSN,
     +  NodePri,NodeQty,NodeQtyLB,NodeQtyUB,MineFunc,
     +  HeatConLB,HeatConUB,HeatConAv,HeatConID,SulphurCon,fUnscNode,
     +  LinkChg,NodeName,LimitTypesAt2)
cObs  call ReadEscalated(NodeQty,NodeQtyEsc)
      call ReadCNWContData(nCont)
c     call CloseCNWInpFiles()
      call AllocateCNWOptimizingArrays()
      call OpenCNWOutFiles(StudyName,B0)
!
!      iYr=RunYr
      do iYr = RunFrYr,RunToYr
cObs    call ImposeEscalated(iYr,BegYr,NodeQty,NodeQtyEsc) ! sets PrtDetail
        call UpdateSupplyData(iYr,NodeQty,NodeQtyUB,MineFunc)
        call UpdateDemandData(iYr,NodeQty,fUnscNode,
     +    SulphurCst,Sulphur_UB) ! SulphurCst changes if fUnscNode does
      ! following was extracted from tail of ReadCNWLinkData to use proper NodeQty
        call AggregatePlantData(iYr,nNode,nLink,nBasn, ! nLnkMax,
     +    NodeID,BasnID,BnOfNode,HPntID,PnOfNode,
     +    LinkID,LinkNdID,LinkNdSN,TestFactor,
     +    NodePri,NodeQty,NodeQtyLB,NodeQtyUB,MineFunc,
     +    HeatConLB,HeatConUB,HeatConAv,HeatConID,SulphurCon,fUnscNode,
     +    LinkChg,NodeName,LimitTypesAt2)
        call AdjustCNWContracts(iYr, ! and WARN of infeasible conditions removed
     +    MaxContFr,HPntID,PnOfNode,NodeQty,NodeQtyUB) ! ,HeatConLB)
        call MinCNWCosts(iYr,BaseYr,TestFactor, ! nLbvMax,nUbvMax,
     +    NodeID,BnOfNode,PnOfNode,
     +    LinkID,LinkNdID,LinkNdSN,
     +    NodeQtyLB,NodeQtyUB,NodeQty,
     +    HeatConLB,HeatConUB,SulphurCon, ! fUnscNode,
     +    MineFunc,BasnQtyUB,SulphurCst,Sulphur_UB,
     +    LinkChg,NodeName)
        do iFocus=1,3 ! AGT hopes that 2nd iteration suffices to LimitTypesAt2
          call SolveCNWLpUsingPcx(Feasible)
c         call CheckSolution(NodeName,NodeQty,LinkNdSN)
          call ReportCNWSolutionDetails(iYr, ! escalates cVect for Supply not Focussed
     +      BasnID,BnOfNode,NodeID,PnOfNode,LinkNdID,LinkNdSN,
     +      iFocus,Focussed,
     +      NodeQty,NodeQtyUB,
c    +      NodePri,NodeMgC, ! perhaps of interest
     +      HeatConLB,HeatConUB,HeatConAv,
     +      LinkChg,MineFunc,BasnName,NodeName)
          if(.not.Feasible) then
            write(4,'(a)') ' WARNING:  solution reported is INFEASIBLE'
            exit
          end if
          if(Focussed.or.(.not.LimitTypesAt2)) exit
        end do
        call CheckSolution(LinkNdSN,PnOfNode,HeatConAv,NodeQty,NodeName)
      end do ! iYr-loop
!
      call ReleaseDbgCNWArrays() ! free memory ASAP
      call CloseCNWOutFiles()
      call ReleaseOtherCNWArrays()
      call ReleaseCNWLinkArrays()
      call ReleaseCNWNodeArrays()
      call DumpCNWOutputsModule(nBasn,nSNod,nDNod,nLink,RunYr)
c     call ps(0,'Execution of GregsRoutine ended normally.')
      return ! SUBROUTINE GregsCNWRoutine
c-----
      entry AllocateCNWBasnArrays
      allocate(BasnID(nBasn))
      allocate(BasnQtyLB(nBasn))
      allocate(BasnQtyUB(nBasn))
      allocate(BasnName(nBasn))
#ifdef UsingF90
    ! assign default of -1, implying N.A.
      call_cinitw(BasnID,nBasn,-1)
      call_cinitd(BasnQtyLB,nBasn,-1.0)
      call_cinitd(BasnQtyUB,nBasn,-1.0)
#endif
      return
c-----
      entry AllocateCNWNodeArrays
      allocate(BnOfNode(nNode))
      allocate(PnOfNode(nNode))
      allocate(HPntID  (nNode))
      allocate(NodeID  (nNode))
      allocate(NodeQtyLB(nNode)) ! min quantity at supply
      allocate(NodeQtyUB(nNode)) ! max quantity at supply
cObs  allocate(NodeQtyEsc(0:LimnYr,nNode)) ! quantity demand or supply Escalated by year
      allocate(NodeQty (nNode)) ! quantity demand or supply
      allocate(fUnscNode(nNode)) ! fraction of Demand not using sulphur scrubbers
      allocate(NodePri (nNode))
c     allocate(NodeMgC (nNode))
      allocate(MineFunc(nCCSegs,0:2,nNode)) ! segment x(EoS fract cap),MinedCost,DeltaX
      allocate(HeatConLB (nNode))
      allocate(HeatConUB (nNode))
      allocate(HeatConAv(0:1,nNode)) ! prior and current years' Avg Heat Content
      allocate(HeatConID(0:1,nNode)) ! annual fractional decrease or increase allowed
      allocate(SulphurCon(nNode))
      allocate(NodeName(nNode))
#ifdef UsingF90
    ! assign default of -1, implying N.A.
      call_cinitw(BnOfNode,nNode,-1)
      call_cinitw(PnOfNode,nNode,-1)
      call_cinitw(HPntID,nNode,-1)
      call_cinitw(NodeID,nNode,-1)
      call_cinitd(NodeQtyLB,nNode,-1.0)
      call_cinitd(NodeQtyUB,nNode,-1.0)
      call_cinitd(fUnscNode,nNode,-1.0)
      call_cinitd(NodeQty,nNode,-0.1) ! preclude usage of -1 as a pointer
      call_cinitd(NodePri,nNode,-1.0)
c     call_cinitd(NodeMgC,nNode,-1.0)
      call_cinitd(MineFunc,nNode,-1.0)
      call_cinitd(HeatConLB,nNode,-1.0)
      call_cinitd(HeatConUB,nNode,-1.0)
      call_cinitd(HeatConAv,nNode*2,-1.0)
      call_cinitd(HeatConID,nNode*2,-1.0)
      call_cinitd(SulphurCon,nNode,-1.0)
#endif
      return
c-----
      entry ReleaseCNWNodeArrays
      deallocate(
     +  BasnID,BnOfNode,HPntID,PnOfNode,
     +  NodeID,NodeQtyLB,NodeQtyUB, ! NodeQtyEsc,
     +  NodeQty,fUnscNode,NodePri, ! NodeMgC,
     +  BasnQtyLB,BasnQtyUB,
     +  HeatConLB,HeatConUB,HeatConAv,HeatConID,SulphurCon,
     +  MineFunc,BasnName,NodeName)
      return
c-----
      entry AllocateCNWLinkArrays
      allocate(LinkID (nLink))
      allocate(LinkNdID(0:1,nLink)) ! A-to-B IDs
      allocate(LinkNdSN(0:1,nLink)) ! A-to-B IDs' serial numbers (contiguous)
      allocate(LinkChg(nLink)) ! A-to-B commodity charge at 100%
#ifdef UsingF90
    ! assign default of -1, implying N.A.
      call_cinitw(LinkID,nLink,-1)
      call_cinitw(LinkNdID,nLink,-1)
      call_cinitw(LinkNdSN,nLink,-1)
      call_cinitd(LinkChg,nLink,-1.0)
#endif
      return
c-----
      entry ReleaseCNWLinkArrays
      deallocate(LinkID,LinkNdID,LinkNdSN,LinkChg)
      return
!
      end ! subroutine GregsCNWRoutine
c-----
      module CoalModelOutputsFromCNW
      real*4
     +  MineQAMTcost(:,:,:),
     +  BasnDmndQty (:,:,:),
     +  SplyDmndQyAfMfAdMdTcost(:,:,:,:)
      allocatable
     +  MineQAMTcost,
     +  BasnDmndQty,
     +  SplyDmndQyAfMfAdMdTcost
      end module CoalModelOutputsFromCNW
c-----
      subroutine InitCNWOutputsModule(nBasn,nSNod,nDNod,nLink,nYr)
      use CoalModelOutputsFromCNW
      integer*2 nBasn,nSNod,nDNod,nLink,nYr
!
      if(allocated(MineQAMTcost)) deallocate(
     +  MineQAMTcost,
     +  BasnDmndQty,
     +  SplyDmndQyAfMfAdMdTcost)
      allocate(
     +  MineQAMTcost(nSNod,0:3,nYr), ! 0 is Quantity; 1-3 are Marginal,Avg,Total costs
     +  BasnDmndQty (nBasn,nDNod,nYr),
     +  SplyDmndQyAfMfAdMdTcost(0:5,0:nSNod,nDNod,nYr))
      !  for the 1st index, 0 is Quantity; 1-5 are
      !  Marginal FOB,Avg FOB,Marginal Dvd,Avg Dvd,Total costs;
      !  for the 2nd index, 0 is for the average across nSNod suppliers
      end
c-----
      subroutine DumpCNWOutputsModule(nBasn,nSNod,nDNod,nLink,RunYr)
      use CoalModelOutputsFromCNW
      integer*2 nBasn,nSNod,nDNod,nLink,RunYr,
     +          iBasn,iSNod,iDNod,iYr,j
!
      do iYr=RunYr,RunYr
        write(4,'(/a,99(a,i2.2))') ' Yr DNod',
     +    (' QtyFromBn',iBasn,iBasn=1,nBasn)
        do iDNod=1,nDNod-1 ! decrement for the pseudo-node for SO2 costs
          write(4,'(i3,i5,99f12.1)') iYr,iDNod,
     +      (BasnDmndQty(iBasn,iDNod,iYr),iBasn=1,nBasn)
        end do
!
        write(4,'(/a)')
     +    ' Yr SN   SupplyQty Avg_Cost MargCost     TotalCost'
        do iSNod=1,nSNod
          write(4,'(2i3,f12.1,2f9.2,f14.0)') iYr,iSNod,
     +      (MineQAMTcost(iSNod,j,iYr),j=0,3)
        end do
!
        write(4,'(/2a)') ' Yr DNod SN',
     +    ' DmndSplyQty Avg_FOBC MargFOBC Avg_DvdC MargDvdC TrnsCost'
        do iDNod=1,nDNod-1 ! decrement for the pseudo-node for SO2 costs
          do iSNod=0,nSNod
            write(4,'(i3,i5,i3,f12.1,5f9.2)') iYr,iDNod,iSNod,
     +        (SplyDmndQyAfMfAdMdTcost(j,iSNod,iDNod,iYr),j=0,5)
          end do
        end do
      end do
      end ! subroutine DumpCNWOutputsModule
c-----
