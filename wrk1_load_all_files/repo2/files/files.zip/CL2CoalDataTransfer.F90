!     ******************************************************************
!     CL2CoalDataTransfer.F90
!     Copyright(c)  2000
!
!     Created: 1/20/2011 1:48:33 PM
!     Author : MARK S GERBER
!     Last change: MSG 3/5/2011 1:57:33 PM
!     ******************************************************************
      MODULE CoalDemandInputData
         CHARACTER (LEN=512), SAVE :: COAL_DEMAND_RECS(2000)
         INTEGER (KIND=8), SAVE :: EVUnitID(2000)
         INTEGER (KIND=2), SAVE :: PlantDemandRecords
         LOGICAL (KIND=1) :: HESI_ID_FOUND(2000)/2000*.FALSE./
      END MODULE
      program CL2CoalDataTransfer
C      USE RUN_PERIOD_DATA
      CHARACTER (LEN=256) :: CURRENT_DIRECTORY,COMMAND_LINE,
     +                       UC_COMMAND_LINE,DUMMY,FILE_NAME
      CHARACTER (LEN=4096) :: DSEXEC_LINE
      LOGICAL (KIND=4) :: FILE_EXISTS,cnw_DATA_PROCESSED,
     +                    READ_COAL_MODEL_DATA
      INTEGER IY,CHDIR,IOS,DELETE,I
      CHARACTER (LEN=5) :: STUDY_NAME,BASE_FILE_DEFINITION,
     +                     BASE_FILE_FAMILY
      INTEGER (KIND=2) :: CURRENT_YEAR,END_POINT=1,YEAR,
     +                    BASE_YR,END_YR,FirstRunYr
      CHARACTER (LEN=256) :: COAL_NODE/'NONE'/            ! 354
      CHARACTER (LEN=256) :: COAL_TRANSPORT/'NONE'/,       ! 355
     +                       COAL_SUPPLY_FORECAST/'NONE'/, ! 356
     +                       PLANT_DEMAND_FORECAST/'NONE'/, ! 357
     +                       COAL_CONTRACTS/'NONE'/,       ! 361
     +                       COAL_MODEL_POINTER_FILE/'NONE'/, ! 372
     +                       COAL_MODEL_SO2_INFO_FILE/'NONE'/,        ! 373
     +                       COAL_MODEL_GENERIC_TRANSPORT_FILE/'NONE'/,  ! 374
     +                       CL__BASE_FILE_NAMES(0:29)/30*'NONE'/ ! 13,94-100,130-136,165-166,205-210,263,307-311
      LOGICAL (KIND=4) :: VOID_LOGICAL,READ_COAL_ESCALATION_FILE
C MOVES TO CORRECT DIRECTORY FOR THE DEBUGGER )
      CALL get_environment_variable("DEBUGDIR",CURRENT_DIRECTORY)
      IF(LEN_TRIM(CURRENT_DIRECTORY) >=1) THEN
         READ(CURRENT_DIRECTORY,*) UC_COMMAND_LINE,
     +                             COMMAND_LINE 
         IY = CHDIR(UC_COMMAND_LINE)
      ELSE
         CALL GETCL(COMMAND_LINE)
      ENDIF
!      CALL CURDIR(" ",CURRENT_DIRECTORY)
! the command line will be
! study project base_family base_year end_year
! The first three items are the standard command line values.
! Adding the last two eliminates the infromation that is currently inputted from
! MSGPARAM.VAL
      read(COMMAND_LINE,*)STUDY_NAME,BASE_FILE_DEFINITION,
     +                    BASE_FILE_FAMILY
      write(*,*) STUDY_NAME,BASE_FILE_DEFINITION,BASE_FILE_FAMILY
      FILE_NAME = "DSF"//trim(BASE_FILE_DEFINITION)//".DAT"
      INQUIRE(FILE=FILE_NAME,EXIST=FILE_EXISTS)
      OPEN(10,FILE=FILE_NAME,ACCESS='SEQUENTIAL')
      READ(10,*)
      DO
         READ(10,"(A)",IOSTAT=IOS) DSEXEC_LINE
         IF(IOS /= 0) EXIT
         DSEXEC_LINE = trim(DSEXEC_LINE)//',,,,,,,,,,,,,,,,,,,,,,,,,,'
     +                                    //',,,,,,,,,,,,,,,,,,,,,,,,,,'
     +                                    //',,,,,,,,,,,,,,,,,,,,,,,,,,'
     +                                    //',,,,,,,,,,,,,,,,,,,,,,,,,,'
     +                                    //',,,,,,,,,,,,,,,,,,,,,,,,,,'
     +                                    //',,,,,,,,,,,,,,,,,,,,,,,,,,'
     +                                    //',,,,,,,,,,,,,,,,,,,,,,,,,,'
     +                                    //',,,,,,,,,,,,,,,,,,,,,,,,,,'
     +                                    //',,,,,,,,,,,,,,,,,,,,,,,,,,'
     +                                    //',,,,,,,,,,,,,,,,,,,,,,,,,,'
         READ(DSEXEC_LINE,*) DELETE,STUDY_NAME
         IF((INDEX(BASE_FILE_FAMILY,STUDY_NAME) /= 0 .AND.
     +            INDEX(STUDY_NAME,BASE_FILE_FAMILY) /= 0)) THEN
            READ(DSEXEC_LINE,*) DELETE,STUDY_NAME,
     +                          (DUMMY,I=1,12),
     +                          CL__BASE_FILE_NAMES(0),
     +                          (DUMMY,I=14,93),
     +                          CL__BASE_FILE_NAMES(1:7),
     +                          (DUMMY,I=101,129),
     +                          CL__BASE_FILE_NAMES(8:14),
     +                          (DUMMY,I=137,164),
     +                          CL__BASE_FILE_NAMES(15:16),
     +                          (DUMMY,I=167,204),
     +                          CL__BASE_FILE_NAMES(17:22),
     +                          (DUMMY,I=211,262),
     +                          CL__BASE_FILE_NAMES(23),
     +                          (DUMMY,I=264,306),
     +                          CL__BASE_FILE_NAMES(24:29),
     +                          (DUMMY,I=313,353),
     +                           COAL_NODE,
     +                           COAL_TRANSPORT,
     +                           COAL_SUPPLY_FORECAST,
     +                           PLANT_DEMAND_FORECAST,
     +                          (DUMMY,I=358,360),
     +                           COAL_CONTRACTS,  ! 361
     +                          (DUMMY,I=362,371),
     +                           COAL_MODEL_POINTER_FILE,      ! 372
     +                           COAL_MODEL_SO2_INFO_FILE,        ! 373
     +                           COAL_MODEL_GENERIC_TRANSPORT_FILE  ! 374
            EXIT
         ENDIF
      ENDDO
      CLOSE(10)
      CALL CoalModel_PLANT_DEMAND_Data(PLANT_DEMAND_FORECAST)  ! ENTERY NAME HERE
      CALL CL_OBJECT(CL__BASE_FILE_NAMES)
      END program CL2CoalDataTransfer
C-----
      SUBROUTINE CoalModel_PLANT_DEMAND_Data(BASE_FILE_NAME)  ! ENTERY NAME HERE
      USE CoalDemandInputData
      CHARACTER (LEN=256) :: FILE_NAME,BASE_FILE_NAME
      INTEGER (KIND=2) :: IREC,I
      CHARACTER (LEN=10) :: DUMMY
      INTEGER (KIND=4) :: IOS
C-----
         FILE_NAME = "HDB"//TRIM(BASE_FILE_NAME )//".DAT"
         OPEN(10,FILE=FILE_NAME)
         IREC = 1
         READ(10,'(A)',IOSTAT=IOS) COAL_DEMAND_RECS(1)
         DO ! TABLE RECORDS
            IREC = IREC + 1
            READ(10,'(A)',IOSTAT=IOS) COAL_DEMAND_RECS(IREC)
!
            IF(IOS /= 0) EXIT ! END OF FILE
            READ(COAL_DEMAND_RECS(IREC),*,IOSTAT=IOS) (DUMMY,I=1,5),
     +                                                EVUnitID(IREC)
         ENDDO
         PlantDemandRecords = IREC - 1
         CLOSE(10)
         RETURN
      END SUBROUTINE
C     Last change: MSG 1/17/2011 8:55:11 AM
! 031210. DELETED CLA_OBJT_ARRAYS MODULE
! 100506. ADDED MARKET FLOOR AND MARKET CEILING VARIABLES FOR KCPL.
! 120606. ADDED REGIONAL OR STATE MAP SWITCH.
      SUBROUTINE CL_OBJECT(CL_FILE_BASE_NAMES)
C
      USE CoalDemandInputData
      CHARACTER (LEN=*) :: CL_FILE_BASE_NAMES(0:*)
      CHARACTER (LEN=30) :: VarStr(150)
      INTEGER*2 DELETE,I,MATCHES_FOUND
      INTEGER IOS
      CHARACTER*5 FOSSILFL
      CHARACTER*256 FILE_NAME
      CHARACTER*256 BASE_FILE_DIRECTORY,OUTPUT_DIRECTORY
      LOGICAL*4 FILE_EXISTS
C DECLARATION FOR DBREAD COMMON BLOCK
      CHARACTER*2048 RECLN
      INTEGER*8 HESI_UNIT_ID_NUM,
     +          H2_UNIT_ID_NUM
      REAL (KIND=4) :: IncHR1,IncHR2
      CHARACTER (LEN=5) :: AveHR

C MULTI-CL FILE VARIABLES
C
      INTEGER FILE_NUMBER,FILE_ID
      INTEGER MAX_CL_FILES
      PARAMETER (MAX_CL_FILES=30) ! note file 24 is for SPCapEx
      CHARACTER*5 VOID_CHR
      CHARACTER*256 BASE_FILE_NAME
      CHARACTER*2 CL_FILE_CODES(0:MAX_CL_FILES-1)/
     +                              'CL','C1','C2','C3','C4','C5',
     +                              'C6','C7','C8','C9','C0',
     +                              'CA','CB','CC','CD','CE','CG',
     +                              'CI','CJ','CK','CM','CP','CQ',
     +                              'XC','CS','CU','CV','CW','CX','CY'/,
     +            FILE_CODE
C***********************************************************************
C
C          ROUTINE TO CONVERT METAFILE FILES TO DIRECT-ACESS BINARY
C          COPYRIGHT (C) 1983, 84, 85  M.S. GERBER & ASSOCIATES, INC.
C
C***********************************************************************
C
C CONVERT THE (FOSSIL-FUELED) CAPACITY-LIMITED-UNITS FILE
C
      MATCHES_FOUND = 0
      DO FILE_ID = 0, MAX_CL_FILES-1
         BASE_FILE_NAME = CL_FILE_BASE_NAMES(FILE_ID)
         IF(INDEX(BASE_FILE_NAME,'NONE') /= 0) CYCLE
         FILE_CODE = CL_FILE_CODES(FILE_ID)
         FILE_NAME = FILE_CODE//
     +                               "B"//trim(BASE_FILE_NAME)//".DAT"
         INQUIRE(FILE=FILE_NAME,EXIST=FILE_EXISTS)
         IF(FILE_EXISTS) THEN
            OPEN(10,FILE=FILE_NAME)
            READ(10,*) DELETE
C
            DO
C
                  READ(10,'(A)',IOSTAT=IOS) RECLN
                  IF(IOS /=0) EXIT
                  IF(RECLN(1:1) == '7') CYCLE
C
                  READ(RECLN,*) DELETE,
     +                         (VarSTr(I), I=1,39),
     +                          IncHR1,
     +                          IncHR2,
     +                         (VarSTr(I), I=42,103),
     +                          HESI_UNIT_ID_NUM,
     +                         (VarSTr(I), I=105,148)
c                  IF(.NOT. (VarSTr(60)(1:1)== 'C' .OR.
c     +                                     VarSTr(60)(1:1)== 'c')) CYCLE
                  DO I = 2, PlantDemandRecords
                     IF(HESI_ID_FOUND(I)) CYCLE
                     IF(HESI_UNIT_ID_NUM == EVUnitID(I)) THEN
                        WRITE(AveHR,'(I5)') INT((IncHR1+IncHR2)/2.)
                        COAL_DEMAND_RECS(I) =
     +                                 TRIM(COAL_DEMAND_RECS(I))//
     +                                 TRIM(VarStr(7))//','//
     +                                 TRIM(VarStr(8))//','//
     +                                 TRIM(VarStr(9))//','//
     +                                 TRIM(VarStr(10))//','//
     +                                 TRIM(VarStr(84))//',"'//
     +                                 TRIM(VarStr(90))//'",'//
     +                                 TRIM(VarStr(37))//','//
     +                                 TRIM(VarStr(145))//','//
     +                                 TRIM(VarStr(146))//','//
     +                                 TRIM(VarStr(147))//','//
     +                                 TRIM(VarStr(148))//','//
     +                                 TRIM(AveHR)//','
                        HESI_ID_FOUND(I) = .TRUE.
                        MATCHES_FOUND = MATCHES_FOUND + 1
                        EXIT
                     ENDIF
                  ENDDO

            ENDDO
            CLOSE(10)
         ENDIF
      ENDDO ! FILE_ID FIRST PASS
C
C  SAVE COAL DEMAND FILE
C
         OPEN(10,FILE="HDBDataTransfer.DAT")
         WRITE(10,'(A)') COAL_DEMAND_RECS(1)
         OPEN(11,FILE="HDBMissingUnits.DAT")
         WRITE(11,'(A)') COAL_DEMAND_RECS(1)
         DO I = 2, PlantDemandRecords
            IF(.NOT. HESI_ID_FOUND(I)) THEN
               COAL_DEMAND_RECS(I) =
     +              TRIM(COAL_DEMAND_RECS(I))//',,,,,,,,,,,,,,,,,,,,,,,'
               WRITE(11,'(1X,A)') TRIM(COAL_DEMAND_RECS(I))
            ENDIF
            WRITE(10,'(1X,A)') TRIM(COAL_DEMAND_RECS(I))
         ENDDO
         CLOSE(10)
         CLOSE(11)
      RETURN
      END SUBROUTINE
