module end_routine
implicit none
    character*1024 :: er_message=""
contains
    subroutine end_program(message)
        logical :: file_found
        character(*), intent(in) :: message
        character(256) :: filename="exit_message.txt"
        integer :: file_unit, open_status
        
        file_unit=get_new_unit()
        INQUIRE(FILE=trim(filename), EXIST=file_found)
        if(file_found) then
            open(unit=file_unit, iostat=open_status, file=trim(filename), status='old')
            if (open_status == 0) then
                close(1234, status='delete')
            endif
        endif
        file_unit=get_new_unit()
        open(unit=file_unit, file=trim(filename), action="write", IOSTAT=open_status)
        if(open_status/=0)then
            stop "Unable to open exit_message file."
        else
            write(file_unit,*) trim(message)
            close(file_unit)
        endif
        
        stop "Error condition encountered. See exit_message.txt for details." 
    end subroutine end_program
    
    integer function get_new_unit()
      integer :: unit
      integer, parameter :: LUN_MIN=10, LUN_MAX=20000
      logical :: opened
      integer :: lun
      get_new_unit=-1
      do lun=LUN_MIN,LUN_MAX
        inquire(unit=lun,opened=opened)
        if (.not. opened) then
          get_new_unit=lun
          exit
        end if
      end do

    end function get_new_unit
end module end_routine