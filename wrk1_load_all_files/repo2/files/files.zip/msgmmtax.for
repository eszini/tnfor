C     Last change: MSG 1/10/2010 3:00:11 PM
C***********************************************************************
C*                                                                     *
C*                        TAX INFORMATION FILE                         *
C*                                                                     *
C*             COPYRIGHT (C) 1998 M.S. GERBER & ASSOCIATES, INC        *
C*                         ALL RIGHTS RESERVED                         *
C*                                                                     *
C***********************************************************************
      SUBROUTINE TX_OBJECT
      use end_routine, only: end_program, er_message
C
      INCLUDE 'SpinLib.MON'
      INCLUDE 'SIZECOM.MON'
      INTEGER*2 IREC,INUNIT,LRECL/512/
      INTEGER*4 IOS,IOS_BASE
      INTEGER*2 NUMBER_OF_BC_CLASSES/0/,
     +          MAX_BC_CLASS_ID_NUM/0/
      INTEGER*2 NUMBER_OF_OL_CLASSES/0/,
     +          MAX_OL_CLASS_ID_NUM/0/
      INTEGER*2 UNIT_NUM/10/
      INTEGER*2 R_NUM_OF_CLASSES,R_MAX_CLASS_NUM,
     +          R_CLASS_POINTERS(*)
      INTEGER*2 R_UNIT_NUM,I
      CHARACTER*5 BASE_FILE_NAME,OVERLAY_FAMILY_NAME
      CHARACTER*256 FILE_NAME
      CHARACTER*256 BASE_FILE_DIRECTORY,OUTPUT_DIRECTORY
      CHARACTER*256 DATA_DRIVE
      LOGICAL*4 FILE_EXISTS,R_FILE_EXISTS
      SAVE FILE_EXISTS
      CHARACTER*2 FILE_OL/'BC'/,R_FILE_OL,
     +            VARIABLE_USEAGE*2,
     +            TAX_TIMING_CLASSIFICATION*22
      INTEGER*2 BC_ASSET_CLASS_POINTER(:),
     +          OL_ASSET_CLASS_POINTER(:),
     +          TEMP_ASSET_CLASS_POINTER(:)
      ALLOCATABLE :: BC_ASSET_CLASS_POINTER,
     +               OL_ASSET_CLASS_POINTER,
     +               TEMP_ASSET_CLASS_POINTER
      SAVE BC_ASSET_CLASS_POINTER,
     +     OL_ASSET_CLASS_POINTER
C DECLARATION FOR DBREAD COMMON BLOCK
      CHARACTER*1024 RECLN
C DECLARATION FOR DATA FILE VARIABLES
      CHARACTER*16 FILE_TYPE/'Tax Information'/
      CHARACTER*5 TAXES_FILE
      CHARACTER*2 FILE_PREFIX/'TX'/
      CHARACTER*12 FILE_BC_NAME/'BCTXINFO.BIN'/
      CHARACTER*12 FILE_OL_NAME/'OLTXINFO.BIN'/
C VARIABLES
      INTEGER*2 DELETE,ASSET_CLASS_NUM,ASSET_CLASS_VECTOR
      CHARACTER*30 COMMENT,DESCRIPTION,TEMP_DESCRIPTION
      REAL*4 DATA_VALUES(AVAIL_DATA_YEARS+1)
C
      INTEGER*2 ESCALATION_VECTOR
      INTEGER ACCTNO
      INTEGER*2 MONTHLY_TAX_VECTOR
      CHARACTER*1 CONSOLIDATED_CLASS,DATA_TYPE,
     +            ANNUAL_VALUE_STATUS(5), ! 5 VALUES
     +            ACCOUNT_ACTIVE
      CHARACTER*10 TAX_APPLIES_TO
      CHARACTER*30 TAX_TYPE,
     +             TAX_RATES,
     +             CARRY_FORWARDS,
     +             TAX_ON_CAPITAL,
     +             TAX_CREDITS_ADJUSTMENTS,
     +             DEFERRED_TAX_AMT,
     +             TAX_DEDUCTIONS,
     +             TAX_ACTUALS
      LOGICAL*1 LAHEY_LF95
      CHARACTER*30 SCREEN_OUTPUT
C
C***********************************************************************
C
C          ROUTINE TO CONVERT METAFILE FILES TO DIRECT-ACESS BINARY
C          COPYRIGHT (C) 1983, 84, 85  M.S. GERBER & ASSOCIATES, INC.
C
C***********************************************************************
C
C CONVERT THE TAX INFORMATION FILE
C***********************************************************************
      ENTRY TX_MAKEBIN
C***********************************************************************
      BASE_FILE_NAME = TAXES_FILE()
      DATA_DRIVE = OUTPUT_DIRECTORY()
      FILE_NAME = trim(BASE_FILE_DIRECTORY())//
     +                  FILE_PREFIX//"B"//trim(BASE_FILE_NAME)//".DAT"
      INQUIRE(FILE=FILE_NAME,EXIST=FILE_EXISTS)
      IF(FILE_EXISTS) THEN
C
         IF(LAHEY_LF95()) THEN
            SCREEN_OUTPUT = trim(FILE_TYPE)//'-'//BASE_FILE_NAME
            CALL MG_LOCATE_WRITE(16,30,SCREEN_OUTPUT,ALL_VERSIONS,0)
         ELSE
            CALL MG_CLEAR_LINE_WRITE(17,9,36,FILE_TYPE,ALL_VERSIONS,0)
            CALL MG_LOCATE_WRITE(16,30,BASE_FILE_NAME,ALL_VERSIONS,0)
         ENDIF
         ALLOCATE(TEMP_ASSET_CLASS_POINTER(1024))
         TEMP_ASSET_CLASS_POINTER = 0
         OPEN(10,FILE=FILE_NAME)
         OPEN(11,FILE=trim(DATA_DRIVE)//FILE_BC_NAME,
     +                      ACCESS="DIRECT",STATUS="REPLACE",RECL=LRECL)
         IREC = 0
         READ(10,*) DELETE
         DO
            DATA_TYPE = 'D'
            ESCALATION_VECTOR = 0
            ASSET_CLASS_NUM = 0
            ASSET_CLASS_VECTOR = 0
            VARIABLE_USEAGE = 'Cl'
            TAX_TIMING_CLASSIFICATION = 'Current'
            MONTHLY_TAX_VECTOR = 0
            ANNUAL_VALUE_STATUS(1) = 'N'
            CONSOLIDATED_CLASS = 'N'
            DO I = 2, 5
               ANNUAL_VALUE_STATUS(I) = 'N'
            ENDDO
            ACCOUNT_ACTIVE = 'A'
C
            DO
               READ(10,1000,IOSTAT=IOS) RECLN
               IF(IOS /=0) EXIT
               IF(RECLN(1:1) == '7') EXIT
               RECLN = trim(RECLN)//',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,'
     +                              //',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,'
               DATA_VALUES = -999999.
               READ(RECLN,*,ERR=200) DELETE,ACCTNO,
     +                               TAX_TYPE,
     +                               TAX_APPLIES_TO,
     +                               DATA_VALUES,
     +                               DESCRIPTION,
     +                               COMMENT,
     +                               DATA_TYPE,
     +                               ESCALATION_VECTOR,
     +                               ASSET_CLASS_NUM,
     +                               ASSET_CLASS_VECTOR,
     +                               DEFERRED_TAX_AMT,
     +                               TAX_RATES,
     +                               CARRY_FORWARDS,
     +                               TAX_ON_CAPITAL,
     +                               TAX_CREDITS_ADJUSTMENTS,
     +                               TAX_DEDUCTIONS,
     +                               CONSOLIDATED_CLASS,
     +                               MONTHLY_TAX_VECTOR,
     +                               VARIABLE_USEAGE,
     +                               TAX_TIMING_CLASSIFICATION,
     +                               TAX_ACTUALS,
     +                               ANNUAL_VALUE_STATUS, ! 5 VALUES
     +                               ACCOUNT_ACTIVE
C
	         IF(DELETE < 8 .AND.(INDEX('Cl',VARIABLE_USEAGE) /= 0 .OR.
     +                                INDEX('Pa',VARIABLE_USEAGE) /= 0))
     +                  CALL SET_ASSET_CLASSES(ASSET_CLASS_NUM,
     +                                         NUMBER_OF_BC_CLASSES,
     +	                                      MAX_BC_CLASS_ID_NUM,
     +                                         TEMP_ASSET_CLASS_POINTER)
C
               IF(DATA_VALUES(1) == -999999.) DATA_VALUES(1) = 0.
               DO I = 2, AVAIL_DATA_YEARS+1
                  IF(DATA_VALUES(I) == -999999.)
     +                                 DATA_VALUES(I) = DATA_VALUES(I-1)
               ENDDO
               IREC = IREC + 1
               WRITE(11,REC=IREC) DELETE,ACCTNO,
     +                               TAX_TYPE,
     +                               TAX_APPLIES_TO,
     +                               DATA_VALUES,
     +                               DESCRIPTION,
     +                               DATA_TYPE,
     +                               ESCALATION_VECTOR,
     +                               ASSET_CLASS_NUM,
     +                               ASSET_CLASS_VECTOR,
     +                               DEFERRED_TAX_AMT,
     +                               TAX_RATES,
     +                               CARRY_FORWARDS,
     +                               TAX_ON_CAPITAL,
     +                               TAX_CREDITS_ADJUSTMENTS,
     +                               TAX_DEDUCTIONS,
     +                               CONSOLIDATED_CLASS,
     +                               MONTHLY_TAX_VECTOR,
     +                               VARIABLE_USEAGE,
     +                               TAX_TIMING_CLASSIFICATION,
     +                               TAX_ACTUALS,
     +                               ANNUAL_VALUE_STATUS, ! 5 VALUES
     +                               ACCOUNT_ACTIVE
            ENDDO
            IF(IOS /= 0) EXIT
         ENDDO
         CLOSE(10)
c        endfile(11)
         CLOSE(11)
         IF(MAX_BC_CLASS_ID_NUM > 0) THEN
            ALLOCATE(BC_ASSET_CLASS_POINTER(MAX_BC_CLASS_ID_NUM))
            BC_ASSET_CLASS_POINTER =
     +                   TEMP_ASSET_CLASS_POINTER(1:MAX_BC_CLASS_ID_NUM)
         ENDIF
         DEALLOCATE(TEMP_ASSET_CLASS_POINTER)
      ELSE IF(INDEX(BASE_FILE_NAME,'NONE') == 0) THEN
         CALL STOP_NOFILE(FILE_TYPE,FILE_NAME)
      ENDIF
      RETURN

C***********************************************************************
C
C          ROUTINE TO CREATE OVERLAY FILES
C          COPYRIGHT (C) 1984-88  M.S. GERBER & ASSOCIATES, INC.
C          COPYRIGHT (C) 1991-92  M.S. GERBER & ASSOCIATES, INC.
C
C***********************************************************************
C
C OVERLAY THE ADDENDUM FILE
C***********************************************************************
      ENTRY TX_MAKEOVL(OVERLAY_FAMILY_NAME)
C***********************************************************************
C
      IF(LAHEY_LF95()) THEN
         SCREEN_OUTPUT = trim(FILE_TYPE)//'-'//OVERLAY_FAMILY_NAME
         CALL MG_LOCATE_WRITE(16,30,SCREEN_OUTPUT,ALL_VERSIONS,0)
      ELSE
         CALL MG_CLEAR_LINE_WRITE(17,9,36,FILE_TYPE,ALL_VERSIONS,0)
         CALL LOCATE(10,51)
      ENDIF
      DATA_DRIVE = OUTPUT_DIRECTORY()
      FILE_NAME = trim(DATA_DRIVE)//FILE_PREFIX//"O"//
     +                               trim(OVERLAY_FAMILY_NAME)//".DAT"
      OPEN(10,FILE=FILE_NAME)
      READ(10,*) DELETE
      INUNIT = 12
      IF(FILE_OL == 'BC') THEN
         OPEN(11,FILE=trim(DATA_DRIVE)//FILE_BC_NAME,
     +                                       ACCESS="DIRECT",RECL=LRECL)
         INUNIT = 11
      ENDIF
      OPEN(12,FILE=trim(DATA_DRIVE)//FILE_OL_NAME,ACCESS="DIRECT",
     +                                      STATUS="UNKNOWN",RECL=LRECL)
      ALLOCATE(TEMP_ASSET_CLASS_POINTER(1024))
      TEMP_ASSET_CLASS_POINTER = 0
      NUMBER_OF_OL_CLASSES = 0
      MAX_OL_CLASS_ID_NUM = 0
      IREC = 0
      DO
         DO
            READ(10,1000,IOSTAT=IOS) RECLN
            IF(RECLN(1:1) == '7') EXIT
            IREC = IREC + 1
            READ(INUNIT,REC=IREC,IOSTAT=IOS_BASE) DELETE,ACCTNO,
     +                               TAX_TYPE,
     +                               TAX_APPLIES_TO,
     +                               DATA_VALUES,
     +                               DESCRIPTION,
     +                               DATA_TYPE,
     +                               ESCALATION_VECTOR,
     +                               ASSET_CLASS_NUM,
     +                               ASSET_CLASS_VECTOR,
     +                               DEFERRED_TAX_AMT,
     +                               TAX_RATES,
     +                               CARRY_FORWARDS,
     +                               TAX_ON_CAPITAL,
     +                               TAX_CREDITS_ADJUSTMENTS,
     +                               TAX_DEDUCTIONS,
     +                               CONSOLIDATED_CLASS,
     +                               MONTHLY_TAX_VECTOR,
     +                               VARIABLE_USEAGE,
     +                               TAX_TIMING_CLASSIFICATION,
     +                               TAX_ACTUALS,
     +                               ANNUAL_VALUE_STATUS, ! 5 VALUES
     +                               ACCOUNT_ACTIVE
            IF(IOS_BASE /= 0) EXIT
            IF(IOS == 0) THEN
               RECLN = trim(RECLN)//',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,'
               READ(RECLN,*,ERR=200) DELETE,ACCTNO,
     +                               TAX_TYPE,
     +                               TAX_APPLIES_TO,
     +                               DATA_VALUES,
     +                               TEMP_DESCRIPTION,
     +                               COMMENT,
     +                               DATA_TYPE,
     +                               ESCALATION_VECTOR,
     +                               ASSET_CLASS_NUM,
     +                               ASSET_CLASS_VECTOR,
     +                               DEFERRED_TAX_AMT,
     +                               TAX_RATES,
     +                               CARRY_FORWARDS,
     +                               TAX_ON_CAPITAL,
     +                               TAX_CREDITS_ADJUSTMENTS,
     +                               TAX_DEDUCTIONS,
     +                               CONSOLIDATED_CLASS,
     +                               MONTHLY_TAX_VECTOR,
     +                               VARIABLE_USEAGE,
     +                               TAX_TIMING_CLASSIFICATION,
     +                               TAX_ACTUALS,
     +                               ANNUAL_VALUE_STATUS, ! 5 VALUES
     +                               ACCOUNT_ACTIVE
            ENDIF
            IF(DELETE < 8 .AND.(INDEX('Cl',VARIABLE_USEAGE) /= 0 .OR.
     +                                INDEX('Pa',VARIABLE_USEAGE) /= 0))
     +                  CALL SET_ASSET_CLASSES(ASSET_CLASS_NUM,
     +                                         NUMBER_OF_OL_CLASSES,
     +	                                      MAX_OL_CLASS_ID_NUM,
     +                                         TEMP_ASSET_CLASS_POINTER)
            WRITE(12,REC=IREC) DELETE,ACCTNO,
     +                               TAX_TYPE,
     +                               TAX_APPLIES_TO,
     +                               DATA_VALUES,
     +                               DESCRIPTION,
     +                               DATA_TYPE,
     +                               ESCALATION_VECTOR,
     +                               ASSET_CLASS_NUM,
     +                               ASSET_CLASS_VECTOR,
     +                               DEFERRED_TAX_AMT,
     +                               TAX_RATES,
     +                               CARRY_FORWARDS,
     +                               TAX_ON_CAPITAL,
     +                               TAX_CREDITS_ADJUSTMENTS,
     +                               TAX_DEDUCTIONS,
     +                               CONSOLIDATED_CLASS,
     +                               MONTHLY_TAX_VECTOR,
     +                               VARIABLE_USEAGE,
     +                               TAX_TIMING_CLASSIFICATION,
     +                               TAX_ACTUALS,
     +                               ANNUAL_VALUE_STATUS, ! 5 VALUES
     +                               ACCOUNT_ACTIVE
         ENDDO
         IF(IOS_BASE /= 0) EXIT
      ENDDO
      CLOSE(10)
      CLOSE(12)
      IF(FILE_OL == 'BC') CLOSE(11)
      FILE_OL= 'OL'
      IF(ALLOCATED(OL_ASSET_CLASS_POINTER))
     +                       DEALLOCATE(OL_ASSET_CLASS_POINTER)
      IF(MAX_OL_CLASS_ID_NUM > 0) THEN
         ALLOCATE(OL_ASSET_CLASS_POINTER(MAX_OL_CLASS_ID_NUM))
         OL_ASSET_CLASS_POINTER =
     +                   TEMP_ASSET_CLASS_POINTER(1:MAX_OL_CLASS_ID_NUM)
      ENDIF
      DEALLOCATE(TEMP_ASSET_CLASS_POINTER)
C
      RETURN
C
c  200 CALL LOCATE(20,0)
c      WRITE(6,1010) trim(RECLN)
  200 CALL MG_LOCATE_WRITE(20,0,trim(RECLN),ALL_VERSIONS,1)
      er_message='stop requested from msgmmtax SIID243'
      call end_program(er_message)
C***********************************************************************
      ENTRY RESET_TAX_LOSS_OL
C***********************************************************************
         FILE_OL = 'BC'
      RETURN
C***********************************************************************
      ENTRY OPEN_TAX_LOSS_FILE(R_UNIT_NUM,R_FILE_OL)
C***********************************************************************
         UNIT_NUM = R_UNIT_NUM
         IF(R_FILE_OL == 'BC') THEN
            OPEN(UNIT_NUM,FILE=trim(OUTPUT_DIRECTORY())//
     +         FILE_BC_NAME,ACCESS="DIRECT",STATUS="UNKNOWN",RECL=LRECL)
         ELSE
            OPEN(UNIT_NUM,FILE=trim(OUTPUT_DIRECTORY())//
     +         FILE_OL_NAME,ACCESS="DIRECT",STATUS="UNKNOWN",RECL=LRECL)
         ENDIF
      RETURN
C***********************************************************************
      ENTRY CLOSE_TAX_LOSS_FILE
C***********************************************************************
         CLOSE(UNIT_NUM)
      RETURN
C***********************************************************************
      ENTRY GET_TAX_OL(R_FILE_OL,R_FILE_EXISTS)
C***********************************************************************
         R_FILE_OL = FILE_OL
         R_FILE_EXISTS = FILE_EXISTS
      RETURN
C***********************************************************************
      ENTRY TAX_ITEMS_FILE_ACTIVE(R_FILE_EXISTS)
C***********************************************************************
C
         R_FILE_EXISTS = FILE_EXISTS
      RETURN
C***********************************************************************
      ENTRY OPEN_TAX_BASE_CASE_FILE(R_UNIT_NUM)
C***********************************************************************
         OPEN(R_UNIT_NUM,FILE=trim(OUTPUT_DIRECTORY())//
     +                                "BC_TAXES.BIN",FORM='UNFORMATTED')
      RETURN
C***********************************************************************
      ENTRY RETURN_NUM_OF_TAX_CLASSES(R_NUM_OF_CLASSES,
     +                                       R_MAX_CLASS_NUM)
C***********************************************************************
         IF(FILE_OL == 'OL') THEN
            R_NUM_OF_CLASSES = NUMBER_OF_OL_CLASSES
            R_MAX_CLASS_NUM = MAX_OL_CLASS_ID_NUM
         ELSE
            R_NUM_OF_CLASSES = NUMBER_OF_BC_CLASSES
            R_MAX_CLASS_NUM = MAX_BC_CLASS_ID_NUM
         ENDIF
      RETURN
C***********************************************************************
      ENTRY RETURN_TAX_CLASS_POINTER(R_CLASS_POINTERS)
C***********************************************************************
         IF(FILE_OL == 'OL') THEN
            R_CLASS_POINTERS(1:MAX_OL_CLASS_ID_NUM) =
     +                     OL_ASSET_CLASS_POINTER(1:MAX_OL_CLASS_ID_NUM)
         ELSE
            IF(MAX_BC_CLASS_ID_NUM > 0) THEN
               R_CLASS_POINTERS(1:MAX_BC_CLASS_ID_NUM) =
     +                     BC_ASSET_CLASS_POINTER(1:MAX_BC_CLASS_ID_NUM)
            ELSE
               R_CLASS_POINTERS(1) = -99
            ENDIF
         ENDIF
      RETURN
C
 1000 FORMAT(A)
 1010 FORMAT('&',A)
      END
C***********************************************************************
C*                                                                     *
C*                          TAX_INFORMATION                            *
C*                                                                     *
C*          COPYRIGHT (C) 1998 M.S. GERBER & ASSOCIATES, INC           *
C*                         ALL RIGHTS RESERVED                         *
C*                                                                     *
C***********************************************************************
C                                                                      *
      RECURSIVE SUBROUTINE TAX_INFORMATION(SAVE_BASE_CASE)

C

C BEGIN TAX STUFF
      USE IREC_ENDPOINT_CONTROL
      USE DRILLING_REPT_PARAMETERS
      INCLUDE 'SpinLib.MON'
      SAVE
      INCLUDE 'SIZECOM.MON'
      INCLUDE 'GLOBECOM.MON'
      INCLUDE 'NAMESCOM.MON'
      INCLUDE 'MTHNMCOM.MON'
      INCLUDE 'm3active.mon'
C
      INTEGER*2 RUN_YEARS,EXTENSION_YEARS,FINANCIAL_SIMULATION_YEARS,
     +          DRILLING_REPORTING_YEARS
      INTEGER*2 NUM_OF_CLASSES,MAX_CLASS_NUM,TAX_TYPE
      INTEGER*2 BASE_CASE_NUM_OF_CLASSES,
     +          BASE_CASE_MAX_CLASS_NUM
      INTEGER*4 VALUES_TO_ZERO
      LOGICAL*1 NON_INCOME_TAXES/.FALSE./
      CHARACTER*(*) R_TAX_CLASSIFICATION,R_TAX_APPLICATION*1
      REAL*4 R_ALLOC_TAX(*)
      INTEGER*2 R_ASSET_CLASS,YR,TAX_POSITION,POINTER,
     +          ACTUAL_TAX_POSITION
      INTEGER*2 R_YR,APP
      REAL*4 TAX_VALUES(:,:,:,:,:),
     +       TAX_VALUES_NOLS(:,:,:,:),
     +       ACTUAL_MONTHLY_TAX_VALUES(:,:,:,:)
      LOGICAL*1 ACTUAL_VALUE_FOUND(:,:)
      ALLOCATABLE :: TAX_VALUES,TAX_VALUES_NOLS,
     +               ACTUAL_MONTHLY_TAX_VALUES,
     +               ACTUAL_VALUE_FOUND
      REAL*4 R_PROPERTY_TAX,
     +       R_OTHER_TAXES,
     +       R_REVENUE_TAXES
      REAL*4 R_FED_TAX_CREDITS,
     +       R_STATE_TAX_CREDITS,
     +       R_FED_INCOME_TAX_ADJ,
     +       R_STATE_INCOME_TAX_ADJ,
     +       R_M1_FED_ADDITIONS,
     +       R_M1_FED_DEDUCTIONS,
     +       R_M1_STATE_ADDITIONS,
     +       R_M1_STATE_DEDUCTIONS,
     +       R_DEFERRED_TAXES_CR,
     +       R_DEFERRED_TAXES_DR,
     +       R_ITC_AMORTIZATION,
     +       R_SEC_29_CREDITS,
     +       R_SEC_42_CREDITS
      CHARACTER*30 DESCRIPTION,
     +             VARIABLE_USEAGE*2,
     +             TAX_TIMING_CLASSIFICATION*22
      INTEGER*2 DELETE,PERIOD
C
      INTEGER*2 ESCALATION_VECTOR
      INTEGER ACCTNO
      INTEGER*2 MONTHLY_TAX_VECTOR
      CHARACTER*1 CONSOLIDATED_CLASS
      CHARACTER*10 TAX_APPLIES_TO
      CHARACTER*30 TAX_TYPE_STR,
     +             TAX_RATES,
     +             CARRY_FORWARDS,
     +             TAX_ON_CAPITAL,
     +             TAX_CREDITS_ADJUSTMENTS,
     +             DEFERRED_TAX_AMT,
     +             TAX_DEDUCTIONS,
     +             TAX_CLASSIFICATION,
     +             TAX_ACTUALS
      CHARACTER*30 DRILLING_NAME
      CHARACTER*2 TAX_INFO_OL
      CHARACTER*1 ANNUAL_VALUE_STATUS(5), ! 5 VALUES
     +            ACCOUNT_ACTIVE
C
C  SECTION
C
      REAL*4 ALLOCATION_VALUE(AVAIL_DATA_YEARS)
      INTEGER*2 ALLOCATION_VECTOR
      INTEGER*2 ASSET_CLASS_ID
      CHARACTER*1 DUMMY_TYPE
      LOGICAL*4 SAVE_BASE_CASE
C
C END TAX STUFF
      INTEGER*2 I,CLASS_POINTER
      INTEGER*4 IOS
      INTEGER*2 ASSET_CLASS_POINTER(:)
      ALLOCATABLE :: ASSET_CLASS_POINTER
      LOGICAL*4 BASE_FILE_EXISTS
      INTEGER*4 IREC,INCOME_DRILLING_REPRT_REC,TAX_DRILLING_REPRT_REC
C
C MONTHLY TAX VECTOR STUFF
C
      CHARACTER*1 MONTHLY_DATA_UNITS(LAST_AVAILABLE_MONTHLY_YEAR)
      CHARACTER*4 MIDAS_LAST_MONTH(LAST_AVAILABLE_MONTHLY_YEAR)
      INTEGER*2 MONTH_ENDING(LAST_AVAILABLE_MONTHLY_YEAR)
      REAL*4 MONTHLY_VALUES(12,LAST_AVAILABLE_MONTHLY_YEAR),
     +       ALLOC_MONTHLY_TAX(12,LAST_AVAILABLE_MONTHLY_YEAR),
     +       R_ALLOC_MONTHLY_TAX(12,LAST_AVAILABLE_MONTHLY_YEAR)
      CHARACTER*1 DATA_TYPE,VECTOR_TYPE*20
C
C     TYPE DECLARATION FOR /FAINPT/
C
      INTEGER*2 ASSET_ALLOCATION_VECTOR,
     +          ASSET_CLASS
      REAL*4 ASSET_ALLOCATOR
      LOGICAL*1 DRILLING_REPORT_IS_INCOME,DRILLING_REPORT_IS_TAX,
     +          VALUE_IS_A_RATE,DONT_ADD_VALUES/.FALSE./
      INTEGER*2 DRILLING_REPORT_UNIT
      LOGICAL*1 VOID_LOGICAL,SET_DRILLING_DATA_INCOME_TRUE,
     +          SET_DRILLING_DATA_TAX_TRUE
C
C     TYPE DECLARATION FOR /WKARRY/
C
      REAL*4 DATA_VALUES(:),ALLOC_TAX(:),
     +       ANNUAL_TAX_VALUES(:),
     +       ASSET_CLASS_LIST(:),ASSET_ALLOCATION_LIST(:),
     +       OUTPUT_VALUE(:),
     +       REPORTING_MONTHLY_VALUES(:,:)
      ALLOCATABLE :: ALLOC_TAX,DATA_VALUES,
     +               ANNUAL_TAX_VALUES,
     +               ASSET_CLASS_LIST,ASSET_ALLOCATION_LIST,
     +               OUTPUT_VALUE,
     +               REPORTING_MONTHLY_VALUES
C
      INTEGER*2 INCOME_DRILLING_REPRT_UNIT,INCOME_DRILLING_UNIT_NO,MO
      INTEGER*2 TAX_DRILLING_REPRT_UNIT,TAX_DRILLING_UNIT_NO
      LOGICAL*1 TAX_ITEMS_IN_DRILLING,DRILLING_ITEM_CAN_BE_REPORTED,
     +          NEEDS_ALLOCATION_VECTOR,ACTUAL_TAX_VALUES
      CHARACTER*1 DRILLING_REPRT_LEVEL,FINANCIAL_DRILLING
      CHARACTER*6 SHORT_MONTH_NAMES
      REAL*4 NOT_AVAIL
      PARAMETER(NOT_AVAIL=-999999.)
      CHARACTER*1 DOLLARS,PERCENT,NORMALIZE,AVERAGE,TREND,LAST_MONTH,
     +            USE_ANNUAL_VALUES,RATE,TRENDED_RATE
      PARAMETER (DOLLARS='D',PERCENT='P',NORMALIZE='N',
     +           AVERAGE='A',TREND='T',LAST_MONTH='L',
     +           USE_ANNUAL_VALUES='U',RATE='R',TRENDED_RATE='E')
      INTEGER*2 PARENT_CLASS_NUMBER
C
      INTEGER*2 NUM_OF_EXP_CLASSES,MAX_EXP_CLASS_NUM,CLASSES,ITEMS
      LOGICAL*1 FALSE_BYTE
      LOGICAL*1 ADDED_TO_CURRENT_VALUE,THIS_IS_A_TIMING_VALUE
      INTEGER*2 Timing Type
      REAL*4 SIGN
C
      REAL*4 MONTHLY_VARS(0:12,*)
      INTEGER*2 R_TAX_TYPE
C
      REAL*4 R_ACE_TAX_DEPRECIATION,
     +       R_TAX_PREFERENCE_DEPRECIATION,
     +       R_BTL_DEFERRED_TAXES_CR,
     +       R_BTL_DEFERRED_TAXES_DR,
     +       R_AMT_INCOME_ADDENDUM,
     +       R_INCOME_TAX_DEPRECIATION,
     +       R_BTL_MISC_DEDUCTIONS
C
      REAL*4 R_CONSOL_DEFERRED_TAXES_DR(0:12)
C
      REAL*4 R_MONTHLY_DEFERRED_TAXES_DR(0:12)
      REAL*4 R_PROPERTY_TAX_ADJUSTMENT(0:12),
     +       R_OTHER_TAX_ADJUSTMENT(0:12),
     +       R_REVENUE_TAX_ADJUSTMENT(0:12),
     +       R_STATE_M1_ADDITIONS(0:12),
     +       R_STATE_M1_DEDUCTIONS(0:12),
     +       R_FEDERAL_M1_ADDITIONS(0:12),
     +       R_FEDERAL_M1_DEDUCTIONS(0:12),
     +       R_STATE_BTL_MISC_DEDUCTIONS(0:12),
     +       R_FEDERAL_BTL_MISC_DEDUCTIONS(0:12),
     +       R_STATE_INCOME_TAX_ADJUSTMENT(0:12),
     +       R_FEDERAL_INCOME_TAX_ADJUSTMENT(0:12)
      REAL*4 RM_TEMP_FED_TAX_RATE(0:12),
     +       RM_ITC_AMORTIZATION_RATE(0:12),
     +       RM_STATE_TAX_RATE(0:12),
     +       RM_OPREV_TAX_RATE(0:12),
     +       RM_PROPERTY_TAX_RATE(0:12),
     +       RM_CLASS_OTHER_TAXES_RATE(0:12),
     +       RM_OTHER_TAXES_PERCENT_OF_EXPEN(0:12),
     +       RM_STATE_DEDUC_PERCT_OF_TIB4DED(0:12),
     +       RM_FED_DEDUC_PERCT_OF_TIB4DEDUC(0:12)
      CHARACTER*1 R_CLASS_TYPE
      REAL*4 DEFAULT,CURRENT
C
      REAL*4 R_ACTUAL_DEFERRED_TAXES_CR(0:12),
     +       R_ACTUAL_FED_INCOME_TAXES(0:12),
     +       R_ACTUAL_STATE_INCOME_TAXES(0:12),
     +       R_ACTUAL_DEFERRED_TAXES_DR(0:12)
      INTEGER*2 R_CLASS
C
      REAL*4 R_ACTUAL_INCOME_TAXES(0:12)
      REAL*4 ANNUAL_AMOUNT,REMAINING_ANNUAL_BALANCE,
     +       UNALLOCATED_BALANCE,RATIO
C
      REAL*4 R_ANNUAL_STATE_INCOME_TAX,
     +       R_ANNUAL_FEDERAL_INCOME_TAX,
     +       R_DEFERRED_TAXES_ACTUAL_DR,
     +       R_DEFERRED_TAXES_ACTUAL_CR
      LOGICAL*1 R_USE_ACTUAL_STATE_TAXES,
     +          R_USE_ACTUAL_FEDERAL_TAXES,
     +          R_USE_ACTUAL_DEFERRED_TAXES_DR,
     +          R_USE_ACTUAL_DEFERRED_TAXES_CR
C
      REAL*4 R_FED_NOLS(*),
     +       R_STATE_NOLS(*),
     +       R_AMT_NOLS(*),
     +       R_GENERAL_TAX_CREDITS(*),
     +       R_SEC_42_TAX_CREDITS(*),
     +       R_STATE_BUSINESS_CREDITS(*)
      LOGICAL*1 R_CLASS_EXITS
C
      REAL*4 R_TEMP_FED_TAX_RATE,
     +       R_ITC_AMORTIZATION_RATE,
     +       R_STATE_TAX_RATE,
     +       R_OPREV_TAX_RATE,
     +       R_PROPERTY_TAX_RATE,
     +       R_CLASS_OTHER_TAXES_RATE,
     +       R_OTHER_TAXES_PERCENT_OF_EXPEN,
     +       R_STATE_DEDUC_PERCT_OF_TIB4DED,
     +       R_FED_DEDUC_PERCT_OF_TIB4DEDUC
C
      REAL*4 R_PROVINCIAL_CAPITAL_TAX_RATE,
     +       R_FEDERAL_CAPITAL_TAX_RATE,
     +       R_PROVINCIAL_CAP_TAX_DEDUCTION,
     +       R_FEDERAL_CAPITAL_TAX_DEDUCTION,
     +       R_FEDERAL_CAPITAL_TAX_ADDENDUM,
     +       R_PROVINCIAL_CAP_TAX_ADDENDUM
      INTEGER*2 MO2,VOID_INT2,WRITE_DRILLING_RPT
      LOGICAL*1 ANNUAL_INFO_ACTIVE
      CHARACTER*1 REPORT_TYPE
      LOGICAL (KIND=1) :: EXTENSION_PERIOD_IS_ADDENUM
C
c      SAVE FINANCIAL_SIMULATION_YEARS
c      SAVE BASE_CASE_NUM_OF_CLASSES,
c     +     BASE_CASE_MAX_CLASS_NUM
c      SAVE NUM_OF_CLASSES,MAX_CLASS_NUM
c      SAVE TAX_VALUES,TAX_VALUES_NOLS,
c     +     ACTUAL_MONTHLY_TAX_VALUES,
c     +     ACTUAL_VALUE_FOUND
c      SAVE TAX_TIMING_CLASSIFICATION
c      SAVE ASSET_CLASS_POINTER
c      SAVE ACTUAL_TAX_VALUES
C
      CALL TAX_ITEMS_FILE_ACTIVE(BASE_FILE_EXISTS)
      IF(.NOT. BASE_FILE_EXISTS) RETURN
      IF(SAVE_BASE_CASE) THEN
         CALL OPEN_TAX_LOSS_FILE(INT2(11),'BC')
      ELSE
         CALL GET_TAX_OL(TAX_INFO_OL,BASE_FILE_EXISTS)
         IF(TAX_INFO_OL == 'BC') THEN
            IF(BASE_FILE_EXISTS) CALL READ_TAX_ITEMS_BASE_CASE
            RETURN
         ENDIF
         CALL OPEN_TAX_LOSS_FILE(INT2(11),'OL')
      ENDIF
C
      FINANCIAL_SIMULATION_YEARS = MAX(15,LAST_AVAILABLE_MONTHLY_YEAR,  ! the 15 is for lose carry forwards
     +                                  RUN_YEARS() + EXTENSION_YEARS())
      DRILLING_REPORTING_YEARS =  MAX(LAST_AVAILABLE_MONTHLY_YEAR,
     +                                  RUN_YEARS() + EXTENSION_YEARS())
      DRILLING_REPRT_LEVEL = FINANCIAL_DRILLING()
      ANNUAL_INFO_ACTIVE = DRILLING_REPRT_LEVEL == 'A'
      IF(DRILLING_REPRT_LEVEL /= 'O') THEN
         INCOME_DRILLING_REPRT_UNIT = INCOME_DRILLING_UNIT_NO()
         TAX_DRILLING_REPRT_UNIT= TAX_DRILLING_UNIT_NO()
         TAX_ITEMS_IN_DRILLING = .TRUE.
      ELSE
         TAX_ITEMS_IN_DRILLING = .FALSE.
      ENDIF
C
      CALL SET_TAX_ARRAYS
C
      ALLOCATE(DATA_VALUES(0:AVAIL_DATA_YEARS),
     +        ANNUAL_TAX_VALUES(0:FINANCIAL_SIMULATION_YEARS),
     +        REPORTING_MONTHLY_VALUES(0:12,
     +                                    0:FINANCIAL_SIMULATION_YEARS),
     +        ALLOC_TAX(FINANCIAL_SIMULATION_YEARS),
     +        OUTPUT_VALUE(FINANCIAL_SIMULATION_YEARS),
     +        ASSET_CLASS_LIST(AVAIL_DATA_YEARS),
     +        ASSET_ALLOCATION_LIST(AVAIL_DATA_YEARS))
      IREC = 0
      CALL PARENT_CLASS_ID(PARENT_CLASS_NUMBER)
C
      DO
         IREC = IREC + 1
         READ(11,REC=IREC,IOSTAT=IOS) DELETE,ACCTNO,
     +                               TAX_TYPE_STR,
     +                               TAX_APPLIES_TO,
     +                               DATA_VALUES,
     +                               DESCRIPTION,
     +                               DATA_TYPE,
     +                               ESCALATION_VECTOR,
     +                               ASSET_CLASS_ID,
     +                               ASSET_ALLOCATION_VECTOR,
     +                               DEFERRED_TAX_AMT,
     +                               TAX_RATES,
     +                               CARRY_FORWARDS,
     +                               TAX_ON_CAPITAL,
     +                               TAX_CREDITS_ADJUSTMENTS,
     +                               TAX_DEDUCTIONS,
     +                               CONSOLIDATED_CLASS,
     +                               MONTHLY_TAX_VECTOR,
     +                               VARIABLE_USEAGE,
     +                               TAX_TIMING_CLASSIFICATION,
     +                               TAX_ACTUALS,
     +                               ANNUAL_VALUE_STATUS, ! 5 VALUES
     +                               ACCOUNT_ACTIVE
         IF(IOS /= 0) EXIT
         IF(DELETE > 7 .OR. ACCOUNT_ACTIVE == 'N' .OR.
     +                                    VARIABLE_USEAGE == 'No') CYCLE ! LOGICAL DELETE OR NOT ACTIVE
         IF(VARIABLE_USEAGE(1:1) == 'P') THEN
            ASSET_CLASS_ID = PARENT_CLASS_NUMBER
            ASSET_ALLOCATION_VECTOR = 0. ! 100.
         ENDIF
C
C IDENTIFY TAX TYPE
C
         NEEDS_ALLOCATION_VECTOR = .TRUE.
         ACTUAL_TAX_VALUES = .FALSE.
C        VALUE_IS_A_RATE = .TRUE.
         VALUE_IS_A_RATE = .FALSE.
         EXTENSION_PERIOD_IS_ADDENUM = .FALSE.
         SELECT CASE (trim(TAX_TYPE_STR))
C
C TAX POSITIONS
C
         CASE ('Rates')
            TAX_CLASSIFICATION = TAX_RATES
            DRILLING_ITEM_CAN_BE_REPORTED = .FALSE.
            NEEDS_ALLOCATION_VECTOR = .FALSE.
C           VALUE_IS_A_RATE = .FALSE.
            VALUE_IS_A_RATE = .TRUE.
            DATA_TYPE = 'D'
         CASE ('Deductions')
            TAX_CLASSIFICATION = TAX_DEDUCTIONS
            DRILLING_ITEM_CAN_BE_REPORTED = .TRUE. ! .FALSE.
         CASE ('Credits & Adjustments')
            TAX_CLASSIFICATION = TAX_CREDITS_ADJUSTMENTS
            DRILLING_ITEM_CAN_BE_REPORTED = .TRUE. ! .FALSE.
C            CONSOLIDATED_CLASS = 'Y'
         CASE ('Deferred & AMT')
            TAX_CLASSIFICATION = DEFERRED_TAX_AMT
            DRILLING_ITEM_CAN_BE_REPORTED = .TRUE. ! .FALSE.
            EXTENSION_PERIOD_IS_ADDENUM = .TRUE.
         CASE ('Carry Forwards')
            TAX_CLASSIFICATION = CARRY_FORWARDS
            DRILLING_ITEM_CAN_BE_REPORTED = .FALSE.
         CASE ('Capital')
            TAX_CLASSIFICATION = TAX_ON_CAPITAL
            DRILLING_ITEM_CAN_BE_REPORTED = .FALSE.
            IF(INDEX(TAX_CLASSIFICATION,'Rate') /= 0) THEN
               NEEDS_ALLOCATION_VECTOR = .FALSE.
               VALUE_IS_A_RATE = .TRUE.
               DATA_TYPE = 'D'
            ENDIF
         CASE ('Actuals')
            TAX_CLASSIFICATION = TAX_ACTUALS
            DRILLING_ITEM_CAN_BE_REPORTED = .FALSE.
            ACTUAL_TAX_VALUES = .TRUE.
         CASE DEFAULT
            CYCLE
         END SELECT
C
C CONVERT THE INPUT DATA TO DOLLARS
C
         IF(MONTHLY_TAX_VECTOR /= 0 .AND. MONTHLY_MIDAS_ACTIVE) THEN
C
C NEED TO GET MONTHLY INFORMTION INTO THIS FILE 9/20/98
C
            CALL GET_MONTHLY_ANNUAL_VALUES(MONTHLY_TAX_VECTOR,
     +                                     DATA_TYPE,
     +                                     VECTOR_TYPE,
     +                                     DATA_VALUES(1),
     +                                     MONTHLY_VALUES(1,1),
     +                                     MONTHLY_DATA_UNITS,
     +                                     MONTH_ENDING)

            CALL RIPPLE_MONTHLY_DATA(DATA_VALUES(1),MONTHLY_VALUES)
C
            IF(ACTUAL_TAX_VALUES) THEN
               CALL MONTHLY_ACTUAL_VALUES(DATA_VALUES(1),
     +                                    MONTHLY_VALUES,
     +                                    MONTHLY_DATA_UNITS,
     +                                    MONTH_ENDING,
     +                                    ANNUAL_VALUE_STATUS)
               DO YR = 1, FINANCIAL_SIMULATION_YEARS
                  ANNUAL_TAX_VALUES(YR) =
     +                             DATA_VALUES(MIN(YR,AVAIL_DATA_YEARS))
               ENDDO
            ELSEIF(VALUE_IS_A_RATE) THEN
               IF(.NOT.(MONTHLY_DATA_UNITS(1) == DOLLARS .OR.
     +                  MONTHLY_DATA_UNITS(1) == PERCENT))
     +                         MONTHLY_DATA_UNITS(1) = USE_ANNUAL_VALUES
               DO YR = 2, LAST_AVAILABLE_MONTHLY_YEAR
                  IF(MONTHLY_DATA_UNITS(YR) == TREND)
     +                             MONTHLY_DATA_UNITS(YR) = TRENDED_RATE
               ENDDO
               CALL MONTHLY_BOOK_VALUES_NO_ADD(DATA_VALUES(1),
     +                                         MONTHLY_VALUES,
     +                                         MONTHLY_DATA_UNITS,
     +                                         MONTH_ENDING,
     +                                         DONT_ADD_VALUES)
               DO YR = 1, FINANCIAL_SIMULATION_YEARS
                  ANNUAL_TAX_VALUES(YR) =
     +                             DATA_VALUES(MIN(YR,AVAIL_DATA_YEARS))
               ENDDO
            ELSE
               CALL MONTHLY_BOOK_VALUES_IN_DOLLARS(DATA_VALUES(1),
     +                                             MONTHLY_VALUES,
     +                                             MONTHLY_DATA_UNITS,
     +                                             MONTH_ENDING)
               IF(EXTENSION_PERIOD_IS_ADDENUM) DATA_TYPE = 'A'!DDENDUM 11/14/06 DR.G

               CALL CREATE_DOLLAR_STREAM(FINANCIAL_SIMULATION_YEARS,
     +                                   DATA_TYPE,ESCALATION_VECTOR,
     +                                   DATA_VALUES,ANNUAL_TAX_VALUES)
            ENDIF
         ELSE
            IF(EXTENSION_PERIOD_IS_ADDENUM) DATA_TYPE = 'A'!DDENDUM 11/14/06 DR.G
            CALL CREATE_DOLLAR_STREAM(FINANCIAL_SIMULATION_YEARS,
     +                                DATA_TYPE,ESCALATION_VECTOR,
     +                                DATA_VALUES,ANNUAL_TAX_VALUES)
            IF(VALUE_IS_A_RATE) THEN
               MONTHLY_VALUES = 0.
               DO YR = 1, LAST_AVAILABLE_MONTHLY_YEAR
                  MONTHLY_DATA_UNITS(YR) = USE_ANNUAL_VALUES
                  MONTH_ENDING(YR) = 12
               ENDDO
            ELSE
               DO YR = 1, LAST_AVAILABLE_MONTHLY_YEAR
                  MONTHLY_DATA_UNITS(YR) = AVERAGE
                  MONTH_ENDING(YR) = 12
               ENDDO
            ENDIF
            CALL MONTHLY_BOOK_VALUES_IN_DOLLARS(ANNUAL_TAX_VALUES(1),
     +                                          MONTHLY_VALUES,
     +                                          MONTHLY_DATA_UNITS,
     +                                          MONTH_ENDING)
         ENDIF
         DATA_TYPE = DOLLARS
C
C WRITE DRILLING ITEMS
C
c$ifdefined(use_this_drilling_code)
c         IF(TAX_ITEMS_IN_DRILLING .AND.
c     +                               DRILLING_ITEM_CAN_BE_REPORTED) THEN
c
c            ACCOUNT_NAME = DESCRIPTION
c            DRILLING_NAME = TAX_CLASSIFICATION
c            IF(DRILLING_REPRT_LEVEL == 'A') THEN
c               WRITE(INCOME_DRILLING_REPRT_UNIT) PRT_ENDPOINT(),
c     +                                    DRILLING_NAME,
c     +                                    ACCOUNT_NAME,
c     +                                   (ANNUAL_TAX_VALUES(YR),YR = 1,
c     +                                       DRILLING_REPORTING_YEARS)
c            ELSEIF(DRILLING_REPRT_LEVEL == 'M') THEN
c               WRITE(INCOME_DRILLING_REPRT_UNIT) PRT_ENDPOINT(),
c     +                                    DRILLING_NAME,
c     +                                    SHORT_MONTH_NAMES(0),
c     +                                    ACCOUNT_NAME,
c     +                                   (ANNUAL_TAX_VALUES(YR),YR = 1,
c     +                                       DRILLING_REPORTING_YEARS)
c               DO MO = 1, 12
c                  DO YR = 1, DRILLING_REPORTING_YEARS
c                     IF(YR >= 1 .AND.
c     +                           YR <= LAST_AVAILABLE_MONTHLY_YEAR) THEN
c                        IF(MONTHLY_TAX_VECTOR /= 0 .AND.
c     +                                        MONTHLY_MIDAS_ACTIVE) THEN
c                           OUTPUT_VALUE(YR) = MONTHLY_VALUES(MO,YR)
c                        ELSE
c                           OUTPUT_VALUE(YR) = MONTHLY_VALUES(MO,YR) ! ANNUAL_TAX_VALUES(YR)/12.
c                        ENDIF
cC                       OUTPUT_VALUE(YR) = ANNUAL_TAX_VALUES(YR)/12.
c                     ELSE
c                        OUTPUT_VALUE(YR) = NOT_AVAIL
c                     ENDIF
c                  ENDDO
c                  WRITE(INCOME_DRILLING_REPRT_UNIT) PRT_ENDPOINT(),
c     +                                    DRILLING_NAME,
c     +                                    SHORT_MONTH_NAMES(MO),
c     +                                    ACCOUNT_NAME,
c     +                                   (OUTPUT_VALUE(YR),YR = 1,
c     +                                       DRILLING_REPORTING_YEARS)
c               ENDDO
c            ENDIF
c         ENDIF
c$endif
C
C ALLOCATE TO TOTAL COMPANY AND ASSET CLASSES
C
         IF(VARIABLE_USEAGE == 'Co' .OR. CONSOLIDATED_CLASS == 'Y') THEN ! Apply only to the Consolidated
            IF(ACTUAL_TAX_VALUES) THEN
               CALL ACTUAL_TAXES_ACCUMULATION(INT2(-1),
     +                                        ANNUAL_TAX_VALUES(1),
     +                                        TAX_CLASSIFICATION,
     +                                        MONTHLY_VALUES)
            ELSE
               CALL TAXES_INCOME_AND_OTHER(INT2(-1),
     +                                     ANNUAL_TAX_VALUES(1),
     +                                     TAX_CLASSIFICATION,
     +                                     TAX_APPLIES_TO(1:1),
     +                                     MONTHLY_VALUES)
            ENDIF
         ENDIF
C
         IF(INDEX('ABSR',VARIABLE_USEAGE(1:1)) /=0) THEN ! Other Default Positions
C
C DEFAULT HOLDING POSITIONS ARE -2==All, -3==Parent, etc.
C
            IF(VARIABLE_USEAGE(1:1) == 'A') THEN
               DO ASSET_CLASS = -5, -2
                  CALL TAXES_INCOME_AND_OTHER(ASSET_CLASS,
     +                                  ANNUAL_TAX_VALUES(1),
     +                                  TAX_CLASSIFICATION,
     +                                  TAX_APPLIES_TO(1:1),
     +                                  MONTHLY_VALUES)
               ENDDO
            ELSE
               ASSET_CLASS = -1 - INDEX('PBSR',VARIABLE_USEAGE(1:1))
               CALL TAXES_INCOME_AND_OTHER(ASSET_CLASS,
     +                                  ANNUAL_TAX_VALUES(1),
     +                                  TAX_CLASSIFICATION,
     +                                  TAX_APPLIES_TO(1:1),
     +                                  MONTHLY_VALUES)
            ENDIF
         ELSEIF(INDEX(VARIABLE_USEAGE,'Co') == 0) THEN
            IF(ASSET_CLASS_ID < 0.) THEN ! Class Specific
               CALL GET_ASSET_VAR(ABS(ASSET_CLASS_ID),
     +                                      DUMMY_TYPE,ASSET_CLASS_LIST)
               IF(NEEDS_ALLOCATION_VECTOR) THEN
                  CALL GET_ASSET_VAR(ABS(ASSET_ALLOCATION_VECTOR),
     +                                 DUMMY_TYPE,ASSET_ALLOCATION_LIST)
               ELSE
                  ASSET_ALLOCATION_LIST = 100.
               ENDIF
            ELSE
               ASSET_CLASS_LIST(1) = ASSET_CLASS_ID
               ASSET_CLASS_LIST(2) = 0
               ASSET_ALLOCATION_LIST(1) = 100.
               ASSET_ALLOCATION_LIST(2) = 0.
            ENDIF
            CLASS_POINTER = 1
            DO
               ASSET_CLASS = ASSET_CLASS_LIST(CLASS_POINTER)
               CALL CHECK_IF_CLASS_DEFINED(ASSET_CLASS)
               ASSET_CLASS = ASSET_CLASS + 1
               IF(ASSET_CLASS >= 0) ASSET_CLASS =
     +                                  ASSET_CLASS_POINTER(ASSET_CLASS)
               IF(ASSET_ALLOCATION_LIST(CLASS_POINTER) < 0.) THEN
                  ALLOCATION_VECTOR =
     +                         ABS(ASSET_ALLOCATION_LIST(CLASS_POINTER))
                  CALL GET_ASSET_VAR(ALLOCATION_VECTOR,
     +                                      DUMMY_TYPE,ALLOCATION_VALUE)
                  DO YR = 1, FINANCIAL_SIMULATION_YEARS
                     IF(ACTUAL_TAX_VALUES) THEN
                        IF(ANNUAL_TAX_VALUES(YR) == -99999.) THEN
                           ALLOC_TAX(YR) = ANNUAL_TAX_VALUES(YR)
                        ELSE
                           ALLOC_TAX(YR) = ASSET_ALLOCATOR *
     +                                             ANNUAL_TAX_VALUES(YR)
                        ENDIF
                        IF(YR <= LAST_AVAILABLE_MONTHLY_YEAR) THEN
                           DO MO = 1, 12
                              IF(MONTHLY_VALUES(MO,YR) == -99999.) THEN
                                 ALLOC_MONTHLY_TAX(MO,YR) =
     +                                             MONTHLY_VALUES(MO,YR)
                              ELSE
                                 ALLOC_MONTHLY_TAX(MO,YR) =
     +                                             ASSET_ALLOCATOR *
     +                                             MONTHLY_VALUES(MO,YR)
                              ENDIF
                           ENDDO
                        ENDIF
                     ELSE
                        IF(YR <= AVAIL_DATA_YEARS)
     +                       ASSET_ALLOCATOR = ALLOCATION_VALUE(YR)/100.
                        ALLOC_TAX(YR) = ASSET_ALLOCATOR *
     +                                             ANNUAL_TAX_VALUES(YR)
     +
                        IF(YR <= LAST_AVAILABLE_MONTHLY_YEAR) THEN
                           DO MO = 1, 12
                              ALLOC_MONTHLY_TAX(MO,YR)=ASSET_ALLOCATOR *
     +                                             MONTHLY_VALUES(MO,YR)
                           ENDDO
                        ENDIF
                     ENDIF
                  ENDDO
               ELSE
                  ASSET_ALLOCATOR =
     +                         ASSET_ALLOCATION_LIST(CLASS_POINTER)/100.
C
                  DO YR = 1, FINANCIAL_SIMULATION_YEARS
                     IF(ACTUAL_TAX_VALUES) THEN
                        IF(ANNUAL_TAX_VALUES(YR) == -99999.) THEN
                           ALLOC_TAX(YR) = ANNUAL_TAX_VALUES(YR)
                        ELSE
                           ALLOC_TAX(YR) = ANNUAL_TAX_VALUES(YR) *
     +                                                   ASSET_ALLOCATOR
                        ENDIF
                     ELSE
                        ALLOC_TAX(YR) = ANNUAL_TAX_VALUES(YR) *
     +                                                   ASSET_ALLOCATOR
                     ENDIF
                     IF(YR <= LAST_AVAILABLE_MONTHLY_YEAR) THEN
                        DO MO = 1, 12
                           IF(ACTUAL_TAX_VALUES) THEN
                              IF(MONTHLY_VALUES(MO,YR) == -99999.) THEN
                                 ALLOC_MONTHLY_TAX(MO,YR) =
     +                                             MONTHLY_VALUES(MO,YR)
                              ELSE
                                 ALLOC_MONTHLY_TAX(MO,YR) =
     +                                             ASSET_ALLOCATOR *
     +                                             MONTHLY_VALUES(MO,YR)
                              ENDIF
                           ELSE
                              ALLOC_MONTHLY_TAX(MO,YR) =
     +                                             ASSET_ALLOCATOR *
     +                                             MONTHLY_VALUES(MO,YR)
                           ENDIF
                        ENDDO
                     ENDIF
                  ENDDO
               ENDIF
C
C ACTUAL TAX VALUES
C
               IF(ACTUAL_TAX_VALUES) THEN
                  CALL ACTUAL_TAXES_ACCUMULATION(ASSET_CLASS,
     +                                           ALLOC_TAX,
     +                                           TAX_CLASSIFICATION,
     +                                           ALLOC_MONTHLY_TAX)
               ELSE
                  CALL TAXES_INCOME_AND_OTHER(ASSET_CLASS,
     +                                        ALLOC_TAX,
     +                                        TAX_CLASSIFICATION,
     +                                        TAX_APPLIES_TO(1:1),
     +                                        ALLOC_MONTHLY_TAX)
C
               ENDIF
               CLASS_POINTER = CLASS_POINTER + 1
               IF(CLASS_POINTER > AVAIL_DATA_YEARS) EXIT
               IF(ASSET_CLASS_LIST(CLASS_POINTER) == 0. .OR.
     +                      ASSET_CLASS_LIST(CLASS_POINTER) == -99.)EXIT
            ENDDO
         ENDIF
C
C WRITE DRILLING ITEMS
C
         IF(TAX_ITEMS_IN_DRILLING .AND. (DRILLING_REPORT_IS_TAX() .OR.
     +                                DRILLING_REPORT_IS_INCOME())) THEN
            IF(DRILLING_REPORT_IS_INCOME()) THEN
               DRILLING_REPORT_UNIT = INCOME_DRILLING_REPRT_UNIT
               VOID_LOGICAL = SET_DRILLING_DATA_INCOME_TRUE()
               REPORT_TYPE = INCOME_REPORT_ITEM
            ELSE
               DRILLING_REPORT_UNIT = TAX_DRILLING_REPRT_UNIT
               VOID_LOGICAL = SET_DRILLING_DATA_TAX_TRUE()
               REPORT_TYPE = TAX_REPORT_ITEM
            ENDIF
            DRILLING_ACCOUNT_NAME = DESCRIPTION
            DRILLING_NAME = TAX_CLASSIFICATION
C
            SELECT CASE (trim(DRILLING_NAME))
               CASE ('M1 Additions','M1 Deductions',
     +                                             'BTL Tax Deductions')
                  IF(INDEX(TAX_TIMING_CLASSIFICATION,'BTL') /= 0) THEN
                     DRILLING_NAME = trim(DRILLING_NAME)//'-'
                  ELSE !(INDEX(TAX_TIMING_CLASSIFICATION,'Oper') /= 0)THEN
                     DRILLING_NAME = trim(DRILLING_NAME)//'-Oper/'
                  ENDIF
                  IF(INDEX(TAX_TIMING_CLASSIFICATION,'Temp')/= 0)THEN
                     DRILLING_NAME = trim(DRILLING_NAME)//'Temp'
                  ELSE
                     DRILLING_NAME = trim(DRILLING_NAME)//'Perm'
                  ENDIF
            END SELECT
C
            REPORTING_MONTHLY_VALUES = 0.
            DO YR = 1, DRILLING_REPORTING_YEARS
               REPORTING_MONTHLY_VALUES(0,YR) = ANNUAL_TAX_VALUES(YR)
               IF(YR >= 1 .AND. YR <= LAST_AVAILABLE_MONTHLY_YEAR) THEN
                  DO MO = 1, 12
                     REPORTING_MONTHLY_VALUES(MO,YR) =
     +                                             MONTHLY_VALUES(MO,YR)
                  ENDDO
               ENDIF
            ENDDO
            VOID_INT2 = WRITE_DRILLING_RPT(DRILLING_NAME,
     +                                     DRILLING_ACCOUNT_NAME,
     +                                     REPORTING_MONTHLY_VALUES,
     +                                     REPORT_TYPE,
     +                                     ANNUAL_INFO_ACTIVE)
C
           IF(.FALSE.) THEN
            IF(DRILLING_REPORT_IS_INCOME()) THEN
               IREC = INCOME_DRILLING_REPRT_REC()
            ELSE
               IREC = TAX_DRILLING_REPRT_REC()
            ENDIF
            IF(DRILLING_REPRT_LEVEL == 'A') THEN
               WRITE(DRILLING_REPORT_UNIT,REC=IREC) PRT_ENDPOINT(),
     +                                    DRILLING_NAME,
     +                                    DRILLING_ACCOUNT_NAME,
     +                                   (ANNUAL_TAX_VALUES(YR),YR = 1,
     +                                         DRILLING_REPORTING_YEARS)
            ELSEIF(DRILLING_REPRT_LEVEL == 'M') THEN
               WRITE(DRILLING_REPORT_UNIT,REC=IREC) PRT_ENDPOINT(),
     +                                    DRILLING_NAME,
     +                                    SHORT_MONTH_NAMES(0),
     +                                    DRILLING_ACCOUNT_NAME,
     +                                   (ANNUAL_TAX_VALUES(YR),YR = 1,
     +                                         DRILLING_REPORTING_YEARS)
               DO MO = 1, 12
                  DO YR = 1, DRILLING_REPORTING_YEARS
                     IF(YR >= 1 .AND.
     +                           YR <= LAST_AVAILABLE_MONTHLY_YEAR) THEN
                        IF(MONTHLY_TAX_VECTOR /= 0 .AND.
     +                                        MONTHLY_MIDAS_ACTIVE) THEN
                           OUTPUT_VALUE(YR) = MONTHLY_VALUES(MO,YR)
                        ELSE
                           OUTPUT_VALUE(YR) = MONTHLY_VALUES(MO,YR) ! ANNUAL_TAX_VALUES(YR)/12.
                        ENDIF
                     ELSE
                        OUTPUT_VALUE(YR) = NOT_AVAIL
                     ENDIF
                  ENDDO
                  WRITE(DRILLING_REPORT_UNIT,REC=IREC) PRT_ENDPOINT(),
     +                                    DRILLING_NAME,
     +                                    SHORT_MONTH_NAMES(MO),
     +                                    DRILLING_ACCOUNT_NAME,
     +                                   (OUTPUT_VALUE(YR),YR = 1,
     +                                         DRILLING_REPORTING_YEARS)
               ENDDO
            ENDIF
           ENDIF ! REMOVE CODE
         ENDIF
      ENDDO
C
      CALL CLOSE_TAX_LOSS_FILE
      DEALLOCATE(DATA_VALUES,ALLOC_TAX,ANNUAL_TAX_VALUES,
     +           ASSET_CLASS_LIST,ASSET_ALLOCATION_LIST,
     +           OUTPUT_VALUE,REPORTING_MONTHLY_VALUES)
      IF(SAVE_BASE_CASE) THEN
         CALL SAVE_TAX_ITEMS_BASE_CASE
      ENDIF
      RETURN
C***********************************************************************
      ENTRY SET_TAX_ARRAYS
C***********************************************************************
C
         CALL RETURN_NUM_OF_TAX_CLASSES(NUM_OF_CLASSES,MAX_CLASS_NUM)
c         CALL RETURN_NUM_OF_EXPENSE_CLASSES(NUM_OF_EXP_CLASSES,
c     +                                                MAX_EXP_CLASS_NUM)
         CALL RETURN_INITIALIZATION_CLASSES(NUM_OF_EXP_CLASSES,
     +                                      MAX_EXP_CLASS_NUM)
         MAX_CLASS_NUM = MAX(MAX_CLASS_NUM,MAX_EXP_CLASS_NUM)
         NUM_OF_CLASSES = MAX(NUM_OF_CLASSES,NUM_OF_EXP_CLASSES)
C
         IF(ALLOCATED(ASSET_CLASS_POINTER))
     +                                   DEALLOCATE(ASSET_CLASS_POINTER)
         IF(MAX_CLASS_NUM > 0) THEN
            ALLOCATE(ASSET_CLASS_POINTER(MAX_CLASS_NUM))
            ASSET_CLASS_POINTER = -99
            CALL RETURN_TAX_CLASS_POINTER(ASSET_CLASS_POINTER)
         ENDIF
C
         IF(ALLOCATED(TAX_VALUES)) DEALLOCATE(TAX_VALUES,
     +                                        TAX_VALUES_NOLS,
     +                                        ACTUAL_MONTHLY_TAX_VALUES,
     +                                        ACTUAL_VALUE_FOUND)
         ALLOCATE(TAX_VALUES(FINANCIAL_SIMULATION_YEARS,0:12,
     +                               -5:NUM_OF_CLASSES,LAST_TAX_ITEM,3))
         TAX_VALUES = 0.
         ALLOCATE(TAX_VALUES_NOLS(0:15,0:12,-5:NUM_OF_CLASSES,35:40))
         TAX_VALUES_NOLS = 0.
         ALLOCATE(ACTUAL_MONTHLY_TAX_VALUES(0:12,
     +                          FINANCIAL_SIMULATION_YEARS,
     +                          -1:NUM_OF_CLASSES,LAST_ACTUAL_TAX_ITEM))
         ACTUAL_MONTHLY_TAX_VALUES = -99999.
C
         ALLOCATE(ACTUAL_VALUE_FOUND(-1:NUM_OF_CLASSES,
     +                                            LAST_ACTUAL_TAX_ITEM))
         FALSE_BYTE = .FALSE.
         ACTUAL_VALUE_FOUND = FALSE_BYTE
C
C SET RATES TO BAD VALUE TO CHECK TO USE THE DEFAULT OR NOT.
C
         DO ITEMS = Federal Income Tax, Taxable Income Deductions Rate
            DO CLASSES = -5, NUM_OF_CLASSES
               DO PERIOD = 0, 12
                  DO YR = 1, FINANCIAL_SIMULATION_YEARS
                     TAX_VALUES(YR,PERIOD,CLASSES,ITEMS,Both) = -999999.
                  ENDDO
               ENDDO
            ENDDO
         ENDDO
         DO CLASSES = -5, NUM_OF_CLASSES
            DO PERIOD = 0, 12
               DO YR = 1, FINANCIAL_SIMULATION_YEARS
                  TAX_VALUES(YR,PERIOD,CLASSES,
     +                        Federal Capitial Tax Rate,Both) = -999999.
                  TAX_VALUES(YR,PERIOD,CLASSES,
     +                          Local Capitial Tax Rate,Both) = -999999.
               ENDDO
            ENDDO
         ENDDO
C
      RETURN
C***********************************************************************
      ENTRY TAXES_INCOME_AND_OTHER(R_ASSET_CLASS,
     +                             R_ALLOC_TAX,
     +                             R_TAX_CLASSIFICATION,
     +                             R_TAX_APPLICATION,
     +                             R_ALLOC_MONTHLY_TAX)
C***********************************************************************
C
         PERIOD = 0.
         TAX_TYPE = TAX_POSITION(R_TAX_CLASSIFICATION,
     +                           R_TAX_APPLICATION,
     +                           ADDED_TO_CURRENT_VALUE)
         IF(TAX_TYPE >= Federal NOLs .AND. TAX_TYPE <= State NOLs) THEN
            IF(TAX_TYPE == General Carry Tax Credits) THEN
               DO YR = 1, 15
                  IF(R_TAX_APPLICATION /= 'S') THEN ! TO MAKE A BLANK PRODUCE INPUT
c                  IF(R_TAX_APPLICATION == 'B' .OR.
c     +                                    R_TAX_APPLICATION == 'F') THEN
                     TAX_VALUES_NOLS(YR,PERIOD,
     +                                         R_ASSET_CLASS,TAX_TYPE) =
     +                    TAX_VALUES_NOLS(YR,PERIOD,
     +                                           R_ASSET_CLASS,TAX_TYPE)
     +                    + R_ALLOC_TAX(YR)
                     IF(YR <= LAST_AVAILABLE_MONTHLY_YEAR) THEN
                        DO MO = 1, 12
                           TAX_VALUES_NOLS(YR,MO,
     +                                         R_ASSET_CLASS,TAX_TYPE) =
     +                           TAX_VALUES_NOLS(YR,MO,
     +                                           R_ASSET_CLASS,TAX_TYPE)
     +                           + R_ALLOC_MONTHLY_TAX(MO,YR)
                        ENDDO
                     ENDIF
                  ENDIF
                  IF(R_TAX_APPLICATION == 'B' .OR.
     +                                    R_TAX_APPLICATION == 'S') THEN
                     TAX_VALUES_NOLS(YR,PERIOD,R_ASSET_CLASS,
     +                                  State Credits Carried Forward) =
     +                    TAX_VALUES_NOLS(YR,PERIOD,R_ASSET_CLASS,
     +                                    State Credits Carried Forward)
     +                    + R_ALLOC_TAX(YR)
                     IF(YR <= LAST_AVAILABLE_MONTHLY_YEAR) THEN
                        DO MO = 1, 12
                           TAX_VALUES_NOLS(YR,MO,R_ASSET_CLASS,
     +                                  State Credits Carried Forward) =
     +                           TAX_VALUES_NOLS(YR,MO,R_ASSET_CLASS,
     +                                    State Credits Carried Forward)
     +                           + R_ALLOC_MONTHLY_TAX(MO,YR)
                        ENDDO
                     ENDIF
                  ENDIF
               ENDDO
            ELSEIF(ADDED_TO_CURRENT_VALUE) THEN
               DO YR = 1, 15
                  TAX_VALUES_NOLS(YR,PERIOD,R_ASSET_CLASS,TAX_TYPE) =
     +                 TAX_VALUES_NOLS(YR,PERIOD,R_ASSET_CLASS,TAX_TYPE)
     +                 + R_ALLOC_TAX(YR)
                  IF(YR <= LAST_AVAILABLE_MONTHLY_YEAR) THEN
                     DO MO = 1, 12
                        TAX_VALUES_NOLS(YR,MO,R_ASSET_CLASS,TAX_TYPE) =
     +                     TAX_VALUES_NOLS(YR,MO,R_ASSET_CLASS,TAX_TYPE)
     +                     + R_ALLOC_MONTHLY_TAX(MO,YR)
                     ENDDO
                  ENDIF
               ENDDO
            ELSE
               DO YR = 1, 15
                  TAX_VALUES_NOLS(YR,PERIOD,R_ASSET_CLASS,TAX_TYPE) =
     +                                                   R_ALLOC_TAX(YR)
                  IF(YR <= LAST_AVAILABLE_MONTHLY_YEAR) THEN
                     DO MO = 1, 12
                        TAX_VALUES_NOLS(YR,MO,R_ASSET_CLASS,TAX_TYPE) =
     +                                        R_ALLOC_MONTHLY_TAX(MO,YR)
                     ENDDO
                  ENDIF
               ENDDO
            ENDIF
            RETURN
         ENDIF
         IF(TAX_TYPE /= -99) THEN
            APP = MAX(1,INDEX('BFS',R_TAX_APPLICATION))
            Timing Type = 0
            IF(ADDED_TO_CURRENT_VALUE) THEN
               THIS_IS_A_TIMING_VALUE = TAX_TYPE == M1 Additions .OR.
     +                                  TAX_TYPE == M1 Deductions .OR.
     +                                  TAX_TYPE == BTL Tax Deductions

               IF(THIS_IS_A_TIMING_VALUE) THEN
                  Timing Type = Permanent ATL Tax Differences ! 44
                  IF(INDEX(TAX_TIMING_CLASSIFICATION,'Oper') /=  0) THEN
                     IF(INDEX(TAX_TIMING_CLASSIFICATION,'Temp') /=  0)
     +                       Timing Type = Temporary ATL Tax Differences ! 42
                  ELSEIF(INDEX(TAX_TIMING_CLASSIFICATION,'BTL')/= 0)THEN
                     Timing Type = Permanent BTL Tax Differences ! 45
                     IF(INDEX(TAX_TIMING_CLASSIFICATION,'Temp') /=  0)
     +                       Timing Type = Temporary BTL Tax Differences ! 43
                  ENDIF
               ENDIF
C
               DO YR = 1, FINANCIAL_SIMULATION_YEARS
                  TAX_VALUES(YR,PERIOD,R_ASSET_CLASS,TAX_TYPE,APP) =
     +                  R_ALLOC_TAX(YR) +
     +                  TAX_VALUES(YR,PERIOD,R_ASSET_CLASS,TAX_TYPE,APP)
                  IF(YR <= LAST_AVAILABLE_MONTHLY_YEAR) THEN
                     DO MO = 1, 12
                        TAX_VALUES(YR,MO,R_ASSET_CLASS,TAX_TYPE,APP)=
     +                      R_ALLOC_MONTHLY_TAX(MO,YR) +
     +                      TAX_VALUES(YR,MO,R_ASSET_CLASS,TAX_TYPE,APP)
                     ENDDO
                  ENDIF
               ENDDO
C
               IF(Timing Type /= 0) THEN
                  SIGN = 1.0
                  IF(TAX_TYPE == M1 Deductions
     +                  .OR. TAX_TYPE == BTL Tax Deductions) SIGN = -1.0
                  DO YR = 1, FINANCIAL_SIMULATION_YEARS
                     TAX_VALUES(YR,PERIOD,R_ASSET_CLASS,
     +                                                Timing Type,APP) =
     +                               SIGN * R_ALLOC_TAX(YR) +
     +                               TAX_VALUES(YR,PERIOD,R_ASSET_CLASS,
     +                                                  Timing Type,APP)
                     IF(YR <= LAST_AVAILABLE_MONTHLY_YEAR) THEN
                        DO MO = 1, 12
                           TAX_VALUES(YR,MO,R_ASSET_CLASS,
     +                                                Timing Type,APP) =
     +                               SIGN * R_ALLOC_MONTHLY_TAX(MO,YR) +
     +                               TAX_VALUES(YR,MO,R_ASSET_CLASS,
     +                                                  Timing Type,APP)
                        ENDDO
                     ENDIF
                  ENDDO
               ENDIF
            ELSE
               DO YR = 1, FINANCIAL_SIMULATION_YEARS
                  TAX_VALUES(YR,PERIOD,R_ASSET_CLASS,TAX_TYPE,APP) =
     +                                                   R_ALLOC_TAX(YR)
                  IF(YR <= LAST_AVAILABLE_MONTHLY_YEAR) THEN
                     DO MO = 1, 12
                        TAX_VALUES(YR,MO,R_ASSET_CLASS,TAX_TYPE,APP) =
     +                                        R_ALLOC_MONTHLY_TAX(MO,YR)
                     ENDDO
                  ENDIF
               ENDDO
            ENDIF
         ENDIF
      RETURN
C***********************************************************************
      ENTRY ACTUAL_TAXES_ACCUMULATION(R_ASSET_CLASS,
     +                                R_ALLOC_TAX,
     +                                R_TAX_CLASSIFICATION,
     +                                R_ALLOC_MONTHLY_TAX)
C***********************************************************************
C
C         ADDENDUM_TYPE = ADDENDUM_POSITION(R_ADDENDUM_CLASSIFICATION,
C     +                                     ADDED_TO_CURRENT_VALUE)
C
         TAX_TYPE = ACTUAL_TAX_POSITION(R_TAX_CLASSIFICATION)
         IF(TAX_TYPE /= -99) THEN
            IF(.NOT.ACTUAL_VALUE_FOUND(R_ASSET_CLASS,TAX_TYPE))THEN
               DO YR = 1, FINANCIAL_SIMULATION_YEARS
                  IF(R_ALLOC_TAX(YR) /= -99999.) THEN
                     IF(ACTUAL_MONTHLY_TAX_VALUES(0,YR,
     +                          R_ASSET_CLASS,TAX_TYPE) == -99999.) THEN
                        ACTUAL_MONTHLY_TAX_VALUES(0,YR,
     +                                      R_ASSET_CLASS,TAX_TYPE) = 0.
                     ENDIF
                     ACTUAL_MONTHLY_TAX_VALUES(0,YR,
     +                                         R_ASSET_CLASS,TAX_TYPE) =
     +                           ACTUAL_MONTHLY_TAX_VALUES(0,YR,
     +                                           R_ASSET_CLASS,TAX_TYPE)
     +                           + R_ALLOC_TAX(YR)
                  ENDIF
                  IF(YR > LAST_AVAILABLE_MONTHLY_YEAR) CYCLE
                  DO MO = 1, 12
                     IF(R_ALLOC_MONTHLY_TAX(MO,YR) == -99999.) CYCLE
                     IF(ACTUAL_MONTHLY_TAX_VALUES(MO,YR,
     +                          R_ASSET_CLASS,TAX_TYPE) == -99999.) THEN
                        ACTUAL_MONTHLY_TAX_VALUES(MO,YR,
     +                                      R_ASSET_CLASS,TAX_TYPE) = 0.
                     ENDIF
                     ACTUAL_MONTHLY_TAX_VALUES(MO,YR,
     +                                         R_ASSET_CLASS,TAX_TYPE) =
     +                           ACTUAL_MONTHLY_TAX_VALUES(MO,YR,
     +                                           R_ASSET_CLASS,TAX_TYPE)
     +                           + R_ALLOC_MONTHLY_TAX(MO,YR)
                  ENDDO
               ENDDO
               ACTUAL_VALUE_FOUND(R_ASSET_CLASS,TAX_TYPE) = .TRUE.
            ENDIF
         ENDIF
C
      RETURN
C***********************************************************************
      ENTRY RETURN_M1_TIMING_DIFFERENCES(R_ASSET_CLASS,R_YR,R_TAX_TYPE,
     +                                   MONTHLY_VARS)
C***********************************************************************
C
         IF(ALLOCATED(TAX_VALUES) .AND.
     +                              R_ASSET_CLASS <= MAX_CLASS_NUM) THEN
            IF(R_ASSET_CLASS == 0) THEN
               POINTER = 0
            ELSE
               POINTER = ASSET_CLASS_POINTER(R_ASSET_CLASS)
            ENDIF
            YR = R_YR ! - 1
            IF(POINTER > 0 .OR. R_ASSET_CLASS == 0) THEN
               DO MO = 0, 12
                  MONTHLY_VARS(MO,Monthly Permanent ATL Tax Dif) =
     +                         TAX_VALUES(YR,MO,POINTER,
     +                                    Permanent ATL Tax Differences,
     +                                                     R_TAX_TYPE) +
     +                                 TAX_VALUES(YR,MO,POINTER,
     +                                    Permanent ATL Tax Differences,
     +                                                             Both)
                  MONTHLY_VARS(MO,Monthly Permanent BTL Tax Dif) =
     +                                 TAX_VALUES(YR,MO,POINTER,
     +                                    Permanent BTL Tax Differences,
     +                                                     R_TAX_TYPE) +
     +                                 TAX_VALUES(YR,MO,POINTER,
     +                                    Permanent BTL Tax Differences,
     +                                                             Both)
                  MONTHLY_VARS(MO,Monthly Temporary ATL Tax Dif) =
     +                                 TAX_VALUES(YR,MO,POINTER,
     +                                    Temporary ATL Tax Differences,
     +                                                     R_TAX_TYPE) +
     +                                 TAX_VALUES(YR,MO,POINTER,
     +                                    Temporary ATL Tax Differences,
     +                                                             Both)
                  MONTHLY_VARS(MO,Monthly Temporary BTL Tax Dif) =
     +                                 TAX_VALUES(YR,MO,POINTER,
     +                                    Temporary BTL Tax Differences,
     +                                                     R_TAX_TYPE) +
     +                                 TAX_VALUES(YR,MO,POINTER,
     +                                    Temporary BTL Tax Differences,
     +                                                             Both)
               ENDDO
            ENDIF
         ENDIF
      RETURN
C***********************************************************************
      ENTRY RETURN_TAX_INFO(R_ASSET_CLASS,R_YR,
     +                      R_PROPERTY_TAX,
     +                      R_OTHER_TAXES,
     +                      R_REVENUE_TAXES,
     +                      R_FED_TAX_CREDITS,
     +                      R_STATE_TAX_CREDITS,
     +                      R_FED_INCOME_TAX_ADJ,
     +                      R_STATE_INCOME_TAX_ADJ,
     +                      R_M1_FED_ADDITIONS,
     +                      R_M1_FED_DEDUCTIONS,
     +                      R_M1_STATE_ADDITIONS,
     +                      R_M1_STATE_DEDUCTIONS,
     +                      R_DEFERRED_TAXES_CR,
     +                      R_DEFERRED_TAXES_DR,
     +                      R_ITC_AMORTIZATION,
     +                      R_SEC_29_CREDITS,
     +                      R_SEC_42_CREDITS,
     +                      R_ACE_TAX_DEPRECIATION,
     +                      R_TAX_PREFERENCE_DEPRECIATION,
     +                      R_BTL_DEFERRED_TAXES_CR,
     +                      R_BTL_DEFERRED_TAXES_DR,
     +                      R_AMT_INCOME_ADDENDUM,
     +                      R_INCOME_TAX_DEPRECIATION,
     +                      R_BTL_MISC_DEDUCTIONS)
C***********************************************************************
C
         R_AMT_INCOME_ADDENDUM = 0.
         R_BTL_MISC_DEDUCTIONS = 0.
         IF(ALLOCATED(TAX_VALUES) .AND.
     +                              R_ASSET_CLASS <= MAX_CLASS_NUM) THEN
            IF(R_ASSET_CLASS == 0) THEN
               POINTER = 0
            ELSE
               POINTER = ASSET_CLASS_POINTER(R_ASSET_CLASS)
            ENDIF
            YR = R_YR - 1
            PERIOD = 0
            IF(POINTER > 0 .OR. R_ASSET_CLASS == 0) THEN
               R_PROPERTY_TAX = R_PROPERTY_TAX +
     +              TAX_VALUES(YR,PERIOD,POINTER,Property Taxes,Both)
               R_OTHER_TAXES = R_OTHER_TAXES +
     +                 TAX_VALUES(YR,PERIOD,POINTER,Other Taxes,Both)
               R_REVENUE_TAXES = R_REVENUE_TAXES +
     +               TAX_VALUES(YR,PERIOD,POINTER,Revenue Taxes,Both)
               R_FED_TAX_CREDITS = R_FED_TAX_CREDITS +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                        Income Tax Credits,Both) +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                       Income Tax Credits,Federal)
               R_SEC_29_CREDITS = R_SEC_29_CREDITS +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                            Sec 29 Credits,Both) +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                           Sec 29 Credits,Federal)
               R_SEC_42_CREDITS = R_SEC_42_CREDITS +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                            Sec 42 Credits,Both) +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                           Sec 42 Credits,Federal)
               R_STATE_TAX_CREDITS = R_STATE_TAX_CREDITS +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                        Income Tax Credits,Both) +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                         Income Tax Credits,State)
               R_FED_INCOME_TAX_ADJ = R_FED_INCOME_TAX_ADJ +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                 Income Tax Adjustments,Federal) +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                      Income Tax Adjustments,Both)
               R_STATE_INCOME_TAX_ADJ = R_STATE_INCOME_TAX_ADJ +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                   Income Tax Adjustments,State) +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                      Income Tax Adjustments,Both)
               R_M1_FED_ADDITIONS = R_M1_FED_ADDITIONS +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                           M1 Additions,Federal) +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                                M1 Additions,Both)
               R_M1_FED_DEDUCTIONS = R_M1_FED_DEDUCTIONS +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                          M1 Deductions,Federal) +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                               M1 Deductions,Both)
               R_M1_STATE_ADDITIONS = R_M1_STATE_ADDITIONS +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                           M1 Additions,State) +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                                M1 Additions,Both)
               R_M1_STATE_DEDUCTIONS = R_M1_STATE_DEDUCTIONS +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                          M1 Deductions,State) +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                               M1 Deductions,Both)
               R_DEFERRED_TAXES_CR = R_DEFERRED_TAXES_CR +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                           Deferred Taxes Cr,Both)
               R_BTL_DEFERRED_TAXES_CR = R_BTL_DEFERRED_TAXES_CR +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                       BTL Deferred Taxes Cr,Both)
               R_DEFERRED_TAXES_DR = R_DEFERRED_TAXES_DR +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                           Deferred Taxes Dr,Both)
               R_BTL_DEFERRED_TAXES_DR = R_BTL_DEFERRED_TAXES_DR +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                       BTL Deferred Taxes Dr,Both)
               R_ITC_AMORTIZATION = R_ITC_AMORTIZATION +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                            ITC Amortization,Both)
               R_ACE_TAX_DEPRECIATION = R_ACE_TAX_DEPRECIATION +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                                 AMT ACE Tax Depreciation,Federal)
               R_TAX_PREFERENCE_DEPRECIATION =
     +                                   R_TAX_PREFERENCE_DEPRECIATION +
     +                  TAX_VALUES(YR,PERIOD,POINTER,
     +                              AMT Depreciation Preference,Federal)
               R_AMT_INCOME_ADDENDUM = TAX_VALUES(YR,PERIOD,POINTER,
     +                                      AMT Income Addendum,Federal)
               R_INCOME_TAX_DEPRECIATION = R_INCOME_TAX_DEPRECIATION
     +                                   + TAX_VALUES(YR,PERIOD,POINTER,
     +                                            Tax Depreciation,Both)
               R_BTL_MISC_DEDUCTIONS = TAX_VALUES(YR,PERIOD,POINTER,
     +                                          BTL Tax Deductions,Both)
            ENDIF
         ENDIF
      RETURN
C***********************************************************************
      ENTRY RETURN_CONSOLD_TAX_INFORMATION(R_YR,
     +                                     R_DEFERRED_TAXES_DR)
C***********************************************************************
C
         IF(ALLOCATED(TAX_VALUES)) THEN
            YR = R_YR - 1
            PERIOD = 0
            POINTER = -1
            R_DEFERRED_TAXES_DR = TAX_VALUES(YR,PERIOD,POINTER,
     +                                           Deferred Taxes Dr,Both)
         ELSE
            R_DEFERRED_TAXES_DR = 0.
         ENDIF
      RETURN
C***********************************************************************
      ENTRY MONTHLY_CONSOL_TAX_ITEMS(R_YR,R_CONSOL_DEFERRED_TAXES_DR)
C***********************************************************************
C
         IF(ALLOCATED(TAX_VALUES)) THEN
            POINTER = -1
            YR = R_YR - 1
            DO MO = 0, 12
               R_CONSOL_DEFERRED_TAXES_DR(MO)=TAX_VALUES(YR,MO,POINTER,
     +                                           Deferred Taxes Dr,Both)
            ENDDO
         ELSE
            DO MO = 0, 12
               R_CONSOL_DEFERRED_TAXES_DR(MO) = 0.
            ENDDO
         ENDIF
      RETURN
C***********************************************************************
      ENTRY MONTHLY_PARENT_TAX_ITEMS(R_YR,R_ASSET_CLASS,
     +                               R_MONTHLY_DEFERRED_TAXES_DR)
C***********************************************************************
C
         IF(ALLOCATED(TAX_VALUES) .AND.
     +                              R_ASSET_CLASS <= MAX_CLASS_NUM) THEN
            IF(R_ASSET_CLASS == 0 .OR. R_ASSET_CLASS == -1) THEN
               POINTER = R_ASSET_CLASS
            ELSE
               POINTER = ASSET_CLASS_POINTER(R_ASSET_CLASS)
            ENDIF
            IF(POINTER > 0) THEN
               YR = R_YR - 1
               DO MO = 0, 12
                  R_MONTHLY_DEFERRED_TAXES_DR(MO) =
     +                  TAX_VALUES(YR,MO,POINTER,Deferred Taxes Dr,Both)
               ENDDO
            ELSE
               DO MO = 0, 12
                  R_MONTHLY_DEFERRED_TAXES_DR(MO) = 0.
               ENDDO
            ENDIF
         ENDIF
      RETURN
C***********************************************************************
      ENTRY MONTHLY_TAX_ADJUSTMENTS(R_ASSET_CLASS,R_YR,
     +                              R_PROPERTY_TAX_ADJUSTMENT,
     +                              R_OTHER_TAX_ADJUSTMENT,
     +                              R_REVENUE_TAX_ADJUSTMENT,
     +                              R_STATE_M1_ADDITIONS,
     +                              R_STATE_M1_DEDUCTIONS,
     +                              R_FEDERAL_M1_ADDITIONS,
     +                              R_FEDERAL_M1_DEDUCTIONS,
     +                              R_STATE_BTL_MISC_DEDUCTIONS,
     +                              R_FEDERAL_BTL_MISC_DEDUCTIONS,
     +                              R_STATE_INCOME_TAX_ADJUSTMENT,
     +                              R_FEDERAL_INCOME_TAX_ADJUSTMENT)
C***********************************************************************
C
         R_PROPERTY_TAX_ADJUSTMENT = 0.
         R_OTHER_TAX_ADJUSTMENT = 0.
         R_REVENUE_TAX_ADJUSTMENT = 0.
         R_STATE_M1_ADDITIONS = 0.
         R_STATE_M1_DEDUCTIONS = 0.
         R_FEDERAL_M1_ADDITIONS = 0.
         R_FEDERAL_M1_DEDUCTIONS = 0.
         R_STATE_BTL_MISC_DEDUCTIONS = 0.
         R_FEDERAL_BTL_MISC_DEDUCTIONS = 0.
         R_STATE_INCOME_TAX_ADJUSTMENT = 0.
         R_FEDERAL_INCOME_TAX_ADJUSTMENT = 0.
C
         IF(ALLOCATED(TAX_VALUES) .AND.
     +                              R_ASSET_CLASS <= MAX_CLASS_NUM) THEN
            IF(R_ASSET_CLASS == 0) THEN
               POINTER = 0
            ELSEIF(R_ASSET_CLASS == -1) THEN
               POINTER = -1
            ELSE
               POINTER = ASSET_CLASS_POINTER(R_ASSET_CLASS)
            ENDIF
            YR = R_YR
            IF(POINTER >= -1) THEN
               R_PROPERTY_TAX_ADJUSTMENT(:) =
     +                     TAX_VALUES(YR,:,POINTER,Property Taxes,Both)
               R_OTHER_TAX_ADJUSTMENT(:) =
     +                        TAX_VALUES(YR,:,POINTER,Other Taxes,Both)
               R_REVENUE_TAX_ADJUSTMENT(:) =
     +                      TAX_VALUES(YR,:,POINTER,Revenue Taxes,Both)
               R_FEDERAL_M1_ADDITIONS(:) =
     +                    TAX_VALUES(YR,:,POINTER,M1 Additions,Federal)
     +                    + TAX_VALUES(YR,:,POINTER,M1 Additions,Both)
               R_FEDERAL_M1_DEDUCTIONS(:) =
     +                   TAX_VALUES(YR,:,POINTER,M1 Deductions,Federal)
     +                   + TAX_VALUES(YR,:,POINTER,M1 Deductions,Both)
     +                   + TAX_VALUES(YR,:,POINTER,
     +                                       BTL Tax Deductions,Federal)
     +                   + TAX_VALUES(YR,:,POINTER,
     +                                          BTL Tax Deductions,Both)
               R_STATE_M1_ADDITIONS(:) =
     +                     TAX_VALUES(YR,:,POINTER,M1 Additions,State)
     +                     + TAX_VALUES(YR,:,POINTER,M1 Additions,Both)
               R_STATE_M1_DEDUCTIONS(:) =
     +              TAX_VALUES(YR,:,POINTER,M1 Deductions,State)
     +              + TAX_VALUES(YR,:,POINTER,M1 Deductions,Both)
     +              + TAX_VALUES(YR,:,POINTER,BTL Tax Deductions,State)
     +              + TAX_VALUES(YR,:,POINTER,BTL Tax Deductions,Both)
               R_STATE_BTL_MISC_DEDUCTIONS(:) =
     +               TAX_VALUES(YR,:,POINTER,BTL Tax Deductions,State)
     +               + TAX_VALUES(YR,:,POINTER,BTL Tax Deductions,Both)
               R_FEDERAL_BTL_MISC_DEDUCTIONS(:) =
     +              TAX_VALUES(YR,:,POINTER,BTL Tax Deductions,Federal)
     +              + TAX_VALUES(YR,:,POINTER,BTL Tax Deductions,Both)
               R_FEDERAL_INCOME_TAX_ADJUSTMENT(:) =
     +                  TAX_VALUES(YR,:,POINTER,
     +                                 Income Tax Adjustments,Federal) +
     +                  TAX_VALUES(YR,:,POINTER,
     +                                      Income Tax Adjustments,Both)
               R_STATE_INCOME_TAX_ADJUSTMENT(:) =
     +                  TAX_VALUES(YR,:,POINTER,
     +                                   Income Tax Adjustments,State) +
     +                  TAX_VALUES(YR,:,POINTER,
     +                                      Income Tax Adjustments,Both)
            ENDIF
         ENDIF
C
      RETURN
C***********************************************************************
      ENTRY MONTHLY_NON_INCOME_TAX_RATES(R_YR,
     +                               R_ASSET_CLASS,
     +                               RM_OPREV_TAX_RATE,
     +                               RM_PROPERTY_TAX_RATE,
     +                               RM_CLASS_OTHER_TAXES_RATE,
     +                               RM_OTHER_TAXES_PERCENT_OF_EXPEN,
     +                               R_CLASS_TYPE)
C***********************************************************************
      NON_INCOME_TAXES = .TRUE.
C***********************************************************************
      ENTRY RETURN_MONTHLY_TAX_RATES(R_YR,R_ASSET_CLASS,
     +                               RM_TEMP_FED_TAX_RATE,
     +                               RM_ITC_AMORTIZATION_RATE,
     +                               RM_STATE_TAX_RATE,
     +                               RM_STATE_DEDUC_PERCT_OF_TIB4DED,
     +                               RM_FED_DEDUC_PERCT_OF_TIB4DEDUC,
     +                               R_CLASS_TYPE)
C***********************************************************************
C
C
         YR = R_YR !  - 1
         PERIOD = 0
         IF(.NOT. ALLOCATED(TAX_VALUES)) RETURN
         CURRENT = -99
         IF(R_CLASS_TYPE == 'P') DEFAULT = -2
         IF(R_CLASS_TYPE == 'B') DEFAULT = -3
         IF(R_CLASS_TYPE == 'S') DEFAULT = -4
         IF(R_CLASS_TYPE == 'R') DEFAULT = -5
         IF(R_ASSET_CLASS == 0) THEN
            CURRENT = 0
         ELSEIF(R_ASSET_CLASS <= MAX_CLASS_NUM) THEN
            CURRENT = ASSET_CLASS_POINTER(R_ASSET_CLASS)
         ENDIF
         IF(CURRENT == -99 .OR. CURRENT == 0) THEN
            CURRENT = DEFAULT
         ENDIF
         IF(CURRENT >= -5 .OR. R_ASSET_CLASS == 0) THEN
            DO MO = 0, 12
               IF(NON_INCOME_TAXES) THEN
C
C OPERATING REVENUE TAX RATE
C
                  IF(TAX_VALUES(YR,MO,CURRENT,
     +                Operating Revenue Tax Rate,Both) /= -999999.) THEN
                     RM_OPREV_TAX_RATE(MO) = TAX_VALUES(YR,MO,CURRENT,
     +                             Operating Revenue Tax Rate,Both)/100.
                  ELSEIF(TAX_VALUES(YR,MO,DEFAULT,
     +                Operating Revenue Tax Rate,Both) /= -999999.) THEN
                     RM_OPREV_TAX_RATE(MO) = TAX_VALUES(YR,MO,DEFAULT,
     +                             Operating Revenue Tax Rate,Both)/100.
                  ELSE
                     RM_OPREV_TAX_RATE(MO) = 0.
                  ENDIF
C
C PROPERTY TAX RATE
C
                  IF(TAX_VALUES(YR,MO,CURRENT,
     +                         Property Tax Rate,Both) /= -999999.) THEN
                     RM_PROPERTY_TAX_RATE(MO)=TAX_VALUES(YR,MO,CURRENT,
     +                                      Property Tax Rate,Both)/100.
                  ELSEIF(TAX_VALUES(YR,MO,DEFAULT,
     +                         Property Tax Rate,Both) /= -999999.) THEN
                     RM_PROPERTY_TAX_RATE(MO)=TAX_VALUES(YR,MO,DEFAULT,
     +                                      Property Tax Rate,Both)/100.
                  ELSE
                     RM_PROPERTY_TAX_RATE(MO) = 0.
                  ENDIF
C
C OTHER TAXES REVENUE RATE
C
                  IF(TAX_VALUES(YR,MO,CURRENT,
     +              Other Taxes of Revenues Rate,Both) /= -999999.) THEN
                     RM_CLASS_OTHER_TAXES_RATE(MO) =
     +                     TAX_VALUES(YR,MO,CURRENT,
     +                           Other Taxes of Revenues Rate,Both)/100.
                  ELSEIF(TAX_VALUES(YR,MO,DEFAULT,
     +              Other Taxes of Revenues Rate,Both) /= -999999.) THEN
                     RM_CLASS_OTHER_TAXES_RATE(MO) =
     +                     TAX_VALUES(YR,MO,DEFAULT,
     +                           Other Taxes of Revenues Rate,Both)/100.
                  ELSE
                     RM_CLASS_OTHER_TAXES_RATE(MO) = 0.
                  ENDIF
C
C OTHER TAXES EXPENSE RATE
C
                  IF(TAX_VALUES(YR,MO,CURRENT,
     +              Other Taxes of Expenses Rate,Both) /= -999999.) THEN
                     RM_OTHER_TAXES_PERCENT_OF_EXPEN(MO) =
     +                     TAX_VALUES(YR,MO,CURRENT,
     +                           Other Taxes of Expenses Rate,Both)/100.
                  ELSEIF(TAX_VALUES(YR,MO,DEFAULT,
     +              Other Taxes of Expenses Rate,Both) /= -999999.) THEN
                     RM_OTHER_TAXES_PERCENT_OF_EXPEN(MO) =
     +                     TAX_VALUES(YR,MO,DEFAULT,
     +                           Other Taxes of Expenses Rate,Both)/100.
                  ELSE
                     RM_OTHER_TAXES_PERCENT_OF_EXPEN(MO) = 0.
                  ENDIF
               ELSE
C
C FEDERAL TAX RATE
C
                  IF(TAX_VALUES(YR,MO,CURRENT,
     +                        Federal Income Tax,Both) /= -999999.) THEN
                     RM_TEMP_FED_TAX_RATE(MO)=TAX_VALUES(YR,MO,CURRENT,
     +                                          Federal Income Tax,Both)
                  ELSEIF(TAX_VALUES(YR,MO,DEFAULT,
     +                        Federal Income Tax,Both) /= -999999.) THEN
                     RM_TEMP_FED_TAX_RATE(MO)=TAX_VALUES(YR,MO,DEFAULT,
     +                                          Federal Income Tax,Both)
                  ENDIF
C
C ITC AMORTIZATION RATE
C
                  IF(TAX_VALUES(YR,MO,CURRENT,
     +                     ITC Amortization Rate,Both) /= -999999.) THEN
                     RM_ITC_AMORTIZATION_RATE(MO)=TAX_VALUES(YR,MO,
     +                               CURRENT,ITC Amortization Rate,Both)
                  ELSEIF(TAX_VALUES(YR,MO,DEFAULT,
     +                     ITC Amortization Rate,Both) /= -999999.) THEN
                     RM_ITC_AMORTIZATION_RATE(MO)=TAX_VALUES(YR,MO,
     +                               DEFAULT,ITC Amortization Rate,Both)
                  ENDIF
C
C STATE TAX RATE
C
                  IF(TAX_VALUES(YR,MO,CURRENT,
     +                            Local Tax Rate,Both) /= -999999.) THEN
                     RM_STATE_TAX_RATE(MO) = TAX_VALUES(YR,MO,CURRENT,
     +                                              Local Tax Rate,Both)
                  ELSEIF(TAX_VALUES(YR,MO,DEFAULT,
     +                            Local Tax Rate,Both) /= -999999.) THEN
                     RM_STATE_TAX_RATE(MO) = TAX_VALUES(YR,MO,DEFAULT,
     +                                              Local Tax Rate,Both)
                  ENDIF
C
C TAX DEDUCTIONS FEDERAL
C
                  IF(TAX_VALUES(YR,MO,CURRENT,
     +                     Taxable Income Deductions Rate,Federal)
     +                                                 /= -999999.) THEN
                     RM_FED_DEDUC_PERCT_OF_TIB4DEDUC(MO) =
     +                     TAX_VALUES(YR,MO,CURRENT,
     +                           Taxable Income Deductions Rate,Federal)
                  ELSEIF(TAX_VALUES(YR,MO,CURRENT,
     +              Taxable Income Deductions Rate,Both)/=-999999.) THEN
                     RM_FED_DEDUC_PERCT_OF_TIB4DEDUC(MO) =
     +                     TAX_VALUES(YR,MO,CURRENT,
     +                              Taxable Income Deductions Rate,Both)
                  ELSEIF(TAX_VALUES(YR,MO,DEFAULT,
     +          Taxable Income Deductions Rate,Federal)/= -999999.) THEN
                     RM_FED_DEDUC_PERCT_OF_TIB4DEDUC(MO) =
     +                     TAX_VALUES(YR,MO,DEFAULT,
     +                           Taxable Income Deductions Rate,Federal)
                  ELSEIF(TAX_VALUES(YR,MO,DEFAULT,
     +              Taxable Income Deductions Rate,Both)/=-999999.) THEN
                     RM_FED_DEDUC_PERCT_OF_TIB4DEDUC(MO) =
     +                     TAX_VALUES(YR,MO,DEFAULT,
     +                              Taxable Income Deductions Rate,Both)
                  ENDIF
C
C TAX DEDUCTIONS STATE
C
                  IF(TAX_VALUES(YR,MO,CURRENT,
     +             Taxable Income Deductions Rate,State)/=-999999.) THEN
                     RM_FED_DEDUC_PERCT_OF_TIB4DEDUC(MO) =
     +                     TAX_VALUES(YR,MO,CURRENT,
     +                             Taxable Income Deductions Rate,State)
                  ELSEIF(TAX_VALUES(YR,MO,CURRENT,
     +              Taxable Income Deductions Rate,Both)/=-999999.) THEN
                     RM_FED_DEDUC_PERCT_OF_TIB4DEDUC(MO) =
     +                        TAX_VALUES(YR,MO,CURRENT,
     +                              Taxable Income Deductions Rate,Both)
                  ELSEIF(TAX_VALUES(YR,MO,DEFAULT,
     +             Taxable Income Deductions Rate,State)/=-999999.) THEN
                     RM_FED_DEDUC_PERCT_OF_TIB4DEDUC(MO) =
     +                     TAX_VALUES(YR,MO,DEFAULT,
     +                             Taxable Income Deductions Rate,State)
                  ELSEIF(TAX_VALUES(YR,MO,DEFAULT,
     +              Taxable Income Deductions Rate,Both)/=-999999.) THEN
                     RM_FED_DEDUC_PERCT_OF_TIB4DEDUC(MO) =
     +                     TAX_VALUES(YR,MO,DEFAULT,
     +                              Taxable Income Deductions Rate,Both)
                  ENDIF
               ENDIF
            ENDDO
         ENDIF
         NON_INCOME_TAXES = .FALSE.
      RETURN
C**********************************************************************
      ENTRY RETURN_ACTUAL_TAX_VALUES(R_YR,R_CLASS,
     +                               R_ACTUAL_DEFERRED_TAXES_CR,
     +                               R_ACTUAL_FED_INCOME_TAXES,
     +                               R_ACTUAL_STATE_INCOME_TAXES,
     +                               R_ACTUAL_DEFERRED_TAXES_DR)
C**********************************************************************
C
         CALL ACTUAL_MONTHLY_INCOME_TAX_ITEMS(R_YR,R_CLASS,
     +                                      R_ACTUAL_DEFERRED_TAXES_CR,
     +                                      INT2(1))
         CALL ACTUAL_MONTHLY_INCOME_TAX_ITEMS(R_YR,R_CLASS,
     +                                      R_ACTUAL_FED_INCOME_TAXES,
     +                                      INT2(2)) ! FEDERAL INCOME TAX
         CALL ACTUAL_MONTHLY_INCOME_TAX_ITEMS(R_YR,R_CLASS,
     +                                      R_ACTUAL_STATE_INCOME_TAXES,
     +                                      INT2(3)) ! STATE INCOME TAX
         CALL ACTUAL_MONTHLY_INCOME_TAX_ITEMS(R_YR,R_CLASS,
     +                                      R_ACTUAL_DEFERRED_TAXES_DR,
     +                                      INT2(4))
      RETURN
C***********************************************************************
      ENTRY ACTUAL_MONTHLY_INCOME_TAX_ITEMS(R_YR,R_CLASS,
     +                                      R_ACTUAL_INCOME_TAXES,
     +                                      R_TAX_TYPE)
C***********************************************************************
C
         IF(R_TAX_TYPE > 4 .OR. R_TAX_TYPE < 1) RETURN
         IF(ALLOCATED(ACTUAL_MONTHLY_TAX_VALUES)) THEN
            IF(R_CLASS <= MAX_CLASS_NUM) THEN
               YR = R_YR
               IF(R_CLASS == 0) THEN
                  ASSET_CLASS = 0
               ELSEIF(R_CLASS == -1) THEN
                  ASSET_CLASS = -1
               ELSE
                  ASSET_CLASS = ASSET_CLASS_POINTER(R_CLASS)
               ENDIF
               IF(ASSET_CLASS >= -1) THEN
C
                  IF(ACTUAL_VALUE_FOUND(ASSET_CLASS,R_TAX_TYPE)) THEN
                     ANNUAL_AMOUNT = 0.
                     DO MO = 1, 12
                        IF(ACTUAL_MONTHLY_TAX_VALUES(MO,YR,
     +                          ASSET_CLASS,R_TAX_TYPE) == -99999.) THEN
                           IF(ACTUAL_MONTHLY_TAX_VALUES(0,YR,
     +                          ASSET_CLASS,R_TAX_TYPE) == -99999.) THEN
                              DO MO2 = MO, 12
                                 ANNUAL_AMOUNT = ANNUAL_AMOUNT
     +                                      + R_ACTUAL_INCOME_TAXES(MO2)
                              ENDDO
                           ELSE ! MARK TO INPUT VALUE
                              UNALLOCATED_BALANCE = 0.
                              DO MO2 = MO, 12
                                 UNALLOCATED_BALANCE =
     +                                UNALLOCATED_BALANCE
     +                                + R_ACTUAL_INCOME_TAXES(MO2)
                              ENDDO
                              REMAINING_ANNUAL_BALANCE =
     +                                 ACTUAL_MONTHLY_TAX_VALUES(0,YR,
     +                                           ASSET_CLASS,R_TAX_TYPE)
     +                                 - ANNUAL_AMOUNT
                              IF(UNALLOCATED_BALANCE /= 0.) THEN
                                 RATIO = REMAINING_ANNUAL_BALANCE/
     +                                      UNALLOCATED_BALANCE
                              ELSE
                                 RATIO = 1./FLOAT(13-MO)
                              ENDIF
                              DO MO2 = MO, 12
                                 R_ACTUAL_INCOME_TAXES(MO2) = RATIO *
     +                                        R_ACTUAL_INCOME_TAXES(MO2)
                                 ANNUAL_AMOUNT = ANNUAL_AMOUNT
     +                                      + R_ACTUAL_INCOME_TAXES(MO2)
                              ENDDO
                           ENDIF
                           EXIT
                        ENDIF
                        R_ACTUAL_INCOME_TAXES(MO) =
     +                                 ACTUAL_MONTHLY_TAX_VALUES(MO,YR,
     +                                           ASSET_CLASS,R_TAX_TYPE)
                        ANNUAL_AMOUNT = ANNUAL_AMOUNT
     +                                 + R_ACTUAL_INCOME_TAXES(MO)
                     ENDDO
                     R_ACTUAL_INCOME_TAXES(0) = ANNUAL_AMOUNT
                  ENDIF
               ENDIF
            ENDIF
         ENDIF
      RETURN
C***********************************************************************
      ENTRY RETURN_MONTHLY_ACTUAL_TAXES(R_YR,R_CLASS,
     +                                  R_ANNUAL_STATE_INCOME_TAX,
     +                                  R_USE_ACTUAL_STATE_TAXES,
     +                                  R_ANNUAL_FEDERAL_INCOME_TAX,
     +                                  R_USE_ACTUAL_FEDERAL_TAXES,
     +                                  R_DEFERRED_TAXES_ACTUAL_DR,
     +                                  R_USE_ACTUAL_DEFERRED_TAXES_DR,
     +                                  R_DEFERRED_TAXES_ACTUAL_CR,
     +                                  R_USE_ACTUAL_DEFERRED_TAXES_CR)
C***********************************************************************
C
         R_USE_ACTUAL_FEDERAL_TAXES = .FALSE.
         R_USE_ACTUAL_STATE_TAXES = .FALSE.
         R_USE_ACTUAL_DEFERRED_TAXES_DR = .FALSE.
         R_USE_ACTUAL_DEFERRED_TAXES_CR = .FALSE.
C
         IF(ALLOCATED(ACTUAL_MONTHLY_TAX_VALUES)) THEN
            IF(R_CLASS <= MAX_CLASS_NUM) THEN
               YR = R_YR
               IF(R_CLASS == 0) THEN
                  ASSET_CLASS = 0
               ELSEIF(R_CLASS == -1) THEN
                  ASSET_CLASS = -1 ! CONSOLIDATED
               ELSE
                  ASSET_CLASS = ASSET_CLASS_POINTER(R_CLASS)
               ENDIF
               IF(ASSET_CLASS >= -1) THEN
C
C FEDERAL TAXES PAID
C
                  R_ANNUAL_FEDERAL_INCOME_TAX =
     +                     ACTUAL_MONTHLY_TAX_VALUES(0,YR,ASSET_CLASS,2)
                  IF(ACTUAL_VALUE_FOUND(ASSET_CLASS,2) .AND.
     +                      R_ANNUAL_FEDERAL_INCOME_TAX /= -99999.)
     +                               R_USE_ACTUAL_FEDERAL_TAXES = .TRUE.
C
C STATE TAXES PAID
C
                  R_ANNUAL_STATE_INCOME_TAX =
     +                     ACTUAL_MONTHLY_TAX_VALUES(0,YR,ASSET_CLASS,3)
                  IF(ACTUAL_VALUE_FOUND(ASSET_CLASS,3) .AND.
     +                      R_ANNUAL_STATE_INCOME_TAX /= -99999.)
     +                                 R_USE_ACTUAL_STATE_TAXES = .TRUE.
C
C DEFERRED TAXES CR
C
                  R_DEFERRED_TAXES_ACTUAL_CR =
     +                     ACTUAL_MONTHLY_TAX_VALUES(0,YR,ASSET_CLASS,1)
                  IF(ACTUAL_VALUE_FOUND(ASSET_CLASS,1) .AND.
     +                      R_DEFERRED_TAXES_ACTUAL_CR /= -99999.)
     +                           R_USE_ACTUAL_DEFERRED_TAXES_CR = .TRUE.
C
C DEFERRED TAXES CR
C
                  R_DEFERRED_TAXES_ACTUAL_DR =
     +                     ACTUAL_MONTHLY_TAX_VALUES(0,YR,ASSET_CLASS,4)
                  IF(ACTUAL_VALUE_FOUND(ASSET_CLASS,4) .AND.
     +                      R_DEFERRED_TAXES_ACTUAL_DR /= -99999.)
     +                           R_USE_ACTUAL_DEFERRED_TAXES_DR = .TRUE.
               ENDIF
            ENDIF
         ENDIF
      RETURN
C***********************************************************************
      ENTRY RETURN_TAX_NOLS_CREDITS(R_ASSET_CLASS,R_CLASS_EXITS,
     +                              R_FED_NOLS,
     +                              R_STATE_NOLS,
     +                              R_AMT_NOLS,
     +                              R_GENERAL_TAX_CREDITS,
     +                              R_SEC_42_TAX_CREDITS,
     +                              R_STATE_BUSINESS_CREDITS)
C***********************************************************************
C
         R_CLASS_EXITS = .FALSE.
         IF(ALLOCATED(TAX_VALUES_NOLS) .AND.
     +                            (R_ASSET_CLASS) <= MAX_CLASS_NUM) THEN
            IF(R_ASSET_CLASS == 0) THEN
               POINTER = 0
            ELSEIF(R_ASSET_CLASS == -1) THEN
               POINTER = -1
            ELSE
               POINTER = ASSET_CLASS_POINTER(R_ASSET_CLASS)
            ENDIF
            IF(POINTER > 0 .OR. R_ASSET_CLASS == 0
     +                                    .OR. R_ASSET_CLASS == -1) THEN
               R_CLASS_EXITS = .TRUE.
               PERIOD = 0
               DO YR = 1,  15
                  R_FED_NOLS(YR) =
     +                   TAX_VALUES_NOLS(YR,PERIOD,POINTER,Federal NOLs)
                  R_STATE_NOLS(YR) =
     +                     TAX_VALUES_NOLS(YR,PERIOD,POINTER,State NOLs)
                  R_AMT_NOLS(YR) =
     +                       TAX_VALUES_NOLS(YR,PERIOD,POINTER,AMT NOLs)
                  R_GENERAL_TAX_CREDITS(YR) =
     +                        TAX_VALUES_NOLS(YR,PERIOD,POINTER,
     +                                        General Carry Tax Credits)
                  R_SEC_42_TAX_CREDITS(YR) =
     +                         TAX_VALUES_NOLS(YR,PERIOD,POINTER,
     +                                         Sec 42 Carry Tax Credits)
                  R_STATE_BUSINESS_CREDITS(YR) =
     +                         TAX_VALUES_NOLS(YR,PERIOD,POINTER,
     +                                    State Credits Carried Forward)
               ENDDO
            ENDIF
         ENDIF
      RETURN
C***********************************************************************
      ENTRY RETURN_TAX_RATES(R_YR,R_ASSET_CLASS,
     +                       R_TEMP_FED_TAX_RATE,
     +                       R_ITC_AMORTIZATION_RATE,
     +                       R_STATE_TAX_RATE,
     +                       R_OPREV_TAX_RATE,
     +                       R_PROPERTY_TAX_RATE,
     +                       R_CLASS_OTHER_TAXES_RATE,
     +                       R_OTHER_TAXES_PERCENT_OF_EXPEN,
     +                       R_STATE_DEDUC_PERCT_OF_TIB4DED,
     +                       R_FED_DEDUC_PERCT_OF_TIB4DEDUC,
     +                       R_CLASS_TYPE)
C***********************************************************************
C
         YR = R_YR !  - 1
         PERIOD = 0
         IF(.NOT. ALLOCATED(TAX_VALUES)) RETURN
            CURRENT = -99
            IF(R_CLASS_TYPE == 'P') DEFAULT = -2
            IF(R_CLASS_TYPE == 'B') DEFAULT = -3
            IF(R_CLASS_TYPE == 'S') DEFAULT = -4
            IF(R_CLASS_TYPE == 'R') DEFAULT = -5
            IF(R_ASSET_CLASS == 0) THEN
               CURRENT = 0
            ELSEIF(R_ASSET_CLASS <= MAX_CLASS_NUM) THEN
               CURRENT = ASSET_CLASS_POINTER(R_ASSET_CLASS)
            ENDIF
            IF(CURRENT == -99 .OR. CURRENT == 0) THEN
               CURRENT = DEFAULT
            ENDIF
            IF(CURRENT >= -5 .OR. R_ASSET_CLASS == 0) THEN
C
C FEDERAL TAX RATE
C
               IF(TAX_VALUES(YR,PERIOD,CURRENT,
     +                        Federal Income Tax,Both) /= -999999.) THEN
                  R_TEMP_FED_TAX_RATE = TAX_VALUES(YR,PERIOD,CURRENT,
     +                                          Federal Income Tax,Both)
               ELSEIF(TAX_VALUES(YR,PERIOD,DEFAULT,
     +                        Federal Income Tax,Both) /= -999999.) THEN
                  R_TEMP_FED_TAX_RATE = TAX_VALUES(YR,PERIOD,DEFAULT,
     +                                          Federal Income Tax,Both)
               ENDIF
C
C ITC AMORTIZATION RATE
C
               IF(TAX_VALUES(YR,PERIOD,CURRENT,
     +                     ITC Amortization Rate,Both) /= -999999.) THEN
                  R_ITC_AMORTIZATION_RATE=TAX_VALUES(YR,PERIOD,CURRENT,
     +                                       ITC Amortization Rate,Both)
               ELSEIF(TAX_VALUES(YR,PERIOD,DEFAULT,
     +                     ITC Amortization Rate,Both) /= -999999.) THEN
                  R_ITC_AMORTIZATION_RATE=TAX_VALUES(YR,PERIOD,DEFAULT,
     +                                       ITC Amortization Rate,Both)
               ENDIF
C
C STATE TAX RATE
C
               IF(TAX_VALUES(YR,PERIOD,CURRENT,
     +                            Local Tax Rate,Both) /= -999999.) THEN
                  R_STATE_TAX_RATE = TAX_VALUES(YR,PERIOD,CURRENT,
     +                                              Local Tax Rate,Both)
               ELSEIF(TAX_VALUES(YR,PERIOD,DEFAULT,
     +                            Local Tax Rate,Both) /= -999999.) THEN
                  R_STATE_TAX_RATE = TAX_VALUES(YR,PERIOD,DEFAULT,
     +                                              Local Tax Rate,Both)
               ENDIF
C
C OPERATING REVENUE TAX RATE
C
               IF(TAX_VALUES(YR,PERIOD,CURRENT,
     +                Operating Revenue Tax Rate,Both) /= -999999.) THEN
                  R_OPREV_TAX_RATE = TAX_VALUES(YR,PERIOD,CURRENT,
     +                                  Operating Revenue Tax Rate,Both)
               ELSEIF(TAX_VALUES(YR,PERIOD,DEFAULT,
     +                Operating Revenue Tax Rate,Both) /= -999999.) THEN
                  R_OPREV_TAX_RATE = TAX_VALUES(YR,PERIOD,DEFAULT,
     +                                  Operating Revenue Tax Rate,Both)
               ENDIF
C
C PROPERTY TAX RATE
C
               IF(TAX_VALUES(YR,PERIOD,CURRENT,
     +                         Property Tax Rate,Both) /= -999999.) THEN
                  R_PROPERTY_TAX_RATE = TAX_VALUES(YR,PERIOD,CURRENT,
     +                                           Property Tax Rate,Both)
               ELSEIF(TAX_VALUES(YR,PERIOD,DEFAULT,
     +                         Property Tax Rate,Both) /= -999999.) THEN
                  R_PROPERTY_TAX_RATE = TAX_VALUES(YR,PERIOD,DEFAULT,
     +                                           Property Tax Rate,Both)
               ENDIF
C
C OTHER TAXES REVENUE RATE
C
               IF(TAX_VALUES(YR,PERIOD,CURRENT,
     +              Other Taxes of Revenues Rate,Both) /= -999999.) THEN
                  R_CLASS_OTHER_TAXES_RATE =
     +                     TAX_VALUES(YR,PERIOD,CURRENT,
     +                                Other Taxes of Revenues Rate,Both)
               ELSEIF(TAX_VALUES(YR,PERIOD,DEFAULT,
     +              Other Taxes of Revenues Rate,Both) /= -999999.) THEN
                  R_CLASS_OTHER_TAXES_RATE =
     +                     TAX_VALUES(YR,PERIOD,DEFAULT,
     +                                Other Taxes of Revenues Rate,Both)
               ENDIF
C
C OTHER TAXES EXPENSE RATE
C
               IF(TAX_VALUES(YR,PERIOD,CURRENT,
     +              Other Taxes of Expenses Rate,Both) /= -999999.) THEN
                  R_OTHER_TAXES_PERCENT_OF_EXPEN =
     +                     TAX_VALUES(YR,PERIOD,CURRENT,
     +                                Other Taxes of Expenses Rate,Both)
               ELSEIF(TAX_VALUES(YR,PERIOD,DEFAULT,
     +              Other Taxes of Expenses Rate,Both) /= -999999.) THEN
                  R_OTHER_TAXES_PERCENT_OF_EXPEN =
     +                     TAX_VALUES(YR,PERIOD,DEFAULT,
     +                                Other Taxes of Expenses Rate,Both)
               ENDIF
C
C TAX DEDUCTIONS FEDERAL
C
               IF(TAX_VALUES(YR,PERIOD,CURRENT,
     +          Taxable Income Deductions Rate,Federal)/= -999999.) THEN
                  R_FED_DEDUC_PERCT_OF_TIB4DEDUC =
     +                     TAX_VALUES(YR,PERIOD,CURRENT,
     +                           Taxable Income Deductions Rate,Federal)
               ELSEIF(TAX_VALUES(YR,PERIOD,CURRENT,
     +              Taxable Income Deductions Rate,Both)/=-999999.) THEN
                  R_FED_DEDUC_PERCT_OF_TIB4DEDUC =
     +                     TAX_VALUES(YR,PERIOD,CURRENT,
     +                              Taxable Income Deductions Rate,Both)
               ELSEIF(TAX_VALUES(YR,PERIOD,DEFAULT,
     +          Taxable Income Deductions Rate,Federal)/= -999999.) THEN
                  R_FED_DEDUC_PERCT_OF_TIB4DEDUC =
     +                     TAX_VALUES(YR,PERIOD,DEFAULT,
     +                           Taxable Income Deductions Rate,Federal)
               ELSEIF(TAX_VALUES(YR,PERIOD,DEFAULT,
     +              Taxable Income Deductions Rate,Both)/=-999999.) THEN
                  R_FED_DEDUC_PERCT_OF_TIB4DEDUC =
     +                     TAX_VALUES(YR,PERIOD,DEFAULT,
     +                              Taxable Income Deductions Rate,Both)
               ENDIF
C
C TAX DEDUCTIONS STATE
C
               IF(TAX_VALUES(YR,PERIOD,CURRENT,
     +             Taxable Income Deductions Rate,State)/=-999999.) THEN
                  R_FED_DEDUC_PERCT_OF_TIB4DEDUC =
     +                     TAX_VALUES(YR,PERIOD,CURRENT,
     +                             Taxable Income Deductions Rate,State)
               ELSEIF(TAX_VALUES(YR,PERIOD,CURRENT,
     +              Taxable Income Deductions Rate,Both)/=-999999.) THEN
                  R_FED_DEDUC_PERCT_OF_TIB4DEDUC =
     +                     TAX_VALUES(YR,PERIOD,CURRENT,
     +                              Taxable Income Deductions Rate,Both)
               ELSEIF(TAX_VALUES(YR,PERIOD,DEFAULT,
     +             Taxable Income Deductions Rate,State)/=-999999.) THEN
                  R_FED_DEDUC_PERCT_OF_TIB4DEDUC =
     +                     TAX_VALUES(YR,PERIOD,DEFAULT,
     +                             Taxable Income Deductions Rate,State)
               ELSEIF(TAX_VALUES(YR,PERIOD,DEFAULT,
     +              Taxable Income Deductions Rate,Both)/=-999999.) THEN
                  R_FED_DEDUC_PERCT_OF_TIB4DEDUC =
     +                     TAX_VALUES(YR,PERIOD,DEFAULT,
     +                              Taxable Income Deductions Rate,Both)
               ENDIF
            ENDIF
      RETURN
C***********************************************************************
      ENTRY RETURN_OPREV_TAX_RATE(R_YR,R_ASSET_CLASS,R_OPREV_TAX_RATE)
C***********************************************************************
C
         YR = R_YR !  - 1
         PERIOD = 0
         IF(ALLOCATED(TAX_VALUES)) THEN
            IF(R_ASSET_CLASS == 0) THEN
               POINTER = 0
            ELSEIF(R_ASSET_CLASS <= MAX_CLASS_NUM) THEN
               POINTER = ASSET_CLASS_POINTER(R_ASSET_CLASS)
            ELSE
               POINTER = -1
            ENDIF
            IF(POINTER >= -1 .OR. R_ASSET_CLASS == 0) THEN
               IF(TAX_VALUES(YR,PERIOD,POINTER,
     +                Operating Revenue Tax Rate,Both) /= -999999.) THEN
                  R_OPREV_TAX_RATE = TAX_VALUES(YR,PERIOD,POINTER,
     +                                  Operating Revenue Tax Rate,Both)
               ELSEIF(TAX_VALUES(YR,PERIOD,-1,      ! ALL DEFAULT
     +                Operating Revenue Tax Rate,Both) /= -999999.) THEN
                  R_OPREV_TAX_RATE = TAX_VALUES(YR,PERIOD,-1,
     +                                  Operating Revenue Tax Rate,Both)
               ELSEIF(TAX_VALUES(YR,PERIOD,-4,      ! SUB DEFAULT
     +                Operating Revenue Tax Rate,Both) /= -999999.) THEN
                  R_OPREV_TAX_RATE = TAX_VALUES(YR,PERIOD,-4,
     +                                  Operating Revenue Tax Rate,Both)
               ELSEIF(TAX_VALUES(YR,PERIOD,-3,      ! SBU DEFAULT
     +                Operating Revenue Tax Rate,Both) /= -999999.) THEN
                  R_OPREV_TAX_RATE = TAX_VALUES(YR,PERIOD,-3,
     +                                  Operating Revenue Tax Rate,Both)
               ELSEIF(TAX_VALUES(YR,PERIOD,-2,      ! PARENT DEFAULT
     +                Operating Revenue Tax Rate,Both) /= -999999.) THEN
                  R_OPREV_TAX_RATE = TAX_VALUES(YR,PERIOD,-2,
     +                                  Operating Revenue Tax Rate,Both)
               ELSEIF(TAX_VALUES(YR,PERIOD,-5,      ! REG DEFAULT
     +                Operating Revenue Tax Rate,Both) /= -999999.) THEN
                  R_OPREV_TAX_RATE = TAX_VALUES(YR,PERIOD,-5,
     +                                  Operating Revenue Tax Rate,Both)
               ENDIF
            ENDIF
         ELSE
            R_OPREV_TAX_RATE = 0.
         ENDIF
      RETURN
C***********************************************************************
      ENTRY RETURN_CAPITAL_TAX_ITEMS(R_YR,R_ASSET_CLASS,
     +                               R_PROVINCIAL_CAPITAL_TAX_RATE,
     +                               R_FEDERAL_CAPITAL_TAX_RATE,
     +                               R_PROVINCIAL_CAP_TAX_DEDUCTION,
     +                               R_FEDERAL_CAPITAL_TAX_DEDUCTION,
     +                               R_FEDERAL_CAPITAL_TAX_ADDENDUM,
     +                               R_PROVINCIAL_CAP_TAX_ADDENDUM,
     +                               R_CLASS_TYPE)
C***********************************************************************
C
         YR = R_YR ! - 1
         PERIOD = 0
         IF(ALLOCATED(TAX_VALUES)) THEN
            CURRENT = -99
            IF(R_CLASS_TYPE == 'P') DEFAULT = -2
            IF(R_CLASS_TYPE == 'B') DEFAULT = -3
            IF(R_CLASS_TYPE == 'S') DEFAULT = -4
            IF(R_CLASS_TYPE == 'R') DEFAULT = -5
            IF(R_ASSET_CLASS == 0) THEN
               CURRENT = 0
            ELSEIF(R_ASSET_CLASS <= MAX_CLASS_NUM) THEN
               CURRENT = ASSET_CLASS_POINTER(R_ASSET_CLASS)
            ENDIF
            IF(CURRENT == -99 .OR. CURRENT == 0) THEN
               CURRENT = DEFAULT
            ENDIF
            IF(CURRENT >= -5 .OR. R_ASSET_CLASS == 0) THEN
C
               IF(TAX_VALUES(YR,PERIOD,CURRENT,
     +                   Local Capitial Tax Rate,Both) /= -999999.) THEN
                  R_PROVINCIAL_CAPITAL_TAX_RATE =
     +                     TAX_VALUES(YR,PERIOD,CURRENT,
     +                                     Local Capitial Tax Rate,Both)
               ELSEIF(TAX_VALUES(YR,PERIOD,DEFAULT,
     +                   Local Capitial Tax Rate,Both) /= -999999.) THEN
                  R_PROVINCIAL_CAPITAL_TAX_RATE =
     +                     TAX_VALUES(YR,PERIOD,DEFAULT,
     +                                     Local Capitial Tax Rate,Both)
               ENDIF
               IF(TAX_VALUES(YR,PERIOD,CURRENT,
     +                Federal Capitial Tax Rate,Both) /= -999999.) THEN
                  R_FEDERAL_CAPITAL_TAX_RATE =
     +                     TAX_VALUES(YR,PERIOD,CURRENT,
     +                                   Federal Capitial Tax Rate,Both)
               ELSEIF(TAX_VALUES(YR,PERIOD,DEFAULT,
     +                Federal Capitial Tax Rate,Both) /= -999999.) THEN
                  R_FEDERAL_CAPITAL_TAX_RATE =
     +                     TAX_VALUES(YR,PERIOD,DEFAULT,
     +                                   Federal Capitial Tax Rate,Both)
               ENDIF
               R_PROVINCIAL_CAP_TAX_DEDUCTION =
     +                            R_PROVINCIAL_CAP_TAX_DEDUCTION +
     +                            TAX_VALUES(YR,PERIOD,CURRENT,
     +                                Local Capitial Tax Deduction,Both)
               R_FEDERAL_CAPITAL_TAX_DEDUCTION =
     +                         R_FEDERAL_CAPITAL_TAX_DEDUCTION +
     +                         TAX_VALUES(YR,PERIOD,CURRENT,
     +                              Federal Capitial Tax Deduction,Both)
               R_FEDERAL_CAPITAL_TAX_ADDENDUM =
     +                         R_FEDERAL_CAPITAL_TAX_ADDENDUM +
     +                         TAX_VALUES(YR,PERIOD,CURRENT,
     +                               Addendum Federal Capitial Tax,Both)
               R_PROVINCIAL_CAP_TAX_ADDENDUM =
     +                         R_PROVINCIAL_CAP_TAX_ADDENDUM +
     +                         TAX_VALUES(YR,PERIOD,CURRENT,
     +                                 Addendum Local Capitial Tax,Both)
            ENDIF
         ENDIF
      RETURN
C**********************************************************************
      ENTRY RETURN_TAX_INFO_ELIM(R_YR,R_ASSET_CLASS,
     +                           R_PROPERTY_TAX,
     +                           R_OTHER_TAXES,
     +                           R_REVENUE_TAXES)
C**********************************************************************
C
         IF(ALLOCATED(TAX_VALUES) .AND.
     +                            (R_ASSET_CLASS) <= MAX_CLASS_NUM) THEN
            PERIOD = 0
            IF(R_ASSET_CLASS == 0) THEN
               POINTER = 0
            ELSE
               POINTER = ASSET_CLASS_POINTER(R_ASSET_CLASS)
            ENDIF
            IF(POINTER > 0 .OR. R_ASSET_CLASS == 0) THEN
               YR = R_YR - 1
               R_PROPERTY_TAX = R_PROPERTY_TAX +
     +              TAX_VALUES(YR,PERIOD,POINTER,Property Taxes,Both)
               R_OTHER_TAXES = R_OTHER_TAXES +
     +                 TAX_VALUES(YR,PERIOD,POINTER,Other Taxes,Both)
               R_REVENUE_TAXES = R_REVENUE_TAXES +
     +               TAX_VALUES(YR,PERIOD,POINTER,Revenue Taxes,Both)
            ENDIF
         ENDIF
      RETURN
C**********************************************************************
      ENTRY RETURN_TAX_ADJUSTMENTS_ELIM(R_YR,R_ASSET_CLASS,
     +                                  R_FED_INCOME_TAX_ADJ,
     +                                  R_STATE_INCOME_TAX_ADJ)
C**********************************************************************
C
         IF(ALLOCATED(TAX_VALUES)) THEN
            PERIOD = 0
            YR = R_YR - 1
            R_FED_INCOME_TAX_ADJ = R_FED_INCOME_TAX_ADJ
     +                  + TAX_VALUES(YR,PERIOD,-1,
     +                                   Income Tax Adjustments,Federal)
     +                  + TAX_VALUES(YR,PERIOD,-1,
     +                                      Income Tax Adjustments,Both)
            IF(R_ASSET_CLASS <= MAX_CLASS_NUM) THEN
               IF(R_ASSET_CLASS == 0) THEN
                  POINTER = 0
               ELSE
                  POINTER = ASSET_CLASS_POINTER(R_ASSET_CLASS)
               ENDIF
               IF(POINTER > 0 .OR. R_ASSET_CLASS == 0) THEN
                  R_FED_INCOME_TAX_ADJ = R_FED_INCOME_TAX_ADJ
     +                  + TAX_VALUES(YR,PERIOD,POINTER,
     +                                   Income Tax Adjustments,Federal)
     +                  + TAX_VALUES(YR,PERIOD,POINTER,
     +                                      Income Tax Adjustments,Both)
                  R_STATE_INCOME_TAX_ADJ = R_STATE_INCOME_TAX_ADJ
     +                  + TAX_VALUES(YR,PERIOD,POINTER,
     +                                     Income Tax Adjustments,State)
     +                  + TAX_VALUES(YR,PERIOD,POINTER,
     +                                      Income Tax Adjustments,Both)
               ENDIF
            ENDIF
         ENDIF
      RETURN
C**********************************************************************
      ENTRY SAVE_TAX_ITEMS_BASE_CASE
C**********************************************************************
C
         IF(ALLOCATED(TAX_VALUES)) THEN
            CALL OPEN_TAX_BASE_CASE_FILE(INT2(10))
            WRITE(10) TAX_VALUES,TAX_VALUES_NOLS,
     +                ACTUAL_MONTHLY_TAX_VALUES,
     +                ACTUAL_VALUE_FOUND
            CLOSE(10)
            BASE_CASE_NUM_OF_CLASSES = NUM_OF_CLASSES
            BASE_CASE_MAX_CLASS_NUM = MAX_CLASS_NUM
         ENDIF
      RETURN
C**********************************************************************
      ENTRY READ_TAX_ITEMS_BASE_CASE
C**********************************************************************
C
C        CALL SET_TAX_ARRAYS
         CALL RESET_TAX_LOSS_OL
         IF(ALLOCATED(ASSET_CLASS_POINTER))
     +                                   DEALLOCATE(ASSET_CLASS_POINTER)
         IF(BASE_CASE_MAX_CLASS_NUM > 0) THEN
            ALLOCATE(ASSET_CLASS_POINTER(BASE_CASE_MAX_CLASS_NUM))
            ASSET_CLASS_POINTER = -99
            CALL RETURN_TAX_CLASS_POINTER(ASSET_CLASS_POINTER)
         ENDIF
         IF(ALLOCATED(TAX_VALUES)) DEALLOCATE(TAX_VALUES,
     +                                        TAX_VALUES_NOLS,
     +                                        ACTUAL_MONTHLY_TAX_VALUES,
     +                                        ACTUAL_VALUE_FOUND)
         ALLOCATE(TAX_VALUES(FINANCIAL_SIMULATION_YEARS,0:12,
     +                     -5:BASE_CASE_NUM_OF_CLASSES,LAST_TAX_ITEM,3))
         ALLOCATE(TAX_VALUES_NOLS(0:15,0:12,
     +                               -5:BASE_CASE_NUM_OF_CLASSES,35:40))
         ALLOCATE(ACTUAL_MONTHLY_TAX_VALUES(0:12,
     +                          FINANCIAL_SIMULATION_YEARS,
     +                          -1:BASE_CASE_NUM_OF_CLASSES,
     +                          LAST_ACTUAL_TAX_ITEM))
         ALLOCATE(ACTUAL_VALUE_FOUND(-1:BASE_CASE_NUM_OF_CLASSES,
     +                                            LAST_ACTUAL_TAX_ITEM))
         CALL OPEN_TAX_BASE_CASE_FILE(INT2(10))
         READ(10) TAX_VALUES,TAX_VALUES_NOLS,
     +            ACTUAL_MONTHLY_TAX_VALUES,
     +            ACTUAL_VALUE_FOUND
         CLOSE(10)
      RETURN
      END
C**********************************************************************
      FUNCTION TAX_POSITION(R_TAX_TITLE,R_TAX_APPLY,
     +                      R_ADDED_TO_CURRENT_VALUE)
C**********************************************************************
C
      INTEGER*2 TAX_POSITION,M1_BOOK_2_TAX_ADJUSTMENTS
      CHARACTER*(*) R_TAX_TITLE,R_TAX_APPLY*1,TAX_APPLY*1
      CHARACTER*30 TAX_TITLE
      LOGICAL*1 R_ADDED_TO_CURRENT_VALUE
      LOGICAL*1 DRILLING_REPORT_IS_INCOME,DRILLING_REPORT_IS_TAX
      LOGICAL*1 REPORT_4_DRILLING_INCOME,REPORT_4_DRILLING_TAX
      SAVE REPORT_4_DRILLING_INCOME,REPORT_4_DRILLING_TAX
C
      INTEGER*2 ACTUAL_TAX_POSITION
C
         TAX_APPLY = 'B'
         R_ADDED_TO_CURRENT_VALUE = .TRUE.
         REPORT_4_DRILLING_INCOME = .FALSE.
         REPORT_4_DRILLING_TAX = .FALSE.
C
         TAX_TITLE = R_TAX_TITLE
         SELECT CASE (trim(TAX_TITLE))
C
C TAX POSITIONS
C
         CASE ('Other Taxes')
            TAX_POSITION = 1
            REPORT_4_DRILLING_INCOME = .TRUE.
         CASE ('Property Taxes')
            TAX_POSITION = 2
            REPORT_4_DRILLING_INCOME = .TRUE.
         CASE ('Revenue Taxes')
            TAX_POSITION = 3
            REPORT_4_DRILLING_INCOME = .TRUE.
         CASE ('Income Tax Credits','Credits-Income Tax')
            TAX_POSITION = 4
            TAX_APPLY = R_TAX_APPLY
            REPORT_4_DRILLING_TAX = .TRUE.
         CASE ('Income Tax Adjustments','Adjustments-Income Tax')
            TAX_POSITION = 5
            TAX_APPLY = R_TAX_APPLY
            REPORT_4_DRILLING_TAX = .TRUE.
         CASE ('M1 Additions')
            TAX_POSITION = 6
            TAX_APPLY = R_TAX_APPLY
            REPORT_4_DRILLING_TAX = .TRUE.
         CASE ('M1 Deductions')
            TAX_POSITION = 7
            TAX_APPLY = R_TAX_APPLY
            REPORT_4_DRILLING_TAX = .TRUE.
         CASE ('Deferred Taxes-Cr','Cr-Deferred Taxes')
            TAX_POSITION = 8
            REPORT_4_DRILLING_INCOME = .TRUE.
         CASE ('BTL Deferred Taxes-Cr')
            TAX_POSITION = 46
            REPORT_4_DRILLING_INCOME = .TRUE.
         CASE ('Deferred Taxes-Dr','Dr-Deferred Taxes')
            TAX_POSITION = 9
            REPORT_4_DRILLING_INCOME = .TRUE.
         CASE ('BTL Deferred Taxes-Dr')
            TAX_POSITION = 47
            REPORT_4_DRILLING_INCOME = .TRUE.
         CASE ('ITC Amortization')
            TAX_POSITION = 10
            REPORT_4_DRILLING_INCOME = .TRUE.
         CASE ('BTL Tax Deductions')
            TAX_POSITION = 11
            TAX_APPLY = R_TAX_APPLY
            REPORT_4_DRILLING_TAX = .TRUE.
         CASE ('Tax Depreciation')
            TAX_POSITION = 12
            TAX_APPLY = R_TAX_APPLY
            REPORT_4_DRILLING_TAX = .TRUE.
         CASE ('AMT ACE Tax Depreciation')
            TAX_POSITION = 13
            TAX_APPLY = 'F'
            REPORT_4_DRILLING_TAX = .TRUE.
         CASE ('AMT Depreciation Preference')
            TAX_POSITION = 14
            TAX_APPLY = 'F'
            REPORT_4_DRILLING_TAX = .TRUE.
         CASE ('AMT Income Addendum')
            TAX_POSITION = 32
            TAX_APPLY = 'F'
            REPORT_4_DRILLING_TAX = .TRUE.
         CASE ('Sec. 29 Credits-Income Tax')
            TAX_POSITION = 15
            TAX_APPLY = 'F' ! R_TAX_APPLY
            REPORT_4_DRILLING_TAX = .TRUE.
         CASE ('Sec. 42 Credits-Income Tax')
            TAX_POSITION = 16
            TAX_POSITION = 4
            TAX_APPLY = 'F' ! R_TAX_APPLY
            REPORT_4_DRILLING_TAX = .TRUE.
C TAX RATES SECTON
         CASE ('Federal Income Tax')
            TAX_POSITION = 17
            R_ADDED_TO_CURRENT_VALUE = .FALSE.
         CASE ('ITC Amortization Rate')
            TAX_POSITION = 18
            R_ADDED_TO_CURRENT_VALUE = .FALSE.
         CASE ('Local Tax Rate')
            TAX_POSITION = 19
            R_ADDED_TO_CURRENT_VALUE = .FALSE.
         CASE ('Operating Revenue Tax Rate')
            TAX_POSITION = 20
            R_ADDED_TO_CURRENT_VALUE = .FALSE.
         CASE ('Property Tax Rate')
            TAX_POSITION = 21
            R_ADDED_TO_CURRENT_VALUE = .FALSE.
         CASE ('Other Taxes-% of Revenues')
            TAX_POSITION = 22
            R_ADDED_TO_CURRENT_VALUE = .FALSE.
         CASE ('Other Taxes-% of Expenses')
            TAX_POSITION = 23
            R_ADDED_TO_CURRENT_VALUE = .FALSE.
         CASE ('Federal Capitial Tax Rate')
            TAX_POSITION = 24
            R_ADDED_TO_CURRENT_VALUE = .FALSE.
         CASE ('Local Capitial Tax Rate')
            TAX_POSITION = 25
            R_ADDED_TO_CURRENT_VALUE = .FALSE.
         CASE ('Deductions as % of Taxable Income'(1:30))
            TAX_POSITION = 26
            R_ADDED_TO_CURRENT_VALUE = .FALSE.
            TAX_APPLY = R_TAX_APPLY
C CARRY FORWARDS
         CASE ('Federal NOLs')
            TAX_POSITION = 35
            TAX_APPLY = 'F'
         CASE ('AMT NOLs')
            TAX_POSITION = 36
            TAX_APPLY = 'F'
         CASE ('General Tax Credits')
            TAX_POSITION = 37
            TAX_APPLY = R_TAX_APPLY
         CASE ('Sec. 42 Tax Credits')
            TAX_POSITION = 38
            TAX_APPLY = 'F'
         CASE ('State NOLs')
            TAX_POSITION = 39
            TAX_APPLY = 'S'
C TAX ON CAPITAL
         CASE ('Federal Capitial Tax Deduction')
            TAX_POSITION = 40
         CASE ('Local Capitial Tax Deduction')
            TAX_POSITION = 41
         CASE ('Addendum-Federal Capitial Tax')
            TAX_POSITION = 33
         CASE ('Addendum-Local Capitial Tax')
            TAX_POSITION = 34
c        CASE ('')
c           TAX_POSITION = 48
         CASE DEFAULT
            TAX_POSITION = -99
         END SELECT
C
         R_TAX_APPLY = TAX_APPLY
      RETURN
C**********************************************************************
      ENTRY ACTUAL_TAX_POSITION(R_TAX_TITLE)
C**********************************************************************
C
         REPORT_4_DRILLING_INCOME = .FALSE.
         REPORT_4_DRILLING_TAX = .FALSE.
C
         SELECT CASE (trim(R_TAX_TITLE))
C
C Actuals
C
         CASE ('Deferred Taxes-Cr')
            ACTUAL_TAX_POSITION = 1
         CASE ('Federal Income Taxes','Total Federal Income Taxes')
            ACTUAL_TAX_POSITION = 2
         CASE ('State Income Taxes','Total State Income Taxes')
            ACTUAL_TAX_POSITION = 3
         CASE ('Deferred Taxes-Dr')
            ACTUAL_TAX_POSITION = 4
         CASE ('ATL Federal Income Taxes')
            ACTUAL_TAX_POSITION = 5
         CASE ('ATL State Income Taxes')
            ACTUAL_TAX_POSITION = 6
         CASE ('BTL Federal Income Taxes')
            ACTUAL_TAX_POSITION = 7
         CASE ('BTL State Income Taxes')
            ACTUAL_TAX_POSITION = 8
c        CASE ('')
c           ACTUAL_TAX_POSITION =
         CASE DEFAULT
            ACTUAL_TAX_POSITION = -99
         END SELECT
C
      RETURN
C***********************************************************************
      ENTRY DRILLING_REPORT_IS_INCOME
C***********************************************************************
C
         DRILLING_REPORT_IS_INCOME = REPORT_4_DRILLING_INCOME
      RETURN
C***********************************************************************
      ENTRY DRILLING_REPORT_IS_TAX
C***********************************************************************
C
         DRILLING_REPORT_IS_TAX = REPORT_4_DRILLING_TAX
      RETURN
      END
C***********************************************************************
C   READ AND MAINTAIN TAX LOSS DATA
C   COPYRIGHT (C) 1995
C   M.S. GERBER & ASSOCIATES, INC.
C   ALL RIGHTS RESERVED
C***********************************************************************
      FUNCTION READ_TAX_LOSSES(MAX_CLASS_NUM,NUM_OF_ACTIVE_CLASSES,
     +                         MASTER_CLASS_LIST)
C***********************************************************************
C
      INCLUDE 'SpinLib.MON'
      INCLUDE 'SIZECOM.MON'
C
C TAX LOSS VARIABLES
C
      INTEGER*2 MAX_CLASS_NUM,MASTER_CLASS_LIST(0:MAX_CLASS_NUM),
     +          NUM_OF_ACTIVE_CLASSES
C
      INTEGER*2 YRS,READ_TAX_LOSSES,I,CLASS,CLASS_POS
      INTEGER*4 VALUES_2_ZERO
      REAL*4 FEDERAL_BOOK_LOSSES(:,:),STATE_BOOK_LOSSES(:,:),
     +     GENERAL_BUSINESS_CREDITS(:,:),AMT_LOSSES(:,:),
     +     UNUSED_FED_NOLS(:),UNUSED_STATE_NOLS(:),
     +     UNUSED_AMT_NOLS(:),SEC_42_CREDITS(:,:),
     +     STATE_BUSINESS_CREDITS(:,:)
      REAL*4 UNUSED_FED_CREDITS(:),UNUSED_STATE_CREDITS(:),
     +       UNUSED_FED_SEC_42_CREDITS(:)
      ALLOCATABLE :: FEDERAL_BOOK_LOSSES,STATE_BOOK_LOSSES,
     +               GENERAL_BUSINESS_CREDITS,AMT_LOSSES,
     +               UNUSED_FED_NOLS,UNUSED_STATE_NOLS,
     +               UNUSED_AMT_NOLS,
     +               UNUSED_FED_CREDITS,
     +               UNUSED_FED_SEC_42_CREDITS,
     +               UNUSED_STATE_CREDITS,
     +               SEC_42_CREDITS,
     +               STATE_BUSINESS_CREDITS
      SAVE  FEDERAL_BOOK_LOSSES,STATE_BOOK_LOSSES,
     +      GENERAL_BUSINESS_CREDITS,AMT_LOSSES,
     +      UNUSED_FED_NOLS,UNUSED_STATE_NOLS,
     +      UNUSED_AMT_NOLS,
     +      UNUSED_FED_CREDITS,
     +      UNUSED_FED_SEC_42_CREDITS,
     +      UNUSED_STATE_CREDITS,
     +      SEC_42_CREDITS,
     +      STATE_BUSINESS_CREDITS
      REAL*4 CLOSE_CLASS_AMT_TAX_INFO
      REAL*4 STATE_TAXABLE_INCOME,STATE_NOLS_USED
      SAVE STATE_TAXABLE_INCOME,STATE_NOLS_USED
      REAL*4 FED_TAXABLE_INCOME,FED_NOLS_USED
      SAVE FED_TAXABLE_INCOME,FED_NOLS_USED
      REAL*4 AMT_TAXABLE_INCOME,AMT_NOLS_USED
      SAVE AMT_TAXABLE_INCOME,AMT_NOLS_USED
      REAL*4 R_TAXABLE_INCOME,AVAILABLE_NOLS,NOL_BALANCE
      INTEGER*2 R_CLASS,R_YEAR
      REAL*4 ADJUST_4_STATE_NOLS,ADJUST_4_FED_NOLS,
     +     CLOSE_CLASS_STATE_TAX_INFO,
     +     CLOSE_CLASS_FED_TAX_INFO,
     +     ADJUST_4_AMT_NOLS
      REAL*4 ADJUST_4_FED_CONSOLIDATED_NOLS,CLOSE_CONSOLIDATED_TAX_INFO,
     +     FED_CONSOLIDATED_NOLS_USED,FED_CONSOLIDATED_TAXABLE_INCOME
      SAVE FED_CONSOLIDATED_NOLS_USED,FED_CONSOLIDATED_TAXABLE_INCOME
      REAL*4 FEDERAL_NOL_GENERATED,STATE_NOL_GENERATED
      SAVE FEDERAL_NOL_GENERATED,STATE_NOL_GENERATED
      LOGICAL*1 RETURN_NOLS_INFO,RETURN_CONSOLIDATED_NOLS_INFO,
     +          RETURN_CURRENT_NOLS_INFO
      REAL*4 ADJUST_4_FED_CREDIT,FED_CREDIT_USED,CLOSE_FED_CREDIT
      SAVE FED_CREDIT_USED
      REAL*4 AVAIL_CREDITS,R_AVAILABLE_CREDITS,
     +       R_SEC_29_CREDITS_PASSED_UP,
     +       R_SEC_42_CREDITS_PASSED_UP,
     +       R_SEC_29_CREDITS_USED
      REAL*4 R_STATE_NOL_GENERATED,
     +       R_STATE_NOLS_USED,
     +       R_FEDERAL_NOL_GENERATED,
     +       R_FED_NOLS_USED,
     +       R_TAXES_B4_CREDITS,
     +       R_AMT_TAX,R_AMT_CREDITS_USED
      REAL*4 ADJUST_CONSOLD_4_FED_CREDIT,
     +       CONSOLIDATED_FED_CREDIT_USED,
     +       UNUSED_CONSOLIDATED_FED_CREDITS,
     +       AVAIL_CONSOLIDATED_CREDITS
      SAVE CONSOLIDATED_FED_CREDIT_USED,
     +     UNUSED_CONSOLIDATED_FED_CREDITS,
     +     AVAIL_CONSOLIDATED_CREDITS
      REAL*4 TAX_OWED,SEC_29_CREDITS_USED,SEC_29_CREDITS_LOST
      SAVE SEC_29_CREDITS_USED,SEC_29_CREDITS_LOST
      REAL*4 AMT_CREDITS_USED,AVAILABLE_AMT_CREDITS,
     +       SAVE_AMT_PARENT_CREDITS,R_AVAILABLE_AMT_CREDITS
      SAVE AMT_CREDITS_USED,AVAILABLE_AMT_CREDITS
      REAL*4 CONSOLID_AMT_CREDITS_USED,CONSOLID_AVAILABLE_AMT_CREDITS
      SAVE CONSOLID_AMT_CREDITS_USED,CONSOLID_AVAILABLE_AMT_CREDITS
      LOGICAL*1 CLASS_EXITS
      LOGICAL*4 SAVE_TAX_BASE/.TRUE./
      REAL*4 FED_CONSOLIDATED_NOLS_GENERATED
      SAVE FED_CONSOLIDATED_NOLS_GENERATED
      REAL*4 R_STATE_CREDITS_PASSED_UP,
     +       R_STATE_CREDITS_USED,
     +       STATE_CREDITS_USED
      SAVE STATE_CREDITS_USED
      INTEGER*2 YR
      LOGICAL*1 R_USE_ALL_CREDITS
C
      REAL*4 ADJUST_4_STATE_CREDITS
      REAL*4 CLOSE_STATE_CREDIT
      LOGICAL*1 USE_ALL_FED_NOLS
C
         IF(SAVE_TAX_BASE) THEN
            CALL TAX_INFORMATION(SAVE_TAX_BASE)
            SAVE_TAX_BASE = .FALSE.
         ENDIF
         CALL TAX_INFORMATION(SAVE_TAX_BASE)
C
         UNUSED_CONSOLIDATED_FED_CREDITS = 0.
         READ_TAX_LOSSES = 1
         IF(ALLOCATED(FEDERAL_BOOK_LOSSES))
     +                 DEALLOCATE(FEDERAL_BOOK_LOSSES,
     +                            STATE_BOOK_LOSSES,
     +                            GENERAL_BUSINESS_CREDITS,
     +                            STATE_BUSINESS_CREDITS,
     +                            AMT_LOSSES,
     +                            UNUSED_FED_NOLS,
     +                            UNUSED_STATE_NOLS,
     +                            UNUSED_AMT_NOLS,
     +                            UNUSED_FED_CREDITS,
     +                            UNUSED_FED_SEC_42_CREDITS,
     +                            UNUSED_STATE_CREDITS,
     +                            SEC_42_CREDITS)
         YRS = MAX_FINANCIAL_SIMULATION_YEARS+15
         ALLOCATE(FEDERAL_BOOK_LOSSES(-1:YRS,-1:MAX_CLASS_NUM),
     +            SEC_42_CREDITS(-1:YRS,-1:MAX_CLASS_NUM),
     +            STATE_BOOK_LOSSES(-1:YRS,-1:MAX_CLASS_NUM),
     +            GENERAL_BUSINESS_CREDITS(-1:YRS,-1:MAX_CLASS_NUM),
     +            STATE_BUSINESS_CREDITS(-1:YRS,-1:MAX_CLASS_NUM),
     +            AMT_LOSSES(-1:YRS,-1:MAX_CLASS_NUM),
     +            UNUSED_FED_NOLS(-1:MAX_CLASS_NUM),
     +            UNUSED_AMT_NOLS(-1:MAX_CLASS_NUM),
     +            UNUSED_STATE_NOLS(-1:MAX_CLASS_NUM),
     +            UNUSED_FED_CREDITS(-1:MAX_CLASS_NUM),
     +            UNUSED_FED_SEC_42_CREDITS(-1:MAX_CLASS_NUM),
     +            UNUSED_STATE_CREDITS(-1:MAX_CLASS_NUM))
         FEDERAL_BOOK_LOSSES = 0.
         SEC_42_CREDITS = 0.
         GENERAL_BUSINESS_CREDITS = 0.
         STATE_BUSINESS_CREDITS = 0.
         STATE_BOOK_LOSSES = 0.
         AMT_LOSSES = 0.
         UNUSED_FED_NOLS = 0.
         UNUSED_AMT_NOLS = 0.
         UNUSED_STATE_NOLS = 0.
         UNUSED_FED_CREDITS = 0.
         UNUSED_FED_SEC_42_CREDITS = 0.
         UNUSED_STATE_CREDITS = 0.
C
         CLASS = -1
         DO ! CLASS = 1, MAX_CLASS_NUM
            CALL RETURN_TAX_NOLS_CREDITS(CLASS,CLASS_EXITS,
     +                                FEDERAL_BOOK_LOSSES(2,CLASS),
     +                                STATE_BOOK_LOSSES(2,CLASS),
     +                                AMT_LOSSES(2,CLASS),
     +                                GENERAL_BUSINESS_CREDITS(2,CLASS),
     +                                SEC_42_CREDITS(2,CLASS),
     +                                STATE_BUSINESS_CREDITS(2,CLASS))
            IF(CLASS_EXITS) THEN
               DO I = 2, 16
                  UNUSED_STATE_NOLS(CLASS)=UNUSED_STATE_NOLS(CLASS)+
     +                                      STATE_BOOK_LOSSES(I,CLASS)
                  UNUSED_FED_NOLS(CLASS) = UNUSED_FED_NOLS(CLASS) +
     +                                    FEDERAL_BOOK_LOSSES(I,CLASS)
                  UNUSED_AMT_NOLS(CLASS) = UNUSED_AMT_NOLS(CLASS) +
     +                                             AMT_LOSSES(I,CLASS)
                  UNUSED_FED_CREDITS(CLASS) = UNUSED_FED_CREDITS(CLASS)
     +                               + GENERAL_BUSINESS_CREDITS(I,CLASS)
     +                               + SEC_42_CREDITS(I,CLASS)
                  SEC_42_CREDITS(I,CLASS) = SEC_42_CREDITS(I,CLASS)
     +                               + GENERAL_BUSINESS_CREDITS(I,CLASS)
                  UNUSED_FED_SEC_42_CREDITS(CLASS) =
     +                              UNUSED_FED_SEC_42_CREDITS(CLASS) +
     +                                         SEC_42_CREDITS(I,CLASS)
                  UNUSED_STATE_CREDITS(CLASS) =
     +                                 UNUSED_STATE_CREDITS(CLASS)
     +                                 + STATE_BUSINESS_CREDITS(I,CLASS)
               ENDDO
            ENDIF
            IF(CLASS == -1) THEN
               CLASS = 1
            ELSE
               CLASS = CLASS + 1
            ENDIF
            IF(CLASS > MAX_CLASS_NUM) EXIT
         ENDDO
C
      UNUSED_CONSOLIDATED_FED_CREDITS =  UNUSED_FED_CREDITS(-1)
      RETURN
C***********************************************************************
      ENTRY ADJUST_4_STATE_NOLS(R_CLASS,R_TAXABLE_INCOME,
     +                          R_USE_ALL_CREDITS)
C***********************************************************************
         CLASS_POS = R_CLASS
         AVAILABLE_NOLS = UNUSED_STATE_NOLS(CLASS_POS)
         IF(R_USE_ALL_CREDITS) THEN
            STATE_TAXABLE_INCOME = R_TAXABLE_INCOME - AVAILABLE_NOLS
            STATE_NOLS_USED = AVAILABLE_NOLS
            ADJUST_4_STATE_NOLS = STATE_TAXABLE_INCOME
         ELSE
            IF (R_TAXABLE_INCOME <= 0.) THEN
               STATE_TAXABLE_INCOME = R_TAXABLE_INCOME
               STATE_NOLS_USED = 0.
            ELSEIF(R_TAXABLE_INCOME > AVAILABLE_NOLS) THEN
               STATE_TAXABLE_INCOME = R_TAXABLE_INCOME - AVAILABLE_NOLS
               STATE_NOLS_USED = AVAILABLE_NOLS
            ELSE
               STATE_TAXABLE_INCOME = 0.
               STATE_NOLS_USED = R_TAXABLE_INCOME
            ENDIF
            ADJUST_4_STATE_NOLS = MAX(0.,STATE_TAXABLE_INCOME)
         ENDIF
      RETURN
C***********************************************************************
      ENTRY ADJUST_4_STATE_CREDITS(R_CLASS,
     +                             R_TAXES_B4_CREDITS,
     +                             R_STATE_CREDITS_PASSED_UP,
     +                             R_USE_ALL_CREDITS)
C***********************************************************************
C
         AVAIL_CREDITS = UNUSED_STATE_CREDITS(R_CLASS)
     +                   + R_STATE_CREDITS_PASSED_UP
C
         STATE_CREDITS_USED = 0.
         IF(R_USE_ALL_CREDITS) THEN
            STATE_CREDITS_USED = AVAIL_CREDITS
         ELSEIF(R_TAXES_B4_CREDITS > 0.) THEN
            IF(AVAIL_CREDITS >= R_TAXES_B4_CREDITS) THEN
              STATE_CREDITS_USED = R_TAXES_B4_CREDITS
            ELSE
              STATE_CREDITS_USED = AVAIL_CREDITS
            ENDIF
         ENDIF
         ADJUST_4_STATE_CREDITS = STATE_CREDITS_USED
      RETURN
C***********************************************************************
      ENTRY CLOSE_STATE_CREDIT(R_CLASS,R_YEAR,R_AVAILABLE_CREDITS)
C***********************************************************************
C
C
C THE PURPOSE OF THIS ROUTINE IS TO ADJUST THE 15 YEAR CARRY FORWARD
C VALUES BY THE CREDITS USED THIS YEAR AND SUM THE REMAINING CREDITS
C FOR THE NEXT YEAR.  AMT CREDITS ARE ASSUMED TO NEVER EXPIRE.
C
         UNUSED_STATE_CREDITS(R_CLASS) = 0.
         STATE_BUSINESS_CREDITS(R_YEAR+15,R_CLASS) = R_AVAILABLE_CREDITS
         DO YR = R_YEAR, R_YEAR+15
            IF(STATE_CREDITS_USED > 0.) THEN
               IF(STATE_CREDITS_USED >
     +                          STATE_BUSINESS_CREDITS(YR,R_CLASS)) THEN
                  STATE_CREDITS_USED = STATE_CREDITS_USED
     +                              - STATE_BUSINESS_CREDITS(YR,R_CLASS)
                  STATE_BUSINESS_CREDITS(YR,R_CLASS) = 0.
               ELSE
                  STATE_BUSINESS_CREDITS(YR,R_CLASS) =
     +                                STATE_BUSINESS_CREDITS(YR,R_CLASS)
     +                                - STATE_CREDITS_USED
                  STATE_CREDITS_USED = 0.
               ENDIF
            ENDIF
            IF(YR == R_YEAR) CYCLE
            UNUSED_STATE_CREDITS(R_CLASS)=UNUSED_STATE_CREDITS(R_CLASS)
     +                              + STATE_BUSINESS_CREDITS(YR,R_CLASS)

         ENDDO
         CLOSE_STATE_CREDIT = UNUSED_STATE_CREDITS(R_CLASS)
      RETURN
C***********************************************************************
      ENTRY ADJUST_4_FED_NOLS(R_CLASS,R_TAXABLE_INCOME)
C***********************************************************************
      USE_ALL_FED_NOLS = .TRUE.
         CLASS_POS = R_CLASS
         AVAILABLE_NOLS = UNUSED_FED_NOLS(CLASS_POS)
         IF (R_TAXABLE_INCOME <= 0.) THEN
            FED_TAXABLE_INCOME = R_TAXABLE_INCOME
            FED_NOLS_USED = 0.
         ELSEIF(R_TAXABLE_INCOME > AVAILABLE_NOLS) THEN
            FED_TAXABLE_INCOME = R_TAXABLE_INCOME - AVAILABLE_NOLS
            FED_NOLS_USED = AVAILABLE_NOLS
         ELSE
            FED_TAXABLE_INCOME = 0.
            FED_NOLS_USED = R_TAXABLE_INCOME
         ENDIF
         ADJUST_4_FED_NOLS = MAX(0.,FED_TAXABLE_INCOME)
      RETURN
C***********************************************************************
      ENTRY ADJUST_4_FED_CREDIT(R_CLASS,
     +                          R_AMT_TAX,
     +                          R_TAXES_B4_CREDITS,
     +                          R_AVAILABLE_CREDITS,
     +                          R_SEC_29_CREDITS_PASSED_UP,
     +                          R_SEC_42_CREDITS_PASSED_UP,
     +                          R_SEC_29_CREDITS_USED,
     +                          R_AMT_CREDITS_USED,
     +                          R_AVAILABLE_AMT_CREDITS)
C***********************************************************************
C
         AVAIL_CREDITS = UNUSED_FED_CREDITS(R_CLASS)
     +                   + R_AVAILABLE_CREDITS ! THESE ARE NEW CREDITS
     +                   + R_SEC_42_CREDITS_PASSED_UP
         AVAIL_CONSOLIDATED_CREDITS = UNUSED_CONSOLIDATED_FED_CREDITS +
     +                                R_AVAILABLE_CREDITS +
     +                                R_SEC_42_CREDITS_PASSED_UP
C
         AMT_CREDITS_USED = 0.
         AVAILABLE_AMT_CREDITS = R_AVAILABLE_AMT_CREDITS
         FED_CREDIT_USED = 0.
         TAX_OWED = MAX(R_TAXES_B4_CREDITS,R_AMT_TAX)
         IF(R_AMT_TAX > R_TAXES_B4_CREDITS) THEN
            AMT_CREDITS_USED = R_TAXES_B4_CREDITS - R_AMT_TAX
         ENDIF
         IF(R_SEC_29_CREDITS_PASSED_UP < TAX_OWED) THEN
            SEC_29_CREDITS_USED = R_SEC_29_CREDITS_PASSED_UP
            SEC_29_CREDITS_LOST = 0.
         ELSE
            SEC_29_CREDITS_USED = TAX_OWED
            SEC_29_CREDITS_LOST = R_SEC_29_CREDITS_PASSED_UP
     +                            - SEC_29_CREDITS_USED
         ENDIF
         IF(TAX_OWED-SEC_29_CREDITS_USED >= R_AMT_TAX) THEN
            IF(AVAIL_CREDITS >=
     +                      TAX_OWED-R_AMT_TAX-SEC_29_CREDITS_USED) THEN
               FED_CREDIT_USED =
     +                      TAX_OWED-R_AMT_TAX-SEC_29_CREDITS_USED
            ELSE
               FED_CREDIT_USED = AVAIL_CREDITS
               IF(AVAILABLE_AMT_CREDITS >=
     +                TAX_OWED-R_AMT_TAX-SEC_29_CREDITS_USED-
     +                                             FED_CREDIT_USED) THEN

                  AMT_CREDITS_USED = TAX_OWED - R_AMT_TAX -
     +                               SEC_29_CREDITS_USED-
     +                               FED_CREDIT_USED
               ELSE
                  AMT_CREDITS_USED = AVAILABLE_AMT_CREDITS
               ENDIF
            ENDIF
         ENDIF
         R_SEC_29_CREDITS_USED = SEC_29_CREDITS_USED
         R_AMT_CREDITS_USED = AMT_CREDITS_USED
         ADJUST_4_FED_CREDIT = FED_CREDIT_USED
      RETURN
C***********************************************************************
      ENTRY CLOSE_FED_CREDIT(R_CLASS,R_YEAR,
     +                       R_AVAILABLE_CREDITS,
     +                       R_AVAILABLE_AMT_CREDITS)
C***********************************************************************
C
C THE PURPOSE OF THIS ROUTINE IS TO ADJUST THE 15 YEAR CARRY FORWARD
C VALUES BY THE CREDITS USED THIS YEAR AND SUM THE REMAINING CREDITS
C FOR THE NEXT YEAR.  AMT CREDITS ARE ASSUMED TO NEVER EXPIRE.
C
         UNUSED_FED_CREDITS(R_CLASS) = 0.
         SEC_42_CREDITS(R_YEAR+15,R_CLASS) = R_AVAILABLE_CREDITS
         DO YR = R_YEAR, R_YEAR+15
            IF(FED_CREDIT_USED > 0.) THEN
               IF(FED_CREDIT_USED > SEC_42_CREDITS(YR,R_CLASS)) THEN
                  FED_CREDIT_USED = FED_CREDIT_USED
     +                              - SEC_42_CREDITS(YR,R_CLASS)
                  SEC_42_CREDITS(YR,R_CLASS) = 0.
               ELSE
                  SEC_42_CREDITS(YR,R_CLASS)=SEC_42_CREDITS(YR,R_CLASS)
     +                                       - FED_CREDIT_USED
                  FED_CREDIT_USED = 0.
               ENDIF
            ENDIF
            IF(YR == R_YEAR) CYCLE
            UNUSED_FED_CREDITS(R_CLASS) = UNUSED_FED_CREDITS(R_CLASS)
     +                                    + SEC_42_CREDITS(YR,R_CLASS)

         ENDDO
         R_AVAILABLE_AMT_CREDITS = R_AVAILABLE_AMT_CREDITS
     +                             - AMT_CREDITS_USED
         CLOSE_FED_CREDIT = UNUSED_FED_CREDITS(R_CLASS)
      RETURN
C***********************************************************************
      ENTRY ADJUST_4_AMT_NOLS(R_CLASS,R_TAXABLE_INCOME)
C***********************************************************************
         CLASS_POS = R_CLASS
         AVAILABLE_NOLS = UNUSED_AMT_NOLS(CLASS_POS)
         IF (R_TAXABLE_INCOME <= 0.) THEN
            AMT_TAXABLE_INCOME = R_TAXABLE_INCOME
            AMT_NOLS_USED = 0.
         ELSEIF(.90*R_TAXABLE_INCOME > AVAILABLE_NOLS) THEN
            AMT_TAXABLE_INCOME = R_TAXABLE_INCOME - AVAILABLE_NOLS
            AMT_NOLS_USED = AVAILABLE_NOLS
         ELSE
            AMT_TAXABLE_INCOME = .10*R_TAXABLE_INCOME
            AMT_NOLS_USED = .90*R_TAXABLE_INCOME
         ENDIF
         ADJUST_4_AMT_NOLS = MAX(0.,AMT_TAXABLE_INCOME)
      RETURN
C***********************************************************************
      ENTRY CLOSE_CLASS_AMT_TAX_INFO(R_CLASS,R_YEAR)
C***********************************************************************
C
         CLOSE_CLASS_AMT_TAX_INFO = 1.
         CLASS_POS = R_CLASS
         IF(AMT_NOLS_USED > 0) THEN
            NOL_BALANCE = AMT_NOLS_USED
            DO I = R_YEAR, R_YEAR + 14
               IF(AMT_LOSSES(I,CLASS_POS) < NOL_BALANCE) THEN
                  NOL_BALANCE = NOL_BALANCE - AMT_LOSSES(I,CLASS_POS)
                  AMT_LOSSES(I,CLASS_POS) = 0.
               ELSE
                  AMT_LOSSES(I,CLASS_POS) = AMT_LOSSES(I,CLASS_POS) -
     +                                                       NOL_BALANCE
                  EXIT
               ENDIF
            ENDDO
         ENDIF
         IF(AMT_TAXABLE_INCOME <= 0.) THEN
            AMT_LOSSES(R_YEAR+15,CLASS_POS) = ABS(AMT_TAXABLE_INCOME)
            AMT_LOSSES(R_YEAR,CLASS_POS) = 0.
         ELSE
            AMT_LOSSES(R_YEAR,CLASS_POS) = AMT_TAXABLE_INCOME
         ENDIF
         UNUSED_AMT_NOLS(CLASS_POS) = 0.
         DO I = R_YEAR+1, R_YEAR+15
            UNUSED_AMT_NOLS(CLASS_POS) = UNUSED_AMT_NOLS(CLASS_POS) +
     +                                           AMT_LOSSES(I,CLASS_POS)
         ENDDO
      RETURN
C***********************************************************************
      ENTRY ADJUST_4_FED_CONSOLIDATED_NOLS(R_TAXABLE_INCOME)
C***********************************************************************
         FED_CONSOLIDATED_NOLS_GENERATED = 0.
         AVAILABLE_NOLS = UNUSED_FED_NOLS(-1)
         IF(R_TAXABLE_INCOME <= 0.) THEN
            FED_CONSOLIDATED_TAXABLE_INCOME = R_TAXABLE_INCOME
            FED_CONSOLIDATED_NOLS_USED = 0.
            FED_CONSOLIDATED_NOLS_GENERATED = ABS(R_TAXABLE_INCOME)
         ELSEIF(R_TAXABLE_INCOME > AVAILABLE_NOLS) THEN
            FED_CONSOLIDATED_TAXABLE_INCOME = R_TAXABLE_INCOME -
     +                                                    AVAILABLE_NOLS
            FED_CONSOLIDATED_NOLS_USED = AVAILABLE_NOLS
         ELSE
            FED_CONSOLIDATED_TAXABLE_INCOME = 0.
            FED_CONSOLIDATED_NOLS_USED = R_TAXABLE_INCOME
         ENDIF
         ADJUST_4_FED_CONSOLIDATED_NOLS = MAX(0.,
     +                                  FED_CONSOLIDATED_TAXABLE_INCOME)
      RETURN
C***********************************************************************
      ENTRY ADJUST_CONSOLD_4_FED_CREDIT(R_AMT_TAX,
     +                                  R_TAXES_B4_CREDITS,
     +                                  R_AVAILABLE_CREDITS,
     +                                  R_SEC_29_CREDITS_PASSED_UP,
     +                                  R_SEC_42_CREDITS_PASSED_UP,
     +                                  R_SEC_29_CREDITS_USED,
     +                                  R_AMT_CREDITS_USED,
     +                                  R_AVAILABLE_AMT_CREDITS)
C***********************************************************************
         AVAIL_CONSOLIDATED_CREDITS = UNUSED_CONSOLIDATED_FED_CREDITS +
     +                                R_AVAILABLE_CREDITS +
     +                                R_SEC_42_CREDITS_PASSED_UP
C
         CONSOLID_AVAILABLE_AMT_CREDITS = R_AVAILABLE_AMT_CREDITS
         CONSOLIDATED_FED_CREDIT_USED = 0.
         CONSOLID_AMT_CREDITS_USED = 0.
         TAX_OWED = MAX(R_TAXES_B4_CREDITS,R_AMT_TAX)
         IF(R_AMT_TAX > R_TAXES_B4_CREDITS) THEN
            CONSOLID_AMT_CREDITS_USED = R_TAXES_B4_CREDITS - R_AMT_TAX
         ENDIF
         IF(R_SEC_29_CREDITS_PASSED_UP >= TAX_OWED) THEN
           SEC_29_CREDITS_USED = TAX_OWED
           SEC_29_CREDITS_LOST = R_SEC_29_CREDITS_PASSED_UP -
     +                           SEC_29_CREDITS_USED
         ELSE
            SEC_29_CREDITS_USED = R_SEC_29_CREDITS_PASSED_UP
            SEC_29_CREDITS_LOST = 0.
            IF(TAX_OWED-SEC_29_CREDITS_USED >= R_AMT_TAX) THEN
               IF(AVAIL_CONSOLIDATED_CREDITS >=
     +                      TAX_OWED-R_AMT_TAX-SEC_29_CREDITS_USED) THEN
                  CONSOLIDATED_FED_CREDIT_USED =
     +                          TAX_OWED-R_AMT_TAX-SEC_29_CREDITS_USED
               ELSE
                  CONSOLIDATED_FED_CREDIT_USED =
     +                                        AVAIL_CONSOLIDATED_CREDITS
                  IF(CONSOLID_AVAILABLE_AMT_CREDITS >=
     +                     TAX_OWED-R_AMT_TAX-SEC_29_CREDITS_USED-
     +                                CONSOLIDATED_FED_CREDIT_USED) THEN

                     CONSOLID_AMT_CREDITS_USED = TAX_OWED - R_AMT_TAX -
     +                                    SEC_29_CREDITS_USED-
     +                                      CONSOLIDATED_FED_CREDIT_USED
                  ELSE
                     CONSOLID_AMT_CREDITS_USED =
     +                                    CONSOLID_AVAILABLE_AMT_CREDITS
                  ENDIF
               ENDIF
            ENDIF
         ENDIF
         R_SEC_29_CREDITS_USED = SEC_29_CREDITS_USED
         R_AMT_CREDITS_USED = CONSOLID_AMT_CREDITS_USED
c$ifdefined(amt_tax_credits)
c         IF(AVAIL_CONSOLIDATED_CREDITS >= R_TAXES_B4_CREDITS) THEN
c           CONSOLIDATED_FED_CREDIT_USED = R_TAXES_B4_CREDITS
c         ELSE
c           CONSOLIDATED_FED_CREDIT_USED = AVAIL_CONSOLIDATED_CREDITS
c         ENDIF
c$endif
         ADJUST_CONSOLD_4_FED_CREDIT = CONSOLIDATED_FED_CREDIT_USED
      RETURN
C***********************************************************************
      ENTRY CLOSE_CONSOLIDATED_TAX_INFO()
C***********************************************************************
         CLOSE_CONSOLIDATED_TAX_INFO = 1.
         UNUSED_FED_NOLS(-1) = UNUSED_FED_NOLS(-1)
     +                         + FED_CONSOLIDATED_NOLS_GENERATED
     +                         - FED_CONSOLIDATED_NOLS_USED
         STATE_NOLS_USED = 0.
         STATE_TAXABLE_INCOME = 0.
         FED_NOLS_USED = FED_CONSOLIDATED_NOLS_USED
         FED_TAXABLE_INCOME = FED_CONSOLIDATED_TAXABLE_INCOME
         FED_NOLS_USED = 0.
         FED_TAXABLE_INCOME = 0.
         UNUSED_CONSOLIDATED_FED_CREDITS = AVAIL_CONSOLIDATED_CREDITS -
     +                                      CONSOLIDATED_FED_CREDIT_USED
         CONSOLID_AVAILABLE_AMT_CREDITS = CONSOLID_AVAILABLE_AMT_CREDITS
     +                                    - CONSOLIDATED_FED_CREDIT_USED
c        AVAILABLE_AMT_CREDITS = AMT_CREDITS_USED-AVAILABLE_AMT_CREDITS
      RETURN
C***********************************************************************
      ENTRY CLOSE_CLASS_STATE_TAX_INFO(R_CLASS,R_YEAR,
     +                                 R_USE_ALL_CREDITS)
C***********************************************************************
         CLOSE_CLASS_STATE_TAX_INFO = 1.
         CLASS_POS = R_CLASS
         STATE_NOL_GENERATED = 0.
         IF(STATE_NOLS_USED > 0) THEN
            NOL_BALANCE = STATE_NOLS_USED
            DO I = R_YEAR, R_YEAR + 14
               IF(STATE_BOOK_LOSSES(I,CLASS_POS) < NOL_BALANCE) THEN
                  NOL_BALANCE = NOL_BALANCE -
     +                                    STATE_BOOK_LOSSES(I,CLASS_POS)
                  STATE_BOOK_LOSSES(I,CLASS_POS) = 0.
               ELSE
                  STATE_BOOK_LOSSES(I,CLASS_POS) = -NOL_BALANCE +
     +                                    STATE_BOOK_LOSSES(I,CLASS_POS)
                  EXIT
               ENDIF
            ENDDO
         ENDIF
         IF(STATE_TAXABLE_INCOME <= 0. .AND..NOT.R_USE_ALL_CREDITS) THEN
            STATE_BOOK_LOSSES(R_YEAR+15,CLASS_POS) =
     +                                         ABS(STATE_TAXABLE_INCOME)
            STATE_BOOK_LOSSES(R_YEAR,CLASS_POS) = 0.
            STATE_NOL_GENERATED = ABS(STATE_TAXABLE_INCOME)
         ELSE
            STATE_BOOK_LOSSES(R_YEAR,CLASS_POS) = STATE_TAXABLE_INCOME
         ENDIF
         UNUSED_STATE_NOLS(CLASS_POS) = 0.
         DO I = R_YEAR+1, R_YEAR+15
            UNUSED_STATE_NOLS(CLASS_POS) = UNUSED_STATE_NOLS(CLASS_POS)+
     +                                    STATE_BOOK_LOSSES(I,CLASS_POS)
         ENDDO
      RETURN
C
C***********************************************************************
      ENTRY CLOSE_CLASS_FED_TAX_INFO(R_CLASS,R_YEAR,
     +                               R_USE_ALL_CREDITS)
C***********************************************************************
         CLOSE_CLASS_FED_TAX_INFO = 1.
         CLASS_POS = R_CLASS
         FEDERAL_NOL_GENERATED = 0.
         IF(FED_NOLS_USED > 0) THEN
            NOL_BALANCE = FED_NOLS_USED
            DO I = R_YEAR, R_YEAR + 14
               IF(FEDERAL_BOOK_LOSSES(I,CLASS_POS) < NOL_BALANCE) THEN
                  NOL_BALANCE = NOL_BALANCE -
     +                                  FEDERAL_BOOK_LOSSES(I,CLASS_POS)
                  FEDERAL_BOOK_LOSSES(I,CLASS_POS) = 0.
               ELSE
                  FEDERAL_BOOK_LOSSES(I,CLASS_POS) = -NOL_BALANCE +
     +                                  FEDERAL_BOOK_LOSSES(I,CLASS_POS)
                  EXIT
               ENDIF
            ENDDO
         ENDIF
         IF(FED_TAXABLE_INCOME <= 0. .AND. .NOT. R_USE_ALL_CREDITS) THEN
            FEDERAL_BOOK_LOSSES(R_YEAR+15,CLASS_POS) =
     +                                           ABS(FED_TAXABLE_INCOME)
            FEDERAL_BOOK_LOSSES(R_YEAR,CLASS_POS) = 0.
            FEDERAL_NOL_GENERATED = ABS(FED_TAXABLE_INCOME)
         ELSE
            FEDERAL_BOOK_LOSSES(R_YEAR,CLASS_POS) = FED_TAXABLE_INCOME
         ENDIF
         UNUSED_FED_NOLS(CLASS_POS) = 0.
         DO I = R_YEAR+1, R_YEAR+15
            UNUSED_FED_NOLS(CLASS_POS) = UNUSED_FED_NOLS(CLASS_POS) +
     +                                  FEDERAL_BOOK_LOSSES(I,CLASS_POS)
         ENDDO
      RETURN
C***********************************************************************
      ENTRY RETURN_NOLS_INFO(R_STATE_NOL_GENERATED,
     +                       R_STATE_NOLS_USED,
     +                       R_FEDERAL_NOL_GENERATED,
     +                       R_FED_NOLS_USED)
C***********************************************************************
C
         R_STATE_NOL_GENERATED = STATE_NOL_GENERATED
         R_STATE_NOLS_USED = STATE_NOLS_USED
         R_FEDERAL_NOL_GENERATED = FEDERAL_NOL_GENERATED
         R_FED_NOLS_USED = FED_NOLS_USED
         STATE_NOL_GENERATED = 0.
         STATE_NOLS_USED = 0.
         FEDERAL_NOL_GENERATED = 0.
         FED_NOLS_USED = 0.
         STATE_TAXABLE_INCOME = 0.
         FED_TAXABLE_INCOME = 0.
         RETURN_NOLS_INFO = .TRUE.
      RETURN
C***********************************************************************
      ENTRY RETURN_CURRENT_NOLS_INFO(R_STATE_NOL_GENERATED,
     +                               R_STATE_NOLS_USED,
     +                               R_FEDERAL_NOL_GENERATED,
     +                               R_FED_NOLS_USED)
C***********************************************************************
C
         R_STATE_NOL_GENERATED = STATE_NOL_GENERATED
         R_STATE_NOLS_USED = STATE_NOLS_USED
         R_FEDERAL_NOL_GENERATED = FEDERAL_NOL_GENERATED
         R_FED_NOLS_USED = FED_NOLS_USED
         RETURN_CURRENT_NOLS_INFO = .TRUE.
      RETURN
C***********************************************************************
      ENTRY RETURN_CONSOLIDATED_NOLS_INFO(R_FEDERAL_NOL_GENERATED,
     +                                    R_FED_NOLS_USED)
C***********************************************************************
         R_FEDERAL_NOL_GENERATED = FED_CONSOLIDATED_NOLS_GENERATED
         R_FED_NOLS_USED = FED_CONSOLIDATED_NOLS_USED
         RETURN_CONSOLIDATED_NOLS_INFO = .TRUE.
      RETURN
      END

