C     Last change: msg 8/7/2022 3:11:50 PM
!			MSG 7/5/2016 11:05:24 AM
!			MSG 7/5/2016 10:49:23 AM
!			MSG 7/5/2016 10:39:05 AM
!			MSG 6/6/2016 3:36:05 PM
!			MSG 6/6/2016 3:29:22 PM
!			MSG 6/4/2016 7:04:43 PM
!			MSG 6/4/2016 7:00:45 PM
!			MSG 6/4/2016 7:00:03 PM
!			MSG 5/22/2016 5:32:26 PM
!			MSG 3/9/2015 2:23:19 PM
!			MSG 3/8/2015 12:12:29 PM
!			MSG 3/8/2015 12:10:22 PM
! 031210. DELETED CLA_OBJT_ARRAYS MODULE
! 100506. ADDED MARKET FLOOR AND MARKET CEILING VARIABLES FOR KCPL.
! 120606. ADDED REGIONAL OR STATE MAP SWITCH.
      MODULE CL_UNITS_READ_DATA
         USE PRODUCTION_ARRAYS_AND_DIMENSIONS
         REAL (KIND=4) :: LOCAL_CL_POOL_FRAC_OWN(MAX_CL_UNITS)
         REAL (KIND=8) :: ThermalDemandPreviousIter(MAX_CL_UNITS)
      END MODULE
      SUBROUTINE CL_OBJECT
      use end_routine, only: end_program, er_message
C
      INCLUDE 'SPINLIB.MON'
      INCLUDE 'SIZECOM.MON'
      INTEGER*2 IREC,INUNIT,DELETE,LRECL/1159/ ! 120218 ! 081818 ! 022510 ! 052609 1068 ! 011809 1041! 091107 ! 1033! 100506 for KCPL ! 080906 ! /961/
      INTEGER*2 UNIT_NO,R_ACTIVE_CL_RECORDS,
     +          MONTHLY_CAPACITY_POINTER,I,
     +          MONTHLY_FUEL_INDEX,
     +          RETROFIT_PROJECT_ID
      INTEGER IOS,IOS_BASE
      CHARACTER*2 CL_LOAD_TYPE,
     +            UNIT_TYPE,
     +            UNIT_TYPE_CATEGORY
      CHARACTER*5 OVERLAY_FAMILY_NAME,FOSSILFL
      CHARACTER*36 THERMAL_GUID
      CHARACTER*48 UNIT_NAME
      CHARACTER*30 DESC,CO2_BASIN_NAME
      CHARACTER*256 FILE_NAME
      CHARACTER*256 BASE_FILE_DIRECTORY,OUTPUT_DIRECTORY
      LOGICAL*4 FILE_EXISTS
C DECLARATION FOR DBREAD COMMON BLOCK
      CHARACTER*2048 RECLN
C DECLARATION FOR /FOSSIL FILE/
      LOGICAL*1 PHASE_I
      CHARACTER (LEN=1) :: PHASE_I_STR
      INTEGER*2 GENGRP,ONLIMO,ONLIYR,OFLIMO,OFLIYR,
     +          PRESCR,SDESCR,VRESCR,FIXED_COST_ESCALATOR,
     +          AI_CAPACITY_ESCALATOR,AI_ENERGY_ESCALATOR,
     +          AI_REMAINING_LIFE,TIE_GROUP,
     +          ASSET_CLASS_NUM,ASSET_CLASS_VECTOR,
     +          INTRA_COMPANY_CLASS_ID,
     +          NOX_SEASON_DATE,
     +          NOX_CONTROL_DATE,
     +          SOX_CONTROL_DATE,
     +          CO2_CONTROL_DATE,
     +          HG_CONTROL_DATE,
     +          OTHER3_CONTROL_DATE,
     +          MONTHLY_MUST_RUN_VECTOR,
     +          MONTHLY_DECOMMIT_VECTOR,
     +          EMISSION_MARKET_LINK,
     +          FIRST_RETIREMENT_YEAR,
     +          RPS_PROGRAM_NUMBER,
     +          GET_RPS_PROGRAM_POSITION
      CHARACTER*1 INTRA_COMPANY_TRANSACTION,
     +            SPECIAL_UNIT_ID*20,
     +            UNIT_ACTIVE,
     +            REPORT_THIS_UNIT,
     +            UTILITY_OWNED,
     +            START_UP_LOGIC,
     +            CONTRIBUTES_TO_SPIN,
     +            APPLY_NOX_SEASON_DATE,
     +            MARKET_RESOURCE,
     +            USE_POLY_HEAT_RATES,
     +            WVPA_RATE_TRACKER,
     +            WVPA_RES_TRACKER,
     +            WVPA_FUEL_TRACKER,
     +            WVPA_MEM_TRACKER,
     +            ALLOW_DECOMMIT,
     +            MONTE_OR_FREQ,
     +            PRIMARY_FUEL_CATEGORY,
     +            SECONDARY_FUEL_CATEGORY,
     +            EMISSIONS_FUEL_CATEGORY,
     +            RETIREMENT_CANDIDATE,
     +            RETROFIT_CANDIDATE,
     +            THERMAL_AGGREGATED_UNIT
      CHARACTER*6    BASECASE_PLANT_ID,
     +               BASECASE_UNIT_ID,
     +               BASECASE_MARKET_AREA_ID,
     +               BASECASE_TRANS_AREA_ID,
     +               BASECASE_PLANT_NERC_SUB_ID,
     +               BASECASE_PLANT_OWNER_ID,
     +               PRIMARY_MOVER_STR
      CHARACTER*20 COUNTY,NEWGEN_UNIT_STATUS,STATE_PROV_NAME
      CHARACTER*6 STATE_PROVINCE
      REAL AI_TAX_LIFE,
     +     AI_ADR_TAX_LIFE,
     +     START_UP_COSTS
C DECLARATION FOR TRANSACT
      INTEGER*2 TRANSACTION_GROUP_ID,DAY_TYPE_ID
C
C CHANGED FROM INTEGER*2 TO REAL 5/14/92 ADDED THE ID AS INTEGER*1
C
      REAL MW(2),ANNUAL_CL_FIXED_COST,CO2_PIPELINE_DISTANCE,
     +     CO2_RETRO_HEAT_MULT,CO2_RETRO_CAP_MULT
      INTEGER*2 RESOURCE_ID,P_FUEL_SUPPLY_ID
C END 5/14/92 CHANGES
      INTEGER*2 ANNUAL_CL_FIXED_COST_ESC
      REAL FRAOWN,FUELMX,PRFCST,SEFCST,EFOR,FUELADJ,MAINRT(12),VARCST,
     +     DISPADJ,HRFACT,COEFF(3),FIXED_COST,AI_CAPACITY_RATE,
     +     AI_ENERGY_RATE,POOL_FRAC_OWN,DISP_ADJ2_OUT,DISPADJ2,
     +     MAINT_DAYS,DISPATCH_MULT,EXCESS_ENERGY_SALES,
     +     MINIMUM_CAPACITY_FACTOR,MAXIMUM_CAPACITY_FACTOR,
     +     RAMP_RATE,MIN_DOWN_TIME,RAMP_DOWN_RATE,
     +     MIN_UP_TIME,
     +     P_FUEL_DELIVERY,
     +     P_FUEL_DELIVERY_2,P_FUEL_DELIVERY_3,
     +     S_FUEL_DELIVERY,
     +     S_FUEL_DELIVERY_2,S_FUEL_DELIVERY_3,
     +     FOR_FREQUENCY,
     +     FOR_DURATION,
     +     WINTER_TOTAL_CAPACITY,
     +     NOX_CONTROL_PERCENT,
     +     SOX_CONTROL_PERCENT,
     +     CO2_CONTROL_PERCENT,
     +     HG_CONTROL_PERCENT,
     +     OTHER3_CONTROL_PERCENT,
     +     EMERGENCY_CAPACITY,
     +     EMERGENCY_HEATRATE,
     +     NOX_VOM,
     +     NOX_FOM,
     +     SOX_VOM,
     +     SOX_FOM,
     +     CO2_VOM,
     +     CO2_FOM,
     +     HG_VOM,
     +     HG_FOM,
     +     OTHER3_VOM,
     +     OTHER3_FOM,
     +     LATITUDE,
     +     LONGITUDE,
     +     MW_INSIDE_FENCE,
     +     CONSTANT_POLY,
     +     FIRST_POLY,
     +     SECOND_POLY,
     +     THIRD_POLY,
     +     MIN_SPIN_CAP,
     +     MAX_SPIN_CAP,
     +     INTER_BLOCKS(3),
     +     MARKET_FLOOR,
     +     MARKET_CEILING,
     +     START_UP_COSTS_ESCALATION,  ! 212
     +     RPS_CONTRIBUTION_PERCENT
C DECLARATION FOR EMISSIONS ITEMS
      REAL P_SO2,P_NOX_BK1,P_CO2,P_NOX,P_PARTICULATES,P_NOX_BK2_OUT,
C ADDED 6/17/91
     +     P_OTHER2,P_OTHER3,
C ADDED 12/9/92 FOR SOUTHERN COMPANY
     +     P_NOX_BK2,EMISS_FUEL_COST,EMISS_BLENDING_RATE
      INTEGER*2 SEC_EMISS_PTR,EMISS_FUEL_ESCAL,EMISS_FUEL_EMISS_PTR,
     +          PRIM_FUEL_EMISS_PTR
C DECLARATION FOR /ENERGY LIMITED RESOURCE FILE/
C 5/20/92 ADDED EL GROUP CAPABILITY-GT
      REAL PLANNING_FACTOR
      CHARACTER*1 EXPENSE_ASSIGNMENT,EXPENSE_COLLECTION,
C ADDED 3/10/93 FOR CLINTON TAX
     +            FUEL_TYPES(2),PRIM_FUEL_TYPE*6
      character*3 temp_expense_collection
      CHARACTER*22 FILE_TYPE/'Capacity-limited Units'/
      INTEGER*2 NUCLEAR_UNITS_ACTIVE,R_NUM_OF_NUCLEAR_UNITS
      SAVE NUCLEAR_UNITS_ACTIVE
      CHARACTER*1 NUCLEAR
      PARAMETER (NUCLEAR='N')
      INTEGER*8 HESI_UNIT_ID_NUM,
     +          H2_UNIT_ID_NUM,
     +          TRANS_BUS_ID,
     +          THERMAL_PARENT_ID
      INTEGER ! H2_UNIT_ID_NUM,
     +        POWERDAT_PLANT_ID,GET_HESI_UNIT_ID_NUM_I4

C MULTI-CL FILE VARIABLES
C
      INTEGER FILE_NUMBER,FILE_ID
      INTEGER MAX_CL_FILES,R_MAX_CL_FILES
      PARAMETER (MAX_CL_FILES=36) ! note file 24 is for SPCapEx
      INTEGER*2 ACTIVE_CL_RECORDS(0:MAX_CL_FILES-1)/MAX_CL_FILES*0/
      INTEGER*2 NUC_UNITS_IN_FILE(0:MAX_CL_FILES-1)/MAX_CL_FILES*0/
      INTEGER*2 NUC_UNITS_IN_OL_FILE(0:MAX_CL_FILES-1)/MAX_CL_FILES*0/
      CHARACTER*2 FOSSILOL(0:MAX_CL_FILES-1)/MAX_CL_FILES*'BC'/
      INTEGER*2 NUC_RECORD_POSITION(200,0:MAX_CL_FILES-1),ONLINE,OFLINE ! 2/19/98. GAT. CHANGED FROM 50
      CHARACTER*5 CL_FILE_BASE_NAMES(0:MAX_CL_FILES-1),
     +            VOID_CHR,BASE_FILE_NAME
      CHARACTER*2 CL_FILE_CODES(0:MAX_CL_FILES-1)/
     +                              'CL','C1','C2','C3','C4','C5',
     +                              'C6','C7','C8','C9','C0',
     +                              'CA','CB','CC','CD','CE','CG',
     +                              'CI','CJ','CK','CM','CP','CQ',
     +                              'XC','CS','CU','CV','CW','CX','CY',
     +                              'EJ','EK','ER','ET','MX','MY'/,
     +            FILE_CODE
      INTEGER*2
     +               CAPACITY_MARKET_POINTER
      REAL*4         CAPACITY_MARKET_COIN_ADJ_FACT
      CHARACTER*5
     +               CAPACITY_MARKET_TYPE,
     +               CAPACITY_MARKET_MONTH,
     +               CAPACITY_MARKET_EXP_COLLECT
      CHARACTER*20   CAPACITY_MARKET_COST_ASSIGN
      CHARACTER*6 CL_FILE_BINARY_NAMES(0:MAX_CL_FILES-1)/'FOSIL ',
     +                                       'FOSIL1',
     +                                       'FOSIL2',
     +                                       'FOSIL3',
     +                                       'FOSIL4',
     +                                       'FOSIL5',
     +                                       'FOSIL6',
     +                                       'FOSIL7',
     +                                       'FOSIL8',
     +                                       'FOSIL9',
     +                                       'FOSIL0',
     +                                       'FOSILA',
     +                                       'FOSILB',
     +                                       'FOSILC',
     +                                       'FOSILD',
     +                                       'FOSILE',
     +                                       'FOSILF',
     +                                       'FOSILG',
     +                                       'FOSILH',
     +                                       'FOSILI',
     +                                       'FOSILJ',
     +                                       'FOSILK',
     +                                       'FOSILL',
     +                                       'FOSILM',
     +                                       'FOSILN',
     +                                       'FOSILO',
     +                                       'FOSILP',
     +                                       'FOSILQ',
     +                                       'CapExF',
     +                                       'FOSILR',
     +                                       'FOSILS',
     +                                       'FOSILU',
     +                                       'FOSILV',
     +                                       'FOSILW',
     +                                       'FOSILX',
     +                                       'FOSILY'/,
     +            BINARY_FILE_NAME
      LOGICAL ACTIVE_BASE_CL_FILES(0:MAX_CL_FILES-1)/
     +                                            MAX_CL_FILES*.FALSE./,
     +        ACTIVE_OVERLAY_CL_FILES(0:MAX_CL_FILES-1)/
     +                                            MAX_CL_FILES*.FALSE./
      LOGICAL*1 CL_FILES_ARE_ACTIVE/.FALSE./,R_CL_FILES_ARE_ACTIVE
      CHARACTER*256 COMMAND1,COMMAND2
      LOGICAL*1 LAHEY_LF95
      CHARACTER*30 SCREEN_OUTPUT
C SPCapEx additions Nov. 2005
      CHARACTER (LEN=20)  :: TECH_TYPE
      LOGICAL (KIND=1) :: SP_CAPEX_ACTIVE,SPCapExOption
      CHARACTER (LEN=15),DIMENSION(155) :: CL_VARIABLES
      REAL (KIND=4) :: FIRST_YEAR_DECOMM_AVAIALABLE
      REAL (KIND=4) :: DECOMMISSIONING_BASE_YR_COST,
     +                 DECOMMISSIONING_COST_ESCALATION,
     +                 ANNUAL_ENERGY_PLANNING_FACTOR,
     +                 NAME_PLATE_CAPACITY,
     +                 FuelRatio(5),
     +                 BlendableFuelsPtr(4), ! 167
     +                 FuelTransportationCost(4),
     +                 BlendedEnthalpyUp,
     +                 BlendedEnthalpyLo,
     +                 BlendedSO2Up,                  ! 177
     +                 BettermentProjectID,
     +                 DECOM_CONTINUING_COST,
     +                 DECOM_CONTINUING_COST_ESCALATION,
     +                 EnrgPatternPointer, ! 181
     +                 EmissRedRate(5),
     +                 EmissMaxRate(5),
     +                 MaxEnergyLimit(3)
      CHARACTER (LEN=1) :: AGGREGATE_THIS_UNIT,
     +                     EMISSION_DATA_UNITS,
     +                     LINKED_BETTERMENT_OPTION
      CHARACTER*10 FUEL_BLENDING_IS
C***********************************************************************
C
C          ROUTINE TO CONVERT METAFILE FILES TO DIRECT-ACESS BINARY
C          COPYRIGHT (C) 1983, 84, 85  M.S. GERBER & ASSOCIATES, INC.
C
C***********************************************************************
C
C CONVERT THE (FOSSIL-FUELED) CAPACITY-LIMITED-UNITS FILE
C***************************************************************
      ENTRY CL_MAKEBIN
C***************************************************************
      VOID_CHR = FOSSILFL(CL_FILE_BASE_NAMES)
C
      IF(.NOT. LAHEY_LF95())
     +        CALL MG_CLEAR_LINE_WRITE(17,9,36,FILE_TYPE,ALL_VERSIONS,0)
      NUCLEAR_UNITS_ACTIVE = 0
C     CALL CINITW(NUC_RECORD_POSITION,INT(200*15),0)
C
      DO FILE_ID = 0, MAX_CL_FILES-1
         IF(.NOT. SP_CAPEX_ACTIVE() .AND. FILE_ID == 23) CYCLE  ! CQ file
         ACTIVE_BASE_CL_FILES(FILE_ID) = .FALSE.
         BASE_FILE_NAME = CL_FILE_BASE_NAMES(FILE_ID)
         IF(INDEX(BASE_FILE_NAME,'NONE') /= 0) CYCLE
         FILE_CODE = CL_FILE_CODES(FILE_ID)
         BINARY_FILE_NAME = CL_FILE_BINARY_NAMES(FILE_ID)
         FILE_NAME = trim(BASE_FILE_DIRECTORY())//FILE_CODE//
     +                               "B"//trim(BASE_FILE_NAME)//".DAT"
         INQUIRE(FILE=FILE_NAME,EXIST=FILE_EXISTS)
         IF(FILE_EXISTS) THEN
            SPCapExOption = FILE_ID == 23
            IF(LAHEY_LF95()) THEN
               SCREEN_OUTPUT = trim(FILE_TYPE)//'-'//BASE_FILE_NAME
               CALL MG_LOCATE_WRITE(16,30,SCREEN_OUTPUT,ALL_VERSIONS,0)
            ELSE
               CALL MG_CLEAR_LINE_WRITE(16,30,34,trim(BASE_FILE_NAME),
     +                                                   ALL_VERSIONS,0)
            ENDIF
            ACTIVE_BASE_CL_FILES(FILE_ID) = .TRUE.
            CL_FILES_ARE_ACTIVE = .TRUE.
            OPEN(10,FILE=FILE_NAME)
            OPEN(11,FILE=trim(OUTPUT_DIRECTORY())//
     +                     "BC"//trim(BINARY_FILE_NAME)//".BIN",
     +                      ACCESS="DIRECT",STATUS="UNKNOWN",RECL=LRECL)
            IREC = 0
            READ(10,*) DELETE
C
            DO
               AI_CAPACITY_RATE = 0.
               AI_CAPACITY_ESCALATOR = 0.
               AI_ENERGY_RATE = 0.
               AI_ENERGY_ESCALATOR = 0.
               AI_REMAINING_LIFE = 0
               P_SO2 = 0.
               P_NOX_BK1 = 0.
               P_CO2 = 0.
               P_OTHER2 = 0.
               P_OTHER3 = 0.
               POOL_FRAC_OWN = 100.
               PHASE_I = .TRUE.
               P_FUEL_SUPPLY_ID = 0
               DISPADJ2  = -99999.
               P_NOX_BK2 = -99999.
               SEC_EMISS_PTR = -1
               EMISS_FUEL_COST = 0.
               EMISS_FUEL_ESCAL = 0
               EMISS_FUEL_EMISS_PTR = 0
               EMISS_BLENDING_RATE = 0.
               PRIM_FUEL_EMISS_PTR = 0
               PRIM_FUEL_TYPE = 'T'
               FUEL_TYPES(1) = 'T'
               FUEL_TYPES(2) = 'T'
               TIE_GROUP = 0
               MONTHLY_CAPACITY_POINTER = 0
               ANNUAL_CL_FIXED_COST = 0.
               ANNUAL_CL_FIXED_COST_ESC = 0
               MAINT_DAYS = 0.
               DISPATCH_MULT = 1.
               EXCESS_ENERGY_SALES = 0.
               AI_TAX_LIFE = 99.
               AI_ADR_TAX_LIFE = 99.
               ASSET_CLASS_NUM = 0
               ASSET_CLASS_VECTOR = 0
               INTRA_COMPANY_CLASS_ID = -1
               INTRA_COMPANY_TRANSACTION = 'N'
               MINIMUM_CAPACITY_FACTOR = 0.
               MAXIMUM_CAPACITY_FACTOR = 8800.
               TRANSACTION_GROUP_ID = 1
               DAY_TYPE_ID = 0
               UNIT_ACTIVE = 'T'
               REPORT_THIS_UNIT = 'T'
               BASECASE_PLANT_ID = 'BLANK ' ! CHAR*6
               BASECASE_UNIT_ID = 'BLANK ' ! CHAR*6
               BASECASE_MARKET_AREA_ID = 'BLANK ' ! CHAR*6
               BASECASE_TRANS_AREA_ID = 'BLANK ' ! CHAR*6
               BASECASE_PLANT_NERC_SUB_ID = 'BLANK ' ! CHAR*6
               BASECASE_PLANT_OWNER_ID = 'BLANK ' ! CHAR*6
               UTILITY_OWNED = 'U'
               MONTHLY_FUEL_INDEX = 0
               START_UP_COSTS = 0.
               START_UP_LOGIC = 'F'
               CONTRIBUTES_TO_SPIN = 'F'
               RAMP_RATE = 999999.
               RAMP_DOWN_RATE = -999999.
               MIN_DOWN_TIME = 0.0
               MIN_UP_TIME = 0.0
               P_FUEL_DELIVERY = 0.0
               P_FUEL_DELIVERY_2 = 0.0
               P_FUEL_DELIVERY_3 = 0.0
               S_FUEL_DELIVERY = 0.0
               S_FUEL_DELIVERY_2 = 0.0
               S_FUEL_DELIVERY_3 = 0.0
               HESI_UNIT_ID_NUM = 0
               H2_UNIT_ID_NUM = 0
               FOR_FREQUENCY = 0.
               FOR_DURATION = 0.
               WINTER_TOTAL_CAPACITY = 0.
               CO2_CONTROL_PERCENT = 0.
               HG_CONTROL_PERCENT = 0.
               OTHER3_CONTROL_PERCENT = 0.
               NOX_CONTROL_PERCENT = 0.
               SOX_CONTROL_PERCENT = 0.
               NOX_CONTROL_DATE = 9001
               SOX_CONTROL_DATE = 9001
               CO2_CONTROL_DATE = 9001
               HG_CONTROL_DATE = 9001
               OTHER3_CONTROL_DATE = 9001
               APPLY_NOX_SEASON_DATE = 'F'
               NOX_SEASON_DATE = 0150
!
               EMERGENCY_CAPACITY = 0.
               EMERGENCY_HEATRATE = 0.
               MARKET_RESOURCE = 'F'
!
               PRIMARY_MOVER_STR = 'BLANK'
               COUNTY = 'BLANK'
               NEWGEN_UNIT_STATUS = 'BLANK'
               STATE_PROVINCE = '#N/A'
!
               NOX_VOM = 0.
               NOX_FOM = 0.
               SOX_VOM = 0.
               SOX_FOM = 0.
               CO2_VOM = 0.
               CO2_FOM = 0.
               HG_VOM = 0.
               HG_FOM = 0.
               OTHER3_VOM = 0.
               OTHER3_FOM = 0.
               LATITUDE = 0.
               LONGITUDE = 0.
               MW_INSIDE_FENCE = 0.
!
               USE_POLY_HEAT_RATES = 'F'
               WVPA_RATE_TRACKER = 'N'
               WVPA_RES_TRACKER = 'N'
               WVPA_FUEL_TRACKER = 'N'
               WVPA_MEM_TRACKER = 'M'
               MONTE_OR_FREQ = 'G'
               LINKED_BETTERMENT_OPTION = 'F'
! 11/21/03. SET BACK TO TRUE PER 'ALLOW DECOMMIT LOGIC PER JULY 29TH.DOC'
               ALLOW_DECOMMIT = 'T'
! 11/20/03.
! TO ALLOW THE GLOBAL SWITCH TO DOMINATE
!               ALLOW_DECOMMIT = 'F'
!
               MONTHLY_MUST_RUN_VECTOR = 0
               MONTHLY_DECOMMIT_VECTOR = 0
               TRANS_BUS_ID = 0
               EMISSION_MARKET_LINK = -9999
               FIRST_RETIREMENT_YEAR = 1901
               RPS_PROGRAM_NUMBER = 0
!
               MIN_SPIN_CAP = 0.
               MAX_SPIN_CAP = 9999.
!
               MARKET_FLOOR = 0.
               MARKET_CEILING = 0.
               START_UP_COSTS_ESCALATION = 0.
!
               INTER_BLOCKS(1) = -99.
               INTER_BLOCKS(2) = -99.
               INTER_BLOCKS(3) = -99.
               NAME_PLATE_CAPACITY = -99.
               FIRST_YEAR_DECOMM_AVAIALABLE = 2100.
               DECOMMISSIONING_BASE_YR_COST = 0.
               DECOMMISSIONING_COST_ESCALATION = 0.
               ANNUAL_ENERGY_PLANNING_FACTOR = 0.
               AGGREGATE_THIS_UNIT = "F"
!
               FuelRatio = 0.
               BlendableFuelsPtr = 0.
               FuelTransportationCost = 0.
               BlendedEnthalpyUp = 0.
               BlendedEnthalpyLo = 0.
               BlendedSO2Up = 0.
               BettermentProjectID = 0.
               DECOM_CONTINUING_COST = 0.
               DECOM_CONTINUING_COST_ESCALATION = 0.
               EnrgPatternPointer = 0.
               EMISSION_DATA_UNITS = 'l'
               EmissRedRate = 0.
               EmissMaxRate = 0.
               MaxEnergyLimit= 0.
               TECH_TYPE = " "
               FUEL_BLENDING_IS = 'Primary'
               FUELMX = 1. ! 070806.
               CAPACITY_MARKET_TYPE = 'NONE'
               CAPACITY_MARKET_COIN_ADJ_FACT = 1.0
               PRIMARY_FUEL_CATEGORY = ' '
               SECONDARY_FUEL_CATEGORY = ' '
               EMISSIONS_FUEL_CATEGORY = ' '
               RPS_CONTRIBUTION_PERCENT = 0.0
               RETIREMENT_CANDIDATE = 'F'
               RETROFIT_CANDIDATE = 'F'
!
               THERMAL_GUID = 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'
               THERMAL_PARENT_ID = 123456789
               THERMAL_AGGREGATED_UNIT = 'F'
C
               DO
c                  RESOURCE_ID = IREC + 1
                  READ(10,1000,IOSTAT=IOS) RECLN
                  IF(IOS /=0) EXIT
                  IF(RECLN(1:1) == '7') EXIT
                  RECLN=trim(RECLN)//
     +            ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,'//
     +            ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,'
C
C VARIABLES THAT CAN NOT PROIGATE LEFT TO RIGHT
C
                  SPECIAL_UNIT_ID = " "
                  CO2_RETRO_CAP_MULT = 1
                  CO2_RETRO_HEAT_MULT = 1
                  FIRST_RETIREMENT_YEAR = 1901
c      CALL MG_LOCATE_WRITE(20,0,trim(RECLN),ALL_VERSIONS,0)
C
                  READ(RECLN,*)DELETE,UNIT_NAME,CL_LOAD_TYPE,
     +               EXPENSE_ASSIGNMENT,TEMP_EXPENSE_COLLECTION,GENGRP,
     +               FRAOWN,
     +               ONLIMO,ONLIYR,OFLIMO,OFLIYR,    ! 10
     +               FUELMX,PRFCST,PRESCR,
     +               SEFCST,SDESCR,FUELADJ,EFOR,
     +               MAINRT,VARCST,VRESCR,  ! 31
     +               FIXED_COST,FIXED_COST_ESCALATOR,
     +               DISPADJ,HRFACT,MW,PLANNING_FACTOR,COEFF,DESC,  !42
     +               P_SO2,P_NOX_BK1,P_CO2,POOL_FRAC_OWN,
     +               P_OTHER2,P_OTHER3,PHASE_I_STR,DISPADJ2, !50
     +               RESOURCE_ID,P_FUEL_SUPPLY_ID,P_NOX_BK2,
     +               SEC_EMISS_PTR,EMISS_FUEL_COST,EMISS_FUEL_ESCAL,
     +               EMISS_FUEL_EMISS_PTR,EMISS_BLENDING_RATE,
     +               PRIM_FUEL_EMISS_PTR,
     +               PRIM_FUEL_TYPE,                          !  60
     +               FUEL_TYPES,TIE_GROUP,
     +               MONTHLY_CAPACITY_POINTER,
     +               AI_CAPACITY_RATE,AI_CAPACITY_ESCALATOR,
     +               AI_ENERGY_RATE,AI_ENERGY_ESCALATOR,
     +               AI_REMAINING_LIFE,
     +               ANNUAL_CL_FIXED_COST,                     ! 70
     +               ANNUAL_CL_FIXED_COST_ESC,
     +               MAINT_DAYS,DISPATCH_MULT,
     +               EXCESS_ENERGY_SALES,
     +               AI_TAX_LIFE,
     +               AI_ADR_TAX_LIFE,
     +               ASSET_CLASS_NUM,
     +               ASSET_CLASS_VECTOR,
     +               INTRA_COMPANY_CLASS_ID,
     +               INTRA_COMPANY_TRANSACTION,               ! 80
     +               SPECIAL_UNIT_ID,
     +               MINIMUM_CAPACITY_FACTOR,
     +               MAXIMUM_CAPACITY_FACTOR,
     +               TRANSACTION_GROUP_ID,
     +               DAY_TYPE_ID,
     +               UNIT_ACTIVE,
     +               BASECASE_PLANT_ID,
     +               BASECASE_UNIT_ID,
     +               BASECASE_MARKET_AREA_ID,
     +               BASECASE_TRANS_AREA_ID,                  ! 90
     +               BASECASE_PLANT_NERC_SUB_ID,
     +               BASECASE_PLANT_OWNER_ID,
     +               UTILITY_OWNED,
     +               MONTHLY_FUEL_INDEX,
     +               START_UP_COSTS,
     +               START_UP_LOGIC,
     +               RAMP_RATE,
     +               MIN_DOWN_TIME,
     +               REPORT_THIS_UNIT,
     +               P_FUEL_DELIVERY,   ! 100
     +               P_FUEL_DELIVERY_2,
     +               P_FUEL_DELIVERY_3,
     +               MIN_UP_TIME,
     +               HESI_UNIT_ID_NUM,  ! 104
     +               FOR_FREQUENCY, ! 105
     +               FOR_DURATION, ! 106
     +               WINTER_TOTAL_CAPACITY,
     +               CONTRIBUTES_TO_SPIN,
     +               H2_UNIT_ID_NUM,      ! 109
     +               POWERDAT_PLANT_ID,   ! 110
     +               APPLY_NOX_SEASON_DATE,  ! 111
     +               NOX_SEASON_DATE,    ! 112
     +               RAMP_DOWN_RATE,      ! 113
     +               NOX_CONTROL_PERCENT,
     +               NOX_CONTROL_DATE,
     +               EMERGENCY_CAPACITY,
     +               EMERGENCY_HEATRATE,
     +               MARKET_RESOURCE,
     +               PRIMARY_MOVER_STR,
     +               COUNTY,              ! 120
     +               STATE_PROVINCE,
     +               NOX_VOM,
     +               NOX_FOM,
     +               S_FUEL_DELIVERY,
     +               S_FUEL_DELIVERY_2,   ! 125
     +               S_FUEL_DELIVERY_3,
     +               CONSTANT_POLY,
     +               FIRST_POLY,
     +               SECOND_POLY,
     +               THIRD_POLY,          ! 130
     +               USE_POLY_HEAT_RATES,
     +               NEWGEN_UNIT_STATUS,
     +               MONTHLY_MUST_RUN_VECTOR,
     +               EMISSION_MARKET_LINK,
     +               WVPA_RATE_TRACKER,    ! 135
     +               ALLOW_DECOMMIT,
     +               MIN_SPIN_CAP,
     +               MAX_SPIN_CAP,
     +               WVPA_RES_TRACKER,
     +               WVPA_FUEL_TRACKER,  ! 140
     +               MONTE_OR_FREQ,
     +               WVPA_MEM_TRACKER,
     +               MONTHLY_DECOMMIT_VECTOR,
     +               TRANS_BUS_ID,
     +               SOX_CONTROL_PERCENT,
     +               SOX_CONTROL_DATE,
     +               SOX_VOM,
     +               SOX_FOM,
     +               LATITUDE,
     +               LONGITUDE,          ! 150
     +               MW_INSIDE_FENCE,
     +               INTER_BLOCKS,     ! 152-154
c SP CapEx Variables added 11/17/05 MSG
     +               FIRST_YEAR_DECOMM_AVAIALABLE,     ! 155
     +               DECOMMISSIONING_BASE_YR_COST,            ! 156
     +               DECOMMISSIONING_COST_ESCALATION,
     +               ANNUAL_ENERGY_PLANNING_FACTOR,
     +               AGGREGATE_THIS_UNIT,              ! 159
     +               NAME_PLATE_CAPACITY,
     +               FUEL_BLENDING_IS,
     +               FuelRatio,         ! 162-166
     +               BlendableFuelsPtr, ! 167-170
     +               FuelTransportationCost, ! 171-174
     +               BlendedEnthalpyUp, ! 175
     +               BlendedEnthalpyLo,
     +               BlendedSO2Up,                  ! 177
     +               BettermentProjectID,
     +               DECOM_CONTINUING_COST,
     +               DECOM_CONTINUING_COST_ESCALATION,
     +               EnrgPatternPointer, ! 181
     +               EMISSION_DATA_UNITS,
     +               EmissRedRate,       ! 183-187
     +               EmissMaxRate,
     +               MaxEnergyLimit,
     +               TECH_TYPE,           ! 196
     +               LINKED_BETTERMENT_OPTION, ! 197
     +               CO2_CONTROL_PERCENT,
     +               HG_CONTROL_PERCENT,
     +               OTHER3_CONTROL_PERCENT,
     +               CO2_CONTROL_DATE,
     +               HG_CONTROL_DATE,
     +               OTHER3_CONTROL_DATE,
     +               CO2_VOM, ! 204
     +               CO2_FOM,
     +               HG_VOM,
     +               HG_FOM,
     +               OTHER3_VOM,
     +               OTHER3_FOM, ! 209
     +               MARKET_FLOOR,
     +               MARKET_CEILING,  ! 211
     +               START_UP_COSTS_ESCALATION,  ! 212
     +               CAPACITY_MARKET_TYPE,
     +               CAPACITY_MARKET_MONTH,
     +               CAPACITY_MARKET_POINTER,
     +               CAPACITY_MARKET_COST_ASSIGN,
     +               CAPACITY_MARKET_EXP_COLLECT,
     +               CAPACITY_MARKET_COIN_ADJ_FACT,
     +               PRIMARY_FUEL_CATEGORY,
     +               SECONDARY_FUEL_CATEGORY, ! 220
     +               EMISSIONS_FUEL_CATEGORY,
     +               RPS_CONTRIBUTION_PERCENT,
     +               RETIREMENT_CANDIDATE,
     +               RETROFIT_CANDIDATE,
     +               RETROFIT_PROJECT_ID,
     +               CO2_BASIN_NAME,
     +               CO2_PIPELINE_DISTANCE,
     +               STATE_PROV_NAME, ! 228
     +               CO2_RETRO_HEAT_MULT,
     +               CO2_RETRO_CAP_MULT,
     +               THERMAL_GUID,
     +               THERMAL_PARENT_ID, ! 232
     +               THERMAL_AGGREGATED_UNIT,
     +               FIRST_RETIREMENT_YEAR,
     +               UNIT_TYPE,
     +               UNIT_TYPE_CATEGORY,
     +               RPS_PROGRAM_NUMBER
C
                  IF(IOS /= 0) THEN
                     CL_VARIABLES = "BAD"
                     READ(RECLN,*,IOSTAT=IOS)DELETE,CL_VARIABLES
                     DO I = 1, 100
                        IF(INDEX(CL_VARIABLES(I),"BAD") /= 0) THEN
                           PAUSE
                           EXIT
                        ENDIF
                     ENDDO
                  ENDIF
                  IF(SPCapExOption) NEWGEN_UNIT_STATUS = 'SPCapEx'
                  IF(RAMP_DOWN_RATE == -999999.) THEN
                     RAMP_DOWN_RATE = RAMP_RATE
                  ENDIF
                  IF(DISPADJ2 == -99999.) THEN
                     DISP_ADJ2_OUT = DISPADJ
                  ELSE
                     DISP_ADJ2_OUT = DISPADJ2
                  ENDIF
!
!                  IF(EMISSION_MARKET_LINK == -9999) THEN
!                     EMISSION_MARKET_LINK = ASSET_CLASS_NUM
!                  ENDIF
                  IF(P_NOX_BK2 == -99999.) THEN
                     P_NOX_BK2_OUT = P_NOX_BK1
                  ELSE
                     P_NOX_BK2_OUT = P_NOX_BK2
                  ENDIF
                  IF(INDEX(TEMP_EXPENSE_COLLECTION,'BTL') /= 0) THEN
                     EXPENSE_COLLECTION = 'X'
                  ELSE
                     EXPENSE_COLLECTION = TEMP_EXPENSE_COLLECTION(1:1)
                  ENDIF
                  IREC = IREC + 1
                  IF(CL_LOAD_TYPE(1:1) == NUCLEAR .AND. DELETE < 8 .AND.
     +                (UNIT_ACTIVE == 'T' .OR. UNIT_ACTIVE == 't')) THEN
                     NUC_UNITS_IN_FILE(FILE_ID) =
     +                                    NUC_UNITS_IN_FILE(FILE_ID) + 1
                     NUC_RECORD_POSITION(NUC_UNITS_IN_FILE(FILE_ID),
     +                                                   FILE_ID) = IREC
                     NUCLEAR_UNITS_ACTIVE = NUCLEAR_UNITS_ACTIVE + 1
                  ENDIF
                  WRITE(11,REC=IREC) DELETE,UNIT_NAME,CL_LOAD_TYPE,
     +               EXPENSE_ASSIGNMENT,EXPENSE_COLLECTION,
     +               GENGRP,FRAOWN,
     +               ONLIMO,ONLIYR,OFLIMO,OFLIYR,FUELMX,PRFCST,PRESCR,
     +               SEFCST,SDESCR,FUELADJ,EFOR,MAINRT,VARCST,VRESCR,
     +               FIXED_COST,FIXED_COST_ESCALATOR,
     +               DISPADJ,HRFACT,MW,PLANNING_FACTOR,COEFF,
     +               AI_CAPACITY_RATE,AI_CAPACITY_ESCALATOR,
     +               AI_ENERGY_RATE,AI_ENERGY_ESCALATOR,
     +               AI_REMAINING_LIFE,
     +               P_SO2,P_NOX_BK1,P_CO2,POOL_FRAC_OWN,
     +               P_OTHER2,P_OTHER3,PHASE_I_STR,DISP_ADJ2_OUT,
     +               RESOURCE_ID,P_FUEL_SUPPLY_ID,P_NOX_BK2_OUT,
     +               SEC_EMISS_PTR,EMISS_FUEL_COST,EMISS_FUEL_ESCAL,
     +               EMISS_FUEL_EMISS_PTR,EMISS_BLENDING_RATE,
     +               PRIM_FUEL_EMISS_PTR,
     +               PRIM_FUEL_TYPE,FUEL_TYPES,TIE_GROUP,
     +               MONTHLY_CAPACITY_POINTER,
     +               ANNUAL_CL_FIXED_COST,
     +               ANNUAL_CL_FIXED_COST_ESC,
     +               MAINT_DAYS,DISPATCH_MULT,
     +               EXCESS_ENERGY_SALES,
     +               AI_TAX_LIFE,
     +               AI_ADR_TAX_LIFE,
     +               ASSET_CLASS_NUM,
     +               ASSET_CLASS_VECTOR,
     +               INTRA_COMPANY_CLASS_ID,
     +               INTRA_COMPANY_TRANSACTION,
     +               SPECIAL_UNIT_ID,
     +               MINIMUM_CAPACITY_FACTOR,
     +               MAXIMUM_CAPACITY_FACTOR,
     +               TRANSACTION_GROUP_ID,
     +               DAY_TYPE_ID,
     +               UNIT_ACTIVE,
     +               BASECASE_PLANT_ID,
     +               BASECASE_UNIT_ID,
     +               BASECASE_MARKET_AREA_ID,
     +               BASECASE_TRANS_AREA_ID,
     +               BASECASE_PLANT_NERC_SUB_ID,
     +               BASECASE_PLANT_OWNER_ID,
     +               UTILITY_OWNED,
     +               MONTHLY_FUEL_INDEX,
     +               START_UP_COSTS,
     +               START_UP_LOGIC,
     +               RAMP_RATE,
     +               MIN_DOWN_TIME,
     +               REPORT_THIS_UNIT,
     +               P_FUEL_DELIVERY,
     +               P_FUEL_DELIVERY_2,
     +               P_FUEL_DELIVERY_3,
     +               MIN_UP_TIME,
     +               HESI_UNIT_ID_NUM,
     +               FOR_FREQUENCY,
     +               FOR_DURATION,
     +               WINTER_TOTAL_CAPACITY,
     +               CONTRIBUTES_TO_SPIN,
     +               H2_UNIT_ID_NUM,
     +               POWERDAT_PLANT_ID,
     +               APPLY_NOX_SEASON_DATE,
     +               NOX_SEASON_DATE,
     +               RAMP_DOWN_RATE,
     +               NOX_CONTROL_PERCENT,
     +               NOX_CONTROL_DATE,
     +               EMERGENCY_CAPACITY,
     +               EMERGENCY_HEATRATE,
     +               MARKET_RESOURCE,
     +               PRIMARY_MOVER_STR,
     +               COUNTY,
     +               STATE_PROVINCE,
     +               NOX_VOM,
     +               NOX_FOM,
     +               S_FUEL_DELIVERY,
     +               S_FUEL_DELIVERY_2,
     +               S_FUEL_DELIVERY_3,
     +               CONSTANT_POLY,
     +               FIRST_POLY,
     +               SECOND_POLY,
     +               THIRD_POLY,
     +               USE_POLY_HEAT_RATES,
     +               NEWGEN_UNIT_STATUS,
     +               MONTHLY_MUST_RUN_VECTOR,
     +               EMISSION_MARKET_LINK,
     +               WVPA_RATE_TRACKER,
     +               ALLOW_DECOMMIT,
     +               MIN_SPIN_CAP,
     +               MAX_SPIN_CAP,
     +               WVPA_RES_TRACKER,
     +               WVPA_FUEL_TRACKER,
     +               MONTE_OR_FREQ,
     +               WVPA_MEM_TRACKER,
     +               MONTHLY_DECOMMIT_VECTOR,
     +               TRANS_BUS_ID,
     +               SOX_CONTROL_PERCENT,
     +               SOX_CONTROL_DATE,
     +               SOX_VOM,
     +               SOX_FOM,
     +               LATITUDE,
     +               LONGITUDE,
     +               MW_INSIDE_FENCE,
     +               INTER_BLOCKS,     ! 152-154
c SP CapEx Variables added 11/17/05 MSG
     +               FIRST_YEAR_DECOMM_AVAIALABLE,
     +               DECOMMISSIONING_BASE_YR_COST,            ! 156
     +               DECOMMISSIONING_COST_ESCALATION,
     +               ANNUAL_ENERGY_PLANNING_FACTOR,
     +               AGGREGATE_THIS_UNIT,               ! 159
     +               NAME_PLATE_CAPACITY,
     +               FUEL_BLENDING_IS,
     +               FuelRatio,
     +               BlendableFuelsPtr, ! 167
     +               FuelTransportationCost,
     +               BlendedEnthalpyUp,
     +               BlendedEnthalpyLo,
     +               BlendedSO2Up,                  ! 178
     +               BettermentProjectID,
     +               DECOM_CONTINUING_COST,
     +               DECOM_CONTINUING_COST_ESCALATION,
     +               EnrgPatternPointer, ! 181
     +               EMISSION_DATA_UNITS, ! 182
     +               EmissRedRate, ! 183-187
     +               EmissMaxRate,
     +               MaxEnergyLimit,
     +               TECH_TYPE,
     +               LINKED_BETTERMENT_OPTION,
     +               CO2_CONTROL_PERCENT,
     +               HG_CONTROL_PERCENT,
     +               OTHER3_CONTROL_PERCENT,
     +               CO2_CONTROL_DATE,
     +               HG_CONTROL_DATE,
     +               OTHER3_CONTROL_DATE,
     +               CO2_VOM,
     +               CO2_FOM,
     +               HG_VOM,
     +               HG_FOM,
     +               OTHER3_VOM,
     +               OTHER3_FOM, ! 209
     +               MARKET_FLOOR,
     +               MARKET_CEILING,
     +               START_UP_COSTS_ESCALATION,  ! 212
     +               CAPACITY_MARKET_TYPE,
     +               CAPACITY_MARKET_MONTH,
     +               CAPACITY_MARKET_POINTER,
     +               CAPACITY_MARKET_COST_ASSIGN,
     +               CAPACITY_MARKET_EXP_COLLECT,
     +               CAPACITY_MARKET_COIN_ADJ_FACT,
     +               PRIMARY_FUEL_CATEGORY,
     +               SECONDARY_FUEL_CATEGORY,
     +               EMISSIONS_FUEL_CATEGORY,
     +               RPS_CONTRIBUTION_PERCENT,
     +               RETIREMENT_CANDIDATE,
     +               RETROFIT_CANDIDATE,
     +               RETROFIT_PROJECT_ID,
     +               CO2_BASIN_NAME,
     +               CO2_PIPELINE_DISTANCE,
     +               STATE_PROV_NAME, ! 228
     +               CO2_RETRO_HEAT_MULT,
     +               CO2_RETRO_CAP_MULT,
     +               THERMAL_GUID,
     +               THERMAL_PARENT_ID, ! 232
     +               THERMAL_AGGREGATED_UNIT,
     +               FIRST_RETIREMENT_YEAR,
     +               UNIT_TYPE,
     +               UNIT_TYPE_CATEGORY,
     +               RPS_PROGRAM_NUMBER
               ENDDO
               IF(IOS /= 0) EXIT
            ENDDO
            ACTIVE_CL_RECORDS(FILE_ID) = IREC
            CLOSE(10)
            CLOSE(11)
         ELSE IF(INDEX(BASE_FILE_NAME,'NONE') == 0) THEN
            CALL STOP_NOFILE(FILE_TYPE,FILE_NAME)
         ENDIF
      ENDDO ! FILE_ID FIRST PASS
      IF(NUCLEAR_UNITS_ACTIVE > 0) THEN
         CALL SETUP_GENERATING_INFORMATION(NUCLEAR_UNITS_ACTIVE)
         DO FILE_ID = 0, MAX_CL_FILES-1
            IF(NUC_UNITS_IN_FILE(FILE_ID) > 0) THEN
               BINARY_FILE_NAME = CL_FILE_BINARY_NAMES(FILE_ID)
               OPEN(11,FILE=trim(OUTPUT_DIRECTORY())//
     +                     "BC"//trim(BINARY_FILE_NAME)//".BIN",
     +                      ACCESS="DIRECT",STATUS="UNKNOWN",RECL=LRECL)
               DO I = 1, NUC_UNITS_IN_FILE(FILE_ID)
                  IREC = NUC_RECORD_POSITION(I,FILE_ID)
                  READ(11,REC=IREC) DELETE,UNIT_NAME,CL_LOAD_TYPE,
     +               EXPENSE_ASSIGNMENT,EXPENSE_COLLECTION,
     +               GENGRP,FRAOWN,ONLIMO,ONLIYR,OFLIMO,OFLIYR,FUELMX,
     +               PRFCST,PRESCR,SEFCST,SDESCR,FUELADJ,EFOR,MAINRT,
     +               VARCST,VRESCR,FIXED_COST,FIXED_COST_ESCALATOR,
     +               DISPADJ,HRFACT,MW,PLANNING_FACTOR,COEFF,
     +               AI_CAPACITY_RATE,AI_CAPACITY_ESCALATOR,
     +               AI_ENERGY_RATE,AI_ENERGY_ESCALATOR,
     +               AI_REMAINING_LIFE,
     +               P_SO2,P_NOX_BK1,P_CO2,POOL_FRAC_OWN,
     +               P_OTHER2,P_OTHER3,PHASE_I_STR,DISP_ADJ2_OUT,
     +               RESOURCE_ID,P_FUEL_SUPPLY_ID,P_NOX_BK2,
     +               SEC_EMISS_PTR,EMISS_FUEL_COST,EMISS_FUEL_ESCAL,
     +               EMISS_FUEL_EMISS_PTR,EMISS_BLENDING_RATE,
     +               PRIM_FUEL_EMISS_PTR,
     +               PRIM_FUEL_TYPE,FUEL_TYPES,TIE_GROUP,
     +               MONTHLY_CAPACITY_POINTER,
     +               ANNUAL_CL_FIXED_COST,
     +               ANNUAL_CL_FIXED_COST_ESC,
     +               MAINT_DAYS,DISPATCH_MULT,
     +               EXCESS_ENERGY_SALES,
     +               AI_TAX_LIFE,
     +               AI_ADR_TAX_LIFE,
     +               ASSET_CLASS_NUM,
     +               ASSET_CLASS_VECTOR,
     +               INTRA_COMPANY_CLASS_ID,
     +               INTRA_COMPANY_TRANSACTION,
     +               SPECIAL_UNIT_ID,
     +               MINIMUM_CAPACITY_FACTOR,
     +               MAXIMUM_CAPACITY_FACTOR,
     +               TRANSACTION_GROUP_ID,
     +               DAY_TYPE_ID,
     +               UNIT_ACTIVE,
     +               BASECASE_PLANT_ID,
     +               BASECASE_UNIT_ID,
     +               BASECASE_MARKET_AREA_ID,
     +               BASECASE_TRANS_AREA_ID,
     +               BASECASE_PLANT_NERC_SUB_ID,
     +               BASECASE_PLANT_OWNER_ID,
     +               UTILITY_OWNED,
     +               MONTHLY_FUEL_INDEX,
     +               START_UP_COSTS,
     +               START_UP_LOGIC,
     +               RAMP_RATE,
     +               MIN_DOWN_TIME,
     +               REPORT_THIS_UNIT,
     +               P_FUEL_DELIVERY,
     +               P_FUEL_DELIVERY_2,
     +               P_FUEL_DELIVERY_3,
     +               MIN_UP_TIME,
     +               HESI_UNIT_ID_NUM,
     +               FOR_FREQUENCY,
     +               FOR_DURATION,
     +               WINTER_TOTAL_CAPACITY,
     +               CONTRIBUTES_TO_SPIN,
     +               H2_UNIT_ID_NUM,
     +               POWERDAT_PLANT_ID,
     +               APPLY_NOX_SEASON_DATE,
     +               NOX_SEASON_DATE,
     +               RAMP_DOWN_RATE,
     +               NOX_CONTROL_PERCENT,
     +               NOX_CONTROL_DATE,
     +               EMERGENCY_CAPACITY,
     +               EMERGENCY_HEATRATE,
     +               MARKET_RESOURCE,
     +               PRIMARY_MOVER_STR,
     +               COUNTY,
     +               STATE_PROVINCE,
     +               NOX_VOM,
     +               NOX_FOM,
     +               S_FUEL_DELIVERY,
     +               S_FUEL_DELIVERY_2,
     +               S_FUEL_DELIVERY_3,
     +               CONSTANT_POLY,
     +               FIRST_POLY,
     +               SECOND_POLY,
     +               THIRD_POLY,
     +               USE_POLY_HEAT_RATES,
     +               NEWGEN_UNIT_STATUS,
     +               MONTHLY_MUST_RUN_VECTOR,
     +               EMISSION_MARKET_LINK,
     +               WVPA_RATE_TRACKER,
     +               ALLOW_DECOMMIT,
     +               MIN_SPIN_CAP,
     +               MAX_SPIN_CAP,
     +               WVPA_RES_TRACKER,
     +               WVPA_FUEL_TRACKER,
     +               MONTE_OR_FREQ,
     +               WVPA_MEM_TRACKER,
     +               MONTHLY_DECOMMIT_VECTOR,
     +               TRANS_BUS_ID,
     +               SOX_CONTROL_PERCENT,
     +               SOX_CONTROL_DATE,
     +               SOX_VOM,
     +               SOX_FOM,
     +               LATITUDE,
     +               LONGITUDE,
     +               MW_INSIDE_FENCE,
     +               INTER_BLOCKS,     ! 152-153
c SP CapEx Variables added 11/17/05 MSG
     +               FIRST_YEAR_DECOMM_AVAIALABLE,
     +               DECOMMISSIONING_BASE_YR_COST,            ! 155
     +               DECOMMISSIONING_COST_ESCALATION,
     +               ANNUAL_ENERGY_PLANNING_FACTOR,
     +               AGGREGATE_THIS_UNIT,               ! 158
     +               NAME_PLATE_CAPACITY,
     +               FUEL_BLENDING_IS,
     +               FuelRatio,
     +               BlendableFuelsPtr, ! 167
     +               FuelTransportationCost,
     +               BlendedEnthalpyUp,
     +               BlendedEnthalpyLo,
     +               BlendedSO2Up,                  ! 177
     +               BettermentProjectID,
     +               DECOM_CONTINUING_COST,
     +               DECOM_CONTINUING_COST_ESCALATION,
     +               EnrgPatternPointer, ! 181
     +               EMISSION_DATA_UNITS,
     +               EmissRedRate,
     +               EmissMaxRate,
     +               MaxEnergyLimit,
     +               TECH_TYPE,
     +               LINKED_BETTERMENT_OPTION,
     +               CO2_CONTROL_PERCENT,
     +               HG_CONTROL_PERCENT,
     +               OTHER3_CONTROL_PERCENT,
     +               CO2_CONTROL_DATE,
     +               HG_CONTROL_DATE,
     +               OTHER3_CONTROL_DATE,
     +               CO2_VOM,
     +               CO2_FOM,
     +               HG_VOM,
     +               HG_FOM,
     +               OTHER3_VOM,
     +               OTHER3_FOM, ! 209
     +               MARKET_FLOOR,
     +               MARKET_CEILING,
     +               START_UP_COSTS_ESCALATION,  ! 212
     +               CAPACITY_MARKET_TYPE,
     +               CAPACITY_MARKET_MONTH,
     +               CAPACITY_MARKET_POINTER,
     +               CAPACITY_MARKET_COST_ASSIGN,
     +               CAPACITY_MARKET_EXP_COLLECT,
     +               CAPACITY_MARKET_COIN_ADJ_FACT,
     +               PRIMARY_FUEL_CATEGORY,
     +               SECONDARY_FUEL_CATEGORY,
     +               EMISSIONS_FUEL_CATEGORY,
     +               RPS_CONTRIBUTION_PERCENT,
     +               RETIREMENT_CANDIDATE,
     +               RETROFIT_CANDIDATE,
     +               RETROFIT_PROJECT_ID,
     +               CO2_BASIN_NAME,
     +               CO2_PIPELINE_DISTANCE,
     +               STATE_PROV_NAME, ! 228
     +               CO2_RETRO_HEAT_MULT,
     +               CO2_RETRO_CAP_MULT,
     +               THERMAL_GUID,
     +               THERMAL_PARENT_ID, ! 232
     +               THERMAL_AGGREGATED_UNIT,
     +               FIRST_RETIREMENT_YEAR,
     +               UNIT_TYPE,
     +               UNIT_TYPE_CATEGORY,
     +               RPS_PROGRAM_NUMBER
C
                  ONLINE = 100*(ONLIYR - 1900) + ONLIMO
                  OFLINE = 100*(OFLIYR - 1900) + OFLIMO
                  CALL CAL_GENERATING_INFORMATION(RESOURCE_ID,
     +                                         FRAOWN,
     +                                         MW(2),
     +                                         MONTHLY_CAPACITY_POINTER,
     +                                         EFOR,
     +                                         MAINRT,
     +                                         ONLINE,
     +                                         OFLINE,
     +                                         UNIT_NAME,
     +                                         PRIM_FUEL_TYPE)
               ENDDO
               CLOSE(11)
            ENDIF
         ENDDO ! FILE_ID FOR NUC UNITS
      ENDIF ! NUC UNITS IN FILES
      RETURN

C***********************************************************************
C
C          ROUTINE TO CREATE OVERLAY FILES
C          COPYRIGHT (C) 1984-88  M.S. GERBER & ASSOCIATES, INC.
C          COPYRIGHT (C) 1991-92  M.S. GERBER & ASSOCIATES, INC.
C
C***********************************************************************
C
C OVERLAY THE (FOSSIL-FUELED) CAPACITY-LIMITED-UNITS FILE
C***************************************************************
      ENTRY CL_MAKEOVL(OVERLAY_FAMILY_NAME,FILE_NUMBER)
C***************************************************************
      IF(.NOT. ACTIVE_BASE_CL_FILES(FILE_NUMBER)) RETURN
      FILE_CODE = CL_FILE_CODES(FILE_NUMBER)
      BINARY_FILE_NAME = CL_FILE_BINARY_NAMES(FILE_NUMBER)
      IF(LAHEY_LF95()) THEN
         SCREEN_OUTPUT = trim(FILE_TYPE)//'-'//OVERLAY_FAMILY_NAME
         CALL MG_LOCATE_WRITE(16,30,SCREEN_OUTPUT,ALL_VERSIONS,0)
      ELSE
         CALL MG_CLEAR_LINE_WRITE(17,9,36,FILE_TYPE,ALL_VERSIONS,0)
         CALL LOCATE(10,51)
      ENDIF
      FILE_NAME = trim(OUTPUT_DIRECTORY())//FILE_CODE//"O"//
     +                               trim(OVERLAY_FAMILY_NAME)//".DAT"
      OPEN(10,FILE=FILE_NAME)
      READ(10,*) DELETE
      INUNIT = 12
      NUCLEAR_UNITS_ACTIVE = 0
      IF(FOSSILOL(FILE_NUMBER) == 'BC') THEN
         OPEN(11,FILE=trim(OUTPUT_DIRECTORY())//"BC"//
     +                      trim(BINARY_FILE_NAME)//".BIN",
     +                      ACCESS="DIRECT",STATUS="UNKNOWN",RECL=LRECL)
         INUNIT = 11
      ENDIF
      OPEN(12,FILE=trim(OUTPUT_DIRECTORY())//"OL"//
     +                      trim(BINARY_FILE_NAME)//".BIN",
     +                      ACCESS="DIRECT",STATUS="UNKNOWN",RECL=LRECL)
      IREC = 0
      DO
         DO
            READ(10,'(A)',IOSTAT=IOS) RECLN
            IF(RECLN(1:1) == '7') EXIT
            IREC = IREC + 1
            READ(INUNIT,REC=IREC,IOSTAT=IOS_BASE) DELETE,UNIT_NAME,
     +         CL_LOAD_TYPE,EXPENSE_ASSIGNMENT,EXPENSE_COLLECTION,
     +         GENGRP,FRAOWN,ONLIMO,ONLIYR,OFLIMO,OFLIYR,FUELMX,PRFCST,
     +         PRESCR,SEFCST,SDESCR,FUELADJ,EFOR,MAINRT,VARCST,VRESCR,
     +         FIXED_COST,FIXED_COST_ESCALATOR,
     +         DISPADJ,HRFACT,MW,PLANNING_FACTOR,COEFF,
     +         AI_CAPACITY_RATE,AI_CAPACITY_ESCALATOR,AI_ENERGY_RATE,
     +         AI_ENERGY_ESCALATOR,AI_REMAINING_LIFE,
     +         P_SO2,P_NOX,P_PARTICULATES,POOL_FRAC_OWN,
     +         P_OTHER2,P_OTHER3,PHASE_I_STR,DISPADJ2,
     +         RESOURCE_ID,P_FUEL_SUPPLY_ID,
     +         P_NOX_BK2,SEC_EMISS_PTR,EMISS_FUEL_COST,EMISS_FUEL_ESCAL,
     +         EMISS_FUEL_EMISS_PTR,EMISS_BLENDING_RATE,
     +         PRIM_FUEL_EMISS_PTR,
     +         PRIM_FUEL_TYPE,FUEL_TYPES,TIE_GROUP,
     +         MONTHLY_CAPACITY_POINTER,
     +         ANNUAL_CL_FIXED_COST,
     +         ANNUAL_CL_FIXED_COST_ESC,
     +         MAINT_DAYS,DISPATCH_MULT,
     +         EXCESS_ENERGY_SALES,
     +         AI_TAX_LIFE,
     +         AI_ADR_TAX_LIFE,
     +         ASSET_CLASS_NUM,
     +         ASSET_CLASS_VECTOR,
     +         INTRA_COMPANY_CLASS_ID,
     +         INTRA_COMPANY_TRANSACTION,
     +         SPECIAL_UNIT_ID,
     +         MINIMUM_CAPACITY_FACTOR,
     +         MAXIMUM_CAPACITY_FACTOR,
     +         TRANSACTION_GROUP_ID,
     +         DAY_TYPE_ID,
     +         UNIT_ACTIVE,
     +         BASECASE_PLANT_ID,
     +         BASECASE_UNIT_ID,
     +         BASECASE_MARKET_AREA_ID,
     +         BASECASE_TRANS_AREA_ID,
     +         BASECASE_PLANT_NERC_SUB_ID,
     +         BASECASE_PLANT_OWNER_ID,
     +         UTILITY_OWNED,
     +         MONTHLY_FUEL_INDEX,
     +         START_UP_COSTS,
     +         START_UP_LOGIC,
     +         RAMP_RATE,
     +         MIN_DOWN_TIME,
     +         REPORT_THIS_UNIT,
     +         P_FUEL_DELIVERY,
     +         P_FUEL_DELIVERY_2,
     +         P_FUEL_DELIVERY_3,
     +         MIN_UP_TIME,
     +         HESI_UNIT_ID_NUM,
     +         FOR_FREQUENCY,
     +         FOR_DURATION,
     +         WINTER_TOTAL_CAPACITY,
     +         CONTRIBUTES_TO_SPIN,
     +         H2_UNIT_ID_NUM,
     +         POWERDAT_PLANT_ID,
     +         APPLY_NOX_SEASON_DATE,
     +         NOX_SEASON_DATE,
     +         RAMP_DOWN_RATE,
     +         NOX_CONTROL_PERCENT,
     +         NOX_CONTROL_DATE,
     +         EMERGENCY_CAPACITY,
     +         EMERGENCY_HEATRATE,
     +         MARKET_RESOURCE,
     +         PRIMARY_MOVER_STR,
     +         COUNTY,
     +         STATE_PROVINCE,
     +         NOX_VOM,
     +         NOX_FOM,
     +         S_FUEL_DELIVERY,
     +         S_FUEL_DELIVERY_2,
     +         S_FUEL_DELIVERY_3,
     +         CONSTANT_POLY,
     +         FIRST_POLY,
     +         SECOND_POLY,
     +         THIRD_POLY,
     +         USE_POLY_HEAT_RATES,
     +         NEWGEN_UNIT_STATUS,
     +         MONTHLY_MUST_RUN_VECTOR,
     +         EMISSION_MARKET_LINK,
     +         WVPA_RATE_TRACKER,
     +         ALLOW_DECOMMIT,
     +         MIN_SPIN_CAP,
     +         MAX_SPIN_CAP,
     +         WVPA_RES_TRACKER,
     +         WVPA_FUEL_TRACKER,
     +         MONTE_OR_FREQ,
     +         WVPA_MEM_TRACKER,
     +         MONTHLY_DECOMMIT_VECTOR,
     +         TRANS_BUS_ID,
     +         SOX_CONTROL_PERCENT,
     +         SOX_CONTROL_DATE,
     +         SOX_VOM,
     +         SOX_FOM,
     +         LATITUDE,
     +         LONGITUDE,
     +         MW_INSIDE_FENCE,
     +         INTER_BLOCKS,     ! 152-153
c SP CapEx Variables added 11/17/05 MSG
     +         FIRST_YEAR_DECOMM_AVAIALABLE,
     +         DECOMMISSIONING_BASE_YR_COST,            ! 155
     +         DECOMMISSIONING_COST_ESCALATION,
     +         ANNUAL_ENERGY_PLANNING_FACTOR,
     +         AGGREGATE_THIS_UNIT,               ! 158
     +         NAME_PLATE_CAPACITY,
     +         FUEL_BLENDING_IS,
     +         FuelRatio,
     +         BlendableFuelsPtr, ! 167
     +         FuelTransportationCost,
     +         BlendedEnthalpyUp,
     +         BlendedEnthalpyLo,
     +         BlendedSO2Up,                  ! 177
     +         BettermentProjectID,
     +         DECOM_CONTINUING_COST,
     +         DECOM_CONTINUING_COST_ESCALATION,
     +         EnrgPatternPointer, ! 181
     +         EMISSION_DATA_UNITS,
     +         EmissRedRate,
     +         EmissMaxRate,
     +         MaxEnergyLimit,
     +         TECH_TYPE,
     +         LINKED_BETTERMENT_OPTION,
     +         CO2_CONTROL_PERCENT,
     +         HG_CONTROL_PERCENT,
     +         OTHER3_CONTROL_PERCENT,
     +         CO2_CONTROL_DATE,
     +         HG_CONTROL_DATE,
     +         OTHER3_CONTROL_DATE,
     +         CO2_VOM,
     +         CO2_FOM,
     +         HG_VOM,
     +         HG_FOM,
     +         OTHER3_VOM,
     +         OTHER3_FOM, ! 209
     +         MARKET_FLOOR,
     +         MARKET_CEILING,
     +         START_UP_COSTS_ESCALATION,  ! 212
     +         CAPACITY_MARKET_TYPE,
     +         CAPACITY_MARKET_MONTH,
     +         CAPACITY_MARKET_POINTER,
     +         CAPACITY_MARKET_COST_ASSIGN,
     +         CAPACITY_MARKET_EXP_COLLECT,
     +         CAPACITY_MARKET_COIN_ADJ_FACT,
     +         PRIMARY_FUEL_CATEGORY,
     +         SECONDARY_FUEL_CATEGORY,
     +         EMISSIONS_FUEL_CATEGORY,
     +         RPS_CONTRIBUTION_PERCENT,
     +         RETIREMENT_CANDIDATE,
     +         RETROFIT_CANDIDATE,
     +         RETROFIT_PROJECT_ID,
     +         CO2_BASIN_NAME,
     +         CO2_PIPELINE_DISTANCE,
     +         STATE_PROV_NAME, ! 228
     +         CO2_RETRO_HEAT_MULT,
     +         CO2_RETRO_CAP_MULT,
     +         THERMAL_GUID,
     +         THERMAL_PARENT_ID, ! 232
     +         THERMAL_AGGREGATED_UNIT,
     +         FIRST_RETIREMENT_YEAR,
     +         UNIT_TYPE,
     +         UNIT_TYPE_CATEGORY,
     +         RPS_PROGRAM_NUMBER
            IF(IOS_BASE /= 0) EXIT
            IF(IOS == 0) THEN
               RECLN = trim(RECLN)//',,,,,,,,,,,,,'//
     +                       ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,'//
     +                       ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,'//
     +                       ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,'
               TEMP_EXPENSE_COLLECTION = EXPENSE_COLLECTION
               READ(RECLN,*,ERR=200) DELETE,UNIT_NAME,CL_LOAD_TYPE,
     +               EXPENSE_ASSIGNMENT,TEMP_EXPENSE_COLLECTION,GENGRP,
     +               FRAOWN,ONLIMO,ONLIYR,OFLIMO,OFLIYR,FUELMX,PRFCST,
     +               PRESCR,SEFCST,SDESCR,FUELADJ,EFOR,MAINRT,VARCST,
     +               VRESCR,FIXED_COST,FIXED_COST_ESCALATOR,
     +               DISPADJ,HRFACT,MW,PLANNING_FACTOR,COEFF,DESC,
     +               P_SO2,P_NOX,P_PARTICULATES,POOL_FRAC_OWN,
     +               P_OTHER2,P_OTHER3,PHASE_I_STR,DISPADJ2,
     +               RESOURCE_ID,P_FUEL_SUPPLY_ID,
     +               P_NOX_BK2,SEC_EMISS_PTR,EMISS_FUEL_COST,
     +               EMISS_FUEL_ESCAL,EMISS_FUEL_EMISS_PTR,
     +               EMISS_BLENDING_RATE,PRIM_FUEL_EMISS_PTR,
     +               PRIM_FUEL_TYPE,FUEL_TYPES,TIE_GROUP,
     +               MONTHLY_CAPACITY_POINTER,
     +               AI_CAPACITY_RATE,AI_CAPACITY_ESCALATOR,
     +               AI_ENERGY_RATE,AI_ENERGY_ESCALATOR,
     +               AI_REMAINING_LIFE,
     +               ANNUAL_CL_FIXED_COST,
     +               ANNUAL_CL_FIXED_COST_ESC,
     +               MAINT_DAYS,DISPATCH_MULT,
     +               EXCESS_ENERGY_SALES,
     +               AI_TAX_LIFE,
     +               AI_ADR_TAX_LIFE,
     +               ASSET_CLASS_NUM,
     +               ASSET_CLASS_VECTOR,
     +               INTRA_COMPANY_CLASS_ID,
     +               INTRA_COMPANY_TRANSACTION,
     +               SPECIAL_UNIT_ID,
     +               MINIMUM_CAPACITY_FACTOR,
     +               MAXIMUM_CAPACITY_FACTOR,
     +               TRANSACTION_GROUP_ID,
     +               DAY_TYPE_ID,
     +               UNIT_ACTIVE,
     +               BASECASE_PLANT_ID,
     +               BASECASE_UNIT_ID,
     +               BASECASE_MARKET_AREA_ID,
     +               BASECASE_TRANS_AREA_ID,
     +               BASECASE_PLANT_NERC_SUB_ID,
     +               BASECASE_PLANT_OWNER_ID,
     +               UTILITY_OWNED,
     +               MONTHLY_FUEL_INDEX,
     +               START_UP_COSTS,
     +               START_UP_LOGIC,
     +               RAMP_RATE,
     +               MIN_DOWN_TIME,
     +               REPORT_THIS_UNIT,
     +               P_FUEL_DELIVERY,
     +               P_FUEL_DELIVERY_2,
     +               P_FUEL_DELIVERY_3,
     +               MIN_UP_TIME,
     +               HESI_UNIT_ID_NUM,
     +               FOR_FREQUENCY,
     +               FOR_DURATION,
     +               WINTER_TOTAL_CAPACITY,
     +               CONTRIBUTES_TO_SPIN,
     +               H2_UNIT_ID_NUM,
     +               POWERDAT_PLANT_ID,
     +               APPLY_NOX_SEASON_DATE,
     +               NOX_SEASON_DATE,
     +               RAMP_DOWN_RATE,
     +               NOX_CONTROL_PERCENT,
     +               NOX_CONTROL_DATE,
     +               EMERGENCY_CAPACITY,
     +               EMERGENCY_HEATRATE,
     +               MARKET_RESOURCE,
     +               PRIMARY_MOVER_STR,
     +               COUNTY,
     +               STATE_PROVINCE,
     +               NOX_VOM,
     +               NOX_FOM,
     +               S_FUEL_DELIVERY,
     +               S_FUEL_DELIVERY_2,
     +               S_FUEL_DELIVERY_3,
     +               CONSTANT_POLY,
     +               FIRST_POLY,
     +               SECOND_POLY,
     +               THIRD_POLY,
     +               USE_POLY_HEAT_RATES,
     +               NEWGEN_UNIT_STATUS,
     +               MONTHLY_MUST_RUN_VECTOR,
     +               EMISSION_MARKET_LINK,
     +               WVPA_RATE_TRACKER,
     +               ALLOW_DECOMMIT,
     +               MIN_SPIN_CAP,
     +               MAX_SPIN_CAP,
     +               WVPA_RES_TRACKER,
     +               WVPA_FUEL_TRACKER,
     +               MONTE_OR_FREQ,
     +               WVPA_MEM_TRACKER,
     +               MONTHLY_DECOMMIT_VECTOR,
     +               TRANS_BUS_ID,
     +               SOX_CONTROL_PERCENT,
     +               SOX_CONTROL_DATE,
     +               SOX_VOM,
     +               SOX_FOM,
     +               LATITUDE,
     +               LONGITUDE,
     +               MW_INSIDE_FENCE,
     +               INTER_BLOCKS,     ! 152-153
c SP CapEx Variables added 11/17/05 MSG
     +               FIRST_YEAR_DECOMM_AVAIALABLE,
     +               DECOMMISSIONING_BASE_YR_COST,            ! 155
     +               DECOMMISSIONING_COST_ESCALATION,
     +               ANNUAL_ENERGY_PLANNING_FACTOR,
     +               AGGREGATE_THIS_UNIT,               ! 158
     +               NAME_PLATE_CAPACITY,
     +               FUEL_BLENDING_IS,
     +               FuelRatio,
     +               BlendableFuelsPtr, ! 167
     +               FuelTransportationCost,
     +               BlendedEnthalpyUp,
     +               BlendedEnthalpyLo,
     +               BlendedSO2Up,                  ! 177
     +               BettermentProjectID,
     +               DECOM_CONTINUING_COST,
     +               DECOM_CONTINUING_COST_ESCALATION,
     +               EnrgPatternPointer, ! 181
     +               EMISSION_DATA_UNITS,
     +               EmissRedRate,
     +               EmissMaxRate,
     +               MaxEnergyLimit,
     +               TECH_TYPE,
     +               LINKED_BETTERMENT_OPTION,
     +               CO2_CONTROL_PERCENT,
     +               HG_CONTROL_PERCENT,
     +               OTHER3_CONTROL_PERCENT,
     +               CO2_CONTROL_DATE,
     +               HG_CONTROL_DATE,
     +               OTHER3_CONTROL_DATE,
     +               CO2_VOM,
     +               CO2_FOM,
     +               HG_VOM,
     +               HG_FOM,
     +               OTHER3_VOM,
     +               OTHER3_FOM, ! 209
     +               MARKET_FLOOR,
     +               MARKET_CEILING,
     +               START_UP_COSTS_ESCALATION,  ! 212
     +               CAPACITY_MARKET_TYPE,
     +               CAPACITY_MARKET_MONTH,
     +               CAPACITY_MARKET_POINTER,
     +               CAPACITY_MARKET_COST_ASSIGN,
     +               CAPACITY_MARKET_EXP_COLLECT,
     +               CAPACITY_MARKET_COIN_ADJ_FACT,
     +               PRIMARY_FUEL_CATEGORY,
     +               SECONDARY_FUEL_CATEGORY,
     +               EMISSIONS_FUEL_CATEGORY,
     +               RPS_CONTRIBUTION_PERCENT,
     +               RETIREMENT_CANDIDATE,
     +               RETROFIT_CANDIDATE,
     +               RETROFIT_PROJECT_ID,
     +               CO2_BASIN_NAME,
     +               CO2_PIPELINE_DISTANCE,
     +               STATE_PROV_NAME, ! 228
     +               CO2_RETRO_HEAT_MULT,
     +               CO2_RETRO_CAP_MULT,
     +               THERMAL_GUID,
     +               THERMAL_PARENT_ID, ! 232
     +               THERMAL_AGGREGATED_UNIT,
     +               FIRST_RETIREMENT_YEAR,
     +               UNIT_TYPE,
     +               UNIT_TYPE_CATEGORY,
     +               RPS_PROGRAM_NUMBER
               IF(INDEX(TEMP_EXPENSE_COLLECTION,'BTL') /= 0) THEN
                  EXPENSE_COLLECTION = 'X'
               ELSE
                  EXPENSE_COLLECTION = TEMP_EXPENSE_COLLECTION(1:1)
               ENDIF
            ENDIF
            IF(CL_LOAD_TYPE(1:1) == NUCLEAR .AND. DELETE < 8 .AND.
     +                (UNIT_ACTIVE == 'T' .OR. UNIT_ACTIVE == 't')) THEN
                NUCLEAR_UNITS_ACTIVE = NUCLEAR_UNITS_ACTIVE + 1
            ENDIF
            WRITE(12,REC=IREC) DELETE,UNIT_NAME,
     +         CL_LOAD_TYPE,EXPENSE_ASSIGNMENT,EXPENSE_COLLECTION,
     +         GENGRP,FRAOWN,ONLIMO,ONLIYR,OFLIMO,OFLIYR,FUELMX,PRFCST,
     +         PRESCR,SEFCST,SDESCR,FUELADJ,EFOR,MAINRT,VARCST,VRESCR,
     +         FIXED_COST,FIXED_COST_ESCALATOR,
     +         DISPADJ,HRFACT,MW,PLANNING_FACTOR,COEFF,
     +         AI_CAPACITY_RATE,AI_CAPACITY_ESCALATOR,AI_ENERGY_RATE,
     +         AI_ENERGY_ESCALATOR,AI_REMAINING_LIFE,
     +         P_SO2,P_NOX,P_PARTICULATES,POOL_FRAC_OWN,
     +         P_OTHER2,P_OTHER3,PHASE_I_STR,DISPADJ2,
     +         RESOURCE_ID,P_FUEL_SUPPLY_ID,
     +         P_NOX_BK2,SEC_EMISS_PTR,EMISS_FUEL_COST,EMISS_FUEL_ESCAL,
     +         EMISS_FUEL_EMISS_PTR,EMISS_BLENDING_RATE,
     +         PRIM_FUEL_EMISS_PTR,
     +         PRIM_FUEL_TYPE,FUEL_TYPES,TIE_GROUP,
     +         MONTHLY_CAPACITY_POINTER,
     +         ANNUAL_CL_FIXED_COST,
     +         ANNUAL_CL_FIXED_COST_ESC,
     +         MAINT_DAYS,DISPATCH_MULT,
     +         EXCESS_ENERGY_SALES,
     +         AI_TAX_LIFE,
     +         AI_ADR_TAX_LIFE,
     +         ASSET_CLASS_NUM,
     +         ASSET_CLASS_VECTOR,
     +         INTRA_COMPANY_CLASS_ID,
     +         INTRA_COMPANY_TRANSACTION,
     +         SPECIAL_UNIT_ID,
     +         MINIMUM_CAPACITY_FACTOR,
     +         MAXIMUM_CAPACITY_FACTOR,
     +         TRANSACTION_GROUP_ID,
     +         DAY_TYPE_ID,
     +         UNIT_ACTIVE,
     +         BASECASE_PLANT_ID,
     +         BASECASE_UNIT_ID,
     +         BASECASE_MARKET_AREA_ID,
     +         BASECASE_TRANS_AREA_ID,
     +         BASECASE_PLANT_NERC_SUB_ID,
     +         BASECASE_PLANT_OWNER_ID,
     +         UTILITY_OWNED,
     +         MONTHLY_FUEL_INDEX,
     +         START_UP_COSTS,
     +         START_UP_LOGIC,
     +         RAMP_RATE,
     +         MIN_DOWN_TIME,
     +         REPORT_THIS_UNIT,
     +         P_FUEL_DELIVERY,
     +         P_FUEL_DELIVERY_2,
     +         P_FUEL_DELIVERY_3,
     +         MIN_UP_TIME,
     +         HESI_UNIT_ID_NUM,
     +         FOR_FREQUENCY,
     +         FOR_DURATION,
     +         WINTER_TOTAL_CAPACITY,
     +         CONTRIBUTES_TO_SPIN,
     +         H2_UNIT_ID_NUM,
     +         POWERDAT_PLANT_ID,
     +         APPLY_NOX_SEASON_DATE,
     +         NOX_SEASON_DATE,
     +         RAMP_DOWN_RATE,
     +         NOX_CONTROL_PERCENT,
     +         NOX_CONTROL_DATE,
     +         EMERGENCY_CAPACITY,
     +         EMERGENCY_HEATRATE,
     +         MARKET_RESOURCE,
     +         PRIMARY_MOVER_STR,
     +         COUNTY,
     +         STATE_PROVINCE,
     +         NOX_VOM,
     +         NOX_FOM,
     +         S_FUEL_DELIVERY,
     +         S_FUEL_DELIVERY_2,
     +         S_FUEL_DELIVERY_3,
     +         CONSTANT_POLY,
     +         FIRST_POLY,
     +         SECOND_POLY,
     +         THIRD_POLY,
     +         USE_POLY_HEAT_RATES,
     +         NEWGEN_UNIT_STATUS,
     +         MONTHLY_MUST_RUN_VECTOR,
     +         EMISSION_MARKET_LINK,
     +         WVPA_RATE_TRACKER,
     +         ALLOW_DECOMMIT,
     +         MIN_SPIN_CAP,
     +         MAX_SPIN_CAP,
     +         WVPA_RES_TRACKER,
     +         WVPA_FUEL_TRACKER,
     +         MONTE_OR_FREQ,
     +         WVPA_MEM_TRACKER,
     +         MONTHLY_DECOMMIT_VECTOR,
     +         TRANS_BUS_ID,
     +         SOX_CONTROL_PERCENT,
     +         SOX_CONTROL_DATE,
     +         SOX_VOM,
     +         SOX_FOM,
     +         LATITUDE,
     +         LONGITUDE,
     +         MW_INSIDE_FENCE,
     +         INTER_BLOCKS,     ! 152-153
c SP CapEx Variables added 11/17/05 MSG
     +         FIRST_YEAR_DECOMM_AVAIALABLE,
     +         DECOMMISSIONING_BASE_YR_COST,            ! 155
     +         DECOMMISSIONING_COST_ESCALATION,
     +         ANNUAL_ENERGY_PLANNING_FACTOR,
     +         AGGREGATE_THIS_UNIT,               ! 158
     +         NAME_PLATE_CAPACITY,
     +         FUEL_BLENDING_IS,
     +         FuelRatio,
     +         BlendableFuelsPtr, ! 167
     +         FuelTransportationCost,
     +         BlendedEnthalpyUp,
     +         BlendedEnthalpyLo,
     +         BlendedSO2Up,                  ! 177
     +         BettermentProjectID,
     +         DECOM_CONTINUING_COST,
     +         DECOM_CONTINUING_COST_ESCALATION,
     +         EnrgPatternPointer, ! 181
     +         EMISSION_DATA_UNITS,
     +         EmissRedRate,
     +         EmissMaxRate,
     +         MaxEnergyLimit,
     +         TECH_TYPE,
     +         LINKED_BETTERMENT_OPTION,
     +         CO2_CONTROL_PERCENT,
     +         HG_CONTROL_PERCENT,
     +         OTHER3_CONTROL_PERCENT,
     +         CO2_CONTROL_DATE,
     +         HG_CONTROL_DATE,
     +         OTHER3_CONTROL_DATE,
     +         CO2_VOM,
     +         CO2_FOM,
     +         HG_VOM,
     +         HG_FOM,
     +         OTHER3_VOM,
     +         OTHER3_FOM, ! 209
     +         MARKET_FLOOR,
     +         MARKET_CEILING,
     +         START_UP_COSTS_ESCALATION,  ! 212
     +         CAPACITY_MARKET_TYPE,
     +         CAPACITY_MARKET_MONTH,
     +         CAPACITY_MARKET_POINTER,
     +         CAPACITY_MARKET_COST_ASSIGN,
     +         CAPACITY_MARKET_EXP_COLLECT,
     +         CAPACITY_MARKET_COIN_ADJ_FACT,
     +         PRIMARY_FUEL_CATEGORY,
     +         SECONDARY_FUEL_CATEGORY,
     +         EMISSIONS_FUEL_CATEGORY,
     +         RPS_CONTRIBUTION_PERCENT,
     +         RETIREMENT_CANDIDATE,
     +         RETROFIT_CANDIDATE,
     +         RETROFIT_PROJECT_ID,
     +         CO2_BASIN_NAME,
     +         CO2_PIPELINE_DISTANCE,
     +         STATE_PROV_NAME, ! 228
     +         CO2_RETRO_HEAT_MULT,
     +         CO2_RETRO_CAP_MULT,
     +         THERMAL_GUID,
     +         THERMAL_PARENT_ID, ! 232
     +         THERMAL_AGGREGATED_UNIT,
     +         FIRST_RETIREMENT_YEAR,
     +         UNIT_TYPE,
     +         UNIT_TYPE_CATEGORY,
     +         RPS_PROGRAM_NUMBER
         ENDDO
         IF(IOS_BASE /= 0) EXIT
      ENDDO
      CLOSE(10)
      CLOSE(12)
      NUC_UNITS_IN_OL_FILE(FILE_NUMBER) = NUCLEAR_UNITS_ACTIVE
      IF(FOSSILOL(FILE_NUMBER) == 'BC') CLOSE(11)
      FOSSILOL(FILE_NUMBER) = 'OL'
      RETURN
C
c  200 CALL LOCATE(20,0)
c      WRITE(6,1010) trim(RECLN)
  200 CALL MG_LOCATE_WRITE(20,0,trim(RECLN),ALL_VERSIONS,1)
      er_message='stop requested from Cla_objt SIID20'
      call end_program(er_message)
C
C***************************************************************
      ENTRY SET_FOSSILOL_TO_OL
C***************************************************************
         DO FILE_ID = 0, MAX_CL_FILES-1
            FOSSILOL(FILE_ID) = 'OL'
C
            COMMAND1 = trim(OUTPUT_DIRECTORY())//'BC'//
     +                     trim(CL_FILE_BINARY_NAMES(FILE_ID))//'.BIN'
            COMMAND2 = trim(OUTPUT_DIRECTORY())//'OL'//
     +                     trim(CL_FILE_BINARY_NAMES(FILE_ID))//'.BIN'
            CALL COPY_FILE_2_FILE(COMMAND1,COMMAND2)
            NUC_UNITS_IN_OL_FILE(FILE_ID) = NUC_UNITS_IN_FILE(FILE_ID)
         ENDDO
      RETURN
C***************************************************************
      ENTRY RESET_FOSSILOL
C***************************************************************
         DO FILE_ID = 0, MAX_CL_FILES-1
            FOSSILOL(FILE_ID) = 'BC'
         ENDDO
      RETURN
C
C***************************************************************
      ENTRY OPEN_CL_FILE(UNIT_NO,R_ACTIVE_CL_RECORDS,FILE_NUMBER)
C***************************************************************
         IF(ACTIVE_CL_RECORDS(FILE_NUMBER) > 0) THEN
            OPEN(UNIT_NO,FILE=trim(OUTPUT_DIRECTORY())//
     +                FOSSILOL(FILE_NUMBER)//
     +                trim(CL_FILE_BINARY_NAMES(FILE_NUMBER))//".BIN",
     +                      ACCESS="DIRECT",STATUS="UNKNOWN",RECL=LRECL)
         ENDIF
         R_ACTIVE_CL_RECORDS = MAX(ACTIVE_CL_RECORDS(FILE_NUMBER),0)
      RETURN
C
C***************************************************************
      ENTRY RETURN_NUCLEAR_UNITS_ACTIVE(R_NUM_OF_NUCLEAR_UNITS)
C***************************************************************
         NUCLEAR_UNITS_ACTIVE = 0
         DO FILE_ID = 0, MAX_CL_FILES-1
            NUCLEAR_UNITS_ACTIVE = NUCLEAR_UNITS_ACTIVE
     +                             + NUC_UNITS_IN_OL_FILE(FILE_ID)
         ENDDO
         R_NUM_OF_NUCLEAR_UNITS = NUCLEAR_UNITS_ACTIVE
      RETURN
C***************************************************************
      ENTRY DOES_CL_FILE_EXIST(R_CL_FILES_ARE_ACTIVE)
C***************************************************************
         R_CL_FILES_ARE_ACTIVE = CL_FILES_ARE_ACTIVE
      RETURN
 1000 FORMAT(A)
 1010 FORMAT('&',A)
      END
C
C***********************************************************************
C
C          SUBROUTINE TO READ FOSSIL DIRECT ACESS BINARY FILES
C          COPYRIGHT (C) 1983, 84, 85  M.S. GERBER & ASSOCIATES, INC.
C
C***********************************************************************
C
C     THIS FILE IS BEFORE THE YEAR COUNTER LOOP. CAPACITY
C     LIMITED UNITS' CHARACTERISTICS ARE READ IN AND PLACED INTO THE
C     PRODCOM.MON AND PROD2COM.MON FILES.
C
C      RECURSIVE FUNCTION CL_UNITS_READ()
      FUNCTION CL_UNITS_READ()
      use end_routine, only: end_program, er_message
C
      USE SPCapExVariables
      USE CLA_OBJT_ARRAYS
      USE CONVERSTION_ROUTINES
      USE LH_GLOBAL_VARIABLES
      USE TRANS_GROUP_VARIALBES
      USE GRX_PLANNING_ROUTINES
      USE IREC_ENDPOINT_CONTROL
      USE ANNLCOMMON
      USE INTERNAL_OPERATION_SWITCHES
      USE CL_UNITS_READ_DATA
      INCLUDE 'SpinLib.MON'
      SAVE
      INCLUDE 'SIZECOM.MON'
      INCLUDE 'KEPCOCOM.MON'
      INCLUDE 'NAMESCOM.MON'
      INCLUDE 'MTHNMCOM.MON'
      INCLUDE 'TRANCOM.MON' ! ADDED 9/27/02 FOR REGIONAL MAINTENANCE
      INCLUDE 'ANNLCOM.MON'
      INCLUDE 'PRODCOM.MON'
      INCLUDE 'PROD2COM.MON'
      INCLUDE 'PROD3COM.MON'
      REAL (KIND=4) :: MN_RATE,TEMP_REAL,
     +                 GET_NEW_UNIT_RETIRE_VALUE_BY_CM
      REAL (KIND=4), ALLOCATABLE :: RETIRE_RETRO_UPLIFT_PER_TON(:),
     +       RETIRE_RETRO_CUM_CO2(:),
     +       NEW_UNIT_RETIRE_VALUE_BY_CM(:),
     +       NUC_FUEL_LEASED_BURN_BY_CLASS(:),
     +       NUC_FUEL_OWNED_BURN_BY_CLASS(:),
     +       NUCLEAR_MWH_BY_CLASS(:),
     +       NUCLEAR_MMBTU_BY_CLASS(:),
     +       INTRA_COMPANY_NF_BURN(:),
     +       ANNUAL_CL_MAINT_MW(:),
     +       MAINT_DAYS(:),
     +       MAINTENANCE_DAYS(:),
     +       MAINT_INDEX_MW(:),
     +       MAINT_INDEX_DAYS(:),
     +       ASSET_CLASS_LIST(:),
     +       ASSET_ALLOCATION_LIST(:),
     +       ANNUAL_CL_MAINTENANCE(:,:),
     +      MON_MDS_CL_UNIT_CAPACITY(:,:),
     +      MON_MDS_CL_UNIT_ENERGY(:,:),
     +      MON_MDS_CL_UNIT_FUEL_COST(:,:),
     +      MON_MDS_CL_UNIT_VAR_COST(:,:),
     +      MON_MDS_CL_UNIT_FIXED_COST(:,:),
     +      MON_MDS_NUC_FUEL_ADDER_COST(:,:),
     +      MON_MDS_ECO_SALES_REV_FROM(:,:),
     +      MON_MDS_ECO_SALES_ENRG_FROM(:,:),
     +      MON_MDS_ECO_PUCH_COST_FROM(:,:),
     +      MON_MDS_ECO_PUCH_ENRG_FROM(:,:),
     +      MON_MDS_ICAP_REVENUES(:,:),
     +      CL_ANN_CLASS_FUEL_COST(:,:),
     +     CL_ANN_MULT_FUEL_COST(:,:),
     +     FE_ANN_MULT_FUEL_COST(:,:),
     +     CL_ANN_MULT_VAR_COST(:,:),
     +     CL_ANN_MULT_FIXED_COST(:,:),
     +     CL_ANN_MULT_REVENUE(:,:),
     +     CL_ANN_MULT_CAPACITY(:,:),
     +     CL_ANN_MULT_PURCHASES(:,:),
     +     CL_ANN_MULT_ENERGY(:,:),
     +     NF_FUEL_LEASED_BY_CLASS(:,:),
     +     NF_FUEL_OWNED_BY_CLASS(:,:),
     +     CL_ANN_CLASS_VAR_COST(:,:),
     +     CL_ANN_CLASS_FIXED_COST(:,:),
     +     CL_ANN_CLASS_REVENUE(:,:),
     +     CL_ANN_CLASS_CAPACITY(:,:),
     +     CL_ANN_CLASS_PURCHASES(:,:),
     +     CL_ANN_CLASS_ENERGY(:,:),
     +     CL_ANN_CLASS_EMISSIONS(:,:),
     +     INTRA_COMPANY_REVENUES(:,:),
     +     MON_MDS_NUC_FUEL_LEASE_BURN_BC(:,:),
     +     MON_MDS_NUC_FUEL_OWNED_BURN_BC(:,:),
     +     MON_MDS_NUCLEAR_MWH_BY_CLASS(:,:),
     +     MON_MDS_NUCLEAR_MMBTU_BY_CLASS(:,:),
     +     MON_MDS_ICAP_REV_BY_CLASS(:,:),
     +     MONTHLY_AC_WHOLESALE_PROD_COST(:,:),
     +     MONTHLY_AC_ECITY_VAR_PROD_COST(:,:),
     +     MONTHLY_AC_ECITY_NEW_FIX_COST(:,:),
     +     MAINT_INDEX_MONTHLY_MW(:,:),
     +     MON_MDS_CL_CLASS_FUEL_COST(:,:,:),
     +     ANNUAL_CL_CAPACITY(:,:,:),
     +     MON_MDS_CL_UNIT_EMISSIONS_COST(:,:,:),
     +     MON_MDS_CL_UNIT_EMISSIONS(:,:,:),
     +     MON_MDS_CL_MULT_FUEL_COST(:,:,:),
     +     MON_MDS_CL_MULT_VAR_COST(:,:,:),
     +     MON_MDS_CL_MULT_FIXED_COST(:,:,:),
     +     MON_MDS_CL_MULT_CAPACITY(:,:,:),
     +     MON_MDS_CL_MULT_ENERGY(:,:,:),
     +     MON_MDS_CL_MULT_PURCHASES(:,:,:),
     +     MON_MDS_CL_CLASS_VAR_COST(:,:,:),
     +     MON_MDS_CL_CLASS_FIXED_COST(:,:,:),
     +     MON_MDS_CL_CLASS_REVENUE(:,:,:),
     +     MON_MDS_CL_CAP_REVENUE(:,:,:),
     +     MON_MDS_CL_CLASS_CAPACITY(:,:,:),
     +     MON_MDS_CL_CLASS_PURCHASES(:,:,:),
     +     MON_MDS_CL_CAP_PURCHASES(:,:,:),
     +     MON_MDS_CL_CLASS_ENERGY(:,:,:),
     +     MON_MDS_CL_CLASS_EMISSIONS(:,:,:),
     +     MON_MDS_CL_CLASS_EMISSIONS_COST(:,:,:),
     +     MON_MDS_INTRA_COMPANY_REVENUES(:,:,:),
     +     MON_MDS_INTRA_COMPANY_NF_BURN(:,:),
     +     MON_MDS_NF_FUEL_LEASED_BC(:,:,:),
     +     MON_MDS_NF_FUEL_OWNED_BC(:,:,:)
!
! FIX TO MAINTENANCE SCHEDULER. 3/8/1.
!
      REAL (KIND=8),ALLOCATABLE :: MON_MDS_CL_UNIT_MMBTUS(:,:)




      INTEGER (KIND=2), ALLOCATABLE :: TG_2_PLANNING_AREA(:),
     +          RETIRE_RETRO_INDEX(:),
     +          TRANS_GROUP_FOR_DATA_BASE(:),
     +          RETIRE_RETRO_POSITION(:),
     +          RETIRE_RETRO_ABATE_INDEX(:),
     +          PURCHASE_ASSET_CLASS_ID(:),
     +          MARKET_RESOURCE_INDEX(:),
     +          MARKET_RESOURCE_COUNTER(:),
     +          ASSET_CLASS_POINTER(:),
     +          MAINT_INDEX(:),
     +          DAY_TYPE_TRANS_GROUP_PAIR(:,:),
     +          DATA_BASE_POSITION(:,:),
     +          MRX_TG_CAP_CURVE_INDEX(:,:),
     +          MRX_TG_CAP_UNIT_NO(:),
     +          MRX_TG_CAP_UNIT_INDEX(:)
!     +          MRX_CM_CAP_CURVE_INDEX(:,:),
!     +          MRX_CM_CAP_UNIT_NO(:),
!     +          MRX_CM_CAP_UNIT_INDEX(:)
      LOGICAL (KIND=1) :: RETROFIT_UNIT_IS_ACTIVE(MAX_CL_UNITS),
     +                    TEMP_L1,RETROFIT_PROJECT_ACTIVE,
     +                    CALC_MRX_RPS_CURVES
      INTEGER (KIND=2) :: CAP_LIMITED_CLASS_POINTER(1024),
     +                    TOP,BOTTOM,HALF,
     +                    CM_INDEX,GET_CM_INDEX_FROM_TG,
     +                    UnitTG,UnitCG
      CHARACTER (LEN=1), ALLOCATABLE :: PURCHASE_POWER_ASSIGN(:)
      CHARACTER (LEN=1)INTRA_COMPANY_TRANSACTION(MAX_CL_UNITS)

      LOGICAL (KIND=1), ALLOCATABLE :: MAINT_DIVISIBLE(:)
      CHARACTER*20 SPECIAL_UNIT_ID(MAX_CL_UNITS)
      INTEGER (KIND=4) :: DA_ERR,CPO_REC,RESET_REC
      LOGICAL (KIND=4) :: temp_grx_converged,GRX_CO2_MARKET_LOGIC
      REAL (KIND=4) :: ITER_0_ECON_RETIRE_MARGIN(MAX_CL_UNITS),
     +                 LAST_ITER_GROSS_MARGIN(MAX_CL_UNITS)
      REAL (KIND=4) :: UNIT_ANNUAL_GROSS_MARGIN,RETIREMENT_MEASURE,
     +                 GET_MRX_TG_CAP_CURVE_PRICE,
     +                 GET_MRX_CM_CAP_CURVE_PRICE
      CHARACTER (LEN=48) :: RPT_UNIT_NAME
      REAL (KIND=4) :: RPT_RETIREMENTS_MW,RPT_RETIREMENTS_MWH,
     +                 RPT_RETIREMENTS_CO2,GRX_CO2_MARKET_TONS,
     +                 GRX_CO2_MARKET_PRICE
      INTEGER (KIND=2) :: RETURN_MONTHLY_CL_EXPENSES,R_YR,RETIRED_UNITS,
     +                    CO2_MARKET_PTS,ABATE_RETROFIT_COUNTER,
     +                    RETROFIT_PROJECT_YEAR,K
      REAL*4 MONTH_VARS(0:12,1:*),TRANS_DISPATCH_EMIS_ADDER
      REAL R_MONTHLY_OWNED_NF(0:12),
     +     R_MONTHLY_LEASED_NF(0:12),
     +     R_MONTHLY_DOE_DISPOSAL(0:12),
     +     R_MONTHLY_DOE_DECOMMISSIONING(0:12)
      LOGICAL (KIND=4) :: HardWiredRetrofitProjectThisYear,
     +                    HardWiredRetrofitProject,
     +                    GRX_RETROFITED_UNIT
      REAL (KIND=4) :: RETRO_CAP_CO2_MULT
      LOGICAL*1   RETURN_CL_INTRA_CLASS_REVENUES,INIT_MON_MDS_CL_UNITS,
     +            MON_MDS_CL_VAR,MON_MDS_CL_FIXED,MON_MDS_NUC_ADDER,
     +            STRATEGIC_RETIRMENTS_LOGIC/.FALSE./,
     +            GET_STRATEGIC_RETIRMENTS_LOGIC,
     +            SCHEDULE_FO,
     +            YES_FREQUENCY_DURATION,
     +            FREQUENCY_DURATION,
     +            UNIT_FREQUENCY_DURATION/.FALSE./,
     +            YES_DETAILED_FOR,
     +            YES_DETAILED_MAINTENANCE,
     +            DETAILED_MAINT,
     +            PRICE_ONLY_WHOLESALE_REV/.FALSE./,
     +            APPLY_TRANS_REV_TO_WHOLESALE,
     +            DETAILED_TRANSFER_PRICING/.FALSE./,
     +            YES_DETAILED_TRANSFER_PRICING,
     +            NOX_ACTIVE_FOR_UNIT,
     +            GET_NOX_CONTROL_FOR_UNIT,
     +            GET_SOX_CONTROL_FOR_UNIT,
     +            GET_CO2_CONTROL_FOR_UNIT,
     +            SET_SOX_CONTROL_COAL_LP,
     +            RESET_SOX_CONTROL_COAL_LP,
     +            R_CO2_FIRST_CONTROL_MONTH,
     +            R_CO2_FIRST_CONTROL_YEAR,
     +            R_CO2_YEAR_BEFORE_CONTROL,
     +            GET_HG_CONTROL_FOR_UNIT,
     +            GET_OTHER3_CONTROL_FOR_UNIT,
     +            R_SEASON_IS_NOX_SEASON,
     +            FIRST_ENERGY/.FALSE./,
     +            R_CALCULATE_NOX,
     +            GET_MONTHLY_MAINTENANCE_PENALTY,
     +            YES_REGIONAL_OUTAGES_ACTIVE,
     +            REGIONAL_PARAMS_ACTIVE,
     +            YES_TURN_OFF_POLY,TURN_OFF_POLY,
     +            TEST_MONTHLY_MUST_RUN,
     +            YES_NEW_BUILD_ADDITIONS_ACTIVE,
     +            NEW_BUILD_ADDITIONS_ACTIVE,
     +            GET_NEW_BUILD_PERCENTS,
     +            KEEP_UNIT,
     +            EXPENSE_ASSIGNMENT_IS_PURCHASE,
     +            CapEx_Running,YES_POWERWORLD_REPORT,
     +            WVPA,
     +            AOD_THERMAL_UNIT_VALUE_LIST,
     +            YES_AOD_PRICE_THERM_VALUE_LIST,
     +            YES_AOD_COMP_THERM_VALUE_LIST,
     +            AOD_THERMAL_LIST_COMPARE,
     +            CO2_RETROFIT_LOGIC_ACTIVE
      REAL*4 R_INTRA_BASE_REVENUES,
     +       R_INTRA_ADJ_REVENUES,
     +       R_INTRA_SALES_REVENUES,
     +       R_INTRA_OTHER_REVENUES,
     +       R_INTRA_COMPANY_NF_BURN,
     +       R_WVPA_EMISSIONS_EXPENSE,
     +       R_CAPACITY_SALES_TO_LEVEL_RM,
     +       R_CAPACITY_PURCHASES_TO_LEVEL_RM,
     +       RETIREMENTS_PROFIT_PER_KW,
     +       R1_MONTHLY_TRANSFER_REV,
     +       R1_MONTHLY_TRANSFER_COST,
     +       R2_MONTHLY_TRANSFER_REV,
     +       R2_MONTHLY_TRANSFER_COST,
     +       UNDER_CONSTRUCTION_PERCENT,
     +       ADVANCED_DEVELOPMENT_PERCENT,
     +       EARLY_DEVELOPMENT_PERCENT,
     +       PROPOSED_PERCENT,
     +       INDEFIN_POSTPHONED_PERCENT
      INTEGER*2 MAX_INTRA_CLASS,
     +       CM_RETIREMENT_UNIT(0:1000)
      REAL INTRA_FOSSIL_FUEL_EXPENSES,
     +     INTRA_LEASED_NUC_FUEL_EXPENSES,
     +     INTRA_OWNED_NUC_FUEL_EXPENSES,
     +     INTRA_NUC_OWN_BURN,
     +     INTRA_NUC_LEASE_BURN,
     +     INTRA_PURCHASE_EXPENSES
      LOGICAL*1 RETURN_CL_INTRA_EXPENSES,
     +          REGIONAL_MAINT_SCHEDULING,
     +          REGIONAL_PA_MAINT_SCHEDULING,
     +          REGIONAL_TG_MAINT_SCHEDULING,
     +          REGIONAL_PA_MAINTENANCE_LOGIC,
     +          REGIONAL_TG_MAINTENANCE_LOGIC
      REAL*4 R_INTRA_FOSSIL_FUEL_EXPENSES,
     +       R_INTRA_LEASED_NUCLEAR_FUEL,
     +       R_INTRA_OWNED_NUC_FUEL_EXPENSES,
     +       R_INTRA_NUC_OWN_BURN,
     +       R_INTRA_NUC_LEASE_BURN,
     +       R_INTRA_PURCHASE_EXPENSES,
     +       R_ENRG,R_FIXED_COST,R_CAP,R_EMIS(5),
     +       ANNUAL_MARGIN_PER_KW,MINIMUM_MARGIN_PER_KW/0./,R_MW,
     +       R_CO2,R_MWH,R_CO2_COST,
     +       R_CAP_COST,
     +       CO2_K,
!     +       RETIREMENTS_CO2(MAX_CL_UNITS),
!     +       RETIREMENTS_MW(MAX_CL_UNITS),
!     +       RETIREMENT_REV_PER_MW(MAX_CL_UNITS),
     +       RETIREMENTS_CUM_CO2(MAX_CL_UNITS),
     +       RETROFIT_CUM_CO2(MAX_CL_UNITS),
!     +       RETIREMENTS_CO2_PRICE(MAX_CL_UNITS),
     +       CM_RETIREMENT_KW(0:1000), ! ASSUMES NO MORE THAN 1000 CM
     +       GET_CM_RETIREMENT_KW,
!     +       RETROFIT_CO2_PRICE(MAX_CL_UNITS),
!     +       RETIREMENTS_MWH(MAX_CL_UNITS),
     +       RETIREMENTS_UPLIFT_PER_TON(MAX_CL_UNITS),
     +       RETROFIT_UPLIFT_PER_TON(MAX_CL_UNITS),
!     +       RETIRE_RETRO_CO2_PRICE(:),
     +       ANNUAL_CAPITAL_COST,
     +       INIT_ANNUAL_GROSS_MARGIN,
     +       MONTHLY_EAVAIL(12),
     +       MONTHLY_NUCLEAR_AVAIL_MULT(12),
     +       GET_SCENARIO_NUCLEAR_AVAIL,
     +       GET_MONTHLY_REGIONAL_OUTAGE,
     +       REGIONAL_MONTHLY_MULT(12),
     +       MONTHLY_COAL_AVAIL_MULT(12),
     +       MONTHLY_GAS_AVAIL_MULT(12),
     +       MONTHLY_OIL_AVAIL_MULT(12),
     +       MONTHLY_OTHER_AVAIL_MULT(12),
     +       GET_SCENARIO_COAL_AVAIL,
     +       GET_SCENARIO_GAS_AVAIL,
     +       GET_SCENARIO_OIL_AVAIL,
     +       GET_SCENARIO_OTHER_AVAIL,
     +       MONTHLY_HYDRO_WATER_YEAR_MULT(12),
     +       GET_SCENARIO_HYDRO_WATER_YEAR,
     +       TT_PERCENT,
     +       NOX_VOM(MAX_CL_UNITS),
     +       GET_NOX_VOM,
     +       NOX_FOM(MAX_CL_UNITS),
     +       GET_NOX_FOM,
     +       SOX_VOM(MAX_CL_UNITS),
     +       GET_SOX_VOM,
     +       SOX_FOM(MAX_CL_UNITS),
     +       GET_SOX_FOM,
     +       GET_CO2_VOM,
     +       CO2_VOM(MAX_CL_UNITS),
     +       GET_CO2_FOM,
     +       CO2_FOM(MAX_CL_UNITS),
     +       GET_HG_VOM,
     +       HG_VOM(MAX_CL_UNITS),
     +       GET_HG_FOM,
     +       HG_FOM(MAX_CL_UNITS),
     +       GET_OTHER3_VOM,
     +       OTHER3_VOM(MAX_CL_UNITS),
     +       GET_OTHER3_FOM,
     +       OTHER3_FOM(MAX_CL_UNITS),
     +       GET_MARKET_FLOOR,
     +       MARKET_FLOOR(MAX_CL_UNITS),
     +       GET_MARKET_CEILING,
     +       MARKET_CEILING(MAX_CL_UNITS),
     +       LATITUDE(MAX_CL_UNITS),
     +       LONGITUDE(MAX_CL_UNITS),
     +       MW_INSIDE_FENCE,
     +       INTER_BLOCKS(3,MAX_CL_UNITS),
     +       PERCENT_INSIDE_FENCE,
     +       MONTHLY_MAINTENANCE_PEAKS(12),
     +       GET_TRANS_GROUP_PEAK,
     +       GET_PA_PEAK,
     +       MAINTENANCE_PENALTY(12),
     +       LOCAL_MW(2),
     +       CO2_PRICE,
     +       CUM_CO2_EMISSIONS,
     +       RETROFIT_CO2,
     +       TRANS_MRX_DISPATCH_EMIS_ADDER,
     +       GET_CO2_RETIREMENT_PRICE,
     +       GET_CO2_RETIRE_RETRO_PRICE,
     +       R_CO2_REDUCTION,
     +       CUM_MW,
     +       CUM_MWH,
     +       RETIREMENT_COST_PER_KWMO,
     +       LOCAL_RPS_CONTRIB_PERCENT,
     +       GET_TRANS_RPS_PERCENT
      INTEGER*2   R_ISEAS,R_UNITNO,
     +            LOCAL_MONTH,
     +            MAX_RESOURCE_ID_NO,
     +            FT, ! PRIMARY MOVER
     +            TT,  ! TRANSFER TYPE
     +            NG,R_NG, ! NEWGEN INDEX
     +            YEAR_OR_SCEN,
     +            PA,
     +            MAX_PLANNING_AREAS,
!     +            LAST_UNIT_FOR_PA(:),
     +            MAX_MAINT_PLANNING_AREAS,
     +            GET_NUMBER_OF_PLANNING_GROUPS,
     +            GET_PA_FROM_TG,
     +            MAX_NEWGEN_INDEX
      PARAMETER(  MAX_RESOURCE_ID_NO=9999,
     +            MAX_NEWGEN_INDEX=100)
      REAL*8      R_HEAT
      INTEGER*4   VALUES_2_ZERO,
     +            INT4_EMIS_TYPE
      INTEGER*2   CL_UNITS_READ,CL_RECORDS,EMISS_TYPE,
     +            RDI_RECORDS,RDI_CL_RECORDS,RDI_REC,RDI_CL_REC,
     +            RDI_IN_UNIT,RDI_OUT_UNIT,
     +            NEWGEN_COUNTER(MAX_NEWGEN_INDEX), ! 082309.
     +            GET_NEWGEN_INDEX,
     +            START_UP_INDEX(MAX_CL_UNITS),
     +            MONTHLY_MUST_RUN_VECTOR(MAX_CL_UNITS),
     +            MONTHLY_DECOMMIT_VECTOR(MAX_CL_UNITS),
     +            State_TG_Index(MAX_CL_UNITS),
     +            State_Index(MAX_CL_UNITS),
     +            EMISSION_MARKET_LINK(MAX_CL_UNITS),
     +            GET_THERMAL_TRACKER_INDEX,
     +            GET_THERMAL_RES_TRACKER_INDEX,
     +            GET_THERMAL_FUEL_TRACKER_INDEX,
     +            GET_THERMAL_MEM_TRACKER_INDEX,
     +            WVPA_TRACKING_TYPE,
     +            WVPA_RESOURCE_TRACKING_TYPE,
     +            WVPA_FUEL_TRACKING_TYPE,
     +            WVPA_MEM_TRACKING_TYPE,
     +            GET_EMISSION_MARKET_LINK,
     +            GET_START_UP_INDEX,
     +            TOTAL_START_UP_UNITS/0/,
     +            GET_TOTAL_START_UP_UNITS,
     +            GET_CL_ENERGY_BY_TYPE,
     +            LOCAL_RESOURCE_ID,
     +            RESOURCE_ID_TO_UNIT(0:MAX_RESOURCE_ID_NO),
     +            NUMBER_OF_RESOURCE_ID(0:MAX_RESOURCE_ID_NO),
     +            GET_RESOURCE_ID_TO_UNIT,
     +            GET_I8_ID_TO_UNIT,
     +            R_ID,
     +            R_NUMBER_OF_RESOURCE_ID,
     +            MAX_FO_PER_MONTH/1/,
     +            GET_MAX_FO_PER_MONTH,
     +            NOX_SEASON_DATE(MAX_CL_UNITS),
     +            R_MONTH,
     +            POINTER_FOR_NEW_CL_UNIT(MAX_CL_UNITS),
     +            GET_POINTER_FOR_NEW_CL_UNIT,
     +            GET_PRIMARY_MOVER_INDEX,
     +            PRIMARY_MOVER_INDEX_DB,
     +            GET_NUM_ANNUAL_DERIVATIVES,
     +            RETIREMENTS_INDEX(MAX_CL_UNITS),
!     +            RETIRE_RETRO_COUNTER,
     +            RETIRE_RETRO_COUNT_AFTER_SORT,
     +            LAST_COUNTER,
     +            RETIRE_RETRO_USED(MAX_CL_UNITS),
     +            CO2_ABATEMENT_INDEX(MAX_CL_UNITS),
     +            CO2_RETROFIT_ABATEMENT_INDEX(MAX_CL_UNITS),
     +            CO2_COUNTER,
     +            ANN_ECON_RETIRE_COUNTER,
     +            NEXT_MRX_RETIREMENT,
     +            NEXT_MRX_RETROFIT,
     +            U,
     +            MONTH
      INTEGER*2 DELETE,ON_LINE_MONTH,ON_LINE_YEAR,
     +          M,IREC,
     +          I,R_NUNITS,
     +          R_LAST_NUNITS,
     +          R_ON_LINE_MONTH,
     +          R_DATE,
     +          BASE_CL_UNITS/0/,
     +          BASE_PLUS_HARDWIRED_CL_UNITS/0/,
     +          AVAILABLE_CL_UNITS/0/,
     +          INCREMENT_AVAILABLE_CL_UNITS,
     +          RETURN_CL_UNITS_B4_ADDITIONS,
     +          RETURN_UNIT_ADDITIONS,
     +          RESET_CL_UNITS,
     +          INCREMENT_HARDWIRED_CL_UNITS,
     +          CL_PLANNING_ADDITIONS,
     +          RETURN_CL_UNITS_AFTER_HARD_ADDS,
     +          MARKET_AREA_LOOKUP,
     +          CO2_ABATEMENT_NO,
     +          CO2_ABATEMENT_RPT_HEADER,
     +          CO2_ABATEMENT_VAR_NUM
      INTEGER IOS,IRAN32,IRAN32_OUT,CO2_ABATEMENT_REC
      REAL GET_CL_MW_FROM_POINTR,R_POINTR,MONTH_MULT,VOID_REAL,
     +     RDI_MONTH_GENERATION(12),RDI_MONTH_CAPACITY(12),
     +     RANDOM_NUMBER
      LOGICAL*4 FILE_EXISTS
      INTEGER*2 NUMBER_OF_CL_UNITS
      CHARACTER*2 LOAD_FILE_CHAR_EXT
      CHARACTER*3 GET_HOURLY_PRICE_NAME
      CHARACTER*5 MARKET_PRICE_NAME
      CHARACTER*256 FILE_NAME,PRB_FILE_DIRECTORY,OUTPUT_DIRECTORY
      CHARACTER*20 RETURN_UNITNM,MONTH_NAME,LOCAL_NAME
      CHARACTER*4 YEAR_CHR
      CHARACTER*5 NUNITS_CHR
      INTEGER*2 RETURN_SHADOW_UNIT_NUMBER,AI_REMAINING_LIFE
      INTEGER*2 SET_AI_CL_REMAINING_LIFE,LOCAL_POINTER
      INTEGER*2 ADD_NEW_CL_UNIT,
     +          GET_THERMAL_STATE_INDEX
      LOGICAL*1 CL_RESET_PRICES,TRANS_ANNUAL_UNIT_RETIREMENT,
     +          ANNUAL_CO2_RETIREMENTS_PROCESS,
     +          GET_CO2_RETIREMENTS_LOGIC,
     +          ANNUAL_CO2_RETROFIT_PROCESS,
     +          ANNUAL_RETIRE_RETRO_PROCESS,
     +          CO2_ABATEMENT_REPORT_ACTIVE,
     +          YES_CO2_ABATEMENT_REPORT,
     +          CO2_ABATEMENT_REPORT_NOT_OPEN/.TRUE./,
     +          RETROFIT_LOGIC_ACTIVE,
     +          ASCENDING,
     +          GET_NEXT_MRX_RETIREMENT,
     +          RETIRE_CO2_THERMAL_UNIT,
     +          RETROFIT_CO2_THERMAL_UNIT,
     +          GET_NEXT_MRX_RETIRE_RETRO,
     +          R_CO2_END_LIST,
     +          MRX_RETIRE_THIS_UNIT,
     +          GET_THERMAL_RPS_DATA
! 121618
      LOGICAL*1 PUT_THERMAL_RPS_ENRG_CAP,
     +          PUT_RPS_ENRG_CAP
      INTEGER*2 TEMP_RPS_NO,
     +          TEMP_PM
      REAL*4    TEMP_ENRG,
     +          TEMP_CAP
      LOGICAL*4 NEW_CL_UNIT_OPENED,RDI_FILE_EXISTS,
     + temp_l4
C
      INTEGER*2 ! INSTALLED_POINTER/0/,
!     +          TEMP_RETIRED_UNIT_NO(:),
!     +          TEMP_RETIRED_OFF_LINE(:),
     +          MARKETSYM_UNIT,
     +          R_CO2_COUNTER,
     +          R_RETIRE_OR_RETRO,
     +          R_CO2_NUNIT,RR_CO2_NUNIT,
     +          R_CO2_TG,R_CO2_RETIRE_OR_RETRO,
     +          COUNTER,
     +          RETROFIT_ACTIVE_ID,
     +          R_PM,R_ST_TG,I2_RETURN_RESULT,R_ST_P
!      ALLOCATABLE :: TEMP_RETIRED_UNIT_NO,
!     +               TEMP_RETIRED_OFF_LINE
      LOGICAL*1 RETURN_CL_ASSET_CLASS_PROD,RETURN_CL_CLASS_TOTAL_PROD,
     +          RETURN_FE_PNL_EXPENSES
C
C FUNCTION DECLARATIONS
C
      INTEGER*2 PEAK_MONTH ! ,CL_CAPACITY_TEMP_RETIRE_UNIT
C
C     VARIABLES FOR CAPACITY PLANNING
C
      INTEGER*2 UNIT_NO,R_UNIT_NO
      LOGICAL*1 SUBTRACT_IT,REPORT_THIS_CL_UNIT
      INTEGER*2 PT_YR,YEAR_START,YEAR_END,UNIT_OFF_YEAR
      REAL CAP_MW,GET_CLASS_PEAK_NET_DSM_FOR_CAP,FIRST_YEAR_CL_CAPACITY,
     +     R_CAP_MW
C      REAL (KIND=4), ALLOCATABLE :: CL_ANN_CAP(:,:,:), ! MOVED TO MODULE CLA_OBJT_ARRAYS 11/13/06 DR.G
C     +                              CL_TG_CAP(:,:,:,:),
C     +                              NEWGEN_CAP_BY_INDEX(:,:,:),
C     +                              CL_TG_RETIRE(:,:),
C     +                              CL_ANNUAL_LOAD_REDUCTION(:)
C      REAL (KIND=4), ALLOCATABLE :: CL_TG_AFTER_PEAK(:,:)
      REAL GET_CL_TG_CAP,
     +     GET_NEWGEN_CAP_BY_INDEX,
     +     GET_CL_AFTER_PEAK,
     +     GET_CL_TG_RETIRE,
     +     R_CO2_UNIT_MW,
     +     R_CO2_UNIT_MWH,
     +     R_CO2_UNIT_CO2,
     +     R_CO2_UNIT_CO2_AFTER,
     +     R_CO2_UNIT_PRICE,
     +     R_CO2_STRIKE_PRICE,
     +     R_CO2_UNIT_MW_AFTER,
     +     R_CO2_STRIKE_PRICE_AFTER,
     +     Min_Cap_Change,
     +     Max_Cap_Change,
     +     Ave_Heat_Rate_Mult,
     +     CO2_Cntl_Percent,
     +     GET_TOTAL_INCREMENTAL_COST,
     +     R_RPS_CONTRIB
      CHARACTER*2 CL_LOAD_TYPE
      CHARACTER*1 UNIT_ACTIVE,
     +            REPORT_THIS_UNIT(MAX_CL_UNITS),
     +            UTILITY_OWNED,IGNORE_NON_UTILITY,
     +            SAVE_IGNORE_NON_UTILITY/'F'/,
     +            START_UP_LOGIC(MAX_CL_UNITS),R_START_UP_TYPE,
     +            CONTRIBUTES_TO_SPIN(MAX_CL_UNITS),
     +            APPLY_NOX_SEASON_DATE(MAX_CL_UNITS),
     +            MARKET_RESOURCE(MAX_CL_UNITS),
     +            FOR_SEED_OPTIONS,
     +            R_MARKET_RESOURCE_STR,
     +            USE_POLY_HEAT_RATES,
     +            WVPA_RATE_TRACKER(MAX_CL_UNITS),
     +            WVPA_RES_TRACKER(MAX_CL_UNITS),
     +            WVPA_FUEL_TRACKER(MAX_CL_UNITS),
     +            MONTE_OR_FREQ(MAX_CL_UNITS),
     +            WVPA_MEM_TRACKER(MAX_CL_UNITS),
     +            ALLOW_DECOMMIT(MAX_CL_UNITS),
     +            PRIMARY_FUEL_CATEGORY(MAX_CL_UNITS),
     +            SECONDARY_FUEL_CATEGORY(MAX_CL_UNITS),
     +            EMISSIONS_FUEL_CATEGORY(MAX_CL_UNITS),
!     +            RETIREMENT_CANDIDATE(MAX_CL_UNITS), ! MOVED TO GRX_ROUTINES
!     +            RETROFIT_CANDIDATE(MAX_CL_UNITS),  ! MOVED TO GRX_ROUTINES
     +            THERMAL_AGGREGATED_UNIT
!
      LOGICAL*1 GET_START_UP_LOGIC,GET_CL_BASECASE_MARKET_ID,
     +          GET_SPIN_STATUS,
     +          IS_A_MARKET_RESOURCE,
     +          IS_STRICT_MARKET_RESOURCE,
     +          PROCESS_MARKET_RESOURCES,
     +          R_AREA_PRICE,
     +          TEMP_L,
     +          ANNUAL_CALL_PUT_CAPACITY,
     +          YES_ALLOW_DECOMMIT_BY_UNIT,
     +          REGION_OR_STATE_POWER_MAP,
     +          YES_REGION_POWER_MAP,
     +          CLA_UNIT_UP_YESTERDAY(MAX_CL_UNITS),
     +          INIT_CLA_UNIT_UP_YESTERDAY,
     +          GET_CLA_UNIT_UP_YESTERDAY,
     +          PUT_CLA_UNIT_UP_YESTERDAY,
     +          R_LOGICAL
      LOGICAL*1 VOID_LOGICAL,GET_PURCHASE_POWER_ASSIGN,
     +           ZONAL_LEVEL_MARKET,
     +           YES_ZONAL_LEVEL_MARKET,
     +           RESURRECT_RETROFIT_UNIT,
     +           ADJUST_CO2_RETRO_PLAN_CAP,
     +           ADJUST_GRX_CO2_RETRO_PLAN_CAP
      LOGICAL*1 RETURN_ASSET_CLASS_LISTS,PICK_FOR_SEED_OPTIONS,
     +          OLD_ADJ_LOGIC/.TRUE./
      CHARACTER*6    BASECASE_PLANT_ID(MAX_CL_UNITS),
     +               R_EIA_PLANT_CODE,
     +               BASECASE_UNIT_ID,
     +               BASECASE_MARKET_AREA_ID(MAX_CL_UNITS),
     +               R_MARKET_ID,
     +               BASECASE_TRANS_AREA_ID,
     +               BASECASE_PLANT_NERC_SUB_ID,
     +               BASECASE_PLANT_OWNER_ID,
     +               PRIMARY_MOVER_STR(MAX_CL_UNITS)
      LOGICAL*1      CAP_MARKET_ACTIVE,CAP_MARKET_SALE,
     +               INIT_CAP_MARKET_REVENUE,
     +               CALC_CL_CAP_MARKETS,
     +               YES_GSP_IS_ST_TG
      INTEGER*2
     +               CAPACITY_MARKET_POINTER(MAX_CL_UNITS),
     +               CAP_MARKET_MONTH_NO(MAX_CL_UNITS),
     +               CAP_MARKET_MONTH_NO_INDEX,
     +               LOCAL_COLLECTION,
     +               RETROFIT_PROJECT_ID(MAX_CL_UNITS),
     +               RETROFIT_UNIT_INDEX(MAX_CL_UNITS),
     +               RETROFIT_COUNTER,RETIREMENT_COUNTER,
     +               ANN_RETROFIT_COUNTER
      REAL*4         GET_CAP_MARKET_REVENUE,
     +               CAP_MARKET_RATE,
     +               PLAN_FACTOR,
     +               PRIMARY_FUEL_ID,
     +               CAPACITY_MARKET_COIN_ADJ_FACT(MAX_CL_UNITS),
     +               GET_CL_TG_CAP_MARKET_MW,
     +               GET_CL_TG_CAP_MARKET_REV
      CHARACTER*5  MARKET_ID,
     +               CAPACITY_MARKET_TYPE(MAX_CL_UNITS),
     +               CAPACITY_MARKET_MONTH(MAX_CL_UNITS),
     +               CAPACITY_MARKET_EXP_COLLECT(MAX_CL_UNITS)
      CHARACTER*20   CAPACITY_MARKET_COST_ASSIGN(MAX_CL_UNITS),
     +               STATE_PROV_NAME
      CHARACTER*36 THERMAL_GUID
      REAL*4
     +         MON_CAP_SALE_MW_FROM(MAX_CL_UNITS),
     +         MON_CAP_SALE_REV_FROM(MAX_CL_UNITS),
     +         MON_CAP_PUCH_MW_FROM(MAX_CL_UNITS),
     +         MON_CAP_PUCH_COST_FROM(MAX_CL_UNITS),
     +         RPS_CONTRIBUTION_PERCENT(MAX_CL_UNITS),
     +         CO2_PIPELINE_DISTANCE(MAX_CL_UNITS),
     +         CO2_RETRO_HEAT_MULT(MAX_CL_UNITS),
     +         GET_CO2_RETRO_HEAT_MULT,
     +         CO2_RETRO_CAP_MULT(MAX_CL_UNITS),
     +         GET_CO2_RETRO_CAP_MULT
      CHARACTER*20 COUNTY,NEWGEN_UNIT_STATUS
      CHARACTER*25 CL_TRANS_NAME
      REAL UNIT_CAPACITY,
     +     CL_PLANNING_CAPACITY,FIRST_YEAR_CAPACITY,
     +     R_CL_CAP_PLANNING_REMOVALS,
     +     R_CL_CAPACITY_PLANNING_ADDITIONS,
     +     OLD_CL_PLANNING_CAPACITY,NEW_CL_PLANNING_CAPACITY
      REAL CL_CAPACITY_PLANNING_ADJUSTMENTS
      REAL CL_PLANNING_LOAD_REDUCTION
      INTEGER*2 R_YEAR,ST
      INTEGER R_CAP_TYPE
      CHARACTER*6 STATE_PROVINCE,
     +            TEMP_STATE,
     +            STATE_PROVINCE_NAMES(0:MAX_STATE_LOOKUP_IDS),
     +            R_STATE_PROVINCE
      INTEGER*2 POINTER,UNIT_ON_LINE_YEAR,
     +          OPERATION_LIFE,
     +          THIS_YEAR,
     +          STATE_PROVINCE_INDEX(-1:MAX_STATE_LOOKUP_IDS),
     +          STATE_PROVINCE_ADDRESS(MAX_STATE_LOOKUP_IDS),
     +          UNIT_STATE_PROVINCE_INDEX(MAX_CL_UNITS),
     +          UNIT_GAS_REGION_INDEX(MAX_CL_UNITS),
     +          GET_UNIT_GAS_REGION_INDEX,
     +          GET_UNIT_STATE_PROVINCE_INDEX,
     +          MAX_STATE_PROVINCE_NO,
     +          GET_MAX_STATE_PROVINCE_NO,
     +          STATE_ID_LOOKUP,
     +          STATE_2_GAS_REGION_LOOKUP,
     +          GET_STATE_PROVINCE_NAMES
C
      INTEGER*2 R_TRANSACTION_GROUP,
     +          GET_BELONGS_TO_GROUP,
     +          DAY_TYPE_ID(MAX_CL_UNITS),DAY_TYPE_FOR_RESOURCE,
     +          GET_MAX_DAY_TYPES,GET_LAST_DAY_TYPE,
     +          GET_MAX_TRANS_GROUPS,MAX_TRANS_DATA_BASES/0/,
     +          GET_MAX_DATA_BASES,
     +          GET_NUNITS,
     +          MAX_DAY_TYPES/0/,MAX_TRANS_GROUPS,DAY_ID,TRANS_ID,
     +          DAY_TYPE_COUNTER,R_DAY_TYPE,GET_DATA_BASE_FOR_UNIT,
     +          GET_DATA_BASE_FOR_TRANS,R_TRANS_GROUP,
     +          GET_TRANS_FOR_DATA_BASE,
     +          R_DATA_BASE,SET_TRANS_FOR_DATA_BASE,
     +          MAX_TRANS_ID_USED/1/,GET_MAX_TRANS_ID_USED,
     +          UPPER_TRANS_GROUP/0/,GET_NUMBER_OF_ACTIVE_GROUPS,
     +          GET_PURCHASE_ASSET_CLASS_ID,
     +          TG_ASSET_CLASS,TG,GET_TRANS_GROUP_POSITION,
     +          GET_CM_FROM_TG,CM,R_CM,CG,PG,
     +          RPS_COUNT,PX,
     +          GET_RPS_PROGRAM_POSITION,
     +          GET_TRANS_RPS_PROG_NUMBER,
     +          NUMBER_OF_RPS_PROGRAMS,
     +          NUM_TRANS,
     +          GET_NUM_SAVE_ACTIVE_TRANSACTIONS,
     +          GET_NUMBER_OF_CAPACITY_MARKETS,
     +          MONTHLY_FUEL_INDEX(MAX_CL_UNITS),
     +          UNIT_BEG_FO_HR(12),UNIT_END_FO_HR(12),
c     +          CO2_CONTROL_DATE(MAX_CL_UNITS), ! moved to moduel CLA_OBJECT_ARRAYS
     +          HG_CONTROL_DATE(MAX_CL_UNITS),
     +          OTHER3_CONTROL_DATE(MAX_CL_UNITS),
     +          NOX_CONTROL_DATE(MAX_CL_UNITS),
     +          SOX_CONTROL_DATE(MAX_CL_UNITS),
     +          SOX_CONTROL_DATE_TEMP(MAX_CL_UNITS)
      REAL FUEL_MIX_PTR(MAX_CL_UNITS),
     +     PBTUCT_SAVE(MAX_CL_UNITS),
     +     SBTUCT_SAVE(MAX_CL_UNITS),
     +     PRIM_HEAT_CONTENT(MAX_CL_UNITS),
     +     FUELADJ_SAVE(MAX_CL_UNITS),
     +     VCPMWH_IN(MAX_CL_UNITS),
     +     GET_VCPMWH_IN,
     +     FIXED_COST_IN(MAX_CL_UNITS),
     +     GET_FIXED_COST_IN,
     +     VCPMWH_IN_SAVE(MAX_CL_UNITS),
     +     ESCALATE_THERMAL_VOM,
     +     ESCALATE_THERMAL_FOM,
     +     ESCALATED_MONTHLY_VALUE,
     +     START_UP_COST_ESCALATED_MONTHLY_VALUE,
     +     RETURN_VALUE_FROM_ESCALATION_VECTOR,
     +     FIXED_COST_SAVE(MAX_CL_UNITS),
     +     ANNUAL_CL_FIXED_COST_SAVE(MAX_CL_UNITS),
     +     DISPADJ_SAVE(MAX_CL_UNITS),
     +     DISPADJ2_SAVE(MAX_CL_UNITS),
     +     CL_AI_CAPACITY_RATE_SAVE(MAX_CL_UNITS),
     +     CL_AI_ENERGY_RATE_SAVE(MAX_CL_UNITS),
!     +     DISPADJ2_SAVE(MAX_CL_UNITS),
     +     EMISS_FUEL_COST_SAVE(MAX_CL_UNITS),
     +     DISPATCH_MULT_SAVE(MAX_CL_UNITS),
     +     EXCESS_ENERGY_SALES_SAVE(MAX_CL_UNITS),
     +     CL_AI_REMAINING_LIFE_SAVE(MAX_CL_UNITS),
     +     MINIMUM_CAPACITY_FACTOR(MAX_CL_UNITS),
     +     MAXIMUM_CAPACITY_FACTOR(MAX_CL_UNITS),
     +     START_UP_COSTS(MAX_CL_UNITS),
     +     START_UP_COSTS_ESCALATION(MAX_CL_UNITS),  ! 212
     +     GET_MONTHLY_FUEL_INDEX,
     +     GET_UNIT_START_UP_COSTS,
     +     RAMP_RATE(MAX_CL_UNITS),
     +     RAMP_DOWN_RATE(MAX_CL_UNITS),
     +     MIN_DOWN_TIME(MAX_CL_UNITS),
     +     MIN_UP_TIME(MAX_CL_UNITS),
     +     FOR_FREQUENCY(MAX_CL_UNITS),
     +     FOR_DURATION(MAX_CL_UNITS),
     +     GET_P_FUEL_DELIVERY,
     +     GET_P_FUEL_DELIVERY_2,
     +     GET_P_FUEL_DELIVERY_3,
     +     S_FUEL_DELIVERY(MAX_CL_UNITS),GET_S_FUEL_DELIVERY,
     +     S_FUEL_DELIVERY_2(MAX_CL_UNITS),GET_S_FUEL_DELIVERY_2,
     +     S_FUEL_DELIVERY_3(MAX_CL_UNITS),GET_S_FUEL_DELIVERY_3,
     +     CUBIC_HEAT_CURVE(0:3,MAX_CL_UNITS),
     +     R_A_CO,R_B_CO,R_C_CO,R_D_CO,
     +     CONSTANT_POLY,
     +     FIRST_POLY,
     +     SECOND_POLY,
     +     THIRD_POLY,
     +     MIN_SPIN_CAP(MAX_CL_UNITS),
     +     MAX_SPIN_CAP(MAX_CL_UNITS),
     +     GET_MIN_SPIN_CAP,
     +     GET_MAX_SPIN_CAP,
     +     TRANS_ANNUAL_UNSERVED_COST,
     +     WHOLESALE_MARKET_COST,
     +     GET_CL_POOL_FRAC_OWN,
     +     ANNUAL_GROSS_MARGIN(MAX_CL_UNITS,0:3),
!     +     ECON_RETIRE_MARGIN(MAX_CL_UNITS,0:4),
     +     ECON_CO2_RETIRE_PRICE(MAX_CL_UNITS),
     +     ECON_CO2_RETRO_PRICE(MAX_CL_UNITS),
     +     R_GROSS_MARGIN,
     +     SAVE_ANNUAL_GROSS_MARGIN,
     +     GET_ANNUAL_GROSS_MARGIN,
     +     GET_START_UP_COSTS,
     +     GET_RAMP_RATE,
     +     GET_RAMP_DOWN_RATE,
     +     GET_MIN_UP_TIME,
     +     GET_MIN_DOWN_TIME,
     +     GET_FOR_DURATION,
     +     GET_FOR_FREQUENCY,
     +     TEMP_R4,
     +     WINTER_TOTAL_CAPACITY,
     +     R_FUEL_DELIVERY_1,
     +     R_FUEL_DELIVERY_2,
     +     R_FUEL_DELIVERY_3,
     +     GET_FUEL_DELIVERY,
     +     GET_SECOND_FUEL_DELIVERY,
     +     NOX_CONTROL_PERCENT(MAX_CL_UNITS),
     +     SOX_CONTROL_PERCENT(MAX_CL_UNITS),
     +     SOX_CONTROL_PERCENT_TEMP(MAX_CL_UNITS),
     +     EMERGENCY_CAPACITY(MAX_CL_UNITS),
C     +     CO2_CONTROL_PERCENT(MAX_CL_UNITS), ! moved to moduel CLA_OBJECT_ARRAYS
     +     HG_CONTROL_PERCENT(MAX_CL_UNITS),
     +     OTHER3_CONTROL_PERCENT(MAX_CL_UNITS),
     +     GET_EMERGENCY_CAPACITY,
     +     EMERGENCY_HEATRATE(MAX_CL_UNITS),
     +     R_EMERGENCY_HEATRATE,
     +     R_NOX_CONTROL_PERCENT,
     +     R_SOX_CONTROL_PERCENT,
     +     R_CO2_CONTROL_PERCENT,
     +     R_HG_CONTROL_PERCENT,
     +     R_OTHER3_CONTROL_PERCENT,
     +     GET_PBTUCT_SAVE,
     +     GET_DISPADJ_SAVE,
     +     GET_DISPADJ2_SAVE,
     +     GET_MAINTENANCE_RATE_FOR_MONTH,
     +     PERCENT_RETAIL
      INTEGER*2 TEMP_I2,
     +     GET_MARKET_RESOURCE_INDEX,
     +     GET_MARKET_RESOURCE_COUNTER,
     +     MARKET_COUNT/0/,
     +     TWO_BLOCK(2)
C
      LOGICAL*1 OFFSET_MAINTENANCE_VECTORS,OFFSET_MAINTENANCE_ACTIVE,
     +         CALC_ANNUAL_CAP_AND_MAINT,
     +         SAVE_DETAILED_MAINTENANCE,DETAILED_MAINTENANCE_IS_ACTIVE,
     +         DETAIL_MAINTENANCE_NOT_ACTIVE,UPDATE_PERIOD_CAPACITY,
     +         UPDATE_PERIOD_MAINTENANCE,TRANS_GROUP_ACTIVE_SWITCH,
     +         RUN_TRANSACT/.FALSE./,YES_RUN_TRANSACT,
     +         IN_ACTIVE_THERMAL_MARKET_AREA,
     +         UNIT_ON_LINE_IN_YEAR,
     +         GET_CUBIC_HEAT_CURVE,
     +         GET_PW_UNIT_TEXT_FIELDS
      INTEGER*2 J,BASE_DATE,GET_YR,R_I,R_J,LAST_ACTIVE_UNIT,DATE_CHECK,
     +          BASE_YEAR_DATE,LOCAL_YEAR
      REAL  GET_CLASS_PEAK_NET_DSM,PERIOD_RATE,FOR_MT,
     +      MW_CAPACITY,RTEMP,GET_VAR,
     +      MAINTENANCE_RATE(*),
     +      R_MAINTENANCE_RATE(*),
     +      GET_ANNUAL_CL_CAPACITY,
     +      MONTHLY_DISPATCH_COST(2,12),
     +      MONTHLY_CAPACITY(2,12),
     +      LOCAL_COEFF(3)
      INTEGER*2 GGI,MONTHLY_INTEGER(12)
      INTEGER*2 ALLOCATION_VECTOR
      REAL*4 ALLOCATION_VALUE(AVAIL_DATA_YEARS)
      REAL*4 TOTAL_MONTHLY_MAINTENANCE(0:12),
     +       GROUP_MW_MAINTENANCE(0:12,0:MAX_REPORTING_GROUPS)
      REAL*4 UNSCHEDULED_MAINT_HOURS
      LOGICAL*1 FALSE_BYTE/.FALSE./,
     +          STARTS_ONLY/.FALSE./
C
C ASSET CLASS DATA
C
      LOGICAL*1 R_CLASS_EXISTS
      INTEGER*2 RETURN_NUM_CAP_LIMITED_CLASSES,
     +          R_MAX_CAP_LIMITED_CLASS_NUM,
     +          RETURN_CAP_LIMITED_POINTER,
c     +          R_CAP_LIMITED_CLASS_POINTERS(*),
     +          R_CLASS,CLASS,R_FT,R_ST,R_TG
      INTEGER*2 GET_CL_ASSET_CLASS_INFO,
     +          ASSET_CLASS_NUM(MAX_CL_UNITS),
     +          ASSET_CLASS_VECTOR(MAX_CL_UNITS),
     +          INTRA_COMPANY_CLASS_ID(MAX_CL_UNITS)
      INTEGER*2 R_ASSET_CLASS_NUM(*),
     +          R_ASSET_VECTOR(*),
     +          R_ASSET_CLASS,
     +          R_ALLOCATION_VECTOR,
     +          R_CL_RESOURCE_ID,
     +          GET_ASSET_CLASS_NUM,
     +          NUM_FUEL_CATEGORIES/11/  ! 12/13/01.
! NUM_FUEL_CATEGORIES   1 = COAL
!                       2 = GAS
!                       3 = OIL
!                       4 = NUCLEAR
!                       5 = WATER
!                       6 = OTHER
!                       7-9 = RESERVED
!                       10 =  WHOLESALE SALES
!                       11 =  WHOLESALE PURCHASES
      CHARACTER*20 SPECIAL_ID_NAME
      REAL R_NUC_FUEL_LEASED,
     +     R_NUC_FUEL_OWNED,
     +     R_NUC_FUEL_OWNED_BURN,
     +     R_NUC_FUEL_LEASED_BURN,
     +     R_NF_BURN_IN_RATEBASE,
     +     R_PURCHASE_POWER_EXPENSE,
     +     R_FUEL_COST,
     +     R_VOM_COST,
     +     R_VARIABLE_EXPENSE,
     +     R_FIXED_EXPENSE,
     +     R_EXPENSE_COLLECTED_ADJ_CLAUSE,
     +     R_EXPENSE_COLLECTED_BASE_RATES,
     +     R_NOT_COLLECTED_IN_RATES,
     +     R_TOTAL_SALES_REVENUE,
     +     R_SALES_REVENUE_NOT_IN_RATES,
     +     R_BTL_SALES_REVENUE,
     +     R_BTL_EXPENSES
      INTEGER*2 NUMBER_OF_CAP_LIMITED_CLASSES,
     +	       MAX_CAP_LIMITED_CLASS_ID_NUM,
     +          RETURN_MAX_CL_CLASS_NUM
C
      LOGICAL*1   MAINTENANCE_REPORT_NOT_OPEN/.TRUE./,
     +            MAINTENANCE_REPORT,
     +            YES_UNIT_COMMITMENT_LOGIC,
     +            ECITIES/.FALSE./,YES_ECITIES_UNITS_ACTIVE,
     +            ECITY_COMPANY,
     +            POWER_DERIV_REV_EXP_BY_CLASS
      REAL RETURN_ECITIES_OBJ_VARS
      INTEGER*2   CL_MAINT_NO,MAINTENANCE_HEADER,BEGIN_DATE
      INTEGER CL_MAINT_REC
      REAL        DAYS_PER_MONTH(13)/31.,28.,31.,30.,31.,30.,31.,31.,
     +                               30.,31.,30.,31.,365./
C
      INTEGER*2 RETURN_CL_FUEL_POINTERS,UPDATE_PRIMARY_FUEL_MIX_RATIO,
     +          FIRST_YEAR_PRICE_MODE/19999/,
     +          GET_FIRST_YEAR_PRICE_MODE

      INTEGER*2 R_P_BTU_COST_POINTR(*),
     +          R_S_BTU_COST_POINTR(*),
     +          R_E_BTU_COST_POINTR(*)
C
      INTEGER*2   UPDATE_PR_ESCALATIONS,ESCALATE_ONE_VALUE,VOID_INT2,
     +            R_POINTER,ASSET_ALLOCATION_VECTOR,
     +            ESCALATE_ONE_VALUE_FOR_ADDITIONS
      INTEGER*2 CURRENT_YEAR,CURRENT_YEAR_COMPARISON,UNUM,ASSET_CLASS,
     +          CLASS_POINTER,COLLECTION,EXPENSE_GROUP
      CHARACTER*1 DUMMY_TYPE
      INTEGER*2 CL_EXPENSES_2_ASSET_CLASSES,
     +          MON_MDS_CL_EXP_2_AC,
     +          RETURN_CL_ASSET_CLASS_EXPENSES,
     +          RETURN_NUC_CL_ASSET_CLASS_EXPENSES,
     +          RETURN_MONTHLY_NF_OP_EXPENSES,
     +          SET_UP_CL_CLASS_ARRAYS,
     +          ZERO_CL_CLASS_ARRAYS,
     +          RETURN_AMEREN_CL_CLASS_EXPENSES
      REAL*4   EL_BASE_REVENUE_RATE,EL_PEAK_REVENUE_RATE,
     +         R_NUC_UNIT_FUEL_ADDER_COST
      REAL*4 EL_BASE_RATE,EL_PEAK_RATE,
     +       BASE_MARKET_ENRG_SALES,
     +       BASE_MARKET_REVENUES,
     +       PEAK_MARKET_ENRG_SALES,
     +       PEAK_MARKET_REVENUES
      REAL GET_CL_EMISSIONS,GET_CL_EMISS_FOR_CLASS
      REAL ASSET_ALLOCATOR
      INTEGER*2 R_EMISS_TYPE
      REAL R_CLASS_CL_EMISSIONS(NUMBER_OF_EMISSION_TYPES),
     +     R_MONTH_AC_WHOLESALE_PROD_COST(0:12),
     +     R_MONTH_AC_ECITY_VAR_PROD_COST(0:12),
     +     R_MONTH_AC_ECITY_NEW_FIX_COST(0:12),
     +     R_WTB(0:12),
     +     R_MONTH_AC_ECITY_SUPP(0:12),
     +     R_MONTH_AC_ECITY_REVENUE(0:12),
     +     R_MONTH_AC_ECITY_FEES(0:12),
     +     R_ECITIES_WHOLESALE_PROD_COST,
     +     R_ECITIES_VAR_PROD_COST,
     +     R_ECITIES_NEW_FIXED_COST,
     +     R_ECITIES_MARKET_ENERGY_SALES,
     +     R_ECITIES_TRANSMISSION_FEES,
     +     TOTAL_DERIV_REV,
     +     TOTAL_DERIV_EXP,
     +     WHOLESALE_PRODUCTION_COST,
     +     TOTAL_VARIABLE_COST,
     +     AVERAGE_PRODUCTION_COSTS
!
      LOGICAL*1 SHADOW_UNITS_ACTIVE
      INTEGER*2 MO,MY_SHADOW,NUM_OF_NUCLEAR_UNITS
C
      LOGICAL*1 ACCUMULATE_MAINTENANCE,MAINTENANCE_IS_ACCUMULATED
      REAL*4 TEMP_CL_MAINTENANCE,MAINTENANCE_CAPACITY
      INTEGER*2 MW_MAINT_NO
      INTEGER MW_MAINT_REC
      CHARACTER*9 GROUP_NAME(0:MAX_REPORTING_GROUPS)/'Group 0',
     +           'Group 1','Group 2','Group 3','Group 4','Group 5',
     +           'Group 6','Group 7','Group 8','Group 9','Group 10',
     +           'Group 11','Group 12','Group 13','Group 14','Group 15'/
C
C DOE AND DECOMMISSIONING VARIABLES
C
      LOGICAL*1 GET_BLOCK_CAP_FACTORS
      INTEGER*2 R_NBLOK2
      REAL*4 MMBTU_ENERGY,MWH_ENERGY,
     +       R_DOE_NUC_FUEL_FEE,DOE_NF_DISPOSAL_COST,
     +       R_NUC_DECOMMISSIONING_COST,NUCLEAR_DECOMMISSIONING_COST,
     +       R_DOE_R300_DISPOSAL_COST,DOE_R300_DISPOSAL_COST,
     +       NUC_MAINTENANCE(12),
     +       R_LOWER_BOUND_CAP_FACTOR(*),R_UPPER_BOUND_CAP_FACTOR(*),
     +       R_FACET_MAINTENANCE_RATE(*),
     +       R_CL_ANN_CLASS_CAPACITY(4),
     +       R_CL_ANN_CLASS_ENERGY(4),
     +       R_CL_ANN_TOTAL_CLASS_CAPACITY,
     +       R_CL_ANN_TOTAL_CLASS_ENERGY,
     +       R_NUC_ENERGY,
     +       R_STEAM_ENERGY,
     +       R_PURCHASES_ENERGY,
     +       R_ASSET_CLASS_900,
     +       R_WHOLESALE_FUEL_EXPENSE,
     +       R_WHOLESALE_VOM_EXPENSE,
     +       R_ICAP_REVENUES
      REAL*8 R_MMBTU_FUEL_BALANCE(*)
      INTEGER*2 FUEL_ID,UNITNO,R_FUEL_INVENTORY_ID(0:*)
      CHARACTER*6 PRIM_FUEL_TYPE_STR,TEMP_PRIM_FUEL_TYPE_STR
      LOGICAL*1 NUC_FUEL_PRICES_FROM_FUEL_FILE(MAX_CL_UNITS),
     +          NUC_FUEL_PRICE_SOURCE_IS_NFILE,
     +          TF_FILE_EXISTS,TG_FILE_EXISTS
      CHARACTER*20      RDI_COMPANY_NAME,
     +                  RDI_NERC_REGION,
     +                  RDI_SUB_REGION,
     +                  RDI_PM_ABBREV,
     +                  RDI_PRIME_FUEL
      CHARACTER*30      RDI_DESC,CO2_BASIN_NAME
      REAL*4      RDI_DEMONSTRATED_CAPACITY_MW,
     +            RDI_INCREMENTAL_FUEL_$MWH,
     +            RDI_AVERAGE_HEAT_RATE

!
! GADS DATA BASE FOR FOR'S AND MOR'S
!
      INTEGER*2 RDI_SIZE_INDEX,RDI_FUEL_INDEX,GET_PRIMARY_MOVER,
     +          FUEL_TYPE_2_PRIM_MOVER
      REAL*4 GADS_FOR(8,5), GADS_MOR(8,5)
!
! UNIT SIZES (MW) 1-99 100-199 200-299 300-399 400-599 600-799 800-1000 1000+
!
      DATA GADS_FOR/ 0.1045,0.1086,0.1240,0.1472,0.1444,
     +               0.1254,0.1253,0.1555, ! COAL
     +               0.0758,0.1260,0.1061,0.1465,0.1423,
     +               0.1663,0.1154,0.1154, ! OIL
     +               0.1450,0.1450,0.1450,0.1450,0.1450,
     +               0.1450,0.1585,0.2106,! NUCLEAR (PWR)
     +               0.0641,0.1052,0.1241,0.1706,0.1322,
     +               0.1697,0.0804,0.0804,! GAS
     +               0.1241,0.1241,0.1241,0.1241,0.1241,
     +               0.1241,0.1241,0.1241/! LIGNITE
     +     GADS_MOR/ 1.1,1.3,1.3,1.3,1.3,0.7,0.6,1.4, ! COAL
     +               0.8,1.0,1.0,2.3,1.3,1.2,0.7,0.7, ! OIL
     +               6.7,6.7,6.7,6.7,6.7,6.7,6.7,6.7, ! NUCLEAR (PWR)
     +               1.3,1.6,1.5,2.0,1.8,1.6,1.5,1.5, ! GAS
     +               0.9,0.9,0.9,0.9,0.9,0.9,0.9,0.9/ ! LIGNITE
! MOVED 5/26/98. GAT.
      LOGICAL*1 BASE_EL_REVENUE_CASE,
     +             PEAK_EL_REVENUE_CASE
      REAL*4   GET_HESI_UNIT_ID_NUM,GET_POWERDAT_PLANT_ID,
     +         R_HESI_SECOND_UNIT_ID_NUM

      INTEGER*8   ! HESI_UNIT_ID_NUM(MAX_CL_UNITS),
     +            TEMP_I8,R_I8_ID,
     +            TRANS_BUS_ID(MAX_CL_UNITS),
     +            THERMAL_PARENT_ID
      INTEGER     ! H2_UNIT_ID_NUM,
     +            POWERDAT_PLANT_ID(MAX_CL_UNITS),
     +            GET_HESI_UNIT_ID_NUM_I4,I4,HIGHEST_ID
!
      LOGICAL*1 CLA_SPECIAL_ID_NAME,CLA_RETURN_UNITNM
      CHARACTER*20 R_NAME
      INTEGER*2 ON_LINE_MONTH_TEMP
!
! 06/13/03. FOR THE ECITY REPORT
!
      LOGICAL*1 ECITY_OBJ_REPORT,
     +          ECITY_OBJ_REPORT_NOT_OPEN/.TRUE./
      INTEGER*2 ECITY_VARIABLE_NUMBER,
     +          ECITY_OBJ_UNIT,
     +          ECITY_OBJ_HEADER
      INTEGER   ECITY_OBJ_REC
      CHARACTER*9 CL_MONTH_NAME(14)
     +                         /'January  ','February ',
     +                          'March    ','April    ',
     +                          'May      ','June     ',
     +                          'July     ','August   ',
     +                          'September','October  ',
     +                          'November ','December ',
     +                          'Annual   ','Fiscal Yr'/
!
C
C MULTI-FILE VARIABLES
C
      LOGICAL*1 PROCESSING_FIRST_DATA_FILE
      INTEGER*2 MAX_CL_FILES/36/
      INTEGER   FILE_ID
      INTEGER*4 UNIQUE_ID_NUM,CL_UNIT_UNIQUE_RPT_ID(MAX_CL_UNITS)
      INTEGER*4 UNIQUE_REPORT_VALUE_FOR_CL_UNIT
      LOGICAL*1 TRANSACT_ACTIVE_IN_ENDPOINT
      INTEGER*2 RETURN_MONTHLY_CL_CASH_EXPENSES
      INTEGER*2 RETURN_MONTHLY_CL_REVENUES
      INTEGER*2 RETURN_MONTHLY_CL_CASH_REVENUES
C
C FE P&L VARIABLES
C
      REAL*4 R_PNL_FUEL_COST(*),
     +       R_PNL_PURCHASE_POWER_EXPENSE(*),
     +       R_PNL_VARIABLE_EXPENSE(*),
     +       R_PNL_FIXED_EXPENSE(*),
     +       R_PNL_TOTAL_SALES_REVENUE(*),
     +       R_PNL_CL_ANN_TOTAL_CLASS_ENERGY(*),
     +       R_PNL_CL_ANN_CLASS_CAPACITY(*),
     +       R_BAY_SHORE_FUEL_EXPENSE
      LOGICAL (KIND=4) :: EFORS0=.FALSE., SORS0=.FALSE.
C SPCapEx Additions Nov. 2005
         LOGICAL (KIND=1) :: SP_CAPEX_ACTIVE
         CHARACTER (LEN=1) :: PHASE_I_STR
         INTEGER (KIND=2) :: ID,UNIT_NAME_COUNT(MAX_CL_UNITS)
         CHARACTER (LEN=46) :: UNIT_NAME
         CHARACTER (LEN=48) :: TEMP_UNIT_NAME
         REAL (KIND=4) :: CL_CAPACITY_PLANNING_REMOVALS
         INTEGER (KIND=2) :: GET_MARKET_PRICE_YEAR
c END SPCapEx Additions
C
C ADDITONS TO CREATE CL FILE OF RESOURCES ADDTIONS 12/06/06 DR.G
C
      CHARACTER (LEN=4096) :: RECLN
      CHARACTER (LEN=256) :: BASE_FILE_DIRECTORY
      INTEGER (KIND=2) :: YEAR_CHECK,YR
      INTEGER (KIND=2) :: END_POINT_CHECK=-999,
     +                    SEQU_NO
      LOGICAL (KIND=1) :: MRX_TEXT_FILE_NOT_OPEN=.TRUE.,
     +                    VECTOR_IS_VALUE
      LOGICAL (KIND=4) :: MRX_TEXT_FILE_OPEN=.FALSE.
      CHARACTER (LEN=2) :: CAPACITY_PLANNING_METHOD,GREEN_MRX_METHOD,
     +                     UNIT_TYPE,UNIT_TYPE_CATEGORY
      CHARACTER (LEN=18) :: TEMP_EXPENSE_ASSIGNMENT,
     +                      TEMP_EXPENSE_COLLECTION
      CHARACTER (LEN=10) :: TEMP_SEC_FUEL_TYPE,
     +                      TEMP_EMISS_FUEL_TYPE
      CHARACTER (LEN=3) :: TEMP_INTRA_COMPANY_TRANSACTION
      CHARACTER (LEN=15) :: TEMP_UTILITY_OWNED
      CHARACTER (LEN=6) :: TEMP_MARKET_RESOURCE

      CHARACTER (LEN=9) :: TEMP_START_UP_LOGIC,
     +                     TEMP_EMISSION_DATA_UNITS
      CHARACTER (LEN=5) :: TEMP_UNIT_ACTIVE,
     +                     TEMP_REPORT_THIS_UNIT,
     +                     TEMP_CONTRIBUTES_TO_SPIN,
     +                     TEMP_APPLY_NOX_SEASON_DATE,
     +                     TEMP_ALLOW_DECOMMIT,
     +                     TEMP_USE_POLY_HEAT_RATES,
     +                     TEMP_AGGREGATE_THIS_UNIT,
     +                     TEMP_LINKED_BETTERMENT_OPTION
      CHARACTER (LEN=20) :: TEMP_WVPA_RATE_TRACKER,
     +                      TEMP_WVPA_RES_TRACKER,
     +                      TEMP_WVPA_FUEL_TRACKER,
     +                      TEMP_MONTE_OR_FREQ,
     +                      TEMP_WVPA_MEM_TRACKER,
     +                      TEMP_PRIMARY_FUEL_CATEGORY,
     +                      TEMP_SECONDARY_FUEL_CATEGORY,
     +                      TEMP_EMISSIONS_FUEL_CATEGORY,
     +                      TEMP_RETIREMENT_CANDIDATE,
     +                      TEMP_RETROFIT_CANDIDATE
      REAL (KIND=4) :: ESCAL_RATE
      CHARACTER*30 SCREEN_OUTPUT
!
C END RESOURCE VARIABLE.
C
C START OF SAVE AREA
C
c      SAVE MAX_INTRA_CLASS
c      SAVE INTRA_FOSSIL_FUEL_EXPENSES,
c     +     INTRA_LEASED_NUC_FUEL_EXPENSES,
c     +     INTRA_OWNED_NUC_FUEL_EXPENSES,
c     +     INTRA_PURCHASE_EXPENSES,
c     +     INTRA_NUC_LEASE_BURN
c      SAVE TEMP_RETIRED_UNIT_NO,
c     +     TEMP_RETIRED_OFF_LINE,
c     +     PRIMARY_MOVER,
c     +     START_UP_INDEX,
c     +     RESOURCE_ID_TO_UNIT,
c     +     NUMBER_OF_RESOURCE_ID
c      SAVE PBTUCT_SAVE,
c     +     SBTUCT_SAVE,
c     +     FUELADJ_SAVE,
c     +     VCPMWH_IN_SAVE,
c     +     FIXED_COST_SAVE,
c     +     ANNUAL_CL_FIXED_COST_SAVE,
c     +     DISPADJ_SAVE,
c     +     CL_AI_CAPACITY_RATE_SAVE,
c     +     CL_AI_ENERGY_RATE_SAVE,
c     +     DISPADJ2_SAVE,
c     +     EMISS_FUEL_COST_SAVE,
c     +     DISPATCH_MULT_SAVE,
c     +     EXCESS_ENERGY_SALES_SAVE,
c     +     CL_AI_REMAINING_LIFE_SAVE,
c     +     MINIMUM_CAPACITY_FACTOR,
c     +     MAXIMUM_CAPACITY_FACTOR,
c     +     TRANSACTION_GROUP_ID,
c     +     DAY_TYPE_ID,
c     +     DAY_TYPE_TRANS_GROUP_PAIR,
c     +     DATA_BASE_POSITION,
c     +     TRANS_GROUP_FOR_DATA_BASE,
c     +     PURCHASE_ASSET_CLASS_ID,
c     +     PURCHASE_POWER_ASSIGN,
c     +     REPORT_THIS_UNIT,
c     +     START_UP_COSTS,
c     +     START_UP_LOGIC,
c     +     RAMP_RATE,
c     +     MIN_DOWN_TIME,
c     +     MIN_UP_TIME,
c     +     FOR_FREQUENCY,
c     +     FOR_DURATION,
c     +     P_FUEL_DELIVERY,
c     +     P_FUEL_DELIVERY_2,
c     +     P_FUEL_DELIVERY_3,
c     +     LOCAL_CL_POOL_FRAC_OWN,
c     +     ANNUAL_GROSS_MARGIN
c      SAVE CL_ANN_CAP,ON_LINE_MONTH,ON_LINE_YEAR,
c     +     OFF_LINE_MONTH,OFF_LINE_YEAR,CL_ANNUAL_LOAD_REDUCTION,
c     +     MONTHLY_FUEL_INDEX
c      SAVE ANNUAL_CL_CAPACITY,ANNUAL_CL_MAINTENANCE,
c     +      SAVE_DETAILED_MAINTENANCE,ANNUAL_CL_MAINT_MW,MAINT_DAYS,
c     +      MAINT_DIVISIBLE
c      SAVE ASSET_CLASS_NUM,
c     +     ASSET_CLASS_VECTOR,
c     +     INTRA_COMPANY_CLASS_ID,
c     +     INTRA_COMPANY_TRANSACTION,
c     +     SPECIAL_UNIT_ID
c      SAVE NUMBER_OF_CAP_LIMITED_CLASSES,
c     +	  MAX_CAP_LIMITED_CLASS_ID_NUM,
c     +     CAP_LIMITED_CLASS_POINTER
c      SAVE CL_MAINT_NO,CL_MAINT_REC
c      SAVE EL_BASE_RATE,EL_PEAK_RATE
c      SAVE CL_UNIT_UNIQUE_RPT_ID
c      SAVE ASSET_CLASS_POINTER,
c     +     CL_ANN_CLASS_FUEL_COST,
c     +     NF_FUEL_LEASED_BY_CLASS,
c     +     NF_FUEL_OWNED_BY_CLASS,
c     +     NUC_FUEL_LEASED_BURN_BY_CLASS,
c     +     NUC_FUEL_OWNED_BURN_BY_CLASS,
c     +     NUCLEAR_MWH_BY_CLASS,
c     +     NUCLEAR_MMBTU_BY_CLASS,
c     +     CL_ANN_CLASS_VAR_COST,
c     +     CL_ANN_CLASS_FIXED_COST,
c     +     CL_ANN_CLASS_REVENUE,
c     +     CL_ANN_CLASS_CAPACITY,
c     +     CL_ANN_CLASS_PURCHASES,
c     +     CL_ANN_CLASS_ENERGY,
c     +     CL_ANN_CLASS_EMISSIONS,
c     +     INTRA_COMPANY_REVENUES,
c     +     INTRA_COMPANY_NF_BURN,
c     +     MON_MDS_CL_CLASS_FUEL_COST,
c     +     MON_MDS_CL_CLASS_VAR_COST,
c     +     MON_MDS_CL_CLASS_FIXED_COST,
c     +     MON_MDS_CL_CLASS_REVENUE,
c     +     MON_MDS_CL_CLASS_CAPACITY,
c     +     MON_MDS_CL_CLASS_PURCHASES,
c     +     MON_MDS_CL_CLASS_ENERGY,
c     +     MON_MDS_CL_CLASS_EMISSIONS,
c     +     MON_MDS_INTRA_COMPANY_REVENUES,
c     +     MON_MDS_INTRA_COMPANY_NF_BURN,
c     +     MON_MDS_NF_FUEL_LEASED_BC,
c     +     MON_MDS_NF_FUEL_OWNED_BC,
c     +     MON_MDS_NUC_FUEL_LEASE_BURN_BC,
c     +     MON_MDS_NUC_FUEL_OWNED_BURN_BC,
c     +     MON_MDS_NUCLEAR_MWH_BY_CLASS,
c     +     MON_MDS_NUCLEAR_MMBTU_BY_CLASS
cC
c      SAVE MW_MAINT_NO,MW_MAINT_REC
c      SAVE NUC_FUEL_PRICES_FROM_FUEL_FILE
c      SAVE MON_MDS_CL_UNIT_EMISSIONS,
c     +     MON_MDS_CL_UNIT_CAPACITY,
c     +     MON_MDS_CL_UNIT_ENERGY,
c     +     MON_MDS_CL_UNIT_FUEL_COST,
c     +     MON_MDS_CL_UNIT_VAR_COST,
c     +     MON_MDS_CL_UNIT_FIXED_COST,
c     +     MON_MDS_NUC_FUEL_ADDER_COST,
c     +     MON_MDS_ECO_SALES_REV_FROM,
c     +     MON_MDS_ECO_SALES_ENRG_FROM,
c     +     MON_MDS_ECO_PUCH_COST_FROM,
c     +     MON_MDS_ECO_PUCH_ENRG_FROM,
c     +     MON_MDS_CL_UNIT_MMBTUS
c      SAVE MAINT_INDEX_MW,MAINT_INDEX,
c     +     MAINT_INDEX_DAYS,
c     +     MAINT_INDEX_MONTHLY_MW
C
C END OF DATA DECLARATIONS
C
      UPPER_TRANS_GROUP = GET_NUMBER_OF_ACTIVE_GROUPS()
      CapEx_Running = YES_POWERWORLD_REPORT()
      UNIT_NAME_COUNT = 0
      INSTALLED_POINTER = 0
!
      BEGIN_DATE = 100.*(BASE_YEAR+1-1900)
!
!
! 9/25/02. FOR REGIONAL MAINTENANCE PLANNING
!
      MAX_PLANNING_AREAS = GET_NUMBER_OF_PLANNING_GROUPS()
!
!      IF(ALLOCATED(LAST_UNIT_FOR_PA)) DEALLOCATE(LAST_UNIT_FOR_PA)
!      ALLOCATE(LAST_UNIT_FOR_PA(0:MAX_PLANNING_AREAS))
!      LAST_UNIT_FOR_PA = 0
!
!      REGIONAL_MAINT_SCHEDULING = .FALSE. ! NEED A SWITCH IN PROD PARAMETERS
      REGIONAL_PA_MAINT_SCHEDULING = REGIONAL_PA_MAINTENANCE_LOGIC()
      REGIONAL_TG_MAINT_SCHEDULING = REGIONAL_TG_MAINTENANCE_LOGIC()
      IF(REGIONAL_PA_MAINT_SCHEDULING) THEN
         MAX_MAINT_PLANNING_AREAS = MAX_PLANNING_AREAS
      ELSEIF(REGIONAL_TG_MAINT_SCHEDULING) THEN
         MAX_MAINT_PLANNING_AREAS = UPPER_TRANS_GROUP
      ELSE
         MAX_MAINT_PLANNING_AREAS = 1
      ENDIF
!
      MAX_TRANS_GROUPS = 256
      MAX_DAY_TYPES = MIN(GET_MAX_DAY_TYPES(),GET_LAST_DAY_TYPE())
      IF(ALLOCATED(TG_2_PLANNING_AREA)) DEALLOCATE(TG_2_PLANNING_AREA)
      ALLOCATE(TG_2_PLANNING_AREA(0:MAX(1,UPPER_TRANS_GROUP)))
      IF(ALLOCATED(DAY_TYPE_TRANS_GROUP_PAIR))
     +          DEALLOCATE(DAY_TYPE_TRANS_GROUP_PAIR,DATA_BASE_POSITION)
      ALLOCATE(DAY_TYPE_TRANS_GROUP_PAIR(MAX_DAY_TYPES,
     +                                              0:MAX_TRANS_GROUPS))
      ALLOCATE(DATA_BASE_POSITION(2*MAX_DAY_TYPES,MAX_CL_UNITS))
      IF(ALLOCATED(MAINT_DAYS)) DEALLOCATE(MAINT_DAYS)
      ALLOCATE(MAINT_DAYS(MAX_CL_UNITS))
      IF(ALLOCATED(CL_ANN_CAP)) DEALLOCATE(CL_ANN_CAP,CL_TG_CAP,
     +                                     CL_TG_AFTER_PEAK,
     +                                     CL_TG_RETIRE,
     +                                     NEWGEN_CAP_BY_INDEX,
     +                                     CL_TG_CAP_MARKET_MW,
     +                                     CL_TG_CAP_MARKET_REV)
      ALLOCATE(CL_ANN_CAP(3,STUDY_PERIOD,2))
      ALLOCATE(CL_TG_CAP(0:6,0:MAX(1,UPPER_TRANS_GROUP),STUDY_PERIOD,2))
      ALLOCATE(NEWGEN_CAP_BY_INDEX(MAX_NEWGEN_INDEX,
     +                                   0:MAX(1,UPPER_TRANS_GROUP),
     +                                                  STUDY_PERIOD))
      ALLOCATE(CL_TG_AFTER_PEAK(0:UPPER_TRANS_GROUP,STUDY_PERIOD))
      ALLOCATE(CL_TG_CAP_MARKET_MW(0:UPPER_TRANS_GROUP),
     +         CL_TG_CAP_MARKET_REV(0:UPPER_TRANS_GROUP))
      ALLOCATE(CL_TG_RETIRE(0:UPPER_TRANS_GROUP,STUDY_PERIOD))
      IF(ALLOCATED(CL_ANNUAL_LOAD_REDUCTION))
     +         DEALLOCATE(CL_ANNUAL_LOAD_REDUCTION)
      ALLOCATE(CL_ANNUAL_LOAD_REDUCTION(STUDY_PERIOD))
      HIGHEST_ID = 1
!
      UNIT_FREQUENCY_DURATION = .FALSE.
!
      ZONAL_LEVEL_MARKET = YES_ZONAL_LEVEL_MARKET()
!
      UNIT_STATE_PROVINCE_INDEX = 0
      UNIT_GAS_REGION_INDEX = 0
      STATE_PROVINCE_INDEX = 0
      STATE_PROVINCE_ADDRESS = 0
      MAX_STATE_PROVINCE_NO = 0
      STATE_PROVINCE_NAMES(0) = "NA "
!
! 112307. HARD-WIRED TO FALSE FOR INTEGRATED PRICING
!
!      YES_REGION_POWER_MAP = .TRUE. ! REGION_OR_STATE_POWER_MAP()

!
      YES_AOD_PRICE_THERM_VALUE_LIST =
     +        AOD_THERMAL_UNIT_VALUE_LIST(YES_AOD_COMP_THERM_VALUE_LIST)
!
! 01/23/03.
      TURN_OFF_POLY = YES_TURN_OFF_POLY()
! 05/16/03.
      NEW_BUILD_ADDITIONS_ACTIVE = YES_NEW_BUILD_ADDITIONS_ACTIVE()
      IF(NEW_BUILD_ADDITIONS_ACTIVE) THEN
         TEMP_L = GET_NEW_BUILD_PERCENTS(
     +                              UNDER_CONSTRUCTION_PERCENT,
     +                              ADVANCED_DEVELOPMENT_PERCENT,
     +                              EARLY_DEVELOPMENT_PERCENT,
     +                              PROPOSED_PERCENT,
     +                              INDEFIN_POSTPHONED_PERCENT)
      ENDIF
!      IF(REGIONAL_MAINT_SCHEDULING) THEN
!
      TG_2_PLANNING_AREA = 0
      DO TG = 1, UPPER_TRANS_GROUP
!
         TG_2_PLANNING_AREA(TG) = GET_PA_FROM_TG(TG)
!
      ENDDO
!      ENDIF
!
      RETROFIT_ACTIVE = .FALSE.
      NEWGEN_INDEX = -1
      NEWGEN_COUNTER = 0
!
!      CALL CINITW(START_UP_INDEX,INT(MAX_CL_UNITS),0)
      START_UP_INDEX= 0
!
!      CALL CINITW(RESOURCE_ID_TO_UNIT,INT(MAX_RESOURCE_ID_NO+1),0)
      RESOURCE_ID_TO_UNIT = 0
!      CALL CINITW(NUMBER_OF_RESOURCE_ID,INT(MAX_RESOURCE_ID_NO+1),0)
      NUMBER_OF_RESOURCE_ID = 0
!
      ANNUAL_GROSS_MARGIN = 0.
      ECON_RETIRE_MARGIN = 0.
!
      CALL RESET_NUCLEAR_UNIT_COUNTER()
!
      MONTHLY_MUST_RUN_VECTOR = 0
      MONTHLY_DECOMMIT_VECTOR = 0
      EMISSION_MARKET_LINK = 0
      CO2_RETRO_CAP_MULT = 0.0
!
C
      MAX_DAY_TYPES = MIN(GET_MAX_DAY_TYPES(),GET_LAST_DAY_TYPE())
!
!
!
!      MAX_TRANS_GROUPS = GET_MAX_TRANS_GROUPS()
      DAY_TYPE_TRANS_GROUP_PAIR = 0
      DATA_BASE_POSITION = 0.
!
!     TRACKING CENTRAL DISPATCHING FOR EVERY DAY TYPE ACROSS TRANSACTION GROUPS
!
      MAX_TRANS_DATA_BASES = MAX_DAY_TYPES
      DO M = 1, MAX_DAY_TYPES
         DAY_TYPE_TRANS_GROUP_PAIR(M,0) = M
      ENDDO
!
      SAVE_DETAILED_MAINTENANCE = .FALSE.
!
      CALL DOES_RDI_FILE_EXIST(RDI_FILE_EXISTS)
      IF(RDI_FILE_EXISTS) THEN
         CALL GET_NUM_OF_RDI_CL_RECORDS(RDI_RECORDS,RDI_CL_RECORDS)
         IF(RDI_CL_RECORDS > 0) THEN
            CALL OPEN_RDI_CL_FILES(RDI_IN_UNIT,RDI_OUT_UNIT)
            WRITE(RDI_OUT_UNIT,*) "9, "
         ENDIF
      ELSE
         RDI_RECORDS = 0
         RDI_CL_RECORDS = 0
      ENDIF
C removed 4/17/01 because if ther isn't any CL files the bottom of
C the file loop will set these values.
c     CALL OPEN_CL_FILE(INT2(10),CL_RECORDS,0)
c     IF(CL_RECORDS < 1 .AND. RDI_RECORDS < 1) THEN
c        BASE_CL_UNITS = 0
c        AVAILABLE_CL_UNITS = 0
c        BASE_PLUS_HARDWIRED_CL_UNITS = 0
c        CL_UNITS_READ = 0
c        RETURN
c     ENDIF
C
      SAVE_IGNORE_NON_UTILITY = IGNORE_NON_UTILITY()
C
      CALL RETURN_NUCLEAR_UNITS_ACTIVE(NUM_OF_NUCLEAR_UNITS)
      IF(NUM_OF_NUCLEAR_UNITS > 0) THEN
         CALL SETUP_GENERATING_INFORMATION(NUM_OF_NUCLEAR_UNITS)
      ENDIF
C
!
      CUBIC_HEAT_CURVE = 0.
!
      CL_ANN_CAP = 0.
      CL_TG_CAP = 0.
      NEWGEN_CAP_BY_INDEX = 0.
      CL_TG_AFTER_PEAK = 0.
      CL_TG_RETIRE = 0.
      RETROFIT_ACTIVE = .FALSE.
      PRIM_HEAT_CONTENT = 0.
      NOX_CONTROL_PERCENT = 0.
      SOX_CONTROL_PERCENT = 0.
      CO2_CONTROL_PERCENT = 0.
      HG_CONTROL_PERCENT = 0.
      OTHER3_CONTROL_PERCENT = 0
      CO2_CONTROL_DATE = 0
      HG_CONTROL_DATE = 0
      OTHER3_CONTROL_DATE = 0.
      EMERGENCY_CAPACITY = 0.
      EMERGENCY_HEATRATE = 0.
      CAP_MARKET_MONTH_NO = 0
      CAPACITY_MARKET_POINTER = 0
      RETROFIT_UNIT_INDEX = 0
      RETROFIT_COUNTER = 0
      RETIREMENT_COUNTER = 0
!      CALL CINITW(POINTER_FOR_NEW_CL_UNIT,INT(MAX_CL_UNITS),0)
      POINTER_FOR_NEW_CL_UNIT = 0
      CL_ANNUAL_LOAD_REDUCTION = 0.
      CL_CAP_AREA_LINKED = .FALSE.
      SP_NEWGEN_UNIT_STATUS = " "
      CAP_LIMITED_CLASS_POINTER = 0
      NUMBER_OF_CAP_LIMITED_CLASSES = 0
      SAVE_DETAILED_MAINTENANCE = .FALSE.
!      RUN_TRANSACT = YES_RUN_TRANSACT() ! OUT 9/23/98. GAT.
      CALL DOES_TG_FILE_EXIST(TG_FILE_EXISTS)
      CALL DOES_TF_FILE_EXIST(TF_FILE_EXISTS)
      RUN_TRANSACT = TG_FILE_EXISTS .AND. UPPER_TRANS_GROUP > 0
!          TF_FILE_EXISTS
!    +               .AND. TRANSACT_ACTIVE_IN_ENDPOINT()
      RDI_REC = 0
      RDI_CL_REC = 0
      NUNITS = 1
      UNIQUE_ID_NUM = 0
      CL_UNIT_UNIQUE_RPT_ID = 0
      TOTAL_START_UP_UNITS = 0
      PROCESSING_FIRST_DATA_FILE = .TRUE.
      PHASE_I_UNIT = .FALSE.
         if(.false.)
     +  write(3471,*) "BASECASE_PLANT_ID,"//
     +            "STATE_PROV_NAME,"//
     +            "BASECASE_UNIT_ID,"//
     +            "TRANSACTION_GROUP_ID,"//
     +            "BASECASE_MARKET_AREA_ID,"//
     +            "BASECASE_TRANS_AREA_ID"
      DO FILE_ID = 0, MAX_CL_FILES-1
C
         IF(.NOT. SP_CAPEX_ACTIVE() .AND. FILE_ID == 23) CYCLE
         CALL OPEN_CL_FILE(INT2(10),CL_RECORDS,FILE_ID)
         IF(CL_RECORDS == 0) CYCLE
         IREC = 0
         DOWHILE (IREC < CL_RECORDS .OR. RDI_CL_REC < RDI_CL_RECORDS)
            IF(IREC < CL_RECORDS) THEN
               IREC = IREC + 1
! 050608. TESTING.
!               WRITE(SCREEN_OUTPUT,*) UNIQUE_ID_NUM
!               SCREEN_OUTPUT = 'UNIQUE_ID_NUM'//SCREEN_OUTPUT
!               CALL MG_LOCATE_WRITE(16,30,SCREEN_OUTPUT,ALL_VERSIONS,0)
!
               UNIQUE_ID_NUM = UNIQUE_ID_NUM + 1
               READ(10,REC=IREC,IOSTAT=IOS)DELETE,SP_UNIT_NAME(NUNITS),
     +            CL_LOAD_TYPE,
     +            EXPENSE_ASSIGNMENT(NUNITS),EXPENSE_COLLECTION(NUNITS),
     +            GENGRP(NUNITS),CAP_FRAC_OWN(NUNITS),ON_LINE_MONTH,
     +            ON_LINE_YEAR,OFF_LINE_MONTH(NUNITS),
     +            OFF_LINE_YEAR(NUNITS),FUEL_MIX_PTR(NUNITS),
     +            PBTUCT(NUNITS),PFESCR(NUNITS),SBTUCT(NUNITS),
     +            SFESCR(NUNITS),
     +            FUELADJ(NUNITS),EFOR(NUNITS),
     +            (MNRATE(NUNITS,M),M=1,12),
     +            VCPMWH_IN(NUNITS),OMESCR(NUNITS),
     +            FIXED_COST_IN(NUNITS),FIXED_COST_ESCALATOR(NUNITS),
     +            DISPADJ(NUNITS),HR_FACTOR(NUNITS),
     +            (INPUT_MW(M,NUNITS),M=1,2),
     +            CAP_PLANNING_FAC(NUNITS),(COEFF(M,NUNITS),M=1,3),
     +            CL_AI_CAPACITY_RATE(NUNITS),
     +            CL_AI_CAPACITY_ESCALATOR(NUNITS),
     +            CL_AI_ENERGY_RATE(NUNITS),
     +            CL_AI_ENERGY_ESCALATOR(NUNITS),
     +            AI_CL_REMAINING_LIFE(NUNITS),
     +            P_SO2(NUNITS),P_NOX(NUNITS),P_PARTICULATES(NUNITS),
     +            LOCAL_CL_POOL_FRAC_OWN(NUNITS),
     +            P_EMIS_OTH2(NUNITS),
     +            P_EMIS_OTH3(NUNITS),
     +            PHASE_I_STR,
     +            DISPADJ2(NUNITS),                  ! 55
     +            CL_RESOURCE_ID(NUNITS),
     +            FUEL_SUPPLY_ID(NUNITS),
     +            P_NOX_BK2(NUNITS),
     +            SEC_FUEL_EMISS_PTR(NUNITS),
     +            EMISS_FUEL_COST(NUNITS),           ! 60
     +            EMISS_FUEL_ESCAL(NUNITS),
     +            EMISS_FUEL_EMISS_PTR(NUNITS),
     +            EMISS_BLENDING_RATE(NUNITS),
     +            PRIM_FUEL_EMISS_PTR(NUNITS),
     +            TEMP_PRIM_FUEL_TYPE_STR,
     +            SEC_FUEL_TYPE(NUNITS),
     +            EMISS_FUEL_TYPE(NUNITS),
     +            TIE_CONSTRAINT_GROUP(NUNITS),
     +            MONTHLY_CAPACITY_POINTER(NUNITS),
     +            ANNUAL_CL_FIXED_COST(NUNITS),       ! 70
     +            ANNUAL_CL_FIXED_COST_ESC(NUNITS),
     +            MAINT_DAYS(NUNITS),
     +            DISPATCH_MULT(NUNITS),
     +            EXCESS_ENERGY_SALES(NUNITS),
     +            AI_CL_TAX_LIFE(NUNITS),
     +            AI_CL_ADR_LIFE(NUNITS),
     +            ASSET_CLASS_NUM(NUNITS),
     +            ASSET_CLASS_VECTOR(NUNITS),
     +            INTRA_COMPANY_CLASS_ID(NUNITS),
     +            INTRA_COMPANY_TRANSACTION(NUNITS),  ! 80
     +            SPECIAL_UNIT_ID(NUNITS),
     +            MINIMUM_CAPACITY_FACTOR(NUNITS),
     +            MAXIMUM_CAPACITY_FACTOR(NUNITS),
     +            TRANSACTION_GROUP_ID(NUNITS),
     +            DAY_TYPE_ID(NUNITS),    ! 85
     +            UNIT_ACTIVE,
     +            BASECASE_PLANT_ID(NUNITS),
     +            BASECASE_UNIT_ID,
     +            BASECASE_MARKET_AREA_ID(NUNITS),
     +            BASECASE_TRANS_AREA_ID,
     +            BASECASE_PLANT_NERC_SUB_ID,
     +            BASECASE_PLANT_OWNER_ID,
     +            UTILITY_OWNED,
     +            MONTHLY_FUEL_INDEX(NUNITS),
     +            START_UP_COSTS(NUNITS),
     +            START_UP_LOGIC(NUNITS),
     +            RAMP_RATE(NUNITS),
     +            MIN_DOWN_TIME(NUNITS),
     +            REPORT_THIS_UNIT(NUNITS),
     +            P_FUEL_DELIVERY_1(NUNITS),
     +            P_FUEL_DELIVERY_2(NUNITS),
     +            P_FUEL_DELIVERY_3(NUNITS),
     +            MIN_UP_TIME(NUNITS),
     +            HESI_UNIT_ID_NUM(NUNITS),
     +            FOR_FREQUENCY(NUNITS),
     +            FOR_DURATION(NUNITS),
     +            WINTER_TOTAL_CAPACITY,
     +            CONTRIBUTES_TO_SPIN(NUNITS),
     +            H2_UNIT_ID_NUM(NUNITS),
     +            POWERDAT_PLANT_ID(NUNITS),
     +            APPLY_NOX_SEASON_DATE(NUNITS),
     +            NOX_SEASON_DATE(NUNITS),
     +            RAMP_DOWN_RATE(NUNITS),
     +            NOX_CONTROL_PERCENT(NUNITS),
     +            NOX_CONTROL_DATE(NUNITS),
     +            EMERGENCY_CAPACITY(NUNITS),
     +            EMERGENCY_HEATRATE(NUNITS),
     +            MARKET_RESOURCE(NUNITS),
     +            PRIMARY_MOVER_STR(NUNITS),
     +            COUNTY,
     +            STATE_PROVINCE,
     +            NOX_VOM(NUNITS),
     +            NOX_FOM(NUNITS),
     +            S_FUEL_DELIVERY(NUNITS),
     +            S_FUEL_DELIVERY_2(NUNITS),
     +            S_FUEL_DELIVERY_3(NUNITS),
     +            CONSTANT_POLY,
     +            FIRST_POLY,
     +            SECOND_POLY,
     +            THIRD_POLY,
     +            USE_POLY_HEAT_RATES,
     +            SP_NEWGEN_UNIT_STATUS(NUNITS),
     +            MONTHLY_MUST_RUN_VECTOR(NUNITS),
     +            EMISSION_MARKET_LINK(NUNITS),
     +            WVPA_RATE_TRACKER(NUNITS),
     +            ALLOW_DECOMMIT(NUNITS),
     +            MIN_SPIN_CAP(NUNITS),
     +            MAX_SPIN_CAP(NUNITS),
     +            WVPA_RES_TRACKER(NUNITS),
     +            WVPA_FUEL_TRACKER(NUNITS),
     +            MONTE_OR_FREQ(NUNITS),
     +            WVPA_MEM_TRACKER(NUNITS),
     +            MONTHLY_DECOMMIT_VECTOR(NUNITS),
     +            TRANS_BUS_ID(NUNITS),
     +            SOX_CONTROL_PERCENT(NUNITS),
     +            SOX_CONTROL_DATE(NUNITS),
     +            SOX_VOM(NUNITS),
     +            SOX_FOM(NUNITS),
     +            LATITUDE(NUNITS),
     +            LONGITUDE(NUNITS),
     +            MW_INSIDE_FENCE,
     +            (INTER_BLOCKS(M,NUNITS),M=1,3),
C SPCapEx Variables
     +            FIRST_YEAR_DECOMM_AVAIALABLE(NUNITS),  ! 155
     +            DECOMMISSIONING_BASE_YR_COST(NUNITS),
     +            DECOM_CONTINUING_COST_ESCALATION(NUNITS),
     +            ANNUAL_ENERGY_PLANNING_FACTOR(NUNITS),   ! 158
     +            AGGREGATE_THIS_UNIT(NUNITS),             ! 159
     +            NAME_PLATE_CAPACITY(NUNITS),
     +            FUEL_BLENDING_IS(NUNITS),   ! NO, FIXED BLEND, MODEL DETERMINED IF ONLY ONE FUEL ELSE USER OPTION
     +            FuelRatio(1,Nunits),
     +            FuelRatio(2,Nunits),
     +            FuelRatio(3,Nunits),         ! 164
     +            FuelRatio(4,Nunits),
     +            FuelRatio(5,Nunits),         ! 166
     +            BlendableFuelsPtr(1,Nunits), ! 167
     +            BlendableFuelsPtr(2,Nunits), ! 168
     +            BlendableFuelsPtr(3,Nunits),
     +            BlendableFuelsPtr(4,Nunits),
     +            FuelTransportationCost(1,Nunits),
     +            FuelTransportationCost(2,Nunits),  ! 172
     +            FuelTransportationCost(3,Nunits),
     +            FuelTransportationCost(4,Nunits),
     +            BlendedEnthalpyUp(Nunits),
     +            BlendedEnthalpyLo(Nunits),
     +            BlendedSO2Up(Nunits),                  ! 177
     +            BettermentProjectID(Nunits),
     +            DECOM_CONTINUING_COST(Nunits),
     +            DECOM_CONTINUING_COST_ESCALATION(Nunits),
     +            EnrgPatternPointer(Nunits), ! 181
     +            EMISSION_DATA_UNITS(Nunits),
     +            EmissRedRate(1,Nunits),
     +            EmissRedRate(2,Nunits),
     +            EmissRedRate(3,Nunits),
     +            EmissRedRate(4,Nunits),              ! 186
     +            EmissRedRate(5,Nunits),
     +            EmissMaxRate(1,Nunits),
     +            EmissMaxRate(2,Nunits),
     +            EmissMaxRate(3,Nunits),
     +            EmissMaxRate(4,Nunits),
     +            EmissMaxRate(5,Nunits),
     +            MaxEnergyLimit(1,Nunits),
     +            MaxEnergyLimit(2,Nunits),
     +            MaxEnergyLimit(3,Nunits),
     +            TECH_TYPE(Nunits),
     +            LINKED_BETTERMENT_OPTION(Nunits),
     +            CO2_CONTROL_PERCENT(NUNITS),
     +            HG_CONTROL_PERCENT(NUNITS),
     +            OTHER3_CONTROL_PERCENT(NUNITS),
     +            CO2_CONTROL_DATE(NUNITS),
     +            HG_CONTROL_DATE(NUNITS),
     +            OTHER3_CONTROL_DATE(NUNITS),
     +            CO2_VOM(NUNITS),
     +            CO2_FOM(NUNITS),
     +            HG_VOM(NUNITS),
     +            HG_FOM(NUNITS),
     +            OTHER3_VOM(NUNITS),
     +            OTHER3_FOM(NUNITS),
     +            MARKET_FLOOR(NUNITS),
     +            MARKET_CEILING(NUNITS),
     +            START_UP_COSTS_ESCALATION(NUNITS),  ! 212
     +            CAPACITY_MARKET_TYPE(NUNITS),
     +            CAPACITY_MARKET_MONTH(NUNITS),
     +            CAPACITY_MARKET_POINTER(NUNITS),
     +            CAPACITY_MARKET_COST_ASSIGN(NUNITS),
     +            CAPACITY_MARKET_EXP_COLLECT(NUNITS),
     +            CAPACITY_MARKET_COIN_ADJ_FACT(NUNITS),
     +            PRIMARY_FUEL_CATEGORY(NUNITS),
     +            SECONDARY_FUEL_CATEGORY(NUNITS),
     +            EMISSIONS_FUEL_CATEGORY(NUNITS),
     +            RPS_CONTRIBUTION_PERCENT(NUNITS),
     +            RETIREMENT_CANDIDATE(NUNITS),
     +            RETROFIT_CANDIDATE(NUNITS),
     +            RETROFIT_PROJECT_ID(NUNITS),
     +            CO2_BASIN_NAME,
     +            CO2_PIPELINE_DISTANCE(NUNITS),
     +            STATE_PROV_NAME,
     +            CO2_RETRO_HEAT_MULT(NUNITS),
     +            CO2_RETRO_CAP_MULT(NUNITS),
     +            THERMAL_GUID,
     +            THERMAL_PARENT_ID, ! 232
     +            THERMAL_AGGREGATED_UNIT,
     +            FIRST_RETIREMENT_YEAR(NUNITS),
     +            UNIT_TYPE,
     +            UNIT_TYPE_CATEGORY,
     +            RPS_PROGRAM_NUMBER(NUNITS)
!
         if(.false.)
     +       write(3471,*) BASECASE_PLANT_ID(NUNITS),",",
     +            STATE_PROV_NAME,",",
     +            BASECASE_UNIT_ID,",",
     +            SP_UNIT_NAME(NUNITS),",",
     +            TRANSACTION_GROUP_ID(NUNITS),",",
     +            BASECASE_MARKET_AREA_ID(NUNITS),",",
     +            BASECASE_TRANS_AREA_ID,","
            ELSEIF(RDI_REC < RDI_RECORDS .AND.
     +                                  PROCESSING_FIRST_DATA_FILE) THEN
               RDI_REC = RDI_REC + 1
               UNIT_ACTIVE = 'T'
               READ(RDI_IN_UNIT,REC=RDI_REC)
     +            DELETE,
     +            RDI_COMPANY_NAME,
     +            RDI_NERC_REGION,
     +            RDI_SUB_REGION,
     +            UNITNM(NUNITS),
     +            RDI_PM_ABBREV,
     +            RDI_PRIME_FUEL,
     +            ON_LINE_YEAR,! NUMBERS ! INT
     +            ON_LINE_MONTH, ! INT
     +            CAP_FRAC_OWN(NUNITS),
     +            RDI_DEMONSTRATED_CAPACITY_MW,
     +            RDI_INCREMENTAL_FUEL_$MWH,
     +            PBTUCT(NUNITS),
     +            VCPMWH_IN(NUNITS),
     +            FIXED_COST_IN(NUNITS),
     +            RDI_AVERAGE_HEAT_RATE,
     +            RDI_MONTH_GENERATION, ! 12 VALUES
     +            RDI_MONTH_CAPACITY ! 12 VALUES
!
               IF(trim(RDI_PM_ABBREV) == 'HY') CYCLE ! THIS PERMITS ONE BIN FILE
!
               RDI_CL_REC = RDI_CL_REC + 1
!
               CL_LOAD_TYPE = 'B '
               EXPENSE_ASSIGNMENT(NUNITS) = 'F' !ossil Fuel
               EXPENSE_COLLECTION(NUNITS) = 'A' !djustment Clause'
               GENGRP(NUNITS) = 0
               OFF_LINE_MONTH(NUNITS) = 12
               OFF_LINE_YEAR(NUNITS) = 2050
               ON_LINE_MONTH = 1 ! HARD WIRED
!
               CAP_FRAC_OWN(NUNITS) = 100.0 ! OWNERSHIP APPEARS TO BE ACCOUNTED FOR
!
               FUEL_MIX_PTR(NUNITS) = 1. ! FUELMX(NUNITS) = 1.
               PFESCR(NUNITS) = 0.
               SBTUCT(NUNITS) = 0.
               SFESCR(NUNITS) = 0
               FUELADJ(NUNITS) = 0.
!
               IF(RDI_DEMONSTRATED_CAPACITY_MW < 100.) THEN
                  RDI_SIZE_INDEX = 1
                  IF(RDI_PRIME_FUEL(1:4) == 'COAL') THEN
                     RDI_FUEL_INDEX = 1
                  ELSEIF(RDI_PRIME_FUEL(1:3) == 'OIL') THEN
                     RDI_FUEL_INDEX = 2
                  ELSEIF(RDI_PRIME_FUEL(1:4) == 'URAN') THEN
                     RDI_FUEL_INDEX = 3
                  ELSEIF(RDI_PRIME_FUEL(1:3) == 'GAS') THEN
                     RDI_FUEL_INDEX = 4
                  ELSE ! LIGNITE
                     RDI_FUEL_INDEX = 5
                  ENDIF
               ELSEIF(RDI_DEMONSTRATED_CAPACITY_MW >= 100. .AND.
     +                         RDI_DEMONSTRATED_CAPACITY_MW < 200.) THEN
                  RDI_SIZE_INDEX = 2
                  IF(RDI_PRIME_FUEL(1:4) == 'COAL') THEN
                     RDI_FUEL_INDEX = 1
                  ELSEIF(RDI_PRIME_FUEL(1:3) == 'OIL') THEN
                     RDI_FUEL_INDEX = 2
                  ELSEIF(RDI_PRIME_FUEL(1:4) == 'URAN') THEN
                     RDI_FUEL_INDEX = 3
                  ELSEIF(RDI_PRIME_FUEL(1:3) == 'GAS') THEN
                     RDI_FUEL_INDEX = 4
                  ELSE ! LIGNITE
                     RDI_FUEL_INDEX = 5
                  ENDIF
               ELSEIF(RDI_DEMONSTRATED_CAPACITY_MW >= 200. .AND.
     +                         RDI_DEMONSTRATED_CAPACITY_MW < 300.) THEN
                  RDI_SIZE_INDEX = 3
                  IF(RDI_PRIME_FUEL(1:4) == 'COAL') THEN
                     RDI_FUEL_INDEX = 1
                  ELSEIF(RDI_PRIME_FUEL(1:3) == 'OIL') THEN
                     RDI_FUEL_INDEX = 2
                  ELSEIF(RDI_PRIME_FUEL(1:4) == 'URAN') THEN
                     RDI_FUEL_INDEX = 3
                  ELSEIF(RDI_PRIME_FUEL(1:3) == 'GAS') THEN
                     RDI_FUEL_INDEX = 4
                  ELSE ! LIGNITE
                     RDI_FUEL_INDEX = 5
                  ENDIF
               ELSEIF(RDI_DEMONSTRATED_CAPACITY_MW >= 300. .AND.
     +                         RDI_DEMONSTRATED_CAPACITY_MW < 400.) THEN
                  RDI_SIZE_INDEX = 4
                  IF(RDI_PRIME_FUEL(1:4) == 'COAL') THEN
                     RDI_FUEL_INDEX = 1
                  ELSEIF(RDI_PRIME_FUEL(1:3) == 'OIL') THEN
                     RDI_FUEL_INDEX = 2
                  ELSEIF(RDI_PRIME_FUEL(1:4) == 'URAN') THEN
                     RDI_FUEL_INDEX = 3
                  ELSEIF(RDI_PRIME_FUEL(1:3) == 'GAS') THEN
                     RDI_FUEL_INDEX = 4
                  ELSE ! LIGNITE
                     RDI_FUEL_INDEX = 5
                  ENDIF
               ELSEIF(RDI_DEMONSTRATED_CAPACITY_MW >= 400. .AND.
     +                         RDI_DEMONSTRATED_CAPACITY_MW < 600.) THEN
                  RDI_SIZE_INDEX = 5
                  IF(RDI_PRIME_FUEL(1:4) == 'COAL') THEN
                     RDI_FUEL_INDEX = 1
                  ELSEIF(RDI_PRIME_FUEL(1:3) == 'OIL') THEN
                     RDI_FUEL_INDEX = 2
                  ELSEIF(RDI_PRIME_FUEL(1:4) == 'URAN') THEN
                     RDI_FUEL_INDEX = 3
                  ELSEIF(RDI_PRIME_FUEL(1:3) == 'GAS') THEN
                     RDI_FUEL_INDEX = 4
                  ELSE ! LIGNITE
                     RDI_FUEL_INDEX = 5
                  ENDIF
               ELSEIF(RDI_DEMONSTRATED_CAPACITY_MW >= 600. .AND.
     +                         RDI_DEMONSTRATED_CAPACITY_MW < 800.) THEN
                  RDI_SIZE_INDEX = 6
                  IF(RDI_PRIME_FUEL(1:4) == 'COAL') THEN
                     RDI_FUEL_INDEX = 1
                  ELSEIF(RDI_PRIME_FUEL(1:3) == 'OIL') THEN
                     RDI_FUEL_INDEX = 2
                  ELSEIF(RDI_PRIME_FUEL(1:4) == 'URAN') THEN
                     RDI_FUEL_INDEX = 3
                  ELSEIF(RDI_PRIME_FUEL(1:3) == 'GAS') THEN
                     RDI_FUEL_INDEX = 4
                  ELSE ! LIGNITE
                     RDI_FUEL_INDEX = 5
                  ENDIF
               ELSEIF(RDI_DEMONSTRATED_CAPACITY_MW >= 800. .AND.
     +                        RDI_DEMONSTRATED_CAPACITY_MW < 1000.) THEN
                  RDI_SIZE_INDEX = 7
                  IF(RDI_PRIME_FUEL(1:4) == 'COAL') THEN
                     RDI_FUEL_INDEX = 1
                  ELSEIF(RDI_PRIME_FUEL(1:3) == 'OIL') THEN
                     RDI_FUEL_INDEX = 2
                  ELSEIF(RDI_PRIME_FUEL(1:4) == 'URAN') THEN
                     RDI_FUEL_INDEX = 3
                  ELSEIF(RDI_PRIME_FUEL(1:3) == 'GAS') THEN
                     RDI_FUEL_INDEX = 4
                  ELSE ! LIGNITE
                     RDI_FUEL_INDEX = 5
                  ENDIF
               ELSE ! > 1000 MW
                  RDI_SIZE_INDEX = 8
                  IF(RDI_PRIME_FUEL(1:4) == 'COAL') THEN
                     RDI_FUEL_INDEX = 1
                  ELSEIF(RDI_PRIME_FUEL(1:3) == 'OIL') THEN
                     RDI_FUEL_INDEX = 2
                  ELSEIF(RDI_PRIME_FUEL(1:4) == 'URAN') THEN
                     RDI_FUEL_INDEX = 3
                  ELSEIF(RDI_PRIME_FUEL(1:3) == 'GAS') THEN
                     RDI_FUEL_INDEX = 4
                  ELSE ! LIGNITE
                     RDI_FUEL_INDEX = 5
                  ENDIF
               ENDIF
!
               EFOR(NUNITS)=GADS_FOR(RDI_SIZE_INDEX,RDI_FUEL_INDEX)*100.
               MAINT_DAYS(NUNITS) =
     +                           GADS_MOR(RDI_SIZE_INDEX,RDI_FUEL_INDEX)
!
!               EFOR(NUNITS) = 5. ! USE THE GADS DATA
               MNRATE(NUNITS,1) = 0.
               MNRATE(NUNITS,2) = 0.
               MNRATE(NUNITS,3) = 0.
               MNRATE(NUNITS,4) = 0.
               MNRATE(NUNITS,5) = 0.
               MNRATE(NUNITS,6) = 0.
               MNRATE(NUNITS,7) = 0.
               MNRATE(NUNITS,8) = 0.
               MNRATE(NUNITS,9) = 0.
               MNRATE(NUNITS,10) = 0.
               MNRATE(NUNITS,11) = 0.
               MNRATE(NUNITS,12) = 0.
               OMESCR(NUNITS) = 0.
               FIXED_COST_ESCALATOR(NUNITS) = 0.
               DISPADJ(NUNITS) = 0.
               HR_FACTOR(NUNITS) = 1.0
               INPUT_MW(1,NUNITS) = RDI_DEMONSTRATED_CAPACITY_MW
               INPUT_MW(2,NUNITS) = RDI_DEMONSTRATED_CAPACITY_MW
               CAP_PLANNING_FAC(NUNITS) = 1.0
               COEFF(1,NUNITS) = RDI_AVERAGE_HEAT_RATE
               COEFF(2,NUNITS) = RDI_AVERAGE_HEAT_RATE
               COEFF(3,NUNITS) = RDI_AVERAGE_HEAT_RATE
               CL_AI_CAPACITY_RATE(NUNITS) = 0.
               CL_AI_CAPACITY_ESCALATOR(NUNITS) = 0
               CL_AI_ENERGY_RATE(NUNITS) = 0.
               CL_AI_ENERGY_ESCALATOR(NUNITS) = 0
               AI_CL_REMAINING_LIFE(NUNITS) = 1
               P_SO2(NUNITS) = 0.
               P_NOX(NUNITS) = 0.
               P_PARTICULATES(NUNITS) = 0.
               LOCAL_CL_POOL_FRAC_OWN(NUNITS) = 100.
               P_EMIS_OTH2(NUNITS) = 0.
               P_EMIS_OTH3(NUNITS) = 0.
               PHASE_I_UNIT(NUNITS) = .FALSE.
               DISPADJ2(NUNITS) = 0.
               CL_RESOURCE_ID(NUNITS) = 0
               FUEL_SUPPLY_ID(NUNITS) = 0
               P_NOX_BK2(NUNITS) = 0.
               SEC_FUEL_EMISS_PTR(NUNITS) = 0
               EMISS_FUEL_COST(NUNITS) =  0.
               EMISS_FUEL_ESCAL(NUNITS) =  0
               EMISS_FUEL_EMISS_PTR(NUNITS) = 0
               EMISS_BLENDING_RATE(NUNITS) = 0.
               PRIM_FUEL_EMISS_PTR(NUNITS) = 0
               IF(trim(RDI_PRIME_FUEL) == 'OIL-L') THEN
                  PRIM_FUEL_TYPE_STR = 'Oil   '
                  SEC_FUEL_TYPE(NUNITS) = 'O' !il   '
               ELSEIF(trim(RDI_PRIME_FUEL) == 'GAS') THEN
                  PRIM_FUEL_TYPE_STR = 'Gas   '
                  SEC_FUEL_TYPE(NUNITS) = 'G' !as   '
               ELSE
                  PRIM_FUEL_TYPE_STR = 'Coal  '
                  SEC_FUEL_TYPE(NUNITS) = 'C' !oal  '
               ENDIF
               EMISS_FUEL_TYPE(NUNITS) = 'C' !oal  '
               TIE_CONSTRAINT_GROUP(NUNITS) = 0.
               MONTHLY_CAPACITY_POINTER(NUNITS) = 0.
               ANNUAL_CL_FIXED_COST(NUNITS) = 0.
               ANNUAL_CL_FIXED_COST_ESC(NUNITS) = 0.
!               MAINT_DAYS(NUNITS) = 2 ! USE THE GADS DATA
               DISPATCH_MULT(NUNITS) = 1.0
               EXCESS_ENERGY_SALES(NUNITS) = 0.
               AI_CL_TAX_LIFE(NUNITS) = 1
               AI_CL_ADR_LIFE(NUNITS) = 1
               ASSET_CLASS_NUM(NUNITS) = 0
               ASSET_CLASS_VECTOR(NUNITS) = 0
               INTRA_COMPANY_CLASS_ID(NUNITS) = 0
               INTRA_COMPANY_TRANSACTION(NUNITS) = 'N'
               RDI_DESC = trim(RDI_COMPANY_NAME)//':POWERDAT'
               SPECIAL_UNIT_ID(NUNITS) = 'NONE'
               MINIMUM_CAPACITY_FACTOR(NUNITS) = 0.
               MAXIMUM_CAPACITY_FACTOR(NUNITS) = 1.
               TRANSACTION_GROUP_ID(NUNITS) = 1
               DAY_TYPE_ID(NUNITS) = 0
! THIS CREATES A MIDAS DATA READABLE CL FILE
               WRITE(RDI_OUT_UNIT,1000)
     +            "1,",
     +            trim(UNITNM(NUNITS)),
     +            trim(CL_LOAD_TYPE),
     +            EXPENSE_ASSIGNMENT(NUNITS),EXPENSE_COLLECTION(NUNITS),
     +            GENGRP(NUNITS),CAP_FRAC_OWN(NUNITS),ON_LINE_MONTH,
     +            ON_LINE_YEAR,OFF_LINE_MONTH(NUNITS),
     +            OFF_LINE_YEAR(NUNITS),FUEL_MIX_PTR(NUNITS), ! FUELMX(NUNITS), replaced 5/17/01 M.S.G.
     +            PBTUCT(NUNITS),PFESCR(NUNITS),SBTUCT(NUNITS),
     +            SFESCR(NUNITS),
     +            FUELADJ(NUNITS),EFOR(NUNITS),
     +            (MNRATE(NUNITS,M),M=1,12),
     +            VCPMWH_IN(NUNITS),OMESCR(NUNITS),
     +            FIXED_COST_IN(NUNITS),
     +            FIXED_COST_ESCALATOR(NUNITS),
     +            DISPADJ(NUNITS),
     +            HR_FACTOR(NUNITS),
     +            (INPUT_MW(M,NUNITS),M=1,2),
     +            CAP_PLANNING_FAC(NUNITS),
     +            (COEFF(M,NUNITS),M=1,3),
     +            trim(RDI_DESC),
     +            P_SO2(NUNITS),
     +            P_NOX(NUNITS),
     +            P_PARTICULATES(NUNITS),
     +            LOCAL_CL_POOL_FRAC_OWN(NUNITS),
     +            P_EMIS_OTH2(NUNITS),
     +            P_EMIS_OTH3(NUNITS),
     +            PHASE_I_UNIT(NUNITS),
     +            DISPADJ2(NUNITS),
     +            CL_RESOURCE_ID(NUNITS),
     +            FUEL_SUPPLY_ID(NUNITS),
     +            P_NOX_BK2(NUNITS),
     +            SEC_FUEL_EMISS_PTR(NUNITS),
     +            EMISS_FUEL_COST(NUNITS),
     +            EMISS_FUEL_ESCAL(NUNITS),
     +            EMISS_FUEL_EMISS_PTR(NUNITS),
     +            EMISS_BLENDING_RATE(NUNITS),
     +            PRIM_FUEL_EMISS_PTR(NUNITS),
     +            trim(PRIM_FUEL_TYPE_STR),
     +            trim(SEC_FUEL_TYPE(NUNITS)),
     +            trim(EMISS_FUEL_TYPE(NUNITS)),
     +            TIE_CONSTRAINT_GROUP(NUNITS),
     +            MONTHLY_CAPACITY_POINTER(NUNITS),
     +            CL_AI_CAPACITY_RATE(NUNITS),
     +            CL_AI_CAPACITY_ESCALATOR(NUNITS),
     +            CL_AI_ENERGY_RATE(NUNITS),
     +            CL_AI_ENERGY_ESCALATOR(NUNITS),
     +            AI_CL_REMAINING_LIFE(NUNITS),
     +            ANNUAL_CL_FIXED_COST(NUNITS),
     +            ANNUAL_CL_FIXED_COST_ESC(NUNITS),
     +            MAINT_DAYS(NUNITS),
     +            DISPATCH_MULT(NUNITS),
     +            EXCESS_ENERGY_SALES(NUNITS),
     +            AI_CL_TAX_LIFE(NUNITS),
     +            AI_CL_ADR_LIFE(NUNITS),
     +            ASSET_CLASS_NUM(NUNITS),
     +            ASSET_CLASS_VECTOR(NUNITS),
     +            INTRA_COMPANY_CLASS_ID(NUNITS),
     +            INTRA_COMPANY_TRANSACTION(NUNITS),
     +            trim(SPECIAL_UNIT_ID(NUNITS)),
     +            MINIMUM_CAPACITY_FACTOR(NUNITS),
     +            MAXIMUM_CAPACITY_FACTOR(NUNITS),
     +            TRANSACTION_GROUP_ID(NUNITS),
     +            DAY_TYPE_ID(NUNITS)
!
 1000             FORMAT(  A,4('"',A,'"',','),
     +               I3,',',F9.2,',',4(I5,','),
     +               2(F9.2,','),I5,',',F9.2,',',I5,',',
     +               15(F9.2,','),I5,',',
     +               F9.2,',',I5,',',8(F9.2,','),'"',A,'"',',', ! DESCRIPTION
     +               6(F9.2,','),
     +               L1,',',F9.2,',',2(I5,','),F9.2,',',I5,',',
     +               F9.2,',',2(I5,','),
     +               F9.2,',',I5,',',3(A,','),
     +               F9.2,',',I5,',', !CAP DISTN POINTER
     +               F9.2,',',I5,',',F9.2,',',I5,',',I5,',', ! AI VARIABLES
     +               F9.2,',',I5,',', ! FIXED COSTS
     +               5(F9.2,','),
     +               3(I5,','),2(A,','),2(F9.2,','),2(I5,','))
!
            ELSE
               WRITE(4,*) "Untrapped error when processing"
               WRITE(4,*) "Capacity Limited Units"
               WRITE(4,*) '*** line 1949 CLA_OBJT.FOR ***'
               er_message='See WARNING MESSAGES'
               call end_program(er_message)
            ENDIF
            IF(IOS /= 0) EXIT
            if(INDEX(SP_UNIT_NAME(NUNITS),'Stryker') /= 0) then
               write(4,*) "stop here"
            endif
!
! 10/15/04. FOR RUNNING TRANSACT ZN INSTEAD OF TRANSACTION GROUP.
!
! TESTING!!!
!
!            ZONAL_LEVEL_MARKET = .TRUE.
! 10/15/04.
!
C
C CHECK FOR DUPLICATE NAME
C
            UNIT_NAME = ADJUSTL(SP_UNIT_NAME(NUNITS))
            DO ID = 1, NUNITS-1
               IF(LEN_TRIM(SP_UNIT_NAME(ID)) ==
     +                                   LEN_TRIM(UNIT_NAME) .AND.
     +                 INDEX(SP_UNIT_NAME(ID),UNIT_NAME) /= 0) THEN
                  WRITE(TEMP_UNIT_NAME,'(A,I2.2)')
     +                     TRIM(UNIT_NAME),UNIT_NAME_COUNT(ID)
                  UNIT_NAME_COUNT(ID) = UNIT_NAME_COUNT(ID) + 1
                  WRITE(4,*) 'The unit name '//
     +                      TRIM(UNIT_NAME)//' has been used before.'
                  WRITE(4,*) 'The name has been changed to '//
     +                                           TRIM(TEMP_UNIT_NAME)
                  SP_UNIT_NAME(NUNITS) = TEMP_UNIT_NAME
                  EXIT
               ENDIF
            ENDDO
C END UNIQUE NAME FIX
               UNITNM(NUNITS) = SP_UNIT_NAME(NUNITS)
            NEWGEN_UNIT_STATUS = SP_NEWGEN_UNIT_STATUS(NUNITS)
            IF(INDEX(NEWGEN_UNIT_STATUS,"SPCapEx") /= 0) THEN
               ON_LINE_YEAR = 2000
               OFF_LINE_YEAR(NUNITS) = 2200
               MW_INSIDE_FENCE = 0.
            ENDIF

            IF(ZONAL_LEVEL_MARKET) THEN
               MARKET_ID = BASECASE_MARKET_AREA_ID(NUNITS)
               TRANSACTION_GROUP_ID(NUNITS) =
     +                                     MARKET_AREA_LOOKUP(MARKET_ID)
            ENDIF
!
! 10/03/02. FOR REGIONAL CONSOLIDATION. NOTE REASSIGNMENT.
! 10/01/03. MOVED CYCLE CONDITIONS UP DUE TO WARNINGS OCCURING.
!
            TRANSACTION_GROUP_ID(NUNITS) =
     +                GET_BELONGS_TO_GROUP(TRANSACTION_GROUP_ID(NUNITS))
!
! CONVERT TO PERCENT
! 112204 MODIFIED
!
            IF(INPUT_MW(2,NUNITS) > 1. .AND. MW_INSIDE_FENCE > .1) THEN
               PERCENT_INSIDE_FENCE = MIN(1.,
     +                               MW_INSIDE_FENCE/INPUT_MW(2,NUNITS))
            ELSE
               PERCENT_INSIDE_FENCE = 0.
            ENDIF
! 013107. MUST CONSIDER PLACEMENT
            IF(YES_AOD_PRICE_THERM_VALUE_LIST) THEN
               IF(.NOT.
     +            AOD_THERMAL_LIST_COMPARE(HESI_UNIT_ID_NUM(NUNITS)))
     +                                                             CYCLE
            ELSEIF(YES_AOD_COMP_THERM_VALUE_LIST) THEN
               IF(.NOT.
     +            AOD_THERMAL_LIST_COMPARE(HESI_UNIT_ID_NUM(NUNITS)))
     +                                                              THEN
                  REPORT_THIS_UNIT(NUNITS) = 'F'
               ENDIF
            ENDIF
!
            TRANS_ID = TRANSACTION_GROUP_ID(NUNITS)
            IF(DELETE > 7 .OR.
     +             (RUN_TRANSACT .AND.
     +               (.NOT. TRANS_GROUP_ACTIVE_SWITCH(TRANS_ID) .OR.
     +                .NOT. IN_ACTIVE_THERMAL_MARKET_AREA(
     +                         BASECASE_MARKET_AREA_ID(NUNITS)))) .OR.
     +                                PERCENT_INSIDE_FENCE > .995) CYCLE
            CAP_MARKET_MONTH_NO(NUNITS) =
     +          CAP_MARKET_MONTH_NO_INDEX(CAPACITY_MARKET_MONTH(NUNITS))
! 100504
! 112204. TESTING FOR BURESH
!
            IF(PERCENT_INSIDE_FENCE > .005) THEN
               CAP_FRAC_OWN(NUNITS) = CAP_FRAC_OWN(NUNITS) *
     +                                         (1.-PERCENT_INSIDE_FENCE)
            ENDIF
!
!
!
            IF(MONTE_OR_FREQ(NUNITS) == 'F')
     +                                  UNIT_FREQUENCY_DURATION = .TRUE.
!
! 11/04/03. ADDED
!
            IF(EMISSION_MARKET_LINK(NUNITS) == -9999) THEN
               EMISSION_MARKET_LINK(NUNITS) = ASSET_CLASS_NUM(NUNITS)
            ENDIF
!
!            TRANS_ID = TRANSACTION_GROUP_ID(NUNITS)
!
! 01/15/03.
! 01/22/03. RELAXED MW CONDITIONS.
!
!            IF(INPUT_MW(1,NUNITS) > 0. .AND.
!     +                                     INPUT_MW(2,NUNITS) > 0.) THEN
            DO M = 2, 1 , -1
               IF(INPUT_MW(M,NUNITS) < 0.) THEN
                  LOCAL_MW(M) =
     +                      GET_VAR(INPUT_MW(M,NUNITS),INT2(1),
     +                                                   UNITNM(NUNITS))
                  IF(LOCAL_MW(M) < 0.) THEN
                     WRITE(4,*) "Negative value for capacity"
                     WRITE(4,*) "for unit ",UNITNM(NUNITS)
                     WRITE(4,*) " "
                  ENDIF
               ELSE
                  LOCAL_MW(M) = INPUT_MW(M,NUNITS)
               ENDIF
               IF(LOCAL_MW(M) < 1. .AND. M == 1) THEN
                  LOCAL_MW(1) = LOCAL_MW(2) * LOCAL_MW(1)
               ELSE
                  LOCAL_MW(M) = LOCAL_MW(M) *
     +                                         CAP_FRAC_OWN(NUNITS)/100.
               ENDIF
            ENDDO
!
            IF(LOCAL_MW(1) > 0. .AND. LOCAL_MW(2) > 0.) THEN
               IF(USE_POLY_HEAT_RATES == 'T' .AND.
     +                                         .NOT. TURN_OFF_POLY) THEN
!
! TOM TO ASSOCIATE VARIABLES HERE (AND IN NEW_CL_UNITS_READ).
!
!
                  COEFF(1,NUNITS) = 1000. *
     +               (CONSTANT_POLY +
     +                FIRST_POLY * LOCAL_MW(1) +
     +                SECOND_POLY *
     +                           LOCAL_MW(1)*LOCAL_MW(1) +
     +                THIRD_POLY *
     +                     LOCAL_MW(1)*LOCAL_MW(1)*
     +                                              LOCAL_MW(1))/
     +                                                LOCAL_MW(1)
                  COEFF(2,NUNITS) = 1000. *
     +                (FIRST_POLY +
     +                2. * SECOND_POLY * LOCAL_MW(1) +
     +                3. * THIRD_POLY *
     +                            LOCAL_MW(1)*LOCAL_MW(1))
                  COEFF(3,NUNITS) = 1000. *
     +                (FIRST_POLY +
     +                2. * SECOND_POLY * LOCAL_MW(2) +
     +                3. * THIRD_POLY *
     +                            LOCAL_MW(2)*LOCAL_MW(2))
!
               ELSE
!                  ASSUMES ORIGINAL COEFF'S EXIST
               ENDIF
!
!
! 1/17/03.
! A+BX+CX^2
!
               IF(LOCAL_MW(2) > LOCAL_MW(1)) THEN
!
                  CUBIC_HEAT_CURVE(1,NUNITS) =
     +                     (COEFF(2,NUNITS)-COEFF(3,NUNITS))/
     +                     (-2.*(LOCAL_MW(2)-LOCAL_MW(1)))
                  CUBIC_HEAT_CURVE(2,NUNITS) =
     +                  COEFF(2,NUNITS) -
     +                             (COEFF(2,NUNITS) - COEFF(3,NUNITS)) *
     +                        LOCAL_MW(1)/
     +                     (-1.*(LOCAL_MW(2)-LOCAL_MW(1)))
                  CUBIC_HEAT_CURVE(3,NUNITS) =
     +                ((COEFF(1,NUNITS)-CUBIC_HEAT_CURVE(2,NUNITS))*
     +                               LOCAL_MW(1)) -
     +                        CUBIC_HEAT_CURVE(1,NUNITS)*
     +                             LOCAL_MW(1)*LOCAL_MW(1)
               ELSE
               ENDIF
            ELSE ! NEED TO CHECK THIS WITH TOM.
               CUBIC_HEAT_CURVE(2,NUNITS) = COEFF(1,NUNITS)
            ENDIF
! 07/09/03.
            CUBIC_HEAT_CURVE(0,NUNITS) = CONSTANT_POLY
            CUBIC_HEAT_CURVE(2,NUNITS) = SECOND_POLY
            CUBIC_HEAT_CURVE(3,NUNITS) = THIRD_POLY
            IF(CONSTANT_POLY <= 0. .AND. FIRST_POLY <= 0. .AND.
     +                                           SECOND_POLY <= 0.) THEN
               IF(COEFF(1,NUNITS) > 0.) THEN
                  CUBIC_HEAT_CURVE(1,NUNITS) = COEFF(1,NUNITS)*.001
               ELSE
                  CUBIC_HEAT_CURVE(1,NUNITS) = 10.
               ENDIF
            ELSE
               CUBIC_HEAT_CURVE(1,NUNITS) = FIRST_POLY
            ENDIF
!
!            ENDIF
C
C MOVE EXISTING UNIT RETIREMENT DATES IN THE EXTENSION PERIOD TO
C OUTSIDE THE PERIOD
! 08/25/03. MOVED UP FOR BURESH AND A.G. EDWARDS.
C
            IF(OFF_LINE_YEAR(NUNITS) > LAST_STUDY_YEAR)
     +                                      OFF_LINE_YEAR(NUNITS) = 2200
C
            ONLINE(NUNITS) = 100*(ON_LINE_YEAR - 1900) + ON_LINE_MONTH
            OFLINE(NUNITS) = 100*(OFF_LINE_YEAR(NUNITS) - 1900) +
     +                                            OFF_LINE_MONTH(NUNITS)
            FIRST_RETIREMENT_YEAR(NUNITS) =
     +                    100*(FIRST_RETIREMENT_YEAR(NUNITS) - 1900)
!
! 05/13/03. NEW RESOURCE ADDITIONS LOGIC
! 05/16/03. MOVED INSIDE UNITS LOOP TO AVOID ADDITIONS AND REMOVALS.
! 08/25/03. MOVED ABOVE UNITS ACTIVE LOOP FOR BURESH AND A.G. EDWARDS.
!
!
            IF(NEWGEN_UNIT_STATUS(1:2) == '01' ) THEN
               NEWGEN_INDEX(NUNITS) = 1
            ELSEIF(NEWGEN_UNIT_STATUS(1:2) == '02' ) THEN
               NEWGEN_INDEX(NUNITS) = 2
            ELSEIF(NEWGEN_UNIT_STATUS(1:2) == '03' ) THEN
               NEWGEN_INDEX(NUNITS) = 3
            ELSEIF(NEWGEN_UNIT_STATUS(1:2) == '04' ) THEN
               NEWGEN_INDEX(NUNITS) = 4
            ELSEIF(NEWGEN_UNIT_STATUS(1:2) == '05') THEN
               NEWGEN_INDEX(NUNITS) = 5
            ELSEIF(NEWGEN_UNIT_STATUS(1:2) == '06' ) THEN
               NEWGEN_INDEX(NUNITS) = 6
            ELSEIF(NEWGEN_UNIT_STATUS(1:2) == '07' ) THEN
               NEWGEN_INDEX(NUNITS) = 7
            ELSEIF(NEWGEN_UNIT_STATUS(1:2) == '08' ) THEN
               NEWGEN_INDEX(NUNITS) = 8
            ELSEIF(NEWGEN_UNIT_STATUS(1:2) == '09' ) THEN
               NEWGEN_INDEX(NUNITS) = 9
            ELSEIF(NEWGEN_UNIT_STATUS(1:2) == '10' ) THEN
               NEWGEN_INDEX(NUNITS) = 10
            ELSEIF(NEWGEN_UNIT_STATUS(1:2) == '11' ) THEN
               NEWGEN_INDEX(NUNITS) = 11
            ELSEIF(NEWGEN_UNIT_STATUS(1:2) == '12' ) THEN
               NEWGEN_INDEX(NUNITS) = 12
            ELSEIF(NEWGEN_UNIT_STATUS(1:2) == '13' ) THEN
               NEWGEN_INDEX(NUNITS) = 13
            ELSE ! DEFAULT INDEX = 1
               NEWGEN_INDEX(NUNITS) = 1
            ENDIF
            NEWGEN_COUNTER(NEWGEN_INDEX(NUNITS)) =
     +                          NEWGEN_COUNTER(NEWGEN_INDEX(NUNITS)) + 1
!
            IF(NEW_BUILD_ADDITIONS_ACTIVE .AND. ONLINE(NUNITS) >
     +                                                  BEGIN_DATE) THEN
! (0.0,1.0) ASSUME UNIFORM DISTRIBUTION
               IRAN32_OUT = iran32()
               RANDOM_NUMBER = FLOAT(IRAN32_OUT)/FLOAT(2147483647)
               KEEP_UNIT = .TRUE.
               IF(    NEWGEN_INDEX(NUNITS) == 2) THEN
                  IF(UNDER_CONSTRUCTION_PERCENT < RANDOM_NUMBER) THEN
                     KEEP_UNIT = .FALSE.
                  ENDIF
               ELSEIF(NEWGEN_INDEX(NUNITS) == 3) THEN
                  IF(ADVANCED_DEVELOPMENT_PERCENT < RANDOM_NUMBER) THEN
                     KEEP_UNIT = .FALSE.
                  ENDIF
               ELSEIF(NEWGEN_INDEX(NUNITS) == 4) THEN
                  IF(EARLY_DEVELOPMENT_PERCENT < RANDOM_NUMBER) THEN
                     KEEP_UNIT = .FALSE.
                  ENDIF
               ELSEIF(NEWGEN_INDEX(NUNITS) == 5) THEN
                  IF(PROPOSED_PERCENT < RANDOM_NUMBER) THEN
                     KEEP_UNIT = .FALSE.
                  ENDIF
               ELSEIF(NEWGEN_INDEX(NUNITS) == 7) THEN
                  IF(INDEFIN_POSTPHONED_PERCENT < RANDOM_NUMBER) THEN
                     KEEP_UNIT = .FALSE.
                  ENDIF
               ELSE
                  IF(UNIT_ACTIVE == 'F') CYCLE
               ENDIF
               IF(.NOT. KEEP_UNIT) THEN
                  CYCLE
               ELSE
                  KEEP_UNIT = .TRUE.
               ENDIF
            ELSE
!
               IF(UNIT_ACTIVE == 'F') CYCLE
!
            ENDIF
!
!
! 10/07/05. TEMP.
!
!            DO M = 1, NUNITS
!               IF(NUNITS == 1) THEN
!                  POWERDAT_PLANT_ID(M) = HIGHEST_ID
!                  HIGHEST_ID = HIGHEST_ID + 1
!                  EXIT
!               ELSEIF(M == NUNITS) THEN
!                  POWERDAT_PLANT_ID(NUNITS) = HIGHEST_ID
!                  HIGHEST_ID = HIGHEST_ID + 1
!               ELSEIF(BASECASE_PLANT_ID(NUNITS) ==
!     +                                        BASECASE_PLANT_ID(M)) THEN
!                  POWERDAT_PLANT_ID(NUNITS) = POWERDAT_PLANT_ID(M)
!                  EXIT
!               ENDIF
!            END DO
!
!
! 052709.
!
            CO2_CONTROL_DATE(NUNITS) = CO2_CONTROL_DATE(NUNITS) + 10000
            IF(HardWiredRetrofitProject(NUNITS)) THEN
               RETIREMENT_CANDIDATE(NUNITS) = 'F'
               FIRST_RETIREMENT_YEAR(NUNITS) = 9999
               RETROFIT_CANDIDATE(NUNITS) = 'F'
            ENDIF
            IF(RETROFIT_CANDIDATE(NUNITS) /= 'F') THEN
               RETROFIT_COUNTER = RETROFIT_COUNTER + 1
               RETROFIT_UNIT_INDEX(RETROFIT_COUNTER) = NUNITS
            ENDIF
            IF(RETIREMENT_CANDIDATE(NUNITS) /= 'F') THEN
               RETIREMENT_COUNTER = RETIREMENT_COUNTER + 1
            ENDIF
!
! 02/03/06.
!
            TEMP_STATE = STATE_PROVINCE(1:2)
            TEMP_I2 = STATE_ID_LOOKUP(TEMP_STATE)
            State_Index(NUNITS) = TEMP_I2
            TEMP_I2 = STATE_ID_LOOKUP(STATE_PROVINCE)
            State_TG_Index(NUNITS) = TEMP_I2
            IF( TEMP_I2 > 0 .AND.
     +                          STATE_PROVINCE_INDEX(TEMP_I2) == 0) THEN
               MAX_STATE_PROVINCE_NO = MAX_STATE_PROVINCE_NO + 1
               STATE_PROVINCE_ADDRESS(MAX_STATE_PROVINCE_NO) = TEMP_I2
               STATE_PROVINCE_INDEX(TEMP_I2) = MAX_STATE_PROVINCE_NO
               STATE_PROVINCE_NAMES(MAX_STATE_PROVINCE_NO) =
     +                                                    STATE_PROVINCE
            ENDIF
            UNIT_STATE_PROVINCE_INDEX(NUNITS) =
     +                                     STATE_PROVINCE_INDEX(TEMP_I2)
! 120606.
!            IF(YES_REGION_POWER_MAP) THEN
! 091309. COMPLETE REWRITE.
            TEMP_I2 = STATE_2_GAS_REGION_LOOKUP(STATE_PROVINCE)
            IF(YES_GSP_IS_ST_TG(TEMP_I2)) THEN
               TEMP_STATE = STATE_PROVINCE
            ELSE
               TEMP_STATE = STATE_PROVINCE(1:2)
            ENDIF
            UNIT_GAS_REGION_INDEX(NUNITS) =
     +                             STATE_2_GAS_REGION_LOOKUP(TEMP_STATE)
!            ELSE
!               UNIT_GAS_REGION_INDEX(NUNITS) = TEMP_I2
!     +                                     STATE_PROVINCE_INDEX(TEMP_I2)
!            ENDIF
!
! 12/05/01
!
            IF(trim(SPECIAL_UNIT_ID(NUNITS)) /= ' ' .AND.
     +                   trim(SPECIAL_UNIT_ID(NUNITS)) /= 'None') THEN
               IF(trim(SPECIAL_UNIT_ID(NUNITS)) == 'BayShore') THEN
!     +               trim(SPECIAL_UNIT_ID(NUNITS)) == 'EastLake') THEN
                  FIRST_ENERGY = .TRUE.
               ENDIF
            ENDIF
! 11/12/01.
            NOX_SEASON_DATE(NUNITS) = NOX_SEASON_DATE(NUNITS) + 10000
! 5/23/02.
            NOX_CONTROL_PERCENT(NUNITS) =
     +             MIN(100.,MAX(0.,1.-NOX_CONTROL_PERCENT(NUNITS)/100.))
            NOX_CONTROL_DATE(NUNITS) = NOX_CONTROL_DATE(NUNITS) + 10000
!
            SOX_CONTROL_PERCENT(NUNITS) =
     +             MIN(100.,MAX(0.,1.-SOX_CONTROL_PERCENT(NUNITS)/100.))
            SOX_CONTROL_DATE(NUNITS) = SOX_CONTROL_DATE(NUNITS) + 10000
!
            CO2_CONTROL_PERCENT(NUNITS) =
     +             MIN(100.,MAX(0.,1.-CO2_CONTROL_PERCENT(NUNITS)/100.))
            HG_CONTROL_PERCENT(NUNITS) =
     +             MIN(100.,MAX(0.,1.-HG_CONTROL_PERCENT(NUNITS)/100.))
            HG_CONTROL_DATE(NUNITS) = HG_CONTROL_DATE(NUNITS) + 10000
            OTHER3_CONTROL_PERCENT(NUNITS) =
     +             MIN(100.,
     +                   MAX(0.,1.-OTHER3_CONTROL_PERCENT(NUNITS)/100.))
            OTHER3_CONTROL_DATE(NUNITS) =
     +                               OTHER3_CONTROL_DATE(NUNITS) + 10000
! TEMP. 12/11/98. GAT. THROW AWAY NON-UTILITY UNITS
!
            IF((SAVE_IGNORE_NON_UTILITY  == 'T' .AND.
     +                                        UTILITY_OWNED == 'N') .OR.
     +         (SAVE_IGNORE_NON_UTILITY  == 'K' .AND.
     +                  UTILITY_OWNED == 'N' .AND.
     +                              ON_LINE_YEAR-BASE_YEAR < 1)  ) CYCLE
C
C THIS ESTABLISHES A UNIQUE UNIT ID VALUE FOR EACH RUN
C
            CL_UNIT_UNIQUE_RPT_ID(NUNITS) = UNIQUE_ID_NUM
!
! 1/17/99. GAT.
!
            CALL UPC(TEMP_PRIM_FUEL_TYPE_STR,PRIM_FUEL_TYPE_STR)
            PRIMARY_MOVER(NUNITS) =
     +                        FUEL_TYPE_2_PRIM_MOVER(PRIM_FUEL_TYPE_STR)
!
! 070209. FOR TESTING.
!
!            IF( (PRIMARY_MOVER(NUNITS) == 1 .OR.
!     +             PRIMARY_MOVER_INDEX_DB(
!     +                    PRIMARY_MOVER_STR(NUNITS)) == 10) .AND.
!     +                                         ON_LINE_YEAR < 1990) THEN
!               RETIREMENT_CANDIDATE(NUNITS) = 'T'
!            ELSE
!               RETIREMENT_CANDIDATE(NUNITS) = 'F'
!            ENDIF
!            IF( .NOT. (PRIMARY_MOVER(NUNITS) == 1 .OR.
!     +                     PRIMARY_MOVER_INDEX_DB(
!     +                           PRIMARY_MOVER_STR(NUNITS)) == 10)) THEN
!               RETROFIT_CANDIDATE(NUNITS) = 'F'
!            ELSE
!            ENDIF
!
!
!
!            IF(               PRIM_FUEL_TYPE_STR == 'SUB   ' .OR.
!     +                        PRIM_FUEL_TYPE_STR == 'ANT   ' .OR.
!     +                        PRIM_FUEL_TYPE_STR == 'COL   ' .OR.
!     +                        PRIM_FUEL_TYPE_STR == 'C     ' .OR.
!     +                        PRIM_FUEL_TYPE_STR == 'PC    ' .OR.
!     +                        PRIM_FUEL_TYPE_STR == 'BIT   ' .OR.
!     +                        PRIM_FUEL_TYPE_STR == 'WC    ' .OR. ! ADDED FOR BURESH 02/11/02.
!     +                        PRIM_FUEL_TYPE_STR == 'COAL  ' .OR.
!     +                        PRIM_FUEL_TYPE_STR == 'LIG   ') THEN
!               PRIMARY_MOVER(NUNITS) = 1
!            ELSEIF(           PRIM_FUEL_TYPE_STR == 'GAS   ' .OR.
!     +                        PRIM_FUEL_TYPE_STR == 'G     ' .OR.
!     +                        PRIM_FUEL_TYPE_STR == 'BFG   ' .OR.
!     +                        PRIM_FUEL_TYPE_STR == 'COG   ' .OR.
!     +                        PRIM_FUEL_TYPE_STR == 'SNG   ' .OR.
!     +                        PRIM_FUEL_TYPE_STR == 'NG    ') THEN
!               PRIMARY_MOVER(NUNITS) = 2
!            ELSEIF(           PRIM_FUEL_TYPE_STR(1:2) == 'FO' .OR.
!     +                        PRIM_FUEL_TYPE_STR == 'DFO   ' .OR.
!     +                        PRIM_FUEL_TYPE_STR == 'DSL   ' .OR.
!     +                        PRIM_FUEL_TYPE_STR == 'KER   ' .OR.
!     +                        PRIM_FUEL_TYPE_STR == 'PET   ' .OR.
!     +                        PRIM_FUEL_TYPE_STR == 'Oil   ' .OR.
!     +                        PRIM_FUEL_TYPE_STR == 'JF    ') THEN
!               PRIMARY_MOVER(NUNITS) = 3
!            ELSEIF(           PRIM_FUEL_TYPE_STR == 'UR    ' .OR.
!     +                        PRIM_FUEL_TYPE_STR == 'URA   ' .OR.
!     +                        PRIM_FUEL_TYPE_STR(1:3) == 'N  ' .OR.
!     +                        PRIM_FUEL_TYPE_STR(1:3) == 'NUC') THEN
!               PRIMARY_MOVER(NUNITS) = 4
!            ELSEIF(           PRIM_FUEL_TYPE_STR == 'WAT   ') THEN
!               PRIMARY_MOVER(NUNITS) = 5
!            ELSEIF(           PRIM_FUEL_TYPE_STR == 'SUN   ' .OR.
!     +                        PRIM_FUEL_TYPE_STR == 'SOLAR ') THEN
!               PRIMARY_MOVER(NUNITS) = 8
!            ELSEIF(           PRIM_FUEL_TYPE_STR == 'WND   ') THEN
!               PRIMARY_MOVER(NUNITS) = 9
!            ELSE
!               PRIMARY_MOVER(NUNITS) = 6
!            ENDIF
!            CALL UPC(TEMP_NEWGEN_UNIT_STATUS,NEWGEN_UNIT_STATUS)
!
!            IF(START_UP_LOGIC(NUNITS) /= 'F') THEN
!               TOTAL_START_UP_UNITS = TOTAL_START_UP_UNITS + 1
!               START_UP_INDEX(NUNITS) = TOTAL_START_UP_UNITS
!            ENDIF
!
            CALL SET_ASSET_CLASSES(ASSET_CLASS_NUM(NUNITS),
     +                             NUMBER_OF_CAP_LIMITED_CLASSES,
     +	                          MAX_CAP_LIMITED_CLASS_ID_NUM,
     +                             CAP_LIMITED_CLASS_POINTER)
!
            IF(TRANS_ID > 0 .AND. ON_LINE_YEAR <= LAST_STUDY_YEAR) THEN
               DAY_ID = DAY_TYPE_ID(NUNITS)
               MAX_TRANS_ID_USED = MAX(MAX_TRANS_ID_USED, TRANS_ID)
               IF(DAY_ID > 0 .AND. DAY_ID <= MAX_DAY_TYPES ) THEN
                  IF(DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,TRANS_ID)==0) THEN
                     MAX_TRANS_DATA_BASES = MAX_TRANS_DATA_BASES + 1
                     DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,TRANS_ID) =
     +                                              MAX_TRANS_DATA_BASES
                  ENDIF
!
                  DATA_BASE_POSITION(1,NUNITS) =
     +                        DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,TRANS_ID)
                  DATA_BASE_POSITION(2,NUNITS) =
     +                        DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,0)
               ELSEIF(DAY_ID < 0) THEN
                  DAY_TYPE_COUNTER = 1
                  DO
                     DAY_ID = INT(GET_VAR(FLOAT(DAY_TYPE_ID(NUNITS)),
     +                                DAY_TYPE_COUNTER,"FIND DAY TYPE"))
                     IF(DAY_ID <= 0 .OR. DAY_ID > MAX_DAY_TYPES) EXIT
                     IF(DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,TRANS_ID) == 0)
     +                                                              THEN
                        MAX_TRANS_DATA_BASES = MAX_TRANS_DATA_BASES + 1
                        DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,TRANS_ID) =
     +                                              MAX_TRANS_DATA_BASES
                     ENDIF
      !
                     DATA_BASE_POSITION(2*DAY_TYPE_COUNTER-1,NUNITS) =
     +                        DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,TRANS_ID)
                     DATA_BASE_POSITION(2*DAY_TYPE_COUNTER,NUNITS) =
     +                               DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,0)
                     DAY_TYPE_COUNTER = DAY_TYPE_COUNTER + 1
                  ENDDO
               ELSEIF(DAY_ID == 0) THEN
                  DO M = 1, MAX_DAY_TYPES
                     IF(DAY_TYPE_TRANS_GROUP_PAIR(M,TRANS_ID) == 0) THEN
                        MAX_TRANS_DATA_BASES = MAX_TRANS_DATA_BASES + 1
                        DAY_TYPE_TRANS_GROUP_PAIR(M,TRANS_ID) =
     +                                              MAX_TRANS_DATA_BASES
                     ENDIF
                     DATA_BASE_POSITION(2*M-1,NUNITS) =
     +                             DAY_TYPE_TRANS_GROUP_PAIR(M,TRANS_ID)
                     DATA_BASE_POSITION(2*M,NUNITS) =
     +                                    DAY_TYPE_TRANS_GROUP_PAIR(M,0)
                  ENDDO
               ELSE
                  WRITE(4,*) "DAY TYPE DESIGNATION",DAY_ID
                  WRITE(4,*) "OUTSIDE THE RANGE OF POSSIBLE OUTCOMES"
                  WRITE(4,*)"MAXIMUM DAY TYPES DEFINED = ",MAX_DAY_TYPES
                  WRITE(4,*) '*** line 2056 CLA_OBJT.FOR ***'
                  er_message='See WARNING MESSAGES'
                  call end_program(er_message)
               ENDIF
            ENDIF
!
            IF(MAINT_DAYS(NUNITS) /= 0.)
     +                                SAVE_DETAILED_MAINTENANCE = .TRUE.
            DISP_ADDER_ESCR(NUNITS) = PFESCR(NUNITS)
!
! 10/1/00. GAT. MOVED FROM MARGOBJ.FOR
!
            LOCAL_RESOURCE_ID = CL_RESOURCE_ID(NUNITS)
            IF(NUMBER_OF_RESOURCE_ID(LOCAL_RESOURCE_ID) == 0) THEN
               RESOURCE_ID_TO_UNIT(LOCAL_RESOURCE_ID) = NUNITS ! FIRST OCCURANCE
            ENDIF
            NUMBER_OF_RESOURCE_ID(LOCAL_RESOURCE_ID) =
     +                      NUMBER_OF_RESOURCE_ID(LOCAL_RESOURCE_ID) + 1
!
            IF(INPUT_MW(1,NUNITS) == 0.)
     +                           INPUT_MW(1,NUNITS) = INPUT_MW(2,NUNITS)
            ECONOMY_TRANS_TYPE(NUNITS) = 'T'
            LDTYPE(NUNITS) = CL_LOAD_TYPE(1:1)
            PRIM_FUEL_TYPE(NUNITS) = PRIM_FUEL_TYPE_STR(1:1)
            NUC_FUEL_PRICES_FROM_FUEL_FILE(NUNITS) =
     +                      INDEX(PRIM_FUEL_TYPE_STR,'Nuc-NF') /= 0 .OR.
     +                           INDEX(PRIM_FUEL_TYPE_STR,'NUC-NF') /= 0
            IF(INDEX('123456',CL_LOAD_TYPE(2:2)) /= 0) THEN
               CL_CAP_AREA_LINKED(NUNITS) = .TRUE.
               MONTHLY_CAPACITY_POINTER(NUNITS) =
     +                                -INDEX('123456',CL_LOAD_TYPE(2:2))
               ECONOMY_TRANS_TYPE(NUNITS) = 'N'
            ELSE
               CL_CAP_AREA_LINKED(NUNITS) = .FALSE.
               IF(CL_LOAD_TYPE(2:2)=='S') ECONOMY_TRANS_TYPE(NUNITS)='S'
               IF(CL_LOAD_TYPE(2:2)=='B') ECONOMY_TRANS_TYPE(NUNITS)='B'
               IF(CL_LOAD_TYPE(2:2)=='N') ECONOMY_TRANS_TYPE(NUNITS)='N'
            ENDIF
            ON_LINE_YEAR = MIN(MAX(ON_LINE_YEAR,1901),2200)
            OFF_LINE_YEAR(NUNITS) = MIN(OFF_LINE_YEAR(NUNITS),2200)
!
!           IF(GENGRP(NUNITS) < 1 .OR.
!     +       GENGRP(NUNITS) > MAX_REPORTING_GROUPS) GENGRP(NUNITS)=0
            IF(EFORS0) EFOR(NUNITS) = 0.
C READ PLANNED MAINTENANCE RATES
            IF(SORS0) THEN
               MAINT_DAYS(NUNITS) = 0
               DO M = 1, 12
                  MNRATE(NUNITS,M) = 0.
               ENDDO
            ENDIF
C
C CHECK IF LAST ENERGY SOURCE
C
            IF(LDTYPE(NUNITS) == 'L') THEN
               INPUT_MW(1,NUNITS) = 0.
               INPUT_MW(2,NUNITS) = 0.
               CAP_PLANNING_FAC(NUNITS) = 0.
               EFOR(NUNITS) = 0.
               FUEL_SUPPLY_ID(NUNITS) = 0
               DO M = 1 , 12
                  IF(MNRATE(NUNITS,M) /= 100.) MNRATE(NUNITS,M) = 0.
               ENDDO
            ENDIF
C
C 9/15/95. GAT. FOR DUKE POWER.
C
            IF(LDTYPE(NUNITS) == 'N'.AND.EXPENSE_ASSIGNMENT(NUNITS)/='O'
     +                     .AND. EXPENSE_ASSIGNMENT(NUNITS) /= 'L') THEN
               EXPENSE_ASSIGNMENT(NUNITS) = 'O'
               WRITE(4,*) "Generating unit",UNITNM(NUNITS),
     +                   "was assigned"//
     +                   " as nuclear without either an owned or leased"
               WRITE(4,*) "expense designation. This unit was "//
     +                               "reassigned as owned nuclear fuel."
               WRITE(4,*) " "
            ENDIF
            IF(LDTYPE(NUNITS) == 'N') THEN
               DO M = 1, 12
                  NUC_MAINTENANCE(M) = MNRATE(NUNITS,M)
               ENDDO
               CALL CAL_GENERATING_INFORMATION(CL_RESOURCE_ID(NUNITS),
     +                              CAP_FRAC_OWN(NUNITS),
     +                              INPUT_MW(2,NUNITS),
     +                              MONTHLY_CAPACITY_POINTER(NUNITS),
     +                              EFOR(NUNITS),
     +                              NUC_MAINTENANCE,
     +                              ONLINE(NUNITS),
     +                              OFLINE(NUNITS),
     +                              UNITNM(NUNITS),
     +                              PRIM_FUEL_TYPE_STR)
               IF(NUC_FUEL_PRICES_FROM_FUEL_FILE(NUNITS)) THEN
                  PBTUCT(NUNITS) = 0.
                  SBTUCT(NUNITS) = 0.
                  EMISS_FUEL_COST(NUNITS) = 0.
               ENDIF
            ENDIF
C
C NEED TO SAVE PRICE INFORMATION
C
            PBTUCT_SAVE(NUNITS) = PBTUCT(NUNITS)
            SBTUCT_SAVE(NUNITS) = SBTUCT(NUNITS)
            FUELADJ_SAVE(NUNITS) = FUELADJ(NUNITS)
            VCPMWH_IN_SAVE(NUNITS) = VCPMWH_IN(NUNITS)
            FIXED_COST_SAVE(NUNITS) = FIXED_COST_IN(NUNITS)
            ANNUAL_CL_FIXED_COST_SAVE(NUNITS) =
     +                                      ANNUAL_CL_FIXED_COST(NUNITS)
            DISPADJ_SAVE(NUNITS) = DISPADJ(NUNITS)
            DISPADJ2_SAVE(NUNITS) = DISPADJ2(NUNITS)
            DISPATCH_MULT_SAVE(NUNITS) = DISPATCH_MULT(NUNITS)
            EXCESS_ENERGY_SALES_SAVE(NUNITS) =
     +                                       EXCESS_ENERGY_SALES(NUNITS)
            CL_AI_CAPACITY_RATE_SAVE(NUNITS) =
     +                                       CL_AI_CAPACITY_RATE(NUNITS)
            CL_AI_ENERGY_RATE_SAVE(NUNITS) = CL_AI_ENERGY_RATE(NUNITS)
            CL_AI_REMAINING_LIFE_SAVE(NUNITS) =
     +                                      AI_CL_REMAINING_LIFE(NUNITS)
            DISPADJ2_SAVE(NUNITS) = DISPADJ2(NUNITS)
            EMISS_FUEL_COST_SAVE(NUNITS) = EMISS_FUEL_COST(NUNITS)
            IF(ON_LINE_YEAR <= OFF_LINE_YEAR(NUNITS) .AND.
     +         ON_LINE_YEAR-BASE_YEAR <= STUDY_PERIOD .AND.
     +                          OFF_LINE_YEAR(NUNITS) > BASE_YEAR) THEN
               VOID_REAL =
     +                CL_CAPACITY_PLANNING_ADJUSTMENTS(ON_LINE_YEAR,
     +                                                 NUNITS,1,.FALSE.) ! REMOVED 11/02/06
c               IF(CapEx_Running)
c     +            CALL CapEx_Thermal_Units(UNITNM(NUNITS),
c     +                                     NUNITS,
c     +                                     LDTYPE(NUNITS),
c     +                                     TRANSACTION_GROUP_ID(NUNITS))

               SHADOW_UNIT_NUMBER(NUNITS) = 0
               IF(FUEL_SUPPLY_ID(NUNITS)>0 .AND.
     +                       FUEL_MIX_PTR(NUNITS) > 0. .AND.
     +                               START_UP_LOGIC(NUNITS) == 'F') THEN ! FUELMX(NUNITS) >0.) THEN
                  I = NUNITS
                  NUNITS = I + 1
                  SHADOW_UNIT_NUMBER(NUNITS) = I
                  SHADOW_UNIT_NUMBER(I) = NUNITS
                  UNITNM(NUNITS) = '+'//UNITNM(I)
                  CL_UNIT_UNIQUE_RPT_ID(NUNITS) = UNIQUE_ID_NUM
                  FUEL_MIX_PTR(NUNITS) = 0. ! FUELMX(NUNITS) = 0 REPLACE 5/17/01
                  LDTYPE(NUNITS) = 'S'
                  EXPENSE_ASSIGNMENT(NUNITS) = EXPENSE_ASSIGNMENT(I)
                  EXPENSE_COLLECTION(NUNITS) = EXPENSE_COLLECTION(I)
                  ASSET_CLASS_NUM(NUNITS) = ASSET_CLASS_NUM(I)
                  ASSET_CLASS_VECTOR(NUNITS) = ASSET_CLASS_VECTOR(I)
                  INTRA_COMPANY_CLASS_ID(NUNITS) =
     +                                         INTRA_COMPANY_CLASS_ID(I)
                  INTRA_COMPANY_TRANSACTION(NUNITS) =
     +                                      INTRA_COMPANY_TRANSACTION(I)
                  SPECIAL_UNIT_ID(NUNITS) = SPECIAL_UNIT_ID(I)
                  MINIMUM_CAPACITY_FACTOR(NUNITS) =
     +                                        MINIMUM_CAPACITY_FACTOR(I)
                  MAXIMUM_CAPACITY_FACTOR(NUNITS) =
     +                                        MAXIMUM_CAPACITY_FACTOR(I)
                  TRANSACTION_GROUP_ID(NUNITS) = TRANSACTION_GROUP_ID(I)
                  REPORT_THIS_UNIT(NUNITS) = REPORT_THIS_UNIT(I)
                  DAY_TYPE_ID(NUNITS) = DAY_TYPE_ID(I)
                  ECONOMY_TRANS_TYPE(NUNITS) = ECONOMY_TRANS_TYPE(I)
                  CL_CAP_AREA_LINKED(NUNITS) = CL_CAP_AREA_LINKED(I)
                  GENGRP(NUNITS) = GENGRP(I)
                  CAP_FRAC_OWN(NUNITS) = CAP_FRAC_OWN(I)
                  ONLINE(NUNITS) = ONLINE(I)
                  OFLINE(NUNITS) = OFLINE(I)
                  SBTUCT(NUNITS) = SBTUCT(I)
                  SBTUCT(I) = 0.
                  SFESCR(NUNITS) = SFESCR(I)
                  SFESCR(I) = 0
                  FUELADJ(NUNITS) = FUELADJ(I)
                  EFOR(NUNITS) = EFOR(I)
                  MAINT_DAYS(NUNITS) = MAINT_DAYS(I)
                  DO M = 1, 12
                     MNRATE(NUNITS,M) = MNRATE(I,M)
                  ENDDO
                  VCPMWH_IN(NUNITS) = VCPMWH_IN(I)
                  OMESCR(NUNITS) = OMESCR(I)
                  FIXED_COST_IN(NUNITS) = 0.
                  ANNUAL_CL_FIXED_COST(NUNITS) = 0.
                  FIXED_COST_ESCALATOR(NUNITS) = 0.
                  ANNUAL_CL_FIXED_COST_ESC(NUNITS) = 0.
                  DISPADJ(NUNITS) = DISPADJ(I)
                  DISPATCH_MULT(NUNITS) = DISPATCH_MULT(I)
                  EXCESS_ENERGY_SALES(NUNITS) = EXCESS_ENERGY_SALES(I)
                  HR_FACTOR(NUNITS) = HR_FACTOR(I)
                  INPUT_MW(1,NUNITS) = INPUT_MW(1,I)
                  INPUT_MW(2,NUNITS) = INPUT_MW(2,I)
                  COEFF(1,NUNITS) = COEFF(1,I)
                  COEFF(2,NUNITS) = COEFF(2,I)
                  COEFF(3,NUNITS) = COEFF(3,I)
                  CL_AI_CAPACITY_RATE(NUNITS) = CL_AI_CAPACITY_RATE(I)
                  CL_AI_CAPACITY_ESCALATOR(NUNITS) =
     +                                       CL_AI_CAPACITY_ESCALATOR(I)
                  CL_AI_ENERGY_RATE(NUNITS) = CL_AI_ENERGY_RATE(I)
                  CL_AI_ENERGY_ESCALATOR(NUNITS) =
     +                                         CL_AI_ENERGY_ESCALATOR(I)
                  AI_CL_REMAINING_LIFE(NUNITS) = AI_CL_REMAINING_LIFE(I)
                  AI_CL_TAX_LIFE(NUNITS) = AI_CL_TAX_LIFE(I)
                  AI_CL_ADR_LIFE(NUNITS) = AI_CL_ADR_LIFE(I)
                  SEC_FUEL_EMISS_PTR(NUNITS) = SEC_FUEL_EMISS_PTR(I)
                  SEC_FUEL_EMISS_PTR(I) = 0
                  CL_RESOURCE_ID(NUNITS) = CL_RESOURCE_ID(I)
                  DISPADJ2(NUNITS) = DISPADJ2(I)
                  PHASE_I_UNIT(NUNITS) = PHASE_I_UNIT(I)
                  LOCAL_CL_POOL_FRAC_OWN(NUNITS) =
     +                                         LOCAL_CL_POOL_FRAC_OWN(I)
C
C SINCE ONLY THE SECONDARY FUEL IS USED ZERO PRIMARLY AND EMISSIONS FUEL
C DATA
C
                  FUEL_SUPPLY_ID(NUNITS) = FUEL_SUPPLY_ID(I)
                  CAP_PLANNING_FAC(NUNITS) = 0.
                  PBTUCT(NUNITS) = PBTUCT(I)
                  PFESCR(NUNITS) = PFESCR(I)
                  DISP_ADDER_ESCR(NUNITS) = DISP_ADDER_ESCR(I)
                  P_SO2(NUNITS) = P_SO2(I)
                  P_NOX(NUNITS) = P_NOX(I)
                  P_PARTICULATES(NUNITS) = P_PARTICULATES(I)
                  P_EMIS_OTH2(NUNITS) = P_EMIS_OTH2(I)
                  P_EMIS_OTH3(NUNITS) = P_EMIS_OTH3(I)
                  P_NOX_BK2(NUNITS) = P_NOX_BK2(I)
                  EMISS_FUEL_COST(NUNITS) = EMISS_FUEL_COST(I)
                  EMISS_FUEL_ESCAL(NUNITS) = EMISS_FUEL_ESCAL(I)
                  EMISS_FUEL_EMISS_PTR(NUNITS) = 0.
                  EMISS_BLENDING_RATE(NUNITS) = EMISS_BLENDING_RATE(I)
                  PRIM_FUEL_EMISS_PTR(NUNITS) = PRIM_FUEL_EMISS_PTR(I)
C 6/10/93. GAT. NO ALLOCATION OF FUEL TYPES BETWEEN SHADOWS
                  PRIM_FUEL_TYPE(NUNITS) = " "
                  NUC_FUEL_PRICES_FROM_FUEL_FILE(NUNITS) = .FALSE.
                  SEC_FUEL_TYPE(NUNITS) = SEC_FUEL_TYPE(I)
                  SEC_FUEL_TYPE(I) = " "
                  EMISS_FUEL_TYPE(NUNITS) = " "
                  TIE_CONSTRAINT_GROUP(NUNITS) = TIE_CONSTRAINT_GROUP(I)
                  PBTUCT_SAVE(NUNITS) = PBTUCT(I)
C                  SBTUCT_SAVE(NUNITS) = SBTUCT(I) ! 9/28/95. GAT.
                  SBTUCT_SAVE(NUNITS) = SBTUCT(NUNITS)
                  FUELADJ_SAVE(NUNITS) = FUELADJ(I)
                  VCPMWH_IN_SAVE(NUNITS) = VCPMWH_IN(I)
                  FIXED_COST_SAVE(NUNITS) = FIXED_COST_IN(I)
                  ANNUAL_CL_FIXED_COST_SAVE(NUNITS) =
     +                                           ANNUAL_CL_FIXED_COST(I)
                  DISPATCH_MULT_SAVE(NUNITS) = DISPATCH_MULT(I)
                  EXCESS_ENERGY_SALES_SAVE(NUNITS) =
     +                                            EXCESS_ENERGY_SALES(I)
                  MONTHLY_CAPACITY_POINTER(NUNITS) =
     +                                       MONTHLY_CAPACITY_POINTER(I)
                  DISPADJ_SAVE(NUNITS) = DISPADJ(I)
                  DISPADJ2_SAVE(NUNITS) = DISPADJ2(I)
                  CL_AI_CAPACITY_RATE_SAVE(NUNITS) =
     +                                            CL_AI_CAPACITY_RATE(I)
                  CL_AI_ENERGY_RATE_SAVE(NUNITS) = CL_AI_ENERGY_RATE(I)
                  CL_AI_REMAINING_LIFE_SAVE(NUNITS) =
     +                                           AI_CL_REMAINING_LIFE(I)
                  DISPADJ2_SAVE(NUNITS) = DISPADJ2(I)
                  EMISS_FUEL_COST_SAVE(NUNITS) = EMISS_FUEL_COST(I)
!
! 072106. TEMP FOR BURESH
!
!                  IF(PRIM_FUEL_TYPE_STR == 'SUB   ' .OR.
!     +                     PRIM_FUEL_TYPE_STR == 'ANT   ' .OR.
!     +                     PRIM_FUEL_TYPE_STR == 'BIT   ' .OR.
!     +                     PRIM_FUEL_TYPE_STR == 'WC    ' .OR. ! ADDED FOR BURESH 02/11/02.
!     +                     PRIM_FUEL_TYPE_STR == 'BLQ   ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'COL   ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'SC    ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'PC    ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'COAL  ' .OR.
!     +                              PRIM_FUEL_TYPE_STR == 'LIG   ') THEN
!                     PRIMARY_MOVER(NUNITS) = 1
!                  ELSEIF(PRIM_FUEL_TYPE_STR == 'GAS   ' .OR.
!     +                  PRIM_FUEL_TYPE_STR == 'G     ' .OR.
!     +                     PRIM_FUEL_TYPE_STR == 'BFG   ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'OG    ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'WH    ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'MTE   ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                              PRIM_FUEL_TYPE_STR == 'NG    ') THEN
!                     PRIMARY_MOVER(NUNITS) = 2
!                  ELSEIF(PRIM_FUEL_TYPE_STR(1:2) == 'FO' .OR.
!     +                     PRIM_FUEL_TYPE_STR == 'DSL   ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'JF    ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'KER   ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'OIL   ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'WO    ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'RFO   ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                              PRIM_FUEL_TYPE_STR == 'DFO   ') THEN
!                     PRIMARY_MOVER(NUNITS) = 3
!                  ELSEIF(PRIM_FUEL_TYPE_STR == 'UR    ' .OR.
!     +                  PRIM_FUEL_TYPE_STR == 'URA   ' .OR.
!     +                  PRIM_FUEL_TYPE_STR(1:3) == 'NUC') THEN
!                     PRIMARY_MOVER(NUNITS) = 4
!                  ELSEIF(PRIM_FUEL_TYPE_STR == 'WAT   ') THEN
!                     PRIMARY_MOVER(NUNITS) = 5
!                  ELSEIF(PRIM_FUEL_TYPE_STR == 'SUN   ' .OR.
!     +                        PRIM_FUEL_TYPE_STR == 'SOLAR ') THEN
!                     PRIMARY_MOVER(NUNITS) = 8
!                  ELSEIF(PRIM_FUEL_TYPE_STR == 'WND   ') THEN
!                     PRIMARY_MOVER(NUNITS) = 9
!                  ELSE
!                     PRIMARY_MOVER(NUNITS) = 6
!                  ENDIF

!
! ADDED 6/29/98. GAT.
                  TRANS_ID = TRANSACTION_GROUP_ID(NUNITS)
!
                  IF(TRANS_ID > 0 .AND.
     +                             ON_LINE_YEAR <= LAST_STUDY_YEAR) THEN
                     DAY_ID = DAY_TYPE_ID(NUNITS)
                     MAX_TRANS_ID_USED = MAX(MAX_TRANS_ID_USED,TRANS_ID)
                     IF(DAY_ID > 0 .AND. DAY_ID <= MAX_DAY_TYPES ) THEN
                        IF(DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,TRANS_ID)
     +                                                        == 0) THEN
                           MAX_TRANS_DATA_BASES = MAX_TRANS_DATA_BASES+1
                           DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,TRANS_ID) =
     +                                              MAX_TRANS_DATA_BASES
                        ENDIF
!
                        DATA_BASE_POSITION(1,NUNITS) =
     +                        DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,TRANS_ID)
                        DATA_BASE_POSITION(2,NUNITS) =
     +                               DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,0)
                     ELSEIF(DAY_ID < 0) THEN
                        DAY_TYPE_COUNTER = 1
                        DO
                           DAY_ID =
     +                           INT(GET_VAR(FLOAT(DAY_TYPE_ID(NUNITS)),
     +                                DAY_TYPE_COUNTER,"FIND DAY TYPE"))
                           IF(DAY_ID <= 0 .OR.
     +                                      DAY_ID > MAX_DAY_TYPES) EXIT
                           IF(DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,TRANS_ID)
     +                                                        == 0) THEN
                              MAX_TRANS_DATA_BASES =
     +                                          MAX_TRANS_DATA_BASES + 1
                              DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,
     +                                  TRANS_ID) = MAX_TRANS_DATA_BASES
                           ENDIF
      !
                           DATA_BASE_POSITION(
     +                                    2*DAY_TYPE_COUNTER-1,NUNITS) =
     +                        DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,TRANS_ID)
                           DATA_BASE_POSITION(2*DAY_TYPE_COUNTER,
     +                       NUNITS)=DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,0)
                           DAY_TYPE_COUNTER = DAY_TYPE_COUNTER + 1
                        ENDDO
                     ELSEIF(DAY_ID == 0) THEN
                        DO M = 1, MAX_DAY_TYPES
                           IF(DAY_TYPE_TRANS_GROUP_PAIR(M,TRANS_ID)
     +                                                        == 0) THEN
                              MAX_TRANS_DATA_BASES =
     +                                          MAX_TRANS_DATA_BASES + 1
                              DAY_TYPE_TRANS_GROUP_PAIR(M,TRANS_ID) =
     +                                              MAX_TRANS_DATA_BASES
                           ENDIF
                           DATA_BASE_POSITION(2*M-1,NUNITS) =
     +                             DAY_TYPE_TRANS_GROUP_PAIR(M,TRANS_ID)
                           DATA_BASE_POSITION(2*M,NUNITS) =
     +                                    DAY_TYPE_TRANS_GROUP_PAIR(M,0)
                        ENDDO
                     ELSE
                        WRITE(4,*) "DAY TYPE DESIGNATION",DAY_ID
                        WRITE(4,*)
     +                          "OUTSIDE THE RANGE OF POSSIBLE OUTCOMES"
                        WRITE(4,*)
     +                      "MAXIMUM DAY TYPES DEFINED = ",MAX_DAY_TYPES
                        WRITE(4,*) '*** line 2391 CLA_OBJT.FOR ***'
                        er_message='See WARNING MESSAGES'
                        call end_program(er_message)
                     ENDIF
                  ENDIF
!
               ENDIF ! SHADOW UNIT
!
               IF(START_UP_LOGIC(NUNITS) /= 'F') THEN
                  TOTAL_START_UP_UNITS = TOTAL_START_UP_UNITS + 1
                  START_UP_INDEX(NUNITS) = TOTAL_START_UP_UNITS
               ENDIF
!
               NUNITS = NUNITS + 1
            ENDIF ! CONTRIBUTES TO CAPACITY PLANNING
            IF(NUNITS > MAX_CL_UNITS) THEN
c               CALL LOCATE(20,0)
c               WRITE(6,'("&",A,I5,A)') 'More than ',MAX_CL_UNITS,
c     +                                 ' capacity-limited'
c               WRITE(6,*) 'units are in the capacity-limited'
c               WRITE(6,*) 'file after expansion planning.'
               WRITE(SCREEN_MESSAGES,'(A,I5,A)')
     +                                        'More than ',MAX_CL_UNITS,
     +                                        ' capacity-limited'
               CALL MG_LOCATE_WRITE(20,0,trim(SCREEN_MESSAGES),
     +                                                   ALL_VERSIONS,1)
               CALL MG_LOCATE_WRITE(21,0,
     +                              'units are in the capacity-limited',
     +                                                   ALL_VERSIONS,1)
               CALL MG_LOCATE_WRITE(22,0,
     +                               'file after expansion planning.',
     +                                                   ALL_VERSIONS,1)
               er_message='stop requested from Cla_objt SIID24'
               call end_program(er_message)
            ENDIF
         ENDDO ! PROCESSING WITHIN A FILE
         CLOSE(10,IOSTAT=IOS)
         IF(RDI_CL_RECORDS > 0 .AND. PROCESSING_FIRST_DATA_FILE) THEN
            CALL CLOSE_BOTH_RDI_FILES
         ENDIF
      ENDDO ! CL FILES LOOP
      NUNITS = NUNITS - 1
      BASE_CL_UNITS = NUNITS
      AVAILABLE_CL_UNITS = NUNITS
      BASE_PLUS_HARDWIRED_CL_UNITS = NUNITS
      CL_UNITS_READ = NUNITS
! 051310. TO GENERATE MONTHLY CAPACITIES
      IF(NUNITS > 0) THEN
         SAVE_DETAILED_MAINTENANCE = .TRUE.
      ENDIF
      RETIRE_RETRO_COUNTER = RETROFIT_COUNTER + RETIREMENT_COUNTER
      IF(ALLOCATED(RETIRE_RETRO_CO2_PRICE))
     +      DEALLOCATE(RETIRE_RETRO_CO2_PRICE,
     +                 RETIRE_RETRO_UPLIFT_PER_TON,
     +                 RETIRE_RETRO_CUM_CO2,
     +                 NEW_UNIT_RETIRE_VALUE_BY_CM,
     +                 RETIRE_RETRO_INDEX,
     +                 RETIRE_OR_RETRO,
     +                 RETIRE_RETRO_POSITION,
     +                 RETIRE_RETRO_ABATE_INDEX)
      ALLOCATE(RETIRE_RETRO_CO2_PRICE(RETIRE_RETRO_COUNTER),
     +         RETIRE_RETRO_UPLIFT_PER_TON(RETIRE_RETRO_COUNTER),
     +         RETIRE_RETRO_CUM_CO2(0:RETIRE_RETRO_COUNTER),
     +         NEW_UNIT_RETIRE_VALUE_BY_CM(UPPER_TRANS_GROUP),
     +         RETIRE_RETRO_INDEX(RETIRE_RETRO_COUNTER),
     +         RETIRE_OR_RETRO(RETIRE_RETRO_COUNTER),
     +         RETIRE_RETRO_POSITION(RETIRE_RETRO_COUNTER),
     +         RETIRE_RETRO_ABATE_INDEX(RETIRE_RETRO_COUNTER))
!
      RETURN
!C***********************************************************************
!      ENTRY GET_MINIMUM_CAPACITY_BID(R_NUNITS)
!C***********************************************************************
!         GET_MINIMUM_CAPACITY_BID = MINIMUM_CAPACITY_BID(R_NUNITS)
!      RETURN
C***********************************************************************
      ENTRY INIT_CLA_UNIT_UP_YESTERDAY()
C***********************************************************************
!
! CALLED FROM PRO_COST, ONCE PER ENDPOINT
!
         CLA_UNIT_UP_YESTERDAY = .TRUE. ! MAX_CL_UNITS
!
         INIT_CLA_UNIT_UP_YESTERDAY = .TRUE.
!
      RETURN
C***********************************************************************
      ENTRY GET_CLA_UNIT_UP_YESTERDAY(R_NUNITS)
C***********************************************************************
!
! CALLED FROM TF_OBJT2, ONCE PER MONTH/TG/UNIT
!
         GET_CLA_UNIT_UP_YESTERDAY = CLA_UNIT_UP_YESTERDAY(R_NUNITS)
!
      RETURN
C***********************************************************************
      ENTRY PUT_CLA_UNIT_UP_YESTERDAY(R_NUNITS,R_LOGICAL)
C***********************************************************************
!
! CALLED FROM TF_OBJT2, ONCE PER MONTH/TG/UNIT
!
         PUT_CLA_UNIT_UP_YESTERDAY = R_LOGICAL
         CLA_UNIT_UP_YESTERDAY(R_NUNITS) = R_LOGICAL
!
      RETURN
C***********************************************************************
      ENTRY GET_STATE_PROVINCE_NAMES(R_STATE_PROVINCE,R_I)
C***********************************************************************
         R_STATE_PROVINCE = STATE_PROVINCE_NAMES(R_I)
         GET_STATE_PROVINCE_NAMES = 1
      RETURN
C***********************************************************************
      ENTRY GET_UNIT_STATE_PROVINCE_INDEX(R_NUNITS)
C***********************************************************************
         GET_UNIT_STATE_PROVINCE_INDEX =
     +                               UNIT_STATE_PROVINCE_INDEX(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_UNIT_GAS_REGION_INDEX(R_NUNITS)
C***********************************************************************
         GET_UNIT_GAS_REGION_INDEX = UNIT_GAS_REGION_INDEX(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_MAX_STATE_PROVINCE_NO
C***********************************************************************
         GET_MAX_STATE_PROVINCE_NO = MAX_STATE_PROVINCE_NO
      RETURN
C***********************************************************************
      ENTRY GET_MIN_SPIN_CAP(R_NUNITS)
C***********************************************************************
         GET_MIN_SPIN_CAP = MIN_SPIN_CAP(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_MAX_SPIN_CAP(R_NUNITS)
C***********************************************************************
         GET_MAX_SPIN_CAP = MAX_SPIN_CAP(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY YES_ALLOW_DECOMMIT_BY_UNIT(R_NUNITS,R_MONTH)
C***********************************************************************
         IF(ALLOW_DECOMMIT(R_NUNITS) == 'T') THEN
            YES_ALLOW_DECOMMIT_BY_UNIT = .TRUE.
         ELSEIF(ALLOW_DECOMMIT(R_NUNITS) == 'M') THEN
            TEMP_R4 = GET_VAR(
     +                 FLOAT(MONTHLY_DECOMMIT_VECTOR(R_NUNITS)),R_MONTH,
     +                                                UNITNM(R_NUNITS))
            IF(TEMP_R4 > 0.) THEN
               YES_ALLOW_DECOMMIT_BY_UNIT = .TRUE.
            ELSE
               YES_ALLOW_DECOMMIT_BY_UNIT = .FALSE.
            ENDIF
         ELSE
            YES_ALLOW_DECOMMIT_BY_UNIT = .FALSE.
         ENDIF
      RETURN
C***********************************************************************
      ENTRY EXPENSE_ASSIGNMENT_IS_PURCHASE(R_NUNITS)
C***********************************************************************
         EXPENSE_ASSIGNMENT_IS_PURCHASE =
     +                               EXPENSE_ASSIGNMENT(R_NUNITS) == 'P'
      RETURN
C***********************************************************************
      ENTRY GET_THERMAL_TRACKER_INDEX(R_NUNITS)
C***********************************************************************
C
         GET_THERMAL_TRACKER_INDEX =
     +                   WVPA_TRACKING_TYPE(WVPA_RATE_TRACKER(R_NUNITS))
!
      RETURN
C***********************************************************************
      ENTRY GET_THERMAL_RES_TRACKER_INDEX(R_NUNITS)
C***********************************************************************
C
         GET_THERMAL_RES_TRACKER_INDEX =
     +           WVPA_RESOURCE_TRACKING_TYPE(WVPA_RES_TRACKER(R_NUNITS))
!
      RETURN
C***********************************************************************
      ENTRY GET_THERMAL_FUEL_TRACKER_INDEX(R_NUNITS)
C***********************************************************************
C
         GET_THERMAL_FUEL_TRACKER_INDEX =
     +              WVPA_FUEL_TRACKING_TYPE(WVPA_FUEL_TRACKER(R_NUNITS))
!
      RETURN
C***********************************************************************
      ENTRY GET_THERMAL_MEM_TRACKER_INDEX(R_NUNITS)
C***********************************************************************
C
         GET_THERMAL_MEM_TRACKER_INDEX =
     +              WVPA_MEM_TRACKING_TYPE(WVPA_MEM_TRACKER(R_NUNITS))
!
      RETURN
C***********************************************************************
      ENTRY GET_EMISSION_MARKET_LINK(R_NUNITS)
C***********************************************************************
         GET_EMISSION_MARKET_LINK = EMISSION_MARKET_LINK(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY TEST_MONTHLY_MUST_RUN(R_NUNITS,R_MONTH)
C***********************************************************************
         TEST_MONTHLY_MUST_RUN = .FALSE.
         IF(MONTHLY_MUST_RUN_VECTOR(R_NUNITS) /= 0) THEN
! FIND THE BLKNO
            DO I = 1, NBLOK
               IF(UNIT(I) /= R_NUNITS) CYCLE
               IF(BLKNO(I) > 1) CYCLE ! THIS SHOULD HAPPEN.
!
               TEMP_R4 = GET_VAR(
     +                 FLOAT(MONTHLY_MUST_RUN_VECTOR(R_NUNITS)),R_MONTH,
     +                                                UNITNM(R_NUNITS))
               IF(TEMP_R4 > 0.) THEN
                  BLKNO(I) = 0
                  TEST_MONTHLY_MUST_RUN = .TRUE.
               ELSE
                  BLKNO(I) = 1
               ENDIF
               EXIT
!
            ENDDO
         ELSE
!            TEST_MONTHLY_MUST_RUN = .FALSE.
         ENDIF
      RETURN
C***********************************************************************
      ENTRY GET_CUBIC_HEAT_CURVE(R_NUNITS,R_A_CO,R_B_CO,R_C_CO,R_D_CO)
C***********************************************************************
         GET_CUBIC_HEAT_CURVE = .TRUE.
         R_A_CO = CUBIC_HEAT_CURVE(0,R_NUNITS)
         R_B_CO = CUBIC_HEAT_CURVE(1,R_NUNITS)
         R_C_CO = CUBIC_HEAT_CURVE(2,R_NUNITS)
         R_D_CO = CUBIC_HEAT_CURVE(3,R_NUNITS)
      RETURN
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      ENTRY GET_PW_UNIT_TEXT_FIELDS(R_NUNITS,
     +                              R_EIA_PLANT_CODE)
!     +                             RDI_PLANT_NUMBER,
!     +                              R_NERC_REGION)
 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         GET_PW_UNIT_TEXT_FIELDS = .TRUE.
         R_EIA_PLANT_CODE = BASECASE_PLANT_ID(R_NUNITS)
!        RDI_PLANT_NUMBER
!        R_NERC_REGION
       RETURN
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      ENTRY GET_EMERGENCY_CAPACITY(R_NUNITS,R_EMERGENCY_HEATRATE)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         GET_EMERGENCY_CAPACITY = EMERGENCY_CAPACITY(R_NUNITS)
         R_EMERGENCY_HEATRATE = EMERGENCY_HEATRATE(R_NUNITS)
      RETURN
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      ENTRY NOX_ACTIVE_FOR_UNIT(R_NUNITS,R_DATE,
     +                          R_SEASON_IS_NOX_SEASON,
     +                          R_CALCULATE_NOX)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         NOX_ACTIVE_FOR_UNIT = .TRUE.
         IF(APPLY_NOX_SEASON_DATE(R_NUNITS) == 'T') THEN
            IF(R_DATE >= NOX_SEASON_DATE(R_NUNITS) .AND.
     +                                      R_SEASON_IS_NOX_SEASON) THEN
               R_CALCULATE_NOX = .TRUE.
            ELSE
               R_CALCULATE_NOX = .FALSE.
            ENDIF
         ENDIF
      RETURN
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      ENTRY GET_NOX_CONTROL_FOR_UNIT(
     +                          R_NUNITS,
     +                          R_DATE,
     +                          R_NOX_CONTROL_PERCENT)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         GET_NOX_CONTROL_FOR_UNIT = .FALSE.
         R_NOX_CONTROL_PERCENT = 1.0
         IF(R_DATE >= NOX_CONTROL_DATE(R_NUNITS)) THEN
            GET_NOX_CONTROL_FOR_UNIT = .TRUE.
            R_NOX_CONTROL_PERCENT = NOX_CONTROL_PERCENT(R_NUNITS)
         ENDIF
      RETURN
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      ENTRY SET_SOX_CONTROL_COAL_LP(R_NUNITS,
     +                              R_DATE,
     +                              R_SOX_CONTROL_PERCENT)
        SET_SOX_CONTROL_COAL_LP = .TRUE.
        SOX_CONTROL_DATE_TEMP(R_NUNITS) =  SOX_CONTROL_DATE(R_NUNITS)
        SOX_CONTROL_PERCENT_TEMP(R_NUNITS) =
     +                                     SOX_CONTROL_PERCENT(R_NUNITS)
        IF(R_DATE < SOX_CONTROL_DATE(R_NUNITS)) THEN
           SOX_CONTROL_DATE(R_NUNITS) =  R_DATE
           SOX_CONTROL_PERCENT(R_NUNITS) = R_SOX_CONTROL_PERCENT
        ENDIF
      RETURN
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      ENTRY RESET_SOX_CONTROL_COAL_LP(R_NUNITS)
        RESET_SOX_CONTROL_COAL_LP = .FALSE.
        SOX_CONTROL_DATE(R_NUNITS) =  SOX_CONTROL_DATE_TEMP(R_NUNITS)
        SOX_CONTROL_PERCENT(R_NUNITS) =
     +                                SOX_CONTROL_PERCENT_TEMP(R_NUNITS)
      RETURN
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      ENTRY GET_SOX_CONTROL_FOR_UNIT(
     +                          R_NUNITS,
     +                          R_DATE,
     +                          R_SOX_CONTROL_PERCENT)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         GET_SOX_CONTROL_FOR_UNIT = .FALSE.
         R_SOX_CONTROL_PERCENT = 1.0
         IF(R_DATE >= SOX_CONTROL_DATE(R_NUNITS)) THEN
            GET_SOX_CONTROL_FOR_UNIT = .TRUE.
            R_SOX_CONTROL_PERCENT = SOX_CONTROL_PERCENT(R_NUNITS)
         ENDIF
      RETURN
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      ENTRY GET_CO2_CONTROL_FOR_UNIT(
     +                          R_NUNITS,
     +                          R_DATE,
     +                          R_CO2_CONTROL_PERCENT,
     +                          R_CO2_FIRST_CONTROL_MONTH,
     +                          R_CO2_FIRST_CONTROL_YEAR,
     +                          R_CO2_YEAR_BEFORE_CONTROL)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         GET_CO2_CONTROL_FOR_UNIT = .FALSE.
         R_CO2_FIRST_CONTROL_MONTH = .FALSE.
         R_CO2_YEAR_BEFORE_CONTROL = .FALSE.
         R_CO2_CONTROL_PERCENT = 1.0
         R_CO2_FIRST_CONTROL_YEAR = .FALSE.
         IF(R_DATE == CO2_CONTROL_DATE(R_NUNITS) - 100) THEN
            R_CO2_YEAR_BEFORE_CONTROL = .TRUE.
         ENDIF
         IF(R_DATE >= CO2_CONTROL_DATE(R_NUNITS)) THEN
            GET_CO2_CONTROL_FOR_UNIT = .TRUE.
            R_CO2_CONTROL_PERCENT = CO2_CONTROL_PERCENT(R_NUNITS)
            IF(R_DATE == CO2_CONTROL_DATE(R_NUNITS)) THEN
               R_CO2_FIRST_CONTROL_MONTH = .TRUE.
            ENDIF
            IF(R_DATE/100 == CO2_CONTROL_DATE(R_NUNITS)/100) THEN
               R_CO2_FIRST_CONTROL_YEAR = .TRUE.
            ENDIF
         ENDIF
      RETURN
C***********************************************************************
! 102909. TO GET MRX TO ADD CAPACITY CORRECTLY
!
      ENTRY ADJUST_CO2_RETRO_PLAN_CAP(R_YEAR)
!
C***********************************************************************
         ADJUST_CO2_RETRO_PLAN_CAP = .TRUE.
         CURRENT_YEAR = BASE_YEAR + R_YEAR
         BASE_DATE = (CURRENT_YEAR - 1900) * 100
         DO I = 1, NUNITS
!            IF(BASE_DATE/100 == CO2_CONTROL_DATE(I)/100) THEN
            IF(BASE_DATE/100 >= CO2_CONTROL_DATE(I)/100) THEN
               RETRO_CAP_CO2_MULT = CO2_RETRO_CAP_MULT(I)
! RETIRE CURRENT CAPACITY
               TEMP_R4 = CL_CAPACITY_PLANNING_ADJUSTMENTS(
     +                                   CURRENT_YEAR,I,2,.TRUE.)
!
               IF(INPUT_MW(2,I) < -.01) THEN
! NEED TO 'POKE' A NEW CAPACITY
               ELSE
                  INPUT_MW(2,I) = INPUT_MW(2,I) * RETRO_CAP_CO2_MULT
               ENDIF
! ADD NEW CAPACITY
               TEMP_L = RESURRECT_RETROFIT_UNIT(CURRENT_YEAR,I)
               TEMP_R4 = CL_CAPACITY_PLANNING_ADJUSTMENTS(
     +                                  CURRENT_YEAR,I,2,.FALSE.)
               IF(RETRO_CAP_CO2_MULT > .01) THEN
                  IF(INPUT_MW(2,I) < -.01) THEN
                  ELSE
                     INPUT_MW(2,I) = INPUT_MW(2,I)/RETRO_CAP_CO2_MULT
                  ENDIF
               ENDIF
            ENDIF
         ENDDO
      RETURN
C***********************************************************************
! 102909. TO GET GRX TO ADD CAPACITY CORRECTLY
!
      ENTRY ADJUST_GRX_CO2_RETRO_PLAN_CAP(R_YEAR,R_UNITNO)
!
C***********************************************************************
         ADJUST_GRX_CO2_RETRO_PLAN_CAP = .TRUE.
         CURRENT_YEAR = BASE_YEAR + R_YEAR

         RETRO_CAP_CO2_MULT = CO2_RETRO_CAP_MULT(I)
         IF(GRX_RETROFITED_UNIT(R_UNITNO,RETRO_CAP_CO2_MULT)) THEN
! RETIRE CURRENT CAPACITY
            TEMP_R4 = CL_CAPACITY_PLANNING_ADJUSTMENTS(
     +                                   CURRENT_YEAR,R_UNITNO,2,.TRUE.)
!
            IF(INPUT_MW(2,R_UNITNO) < -.01) THEN
! NEED TO 'POKE' A NEW CAPACITY
            ELSE
               INPUT_MW(2,R_UNITNO) = INPUT_MW(2,R_UNITNO)
     +                                              * RETRO_CAP_CO2_MULT
            ENDIF
! ADD NEW CAPACITY
            TEMP_L = RESURRECT_RETROFIT_UNIT(CURRENT_YEAR,R_UNITNO)
            TEMP_R4 = CL_CAPACITY_PLANNING_ADJUSTMENTS(
     +                                  CURRENT_YEAR,R_UNITNO,2,.FALSE.)
            IF(RETRO_CAP_CO2_MULT > .01) THEN
               IF(INPUT_MW(2,R_UNITNO) < -.01) THEN
               ELSE
                  INPUT_MW(2,R_UNITNO) = INPUT_MW(2,R_UNITNO)/
     +                                               RETRO_CAP_CO2_MULT
               ENDIF
            ENDIF
         ENDIF
      RETURN
C***********************************************************************
      ENTRY GET_CO2_RETRO_HEAT_MULT(R_NUNITS)
C***********************************************************************
         GET_CO2_RETRO_HEAT_MULT = CO2_RETRO_HEAT_MULT(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_CO2_RETRO_CAP_MULT(R_NUNITS)
C***********************************************************************
         GET_CO2_RETRO_CAP_MULT = CO2_RETRO_CAP_MULT(R_NUNITS)
      RETURN
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      ENTRY GET_HG_CONTROL_FOR_UNIT(
     +                          R_NUNITS,
     +                          R_DATE,
     +                          R_HG_CONTROL_PERCENT)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         GET_HG_CONTROL_FOR_UNIT = .FALSE.
         R_HG_CONTROL_PERCENT = 1.0
         IF(R_DATE >= HG_CONTROL_DATE(R_NUNITS)) THEN
            GET_HG_CONTROL_FOR_UNIT = .TRUE.
            R_HG_CONTROL_PERCENT = HG_CONTROL_PERCENT(R_NUNITS)
         ENDIF
      RETURN
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      ENTRY GET_OTHER3_CONTROL_FOR_UNIT(
     +                          R_NUNITS,
     +                          R_DATE,
     +                          R_OTHER3_CONTROL_PERCENT)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         GET_OTHER3_CONTROL_FOR_UNIT = .FALSE.
         R_OTHER3_CONTROL_PERCENT = 1.0
         IF(R_DATE >= OTHER3_CONTROL_DATE(R_NUNITS)) THEN
            GET_OTHER3_CONTROL_FOR_UNIT = .TRUE.
            R_OTHER3_CONTROL_PERCENT = OTHER3_CONTROL_PERCENT(R_NUNITS)
         ENDIF
      RETURN
!
! 062304 MODIFIED FOR PLATTS.
!
************************************************************************
      ENTRY GET_HESI_UNIT_ID_NUM(R_NUNITS,R_HESI_SECOND_UNIT_ID_NUM)
************************************************************************
         IF(HESI_UNIT_ID_NUM(R_NUNITS) <= 999999) THEN
            GET_HESI_UNIT_ID_NUM = REAL(HESI_UNIT_ID_NUM(R_NUNITS))
            R_HESI_SECOND_UNIT_ID_NUM = 0.
         ELSE
            TEMP_I8 = HESI_UNIT_ID_NUM(R_NUNITS)/1000000
            R_HESI_SECOND_UNIT_ID_NUM = REAL(TEMP_I8)
            GET_HESI_UNIT_ID_NUM =
     +               REAL(HESI_UNIT_ID_NUM(R_NUNITS)-1000000*TEMP_I8)
         ENDIF
      RETURN
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      ENTRY GET_HESI_UNIT_ID_NUM_I4(R_NUNITS)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         GET_HESI_UNIT_ID_NUM_I4 = HESI_UNIT_ID_NUM(R_NUNITS)
      RETURN
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      ENTRY GET_POWERDAT_PLANT_ID(R_NUNITS)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         GET_POWERDAT_PLANT_ID = FLOAT(POWERDAT_PLANT_ID(R_NUNITS))
      RETURN
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! 10/1/00 MOVED FROM MARGNOBJ.FOR
!
      ENTRY GET_RESOURCE_ID_TO_UNIT(R_ID,R_NUMBER_OF_RESOURCE_ID) ! I2
!
!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!
         GET_RESOURCE_ID_TO_UNIT = RESOURCE_ID_TO_UNIT(R_ID)
         R_NUMBER_OF_RESOURCE_ID = NUMBER_OF_RESOURCE_ID(R_ID)
         IF(GET_RESOURCE_ID_TO_UNIT > 0) THEN
            TEMP_R4 = TEMP_R4
         ENDIF
      RETURN
! 063007.
C***********************************************************************
      ENTRY GET_I8_ID_TO_UNIT(R_I8_ID) ! I8
C***********************************************************************
! 021910 CHANGED TO GET CORRECT RETURN
         GET_I8_ID_TO_UNIT = 0
         DO I = 1, NUNITS
            IF(HESI_UNIT_ID_NUM(I) /= R_I8_ID) CYCLE
            GET_I8_ID_TO_UNIT = I
            EXIT
         END DO
      RETURN
C***********************************************************************
      ENTRY UNIQUE_REPORT_VALUE_FOR_CL_UNIT(R_NUNITS)  ! I4
C***********************************************************************
         UNIQUE_REPORT_VALUE_FOR_CL_UNIT =
     +                                   CL_UNIT_UNIQUE_RPT_ID(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY REPORT_THIS_CL_UNIT(R_NUNITS)  ! L1
C***********************************************************************
         REPORT_THIS_CL_UNIT = REPORT_THIS_UNIT(R_NUNITS) == 'T'
      RETURN
C***********************************************************************
      ENTRY GET_VCPMWH_IN(R_NUNITS)  !R4
C***********************************************************************
         GET_VCPMWH_IN = VCPMWH_IN(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY ESCALATE_THERMAL_VOM(R_YEAR,R_MONTH,R_NUNITS)  !R4
C***********************************************************************
         IF(GRX_ITERATIONS == 0 .OR. R_NUNITS > GRX_NUNITS) THEN
            VCPMWH_IN(R_NUNITS) =
     +                      ESCALATED_MONTHLY_VALUE(VCPMWH_IN(R_NUNITS),
     +                          OMESCR(R_NUNITS),R_YEAR,R_MONTH,INT2(1))
         ENDIF
         ESCALATE_THERMAL_VOM = VCPMWH_IN(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY ESCALATE_THERMAL_FOM(R_YEAR,R_MONTH,R_NUNITS)  !R4
C***********************************************************************
         IF(GRX_ITERATIONS == 0 .OR. R_NUNITS > GRX_NUNITS) THEN
            FIXED_COST_IN(R_NUNITS) =
     +                  ESCALATED_MONTHLY_VALUE(FIXED_COST_IN(R_NUNITS),
     +                          FIXED_COST_ESCALATOR(R_NUNITS),
     +                                           R_YEAR,R_MONTH,INT2(1))
         ENDIF
         ESCALATE_THERMAL_FOM = FIXED_COST_IN(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_FIXED_COST_IN(R_NUNITS)  !R4
C***********************************************************************
         GET_FIXED_COST_IN = FIXED_COST_IN(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_NOX_VOM(R_NUNITS)  !R4
C***********************************************************************
         GET_NOX_VOM = NOX_VOM(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_NOX_FOM(R_NUNITS)  !R4
C***********************************************************************
         GET_NOX_FOM = NOX_FOM(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_SOX_VOM(R_NUNITS)  !R4
C***********************************************************************
         GET_SOX_VOM = SOX_VOM(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_SOX_FOM(R_NUNITS)  !R4
C***********************************************************************
         GET_SOX_FOM = SOX_FOM(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_CO2_VOM(R_NUNITS)  !R4
C***********************************************************************
         GET_CO2_VOM = CO2_VOM(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_CO2_FOM(R_NUNITS)  !R4
C***********************************************************************
         GET_CO2_FOM = CO2_FOM(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_HG_VOM(R_NUNITS)  !R4
C***********************************************************************
         GET_HG_VOM = HG_VOM(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_HG_FOM(R_NUNITS)  !R4
C***********************************************************************
         GET_HG_FOM = HG_FOM(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_OTHER3_VOM(R_NUNITS)  !R4
C***********************************************************************
         GET_OTHER3_VOM = OTHER3_VOM(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_OTHER3_FOM(R_NUNITS)  !R4
C***********************************************************************
         GET_OTHER3_FOM = OTHER3_FOM(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_MARKET_FLOOR(R_NUNITS)
C***********************************************************************
         GET_MARKET_FLOOR = MARKET_FLOOR(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_MARKET_CEILING(R_NUNITS)
C***********************************************************************
         GET_MARKET_CEILING = MARKET_CEILING(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_PBTUCT_SAVE(R_NUNITS)  !R4
C***********************************************************************
         GET_PBTUCT_SAVE = PBTUCT_SAVE(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_DISPADJ_SAVE(R_NUNITS)  !R4
C***********************************************************************
         GET_DISPADJ_SAVE = DISPADJ_SAVE(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_DISPADJ2_SAVE(R_NUNITS)  !R4
C***********************************************************************
         GET_DISPADJ2_SAVE = DISPADJ2_SAVE(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_S_FUEL_DELIVERY(R_NUNITS)  !R4
C***********************************************************************
         GET_S_FUEL_DELIVERY = S_FUEL_DELIVERY(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_S_FUEL_DELIVERY_2(R_NUNITS)   !R4
C***********************************************************************
         GET_S_FUEL_DELIVERY_2 = S_FUEL_DELIVERY_2(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_S_FUEL_DELIVERY_3(R_NUNITS)  !R4
C***********************************************************************
         GET_S_FUEL_DELIVERY_3 = S_FUEL_DELIVERY_3(R_NUNITS)
      RETURN
C***********************************************************************
       ENTRY GET_START_UP_LOGIC(R_NUNITS,R_START_UP_TYPE) !L1
C***********************************************************************
          R_START_UP_TYPE = START_UP_LOGIC(R_NUNITS)
          GET_START_UP_LOGIC = .TRUE.
       RETURN
C***********************************************************************
       ENTRY GET_SPIN_STATUS(R_NUNITS)
C***********************************************************************
          GET_SPIN_STATUS = CONTRIBUTES_TO_SPIN(R_NUNITS) /= 'F'
       RETURN
C***********************************************************************
      ENTRY GET_TOTAL_START_UP_UNITS()
C***********************************************************************
         GET_TOTAL_START_UP_UNITS = TOTAL_START_UP_UNITS
      RETURN
C***********************************************************************
      ENTRY GET_NEWGEN_INDEX(R_NUNITS) ! INTEGER*2
C***********************************************************************
         GET_NEWGEN_INDEX = NEWGEN_INDEX(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_START_UP_INDEX(R_NUNITS)
C***********************************************************************
         GET_START_UP_INDEX = START_UP_INDEX(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_ANNUAL_GROSS_MARGIN(R_NUNITS)
C***********************************************************************
         GET_ANNUAL_GROSS_MARGIN = ANNUAL_GROSS_MARGIN(R_NUNITS,3)
      RETURN
C***********************************************************************
      ENTRY GET_UNIT_START_UP_COSTS(R_YEAR,R_NUNITS,R_MONTH)
C***********************************************************************
         IF(START_UP_COSTS(R_NUNITS) < 0.) THEN
            GET_UNIT_START_UP_COSTS =
     +                 START_UP_COST_ESCALATED_MONTHLY_VALUE(
     +                              INT2(ABS(START_UP_COSTS(R_NUNITS))),
     +                              R_YEAR)
         ELSE
!
            IF(START_UP_COSTS_ESCALATION(R_NUNITS) < 0.) THEN
               GET_UNIT_START_UP_COSTS = 1. ! START_UP_COSTS(R_NUNITS)
               VECTOR_IS_VALUE = .FALSE.
               DO YR = R_YEAR ,1,-1
                  TEMP_I2 = INT2(START_UP_COSTS_ESCALATION(R_NUNITS))
                  ESCAL_RATE = RETURN_VALUE_FROM_ESCALATION_VECTOR(
     +                               YR,TEMP_I2,VECTOR_IS_VALUE,R_MONTH)
                  IF(VECTOR_IS_VALUE) THEN
!                     TEMP_I2 =
!     +                    INT2(ABS(START_UP_COSTS_ESCALATION(R_NUNITS)))
                     GET_UNIT_START_UP_COSTS =
     +                  GET_UNIT_START_UP_COSTS * ESCAL_RATE
!     +                   ESCALATED_MONTHLY_VALUE(ESCAL_RATE,TEMP_I2,
!     +                                               YR,R_MONTH,INT2(1))
                     EXIT
                  ELSE
                     GET_UNIT_START_UP_COSTS = GET_UNIT_START_UP_COSTS *
     +                                           (1.0 + ESCAL_RATE/100.)
                  ENDIF
               ENDDO ! YR
               IF(.NOT. VECTOR_IS_VALUE) THEN
                  GET_UNIT_START_UP_COSTS = GET_UNIT_START_UP_COSTS *
     +                                          START_UP_COSTS(R_NUNITS)
               ENDIF
            ELSEIF(START_UP_COSTS_ESCALATION(R_NUNITS) > 0.) THEN
               ESCAL_RATE =  START_UP_COSTS_ESCALATION(R_NUNITS)/100.
               GET_UNIT_START_UP_COSTS = START_UP_COSTS(R_NUNITS)
               DO YR = 1, R_YEAR
                  GET_UNIT_START_UP_COSTS = GET_UNIT_START_UP_COSTS *
     +                                                (1.0 + ESCAL_RATE)
               ENDDO
            ELSE
               GET_UNIT_START_UP_COSTS = START_UP_COSTS(R_NUNITS)
            ENDIF
         ENDIF
      RETURN
C***********************************************************************
      ENTRY GET_START_UP_COSTS(R_NUNITS)
C***********************************************************************
         GET_START_UP_COSTS = START_UP_COSTS(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_RAMP_RATE(R_NUNITS)
C***********************************************************************
         GET_RAMP_RATE = RAMP_RATE(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_RAMP_DOWN_RATE(R_NUNITS)
C***********************************************************************
         GET_RAMP_DOWN_RATE = RAMP_DOWN_RATE(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_MIN_UP_TIME(R_NUNITS)
C***********************************************************************
         GET_MIN_UP_TIME = MIN_UP_TIME(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_FOR_DURATION(R_NUNITS)
C***********************************************************************
         GET_FOR_DURATION = FOR_DURATION(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_FOR_FREQUENCY(R_NUNITS)
C***********************************************************************
         GET_FOR_FREQUENCY = FOR_FREQUENCY(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_MIN_DOWN_TIME(R_NUNITS)
C***********************************************************************
         GET_MIN_DOWN_TIME = MIN_DOWN_TIME(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY UNIT_ON_LINE_IN_YEAR(R_NUNITS,R_YEAR)
C***********************************************************************
         BASE_DATE = (BASE_YEAR + R_YEAR - 1900) * 100
         DATE1 = BASE_DATE + 1
         DATE2 = BASE_DATE + 12
         IF(ONLINE(R_NUNITS) > DATE2 .OR. OFLINE(R_NUNITS) < DATE1) THEN
            UNIT_ON_LINE_IN_YEAR = .FALSE.
         ELSE
            UNIT_ON_LINE_IN_YEAR = .TRUE.
         ENDIF
      RETURN
C***********************************************************************
      ENTRY INIT_ANNUAL_GROSS_MARGIN()
C***********************************************************************
!
         STRATEGIC_RETIRMENTS_LOGIC =
     +         GET_STRATEGIC_RETIRMENTS_LOGIC(MINIMUM_MARGIN_PER_KW)
         INIT_ANNUAL_GROSS_MARGIN = MINIMUM_MARGIN_PER_KW
         RETIREMENTS_CO2 = 0.0
         RETIREMENTS_MW = 0.0
         RETIREMENTS_MWH = 0.0
         RETIREMENTS_UPLIFT_PER_TON = 0.0
         RETIREMENTS_CUM_CO2 = 0.0
         RETIREMENTS_CO2_PRICE = 999.0 ! COST OF UNMET CO2
!
         CM_RETIREMENT_KW = 999999.0
         CM_RETIREMENT_UNIT = 0
         NEW_UNIT_RETIRE_VALUE_BY_CM = 0.0
!
       IF(GRX_ITERATIONS == 0) ECON_CO2_RETIRE_PRICE = 999999.0

      RETURN
C***********************************************************************
      ENTRY GET_CM_RETIREMENT_KW(R_CM,R_NUNITS)
C***********************************************************************
         IF(R_CM > 0 .AND. R_CM < 1001) THEN
            IF(CM_RETIREMENT_KW(R_CM) > 999998.0) THEN
               GET_CM_RETIREMENT_KW = 0.0
               R_NUNITS = 0
            ELSE
               GET_CM_RETIREMENT_KW = CM_RETIREMENT_KW(R_CM)
               R_NUNITS = CM_RETIREMENT_UNIT(R_CM)
               ANNUAL_MARGIN_PER_KW =
     +               1000.0 * (ECON_RETIRE_MARGIN(R_NUNITS,0))/
     +                                          (MW(2,R_NUNITS)*4.0)
               WRITE(4,*)
     +          'At GET_CM_RETIREMENT_KW   ',
     +          'RET T-3',ECON_RETIRE_MARGIN(R_NUNITS,1),
     +          'RET T-2',ECON_RETIRE_MARGIN(R_NUNITS,2),
     +          'RET T-1',ECON_RETIRE_MARGIN(R_NUNITS,3),
     +          'RET T  ',ECON_RETIRE_MARGIN(R_NUNITS,4),
     +          'MW     ',MW(2,R_NUNITS),
     +          'RET SUM',ECON_RETIRE_MARGIN(R_NUNITS,0),
     +          'R_NUNITS',R_NUNITS,
     +          'R_CM',R_CM,
     +          'IN-CM_RETIRE_KW',CM_RETIREMENT_KW(R_CM),
     +          'ANNUAL_MARGIN_PER_KW',ANNUAL_MARGIN_PER_KW,
     +          'ReCalCM_RETIRE_KW',MIN(CM_RETIREMENT_KW(R_CM),
     +                                         -ANNUAL_MARGIN_PER_KW)
            ENDIF
         ENDIF
      RETURN
C***********************************************************************
      ENTRY SAVE_ANNUAL_GROSS_MARGIN(  R_NUNITS,
     +                                 R_MW,
     +                                 R_GROSS_MARGIN,
     +                                 R_CO2,R_MWH,
     +                                 R_CO2_COST,
     +                                 R_CAP_COST)
C***********************************************************************
!
!
! 031710.
! 041810. REMOVED R_CO2_COST. THIS SHOULD CAUSE MORE RETIREMENTS.
!
         LAST_ITER_GROSS_MARGIN(R_NUNITS) = R_GROSS_MARGIN
         IF(GRX_ITERATIONS == 0) then
            IF(USED_4_YR_EBITDA_TOTAL .OR. USE_EACH_YR_EBITDA_NEG) THEN
               ECON_RETIRE_MARGIN(R_NUNITS,1) =
     +                                    ECON_RETIRE_MARGIN(R_NUNITS,2)
               ECON_RETIRE_MARGIN(R_NUNITS,2) =
     +                                    ECON_RETIRE_MARGIN(R_NUNITS,3)
               ECON_RETIRE_MARGIN(R_NUNITS,3) =
     +                                    ECON_RETIRE_MARGIN(R_NUNITS,4)
               ECON_RETIRE_MARGIN(R_NUNITS,4) = R_GROSS_MARGIN
               ITER_0_ECON_RETIRE_MARGIN(R_NUNITS) =
     +                                 ECON_RETIRE_MARGIN(R_NUNITS,1) +
     +                                 ECON_RETIRE_MARGIN(R_NUNITS,2) +
     +                                 ECON_RETIRE_MARGIN(R_NUNITS,3) +
     +                                 ECON_RETIRE_MARGIN(R_NUNITS,4)
            ELSE
               ITER_0_ECON_RETIRE_MARGIN(R_NUNITS) = R_GROSS_MARGIN
               ECON_RETIRE_MARGIN(R_NUNITS,4) =
     +                                  LAST_ITER_GROSS_MARGIN(R_NUNITS)
            ENDIF
         ELSE
            ECON_RETIRE_MARGIN(R_NUNITS,4) =
     +                                  LAST_ITER_GROSS_MARGIN(R_NUNITS)
         ENDIF
         ECON_RETIRE_MARGIN(R_NUNITS,0) =
     +                                 ECON_RETIRE_MARGIN(R_NUNITS,1) +
     +                                 ECON_RETIRE_MARGIN(R_NUNITS,2) +
     +                                 ECON_RETIRE_MARGIN(R_NUNITS,3) +
     +                                 ECON_RETIRE_MARGIN(R_NUNITS,4)
         IF(R_MWH < .001) THEN
            RETIREMENT_MEASURE = ITER_0_ECON_RETIRE_MARGIN(R_NUNITS) ! RESET TO 0 ITER
         ELSEIF(USED_4_YR_EBITDA_TOTAL .OR. USE_EACH_YR_EBITDA_NEG) THEN
            RETIREMENT_MEASURE = ECON_RETIRE_MARGIN(R_NUNITS,1) +
     +                           ECON_RETIRE_MARGIN(R_NUNITS,2) +
     +                           ECON_RETIRE_MARGIN(R_NUNITS,3) +
     +                           R_GROSS_MARGIN
         ELSE
            RETIREMENT_MEASURE = R_GROSS_MARGIN
         ENDIF
         RETIRE_THIS_UNIT(R_NUNITS) = RETIREMENT_MEASURE < 0.
         IF(USE_EACH_YR_EBITDA_NEG) THEN
            RETIRE_THIS_UNIT(R_NUNITS) =
     +                      ECON_RETIRE_MARGIN(R_NUNITS,1) < 0.
     +                      .AND. ECON_RETIRE_MARGIN(R_NUNITS,2)  < 0.
     +                      .AND. ECON_RETIRE_MARGIN(R_NUNITS,3) < 0.
     +                      .AND. R_GROSS_MARGIN < 0.
         ENDIF
         IF(RETIRE_THIS_UNIT(R_NUNITS) .AND.
     +                                    YEAR + BASE_YEAR == 2032) THEN
            RETIREMENT_MEASURE = RETIREMENT_MEASURE
         ENDIF
!
!
! retirement unit price is set here. retros are in
         ECON_CO2_RETIRE_PRICE(R_NUNITS) = RETIREMENT_MEASURE
         CO2_K = 0.0000005 * 7000.0 * 130.0
         if(ABS(R_CO2 - CO2_K * R_MWH) < 0.01) then
            ECON_CO2_RETRO_PRICE(R_NUNITS) = RETIREMENT_MEASURE
         else
! the retro fit comparison should be based on the change in theunit CO2 output
            ECON_CO2_RETRO_PRICE(R_NUNITS) =
     +                              RETIREMENT_MEASURE* 1000000.0 /
     +                                           (R_CO2 - CO2_K * R_MWH)
         endif
!
         RETIREMENTS_CO2(R_NUNITS) = R_CO2
         RETIREMENTS_CO2_COST(R_NUNITS) = RETIREMENT_MEASURE ! R_CO2_COST
         RETIREMENTS_CAP_COST(R_NUNITS) = R_CAP_COST
         RETIREMENTS_MW(R_NUNITS) = R_MW
         RETIREMENTS_MWH(R_NUNITS) = R_MWH
!
         ANNUAL_GROSS_MARGIN(R_NUNITS,3) = R_GROSS_MARGIN
         IF(GRX_ITERATIONS == 0) then
            ANNUAL_GROSS_MARGIN(R_NUNITS,1) =
     +                                   ANNUAL_GROSS_MARGIN(R_NUNITS,2)
            ANNUAL_GROSS_MARGIN(R_NUNITS,2) =
     +                                   ANNUAL_GROSS_MARGIN(R_NUNITS,3)
            ANNUAL_GROSS_MARGIN(R_NUNITS,0) =
     +                                 ANNUAL_GROSS_MARGIN(R_NUNITS,1) +
     +                                 ANNUAL_GROSS_MARGIN(R_NUNITS,2) +
     +                                 ANNUAL_GROSS_MARGIN(R_NUNITS,3)
         ENDIF
         IF(R_MWH < .001) THEN
            UNIT_ANNUAL_GROSS_MARGIN = ANNUAL_GROSS_MARGIN(R_NUNITS,0)
         ELSE
            UNIT_ANNUAL_GROSS_MARGIN = R_GROSS_MARGIN +
     +                                 ANNUAL_GROSS_MARGIN(R_NUNITS,1) +
     +                                 ANNUAL_GROSS_MARGIN(R_NUNITS,2)
         ENDIF
         IF(STRATEGIC_RETIRMENTS_LOGIC .AND. R_MW > 0.) THEN
            ANNUAL_MARGIN_PER_KW = UNIT_ANNUAL_GROSS_MARGIN/(.036*R_MW)
            CURRENT_YEAR = YEAR+BASE_YEAR
            IF(ANNUAL_MARGIN_PER_KW < MINIMUM_MARGIN_PER_KW) THEN
!
               TEMP_R4 = CL_CAPACITY_PLANNING_ADJUSTMENTS(
     +                                   CURRENT_YEAR,R_NUNITS,2,.TRUE.)
               TEMP_I2 = CL_CAPACITY_TEMP_RETIRE_UNIT(CURRENT_YEAR,
     +                                                R_NUNITS)
               WRITE(9,1007) "Retirement",UNITNM(R_NUNITS),CURRENT_YEAR,
     +                                    ANNUAL_MARGIN_PER_KW
            ENDIF
         ENDIF
         TG = GET_TRANS_GROUP_POSITION(
     +                                   TRANSACTION_GROUP_ID(R_NUNITS))
         CM = GET_CM_FROM_TG(TG)
!
! !!! 022411 !!!
!
!         IF(R_MW > 0.0 .AND. UNIT_ANNUAL_GROSS_MARGIN < 0.0) THEN
!
! 041110.
!
!            ANNUAL_MARGIN_PER_KW =
!     +               1000.0 * (UNIT_ANNUAL_GROSS_MARGIN-R_CAP_COST)/R_MW
!            IF(ANNUAL_MARGIN_PER_KW < MINIMUM_MARGIN_PER_KW) THEN
!               CM_RETIREMENT_KW(CM) = MIN(CM_RETIREMENT_KW(CM),
!     +                                            -ANNUAL_MARGIN_PER_KW)
!            ENDIF
!         ENDIF
!
!         IF(R_MW > 0.0 .AND. ECON_RETIRE_MARGIN(R_NUNITS,0) < 0.0 .AND.
         IF(MW(2,R_NUNITS) > 0.001 .AND. R_MWH > 0.001 .AND.
     +            ECON_RETIRE_MARGIN(R_NUNITS,4) < 0.0 .AND.
     +            ECON_RETIRE_MARGIN(R_NUNITS,3) < 0.0 .AND.
     +            ECON_RETIRE_MARGIN(R_NUNITS,2) < 0.0 .AND.
     +            ECON_RETIRE_MARGIN(R_NUNITS,1) < 0.0 .AND.
     +                          REPORT_THIS_UNIT(R_NUNITS) == 'T' .AND.
     +            PRIMARY_MOVER_STR(R_NUNITS) /= 'FC    ' .AND.
     +            PRIMARY_MOVER_STR(R_NUNITS) /= 'GE    ' .AND.
     +            PRIMARY_MOVER_STR(R_NUNITS) /= 'BI    ' .AND.
     +            PRIMARY_MOVER_STR(R_NUNITS) /= 'LF    ' .AND.
     +            PRIMARY_MOVER_STR(R_NUNITS) /= 'ZZ    ') THEN
            ANNUAL_MARGIN_PER_KW =
     +               1000.0 * (ECON_RETIRE_MARGIN(R_NUNITS,0))/
     +                                          (MW(2,R_NUNITS)*4.0)
            TEMP_REAL = CM_RETIREMENT_KW(CM)
            IF(ANNUAL_MARGIN_PER_KW < MINIMUM_MARGIN_PER_KW) THEN
!
! 070612.
!
!               CM_RETIREMENT_KW(CM) = MIN(CM_RETIREMENT_KW(CM),
!     +                                     -ANNUAL_MARGIN_PER_KW)
!               CM_RETIREMENT_UNIT(CM) = R_NUNITS
               IF(-ANNUAL_MARGIN_PER_KW < CM_RETIREMENT_KW(CM)) THEN
                  CM_RETIREMENT_KW(CM) = MIN(CM_RETIREMENT_KW(CM),
     +                                     -ANNUAL_MARGIN_PER_KW)
                  CM_RETIREMENT_UNIT(CM) = R_NUNITS
               ENDIF
            ENDIF
               WRITE(4,*)
     +          'At SAVE_ANNUAL_GROSS_MARGIN   ',
     +          'RET T-3',ECON_RETIRE_MARGIN(R_NUNITS,1),
     +          'RET T-2',ECON_RETIRE_MARGIN(R_NUNITS,2),
     +          'RET T-1',ECON_RETIRE_MARGIN(R_NUNITS,3),
     +          'RET T  ',ECON_RETIRE_MARGIN(R_NUNITS,4),
     +          'MW     ',MW(2,R_NUNITS),
     +          'RET SUM',ECON_RETIRE_MARGIN(R_NUNITS,0),
     +          'R_NUNITS',R_NUNITS,
     +          'R_CM',CM,
     +          'OUT-CM_RETIRE_KW',CM_RETIREMENT_KW(CM),
     +          'ANNUAL_MARGIN_PER_KW',ANNUAL_MARGIN_PER_KW,
     +          'IN-CM_RETIRE_KW',TEMP_REAL
         ENDIF
!
! !!! 022411. !!!
!
!
! 091210.
         IF( 1 == 2 .AND. R_NUNITS > BASE_CL_UNITS .AND.
     +                  R_MW > 0.0 .AND.
     +                        R_GROSS_MARGIN < 0.0 .AND.
     +                              CM > 0 .AND.
     +                                    CM <= UPPER_TRANS_GROUP) THEN
            NEW_UNIT_RETIRE_VALUE_BY_CM(CM) =
     +               MAX(NEW_UNIT_RETIRE_VALUE_BY_CM(CM),
     +                                      -1000.0*R_GROSS_MARGIN/R_MW)
         ENDIF
!
!
!
         SAVE_ANNUAL_GROSS_MARGIN = R_GROSS_MARGIN
      RETURN
 1007 FORMAT(5X,A,5X,A,5X,I4,5X,F7.2)
C***********************************************************************
      ENTRY CALC_MRX_RPS_CURVES(R_YEAR)
C***********************************************************************
         CALC_MRX_RPS_CURVES = .FALSE.
!         CG = MAX(GET_NUMBER_OF_CAPACITY_MARKETS(),1)
!         PG = MAX(GET_NUMBER_OF_PLANNING_GROUPS(),1)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         PG = NUMBER_OF_RPS_PROGRAMS()
         NUM_TRANS = GET_NUM_SAVE_ACTIVE_TRANSACTIONS()
         IF(ALLOCATED(MRX_RPS_CL_CURVE_MWH))
     +          DEALLOCATE(MRX_RPS_CL_CURVE_MWH,
     +                      MRX_RPS_CL_CURVE_CUM_MWH,
     +                      MRX_RPS_CL_CURVE_MARGIN,
     +                      MRX_RPS_CL_CURVE_CUM_MARGIN,
     +                      MRX_RPS_CL_CURVE_INDEX,
     +                      MRX_RPS_CL_UNIT_NO,
     +                      MRX_RPS_CL_UNIT_INDEX,
     +                      MRX_RPS_DV_CURVE_MWH,
     +                      MRX_RPS_DV_CURVE_CUM_MWH,
     +                      MRX_RPS_DV_CURVE_MARGIN,
     +                      MRX_RPS_DV_CURVE_CUM_MARGIN,
     +                      MRX_RPS_DV_CURVE_INDEX,
     +                      MRX_RPS_DV_UNIT_NO,
     +                      MRX_RPS_DV_UNIT_INDEX)
         ALLOCATE(MRX_RPS_CL_CURVE_MWH(NUNITS,PG),
     +            MRX_RPS_CL_CURVE_CUM_MWH(NUNITS,PG),
     +            MRX_RPS_CL_CURVE_MARGIN(NUNITS,PG),
     +            MRX_RPS_CL_CURVE_CUM_MARGIN(NUNITS,PG),
     +            MRX_RPS_CL_CURVE_INDEX(NUNITS,PG),
     +            MRX_RPS_CL_UNIT_NO(PG),
     +            MRX_RPS_CL_UNIT_INDEX(NUNITS,PG),
     +            MRX_RPS_DV_CURVE_MWH(NUM_TRANS,PG),
     +            MRX_RPS_DV_CURVE_CUM_MWH(NUM_TRANS,PG),
     +            MRX_RPS_DV_CURVE_MARGIN(NUM_TRANS,PG),
     +            MRX_RPS_DV_CURVE_CUM_MARGIN(NUM_TRANS,PG),
     +            MRX_RPS_DV_CURVE_INDEX(NUM_TRANS,PG),
     +            MRX_RPS_DV_UNIT_NO(PG),
     +            MRX_RPS_DV_UNIT_INDEX(NUM_TRANS,PG))
         CALC_MRX_RPS_CURVES = .TRUE.
!
         MRX_RPS_CL_UNIT_NO = 0
         MRX_RPS_CL_UNIT_INDEX = 0
         MRX_RPS_CL_CURVE_INDEX = 0
         MRX_RPS_CL_CURVE_MWH = 0.0
         MRX_RPS_CL_CURVE_CUM_MWH = 0.0
         MRX_RPS_CL_CURVE_MARGIN = 0.0
         MRX_RPS_CL_CURVE_CUM_MARGIN = 0.0
         DO U = 1, GRX_NUNITS ! 071220. CHANGED FROM NUNITS.
! DOUBLE INDEX
            PA = RPS_PROGRAM_NUMBER(U)
            IF(PA == 0) CYCLE
            RPS_COUNT = 1
            DO
               PX = GET_RPS_PROGRAM_POSITION(PA,RPS_COUNT)
               IF(PX == 0) EXIT
               RPS_COUNT = RPS_COUNT + 1
!
               LOCAL_RPS_CONTRIB_PERCENT = RPS_CONTRIBUTION_PERCENT(U)
               IF(LOCAL_RPS_CONTRIB_PERCENT < -0.01) THEN
                  LOCAL_RPS_CONTRIB_PERCENT = 0.01 *
     +               ESCALATED_MONTHLY_VALUE(LOCAL_RPS_CONTRIB_PERCENT,
     +                    ABS(INT2(RPS_CONTRIBUTION_PERCENT(U))),
     +                                          R_YEAR,INT2(1),INT2(1))
               ELSE
                  LOCAL_RPS_CONTRIB_PERCENT =
     +                                  0.01 * LOCAL_RPS_CONTRIB_PERCENT
               ENDIF
               TEMP_ENRG = MRX_RPS_CL_CURVE_UMWH(U) *
     +                                         LOCAL_RPS_CONTRIB_PERCENT
!
               IF(TEMP_ENRG < 0.0001) CYCLE
               MRX_RPS_CL_UNIT_NO(PX) = MRX_RPS_CL_UNIT_NO(PX) + 1
               TEMP_I2 = MRX_RPS_CL_UNIT_NO(PX)
               IF(TEMP_I2 < 1 .OR. TEMP_I2 > NUNITS) THEN
                  TEMP_I2 = TEMP_I2
               ENDIF
               MRX_RPS_CL_UNIT_INDEX(TEMP_I2,PX) = U
               MRX_RPS_CL_CURVE_INDEX(TEMP_I2,PX) =
     +                                            MRX_RPS_CL_UNIT_NO(PX)
               MRX_RPS_CL_CURVE_MWH(TEMP_I2,PX) = TEMP_ENRG
               MRX_RPS_CL_CURVE_MARGIN(TEMP_I2,PX) =
     +                 1000.0 * (MRX_RPS_CL_CURVE_REVENUE(U) -
     +                               MRX_RPS_CL_CURVE_COST(U))/TEMP_ENRG
            ENDDO
         ENDDO
         DO PA = 1, PG
            IF(MRX_RPS_CL_UNIT_NO(PA) > 1) THEN
               CALL SortIncrPos(MRX_RPS_CL_UNIT_NO(PA),
     +                          MRX_RPS_CL_CURVE_INDEX(1,PA),
     +                          MRX_RPS_CL_CURVE_MARGIN(1,PA))
            ENDIF
            DO I = MRX_RPS_CL_UNIT_NO(PA), 1, -1
               J = MRX_RPS_CL_CURVE_INDEX(I,PA)
               U = MRX_RPS_CL_UNIT_INDEX(J,PA)
               IF(I == MRX_RPS_CL_UNIT_NO(PA)) THEN
                  MRX_RPS_CL_CURVE_CUM_MWH(I,PA) =
     +                                        MRX_RPS_CL_CURVE_MWH(J,PA)
               ELSE
                  MRX_RPS_CL_CURVE_CUM_MWH(I,PA) =
     +                  MRX_RPS_CL_CURVE_CUM_MWH(I+1,PA) +
     +                                     MRX_RPS_CL_CURVE_MWH(J,PA)
               ENDIF
               MRX_RPS_CL_CURVE_CUM_MARGIN(I,PA) =
     +                                    MRX_RPS_CL_CURVE_MARGIN(J,PA)
            ENDDO
         ENDDO
!!!!!
! 062120. IDENTICAL FOR DV
!!!!!
         MRX_RPS_DV_UNIT_NO = 0
         MRX_RPS_DV_UNIT_INDEX = 0
         MRX_RPS_DV_CURVE_INDEX = 0
         MRX_RPS_DV_CURVE_MWH = 0.0
         MRX_RPS_DV_CURVE_CUM_MWH = 0.0
         MRX_RPS_DV_CURVE_MARGIN = 0.0
         MRX_RPS_DV_CURVE_CUM_MARGIN = 0.0
         DO U = 1, NUM_TRANS
! DOUBLE INDEX
            PA = GET_TRANS_RPS_PROG_NUMBER(U)
            IF(PA == 0) CYCLE
            RPS_COUNT = 1
            DO
               PX = GET_RPS_PROGRAM_POSITION(PA,RPS_COUNT)
               IF(PX == 0) EXIT
               RPS_COUNT = RPS_COUNT + 1
!
               LOCAL_RPS_CONTRIB_PERCENT =
     +                                   GET_TRANS_RPS_PERCENT(U,R_YEAR)
               TEMP_ENRG = MRX_RPS_DV_CURVE_UMWH(U) *
     +                                         LOCAL_RPS_CONTRIB_PERCENT
               IF(TEMP_ENRG < 0.0001) CYCLE
               MRX_RPS_DV_UNIT_NO(PX) = MRX_RPS_DV_UNIT_NO(PX) + 1
               TEMP_I2 = MRX_RPS_DV_UNIT_NO(PX)
               MRX_RPS_DV_UNIT_INDEX(TEMP_I2,PX) = U
               MRX_RPS_DV_CURVE_INDEX(TEMP_I2,PX) =
     +                                            MRX_RPS_DV_UNIT_NO(PX)
               MRX_RPS_DV_CURVE_MWH(TEMP_I2,PX) = TEMP_ENRG
               MRX_RPS_DV_CURVE_MARGIN(TEMP_I2,PX) =
     +                 1000.0 * (MRX_RPS_DV_CURVE_REVENUE(U) -
     +                               MRX_RPS_DV_CURVE_COST(U))/TEMP_ENRG
            ENDDO
         ENDDO
         DO PA = 1, PG
            IF(MRX_RPS_DV_UNIT_NO(PA) > 1) THEN
               CALL SortIncrPos(MRX_RPS_DV_UNIT_NO(PA),
     +                          MRX_RPS_DV_CURVE_INDEX(1,PA),
     +                          MRX_RPS_DV_CURVE_MARGIN(1,PA))
            ENDIF
            DO I = MRX_RPS_DV_UNIT_NO(PA), 1, -1
               J = MRX_RPS_DV_CURVE_INDEX(I,PA)
               U = MRX_RPS_DV_UNIT_INDEX(J,PA)
               IF(I == MRX_RPS_DV_UNIT_NO(PA)) THEN
                  MRX_RPS_DV_CURVE_CUM_MWH(I,PA) =
     +                                        MRX_RPS_DV_CURVE_MWH(J,PA)
               ELSE
                  MRX_RPS_DV_CURVE_CUM_MWH(I,PA) =
     +                  MRX_RPS_DV_CURVE_CUM_MWH(I+1,PA) +
     +                                        MRX_RPS_DV_CURVE_MWH(J,PA)
               ENDIF
               MRX_RPS_DV_CURVE_CUM_MARGIN(I,PA) =
     +                                    MRX_RPS_DV_CURVE_MARGIN(J,PA)
            ENDDO
         ENDDO
      RETURN
C***********************************************************************
      ENTRY GET_NEW_UNIT_RETIRE_VALUE_BY_CM(R_CM)
C***********************************************************************
         IF(ALLOCATED(NEW_UNIT_RETIRE_VALUE_BY_CM) .AND. CM > 0 .AND.
     +                                     CM <= UPPER_TRANS_GROUP) THEN
            GET_NEW_UNIT_RETIRE_VALUE_BY_CM =
     +                                 NEW_UNIT_RETIRE_VALUE_BY_CM(R_CM)
         ELSE
            GET_NEW_UNIT_RETIRE_VALUE_BY_CM = 0.0
         ENDIF
      RETURN
C***********************************************************************
      ENTRY ANNUAL_CO2_RETROFIT_PROCESS(R_YEAR)
C***********************************************************************
         TEMP_L = RETROFIT_LOGIC_ACTIVE(TEMP_R4,TEMP_I2)
         ANN_RETROFIT_COUNTER = 0
!         IF(.NOT. TEMP_L .OR. TEMP_I2 < R_YEAR + BASE_YEAR) THEN
         IF(.NOT. TEMP_L) THEN
            ANNUAL_CO2_RETROFIT_PROCESS = .FALSE.
            RETURN
         ENDIF
         IF(.NOT. GRX_CONVERGED) THEN
            CALL  GRX_RETROFIT_OPTONS(RESTORE)!RESETS THE UNITS RETIRED IN THE LOOP
         ENDIF
         CO2_RETROFIT_ABATEMENT_INDEX = 0
         CUM_CO2_EMISSIONS = 0.0
         RETROFIT_UNIT_IS_ACTIVE = .FALSE.
         DO I = 1, RETROFIT_COUNTER
            U = RETROFIT_UNIT_INDEX(I)
            IF(RETROFIT_CANDIDATE(U) /= 'T') CYCLE
            IF(RETIREMENTS_CO2(U) < 0.01 .OR.
     +                  RETIREMENTS_MWH(U) < 0.01 .OR.
     +                         RETIREMENTS_MW(U) < 0.0001) CYCLE
            IF(.NOT. GRX_CONVERGED) THEN
               CALL GRX_CAPACITY_TEMP_RETRO_UNIT(U)
            ENDIF
!            RETROFIT_UPLIFT_PER_TON(U) =
!     +                  ANNUAL_GROSS_MARGIN(U,3)*1000000 /
!     +                                                RETIREMENTS_CO2(U)
            ANN_RETROFIT_COUNTER = ANN_RETROFIT_COUNTER + 1
            RETROFIT_UNIT_IS_ACTIVE(U) = .TRUE.
            CALL ANNUAL_RETROFIT_PROJECT(RETROFIT_PROJECT_ID(U),
     +                                   R_YEAR,
     +                                   RETIREMENTS_CO2(U),
     +                                   RETIREMENTS_MW(U),
     +                                   RETIREMENTS_MWH(U),
     +                                   ANNUAL_GROSS_MARGIN(U,3),
     +                                   RETROFIT_UPLIFT_PER_TON(U),
     +                                   RETROFIT_CO2)
            RETROFIT_CO2_PRICE(U) = RETROFIT_UPLIFT_PER_TON(U)
            CUM_CO2_EMISSIONS = CUM_CO2_EMISSIONS + RETROFIT_CO2
         END DO
! SORT FROM WORST TO BEST RETIREMENT
!      IF(.FALSE.) THEN
         ASCENDING = .FALSE. ! DECENDING
         CALL INDEXED_SORT_ASCENDING(RETROFIT_UPLIFT_PER_TON,
     +                               RETROFIT_UNIT_INDEX,
     +                               RETROFIT_COUNTER,
     +                               ASCENDING)
         NEXT_MRX_RETROFIT = 1
         DO COUNTER = 1, RETROFIT_COUNTER
             TEMP_I2 = RETROFIT_UNIT_INDEX(RETROFIT_COUNTER-COUNTER+1)
             CO2_RETROFIT_ABATEMENT_INDEX(COUNTER) = TEMP_I2
             IF(COUNTER > 1) THEN
               RETROFIT_CUM_CO2(TEMP_I2) =
     +             RETROFIT_CUM_CO2(
     +                        CO2_RETROFIT_ABATEMENT_INDEX(COUNTER-1)) +
     +                                          RETIREMENTS_CO2(TEMP_I2)
             ELSE
               RETROFIT_CUM_CO2(TEMP_I2) = RETIREMENTS_CO2(TEMP_I2)
             ENDIF
             RETROFIT_CO2_PRICE(TEMP_I2) =
     +                               RETROFIT_UPLIFT_PER_TON(TEMP_I2)
         END DO
!       ENDIF ! REMOVE CODE
! 031910. ANN_RETROFIT = RETROFIT FOR NOW
         ANNUAL_CO2_RETROFIT_PROCESS = .TRUE.
      RETURN
C***********************************************************************
      ENTRY ANNUAL_CO2_RETIREMENTS_PROCESS(R_YEAR)
C***********************************************************************
         RETIREMENTS_INDEX = 0
         CO2_ABATEMENT_INDEX = 0
         ANN_ECON_RETIRE_COUNTER = 0
         CUM_CO2_EMISSIONS = 0.0
!         RETIREMENT_REV_PER_MW = -9999999999.0
         CLASS = 0
         MONTH = 7
         INT4_EMIS_TYPE = 3
         ANNUAL_CO2_RETIREMENTS_PROCESS = .FALSE.
         IF(.NOT. GET_CO2_RETIREMENTS_LOGIC()) RETURN  !MSG AUG 09
!          temp_grx_converged = CHECK_FOR_GRX_CONVERGENCE(0_2)
         IF(.NOT. GRX_CONVERGED)
     +                          RETIRED_UNITS = RESET_CL_RETIRED_UNITS() !RESETS THE UNITS RETIRED IN THE LOOP
         CURRENT_YEAR = 100*(BASE_YEAR + R_YEAR - 1900)
!         CO2_PRICE = TRANS_MRX_DISPATCH_EMIS_ADDER(INT4_EMIS_TYPE,MONTH,
!     +                                             R_YEAR,CLASS)
         DO U = 1, NUNITS
! 081918.
            IF(FIRST_RETIREMENT_YEAR(U) > CURRENT_YEAR) CYCLE
            IF(RETIREMENT_CANDIDATE(U) /= 'T' .OR.
     +                RETIREMENTS_CO2(U) < 0.01 .OR.
     +                     OFLINE(U) < CURRENT_YEAR .OR.
     +                                 RETIREMENTS_MW(U) < 0.0001) CYCLE
            ANN_ECON_RETIRE_COUNTER = ANN_ECON_RETIRE_COUNTER + 1
            RETIREMENTS_INDEX(ANN_ECON_RETIRE_COUNTER) = U
!            RETIREMENT_REV_PER_MW(U) =
!     +               CO2_PRICE * RETIREMENTS_CO2(U) * 0.000001 -
!     +                                       ANNUAL_GROSS_MARGIN(U,3)
!            RETIREMENT_REV_PER_MW(U) = RETIREMENT_REV_PER_MW(U) /
!     +                                                 RETIREMENTS_MW(U)
!            LINK_CN = MRX_ICAP_UNIT_LINK(L)
!            IF(LINK_CN > 0) THEN
!               LINK_I = OPTION_POSITION(LINK_CN)
!               ANNUAL_ICAP_REVENUE = 1000000. *
!     +                     (RETURN_SCREEN_CAP_COST(LINK_I,R_YEAR))
!            ELSE
!               LINK_I = I
!               ANNUAL_ICAP_REVENUE = 1000000. *
!     +                     (RETURN_SCREEN_CAP_COST(LINK_I,R_YEAR) +
!     +                               SCENARIO_CAP_COST_MULT
!            ENDIF
!
!
            IF(.NOT. GRX_CONVERGED) THEN
               CALL
     +           GRX_CAPACITY_RETIRE_OPTIONS(U,ANNUAL_GROSS_MARGIN(U,3))
            ENDIF
            ANNUAL_CAPITAL_COST = 0.17 * 1050.0 * 1000.0 *
     +                                                 RETIREMENTS_MW(U)
!
! 031710. NEW MEASURE OF PROFITABILITY
            RETIREMENTS_UPLIFT_PER_TON(U) = ECON_CO2_RETIRE_PRICE(U)
!     +                  (ANNUAL_GROSS_MARGIN(U,3)*1000000.0 +
!     +                     ANNUAL_CAPITAL_COST) /
!     +                                                RETIREMENTS_CO2(U)
            CUM_CO2_EMISSIONS = CUM_CO2_EMISSIONS +
     +                                                RETIREMENTS_CO2(U)
         END DO
! SORT FROM WORST TO BEST RETIREMENT
         ASCENDING = .FALSE. ! DECENDING
         CALL INDEXED_SORT_ASCENDING(RETIREMENTS_UPLIFT_PER_TON,
     +                               RETIREMENTS_INDEX,
     +                               ANN_ECON_RETIRE_COUNTER,
!     +                               NUNITS,
     +                               ASCENDING)
         NEXT_MRX_RETIREMENT = 1
         DO COUNTER = 1, ANN_ECON_RETIRE_COUNTER
             TEMP_I2 =
     +              RETIREMENTS_INDEX(ANN_ECON_RETIRE_COUNTER-COUNTER+1)
             CO2_ABATEMENT_INDEX(COUNTER) = TEMP_I2
             IF(COUNTER > 1) THEN
               RETIREMENTS_CUM_CO2(TEMP_I2) =
     +             RETIREMENTS_CUM_CO2(CO2_ABATEMENT_INDEX(COUNTER-1)) +
     +                                          RETIREMENTS_CO2(TEMP_I2)
             ELSE
               RETIREMENTS_CUM_CO2(TEMP_I2) = RETIREMENTS_CO2(TEMP_I2)
             ENDIF
             RETIREMENTS_CO2_PRICE(TEMP_I2) =
     +                               RETIREMENTS_UPLIFT_PER_TON(TEMP_I2)
         END DO
         ANNUAL_CO2_RETIREMENTS_PROCESS = .TRUE.
      RETURN
C***********************************************************************
      ENTRY ANNUAL_RETIRE_RETRO_PROCESS(R_YEAR)
C***********************************************************************
         ANNUAL_RETIRE_RETRO_PROCESS = .FALSE.  !MSG AUG 09
         RETIRE_RETRO_COUNTER = 0               !MSG AUG 09
         IF(CO2_RETROFIT_LOGIC_ACTIVE()) THEN
            RETIRE_RETRO_COUNTER = RETIRE_RETRO_COUNTER+RETROFIT_COUNTER !MSG AUG 09
            ABATE_RETROFIT_COUNTER = RETROFIT_COUNTER
         ELSE
            ABATE_RETROFIT_COUNTER = 0
         ENDIF
         IF(GET_CO2_RETIREMENTS_LOGIC())
     +             RETIRE_RETRO_COUNTER = RETIRE_RETRO_COUNTER
     +                                    + ANN_ECON_RETIRE_COUNTER  !MSG AUG 09
          CO2_MARKET_PTS = 0
!         IF(GRX_CO2_MARKET_LOGIC(CO2_MARKET_PTS))
!     +          RETIRE_RETRO_COUNTER=RETIRE_RETRO_COUNTER+CO2_MARKET_PTS !MSG AUG 09
!
         IF(RETIRE_RETRO_COUNTER <= 0) RETURN
         ANNUAL_RETIRE_RETRO_PROCESS = .TRUE.
!
         YES_CO2_ABATEMENT_REPORT = CO2_ABATEMENT_REPORT_ACTIVE()
         IF(  YES_CO2_ABATEMENT_REPORT .AND.
     +                 CO2_ABATEMENT_REPORT_NOT_OPEN) THEN
            CO2_ABATEMENT_VAR_NUM = 12
            CO2_ABATEMENT_NO = CO2_ABATEMENT_RPT_HEADER(
     +                                          CO2_ABATEMENT_VAR_NUM,
     +                                          CO2_ABATEMENT_REC)
            CO2_ABATEMENT_REPORT_NOT_OPEN = .FALSE.
         ENDIF
         CURRENT_YEAR = R_YEAR+BASE_YEAR
!
         RETIRE_RETRO_INDEX = 0
         RETIRE_OR_RETRO = 0
         RETIRE_RETRO_POSITION = 0
         RETIRE_RETRO_ABATE_INDEX = 0
! COMBINE RETIRE AND RETRO AND SORT INTO ONE MASTER LIST
         DO I = 1, ANN_ECON_RETIRE_COUNTER
            RETIRE_RETRO_POSITION(I) = I
            RETIRE_RETRO_INDEX(I) = RETIREMENTS_INDEX(I) ! = U
            RETIRE_OR_RETRO(I) = 1 ! RETIRE = 1
! CHANGING INDEX DEFINITION
            RETIRE_RETRO_UPLIFT_PER_TON(I) =
     +                       RETIREMENTS_CO2_PRICE(RETIREMENTS_INDEX(I))
         END DO
         I = ANN_ECON_RETIRE_COUNTER
         DO J = 1, ABATE_RETROFIT_COUNTER
            U = RETROFIT_UNIT_INDEX(J)
            IF(.NOT. RETROFIT_UNIT_IS_ACTIVE(U)) CYCLE
            IF(RETROFIT_CANDIDATE(U) /= 'T') CYCLE
!            IF(GRX_BOP_RETROFIT_ACTIVE(U)) CYCLE
            IF(ALLOCATED(GRX_BOP_RETROFIT_ACTIVE)) THEN
               IF(GRX_BOP_RETROFIT_ACTIVE(U)) CYCLE
            ENDIF
            IF(HardWiredRetrofitProject(U) .AND.
     +                  .NOT. HardWiredRetrofitProjectThisYear(U))CYCLE
            IF(OFLINE(U) < 100*(BASE_YEAR + R_YEAR - 1900)) CYCLE
            I = I + 1
            RETIRE_RETRO_POSITION(I) = I
            RETIRE_RETRO_INDEX(I) = RETROFIT_UNIT_INDEX(J)
            IF(HardWiredRetrofitProjectThisYear(U)) THEN
               RETIRE_OR_RETRO(I) = 4 ! RETRO = IS Hard Wired
            ELSE
               RETIRE_OR_RETRO(I) = 2 ! RETRO = 2
            ENDIF
            RETIRE_RETRO_UPLIFT_PER_TON(I) = RETROFIT_CO2_PRICE(U)
         END DO
       IF(.FALSE. ) THEN
         DO J = 1, CO2_MARKET_PTS
            I = I +1
            RETIRE_RETRO_POSITION(I) = I
            RETIRE_RETRO_INDEX(I) = J
            RETIRE_OR_RETRO(I) = 3 ! MARKET SOURCE = 2
            RETIRE_RETRO_UPLIFT_PER_TON(I) = 0. ! GRX_CO2_MARKET_PRICE(J)
         ENDDO
       ENDIF ! REMOVE MARKET SOURCE WHICH ISN'T ACTIVE
       RETIRE_RETRO_COUNTER = I
! SORT FROM WORST TO BEST RETIREMENT
!         CALL INDEXED_SORT_ASCENDING(RETIRE_RETRO_UPLIFT_PER_TON,
!     +                               RETIRE_RETRO_INDEX,
!     +                               RETIRE_RETRO_COUNTER,
!     +                               ASCENDING)
         ASCENDING = .FALSE. ! DECENDING
         CALL INDEXED_SORT_ASCENDING(RETIRE_RETRO_UPLIFT_PER_TON,
     +                               RETIRE_RETRO_POSITION,
     +                               RETIRE_RETRO_COUNTER,
     +                               ASCENDING)
         CUM_MW = 0.0
         CUM_MWH = 0.0
         RETIRE_RETRO_COUNT_AFTER_SORT = 0
         RETIRE_RETRO_USED = 0
         LAST_COUNTER = 0
         RETIRE_RETRO_CUM_CO2(0) =  0.
         DO COUNTER = 1, RETIRE_RETRO_COUNTER
            TEMP_I2 =
     +             RETIRE_RETRO_POSITION(RETIRE_RETRO_COUNTER-COUNTER+1)
            U = RETIRE_RETRO_INDEX(TEMP_I2)
!            IF(RETIRE_RETRO_USED(U) > 0) THEN
! 031910. THIS FILTERS-OUT MORE EXPENSIVE OPTIONS.
!               CYCLE
!            ELSE
               RETIRE_RETRO_USED(U) = RETIRE_RETRO_USED(U) + 1
!            ENDIF
            RETIRE_RETRO_COUNT_AFTER_SORT =
     +                                 RETIRE_RETRO_COUNT_AFTER_SORT + 1
            RETIRE_RETRO_ABATE_INDEX(COUNTER) = U
            IF(RETIRE_OR_RETRO(TEMP_I2) == 3) THEN ! MARKET POSITION
               RPT_UNIT_NAME = "CO2 Market Purchase-"//
     +               CONVERT_2_STR(RETIRE_RETRO_UPLIFT_PER_TON(TEMP_I2))   ! 48 CHARACTERS
               RPT_RETIREMENTS_CO2 = 0. ! GRX_CO2_MARKET_TONS(U)
               RPT_RETIREMENTS_MW = 0.
               RPT_RETIREMENTS_MWH = 0.
            ELSE
               IF(RETIRE_OR_RETRO(TEMP_I2) == 2) THEN
                 RPT_UNIT_NAME = TRIM(SP_UNIT_NAME(U))//'-Retro'
               ELSE
                 RPT_UNIT_NAME = SP_UNIT_NAME(U)
               ENDIF
               RPT_RETIREMENTS_CO2 = RETIREMENTS_CO2(U)
               CUM_MW = CUM_MW + RETIREMENTS_MW(U)
               CUM_MWH = CUM_MWH + RETIREMENTS_MWH(U)
               RPT_RETIREMENTS_MW = RETIREMENTS_MW(U)
               RPT_RETIREMENTS_MWH = RETIREMENTS_MWH(U)
            ENDIF
            RETIRE_RETRO_CUM_CO2(COUNTER) =
     +             RETIRE_RETRO_CUM_CO2(COUNTER-1) + RPT_RETIREMENTS_CO2
            RETIRE_RETRO_CO2_PRICE(COUNTER) =
     +                              RETIRE_RETRO_UPLIFT_PER_TON(TEMP_I2)
            UNIT_Decision_CO2_Price(U) = RETIRE_RETRO_CO2_PRICE(COUNTER)
!
            IF(YES_CO2_ABATEMENT_REPORT) THEN
               IF(CAPACITY_PLANNING_METHOD() == 'MX'  .AND.
     +                                  GREEN_MRX_METHOD() == 'GX') THEN
                  WRITE(CO2_ABATEMENT_NO,
     +                  REC=CO2_ABATEMENT_REC)
     +                        PRT_ENDPOINT(),
     +                        FLOAT(CURRENT_YEAR),
     +                        RPT_UNIT_NAME,
     +                        FLOAT(GRX_ITERATIONS),
     +                        FLOAT(COUNTER),
     +                        FLOAT(RETIRE_OR_RETRO(TEMP_I2)),
     +                        RETIRE_RETRO_CUM_CO2(COUNTER)/1000000.,
     +                        RETIRE_RETRO_CO2_PRICE(COUNTER),
     +                        CUM_MW,
     +                        CUM_MWH,
     +                        RPT_RETIREMENTS_CO2/1000000.,
     +                        RPT_RETIREMENTS_MW,
     +                        RPT_RETIREMENTS_MWH,
     +                        CURRENT_CO2_DISPATCH_COST,
     +                        RETIREMENT_CO2_COST_PER_TON(U)
               ELSE
                  WRITE(CO2_ABATEMENT_NO,
     +                  REC=CO2_ABATEMENT_REC)
     +                        PRT_ENDPOINT(),
     +                        FLOAT(CURRENT_YEAR),
     +                        RPT_UNIT_NAME,
     +                        FLOAT(COUNTER),
     +                        FLOAT(RETIRE_OR_RETRO(TEMP_I2)),
     +                        RETIRE_RETRO_CUM_CO2(COUNTER)/1000000.,
     +                        RETIRE_RETRO_CO2_PRICE(COUNTER),
     +                        CUM_MW,
     +                        CUM_MWH,
     +                        RPT_RETIREMENTS_CO2/1000000.,
     +                        RPT_RETIREMENTS_MW,
     +                        RPT_RETIREMENTS_MWH,
     +                        CURRENT_CO2_DISPATCH_COST,
     +                        RETIREMENT_CO2_COST_PER_TON(U)
               ENDIF
               CO2_ABATEMENT_REC = CO2_ABATEMENT_REC + 1
            ENDIF
         END DO
         IF(YES_CO2_ABATEMENT_REPORT) CALL FLUSH(CO2_ABATEMENT_NO)
         J = J
      RETURN
C***********************************************************************
      ENTRY GET_CO2_RETIREMENT_PRICE(R_CO2_REDUCTION)
C***********************************************************************
! SEARCH ALGORITHM WOULD BE BETTER.
       IF(R_CO2_REDUCTION < 0.01) THEN
          GET_CO2_RETIREMENT_PRICE = 0.0
       ELSE
         IF(R_CO2_REDUCTION <
     +                 RETIREMENTS_CUM_CO2(CO2_ABATEMENT_INDEX(1))) THEN
            COUNTER = 1
         ELSEIF(R_CO2_REDUCTION >
     +       RETIREMENTS_CUM_CO2(CO2_ABATEMENT_INDEX(
     +                                   ANN_ECON_RETIRE_COUNTER))) THEN
            COUNTER = ANN_ECON_RETIRE_COUNTER
         ELSE
!            HALF = CO2_COUNTER / 2
            DO COUNTER = 1, ANN_ECON_RETIRE_COUNTER
               IF(R_CO2_REDUCTION >
     +              RETIREMENTS_CUM_CO2(
     +                              CO2_ABATEMENT_INDEX(COUNTER))) CYCLE
               EXIT
!               IF(HALF <= 1) THEN
!                  COUNTER = 1
!                  EXIT
!               ELSEIF(R_CO2_REDUCTION <
!     +              RETIREMENTS_CUM_CO2(CO2_ABATEMENT_INDEX(HALF))) THEN
!               ELSE
!               ENDIF
            ENDDO
         ENDIF
         GET_CO2_RETIREMENT_PRICE = RETIREMENTS_CO2_PRICE(
     +                                     CO2_ABATEMENT_INDEX(COUNTER))
        ENDIF
      RETURN
C***********************************************************************
      ENTRY GET_CO2_RETIRE_RETRO_PRICE(R_CO2_REDUCTION)
C***********************************************************************
! SEARCH ALGORITHM WOULD BE BETTER.
         IF(R_CO2_REDUCTION < RETIRE_RETRO_CUM_CO2(1)) THEN
            COUNTER = 1
         ELSEIF(R_CO2_REDUCTION >
     +        RETIRE_RETRO_CUM_CO2(RETIRE_RETRO_COUNT_AFTER_SORT) ) THEN
            COUNTER = RETIRE_RETRO_COUNT_AFTER_SORT
         ELSE
!            HALF = CO2_COUNTER / 2
            DO COUNTER = 1, RETIRE_RETRO_COUNT_AFTER_SORT
               IF(R_CO2_REDUCTION >
     +              RETIRE_RETRO_CUM_CO2(COUNTER) ) CYCLE
               EXIT
!               IF(HALF <= 1) THEN
!                  COUNTER = 1
!                  EXIT
!               ELSEIF(R_CO2_REDUCTION <
!     +              RETIREMENTS_CUM_CO2(CO2_ABATEMENT_INDEX(HALF))) THEN
!               ELSE
!               ENDIF
            ENDDO
         ENDIF
         GET_CO2_RETIREMENT_PRICE = RETIRE_RETRO_CO2_PRICE(COUNTER)
      RETURN
C***********************************************************************
      ENTRY GET_NEXT_MRX_RETIRE_RETRO(    R_CO2_COUNTER,
     +                                    R_RETIRE_OR_RETRO,
     +                                    R_CO2_NUNIT,
     +                                    R_CO2_TG,
     +                                    R_CO2_UNIT_MW,
     +                                    R_CO2_UNIT_MWH,
     +                                    R_CO2_UNIT_CO2,
     +                                    R_CO2_UNIT_PRICE,
     +                                    R_CO2_STRIKE_PRICE,
     +                                    R_CO2_UNIT_MW_AFTER,
     +                                    R_CO2_STRIKE_PRICE_AFTER,
     +                                    R_CO2_UNIT_CO2_AFTER,
     +                                    R_CO2_END_LIST)
C***********************************************************************
! FOR RETRO NEED:
!  1. CAPACITY BEFORE
!  2. CAPACITY AFTER
!  3. STRIKE BEFORE
!  4. STRIKE AFTER
!
         GET_NEXT_MRX_RETIRE_RETRO = .FALSE.
         IF(R_CO2_COUNTER > RETIRE_RETRO_COUNT_AFTER_SORT) RETURN
         COUNTER = R_CO2_COUNTER ! ASSUMES THE CORRECT COUNTER IS PASSED IN
         TEMP_I2 =
     +             RETIRE_RETRO_POSITION(RETIRE_RETRO_COUNTER-COUNTER+1)
         R_RETIRE_OR_RETRO = RETIRE_OR_RETRO(TEMP_I2)
         IF(R_RETIRE_OR_RETRO == 3) THEN ! CO2 MARKET
         ELSE
            R_CO2_NUNIT = RETIRE_RETRO_ABATE_INDEX(COUNTER) ! CO2_ABATEMENT_INDEX(COUNTER)
            R_CO2_TG = GET_TRANS_GROUP_POSITION(
     +                                TRANSACTION_GROUP_ID(R_CO2_NUNIT))
            R_CO2_UNIT_CO2 = RETIREMENTS_CO2(R_CO2_NUNIT)
            R_CO2_UNIT_MW = RETIREMENTS_MW(R_CO2_NUNIT)
            R_CO2_UNIT_MWH = RETIREMENTS_MWH(R_CO2_NUNIT)
            R_CO2_UNIT_PRICE = RETIRE_RETRO_CO2_PRICE(COUNTER)
            TEMP_I2 = 2
            R_CO2_STRIKE_PRICE = GET_TOTAL_INCREMENTAL_COST(R_CO2_NUNIT,
     +                                                      TEMP_I2)
            TEMP_I2 = 1
            R_CO2_STRIKE_PRICE =
     +               MAX(R_CO2_STRIKE_PRICE,
     +                      GET_TOTAL_INCREMENTAL_COST(R_CO2_NUNIT,
     +                                                      TEMP_I2))
!         R_CO2_STRIKE_PRICE = 10.0
            IF(R_RETIRE_OR_RETRO == 2) THEN ! .AND. 1 == 2) THEN
               CALL RETURN_RETROFIT_PROJECT_IMPACTS(
     +                        RETROFIT_PROJECT_ID(R_CO2_NUNIT),
     +                                      Min_Cap_Change,
     +                                      Max_Cap_Change,
     +                                      Ave_Heat_Rate_Mult,
     +                                      CO2_Cntl_Percent)
               R_CO2_UNIT_MW_AFTER = R_CO2_UNIT_MW * Max_Cap_Change
! THIS NEEDS TO BE REDEFINED
               R_CO2_STRIKE_PRICE_AFTER = R_CO2_STRIKE_PRICE *
     +                                                Ave_Heat_Rate_Mult
               R_CO2_UNIT_CO2_AFTER = R_CO2_UNIT_CO2 *
     +                                     (1.0 - CO2_Cntl_Percent*0.01)
            ELSE
               R_CO2_UNIT_MW_AFTER = 0.0
               R_CO2_STRIKE_PRICE_AFTER = 0.0
               R_CO2_UNIT_CO2_AFTER = 0.0
            ENDIF
         ENDIF ! CO2 MARKET
!     +      MAX(
!     +         GET_TOTAL_INCREMENTAL_COST(R_CO2_NUNIT,INT2(1)),
!     +         GET_TOTAL_INCREMENTAL_COST(R_CO2_NUNIT,INT2(2)))
         R_CO2_COUNTER = R_CO2_COUNTER + 1
         IF(R_CO2_COUNTER <= RETIRE_RETRO_COUNT_AFTER_SORT) THEN
            R_CO2_END_LIST = .FALSE.
         ELSE
            R_CO2_END_LIST = .TRUE.
         ENDIF
         GET_NEXT_MRX_RETIRE_RETRO = .TRUE.
      RETURN
C***********************************************************************
      ENTRY GET_NEXT_MRX_RETIREMENT(
     +                                    R_CO2_COUNTER,
     +                                    R_CO2_NUNIT,
     +                                    R_CO2_UNIT_MW,
     +                                    R_CO2_UNIT_MWH,
     +                                    R_CO2_UNIT_CO2,
     +                                    R_CO2_UNIT_PRICE,
     +                                    R_CO2_END_LIST)
C***********************************************************************
!
         GET_NEXT_MRX_RETIREMENT = .FALSE.
!
         IF(NEXT_MRX_RETIREMENT == ANN_ECON_RETIRE_COUNTER) THEN
            CURRENT_YEAR = CURRENT_YEAR
         ENDIF
!
         CURRENT_YEAR = YEAR+BASE_YEAR
!         DO COUNTER =  CO2_COUNTER, NEXT_MRX_RETIREMENT, - 1
         DO COUNTER =  NEXT_MRX_RETIREMENT, ANN_ECON_RETIRE_COUNTER
!            IF(RETIREMENTS_INDEX(COUNTER) <= 0) CYCLE
            IF(CO2_ABATEMENT_INDEX(COUNTER) <= 0) CYCLE
            R_CO2_COUNTER = COUNTER
            R_CO2_NUNIT = CO2_ABATEMENT_INDEX(COUNTER)
!            R_CO2_NUNIT = RETIREMENTS_INDEX(COUNTER)
            R_CO2_UNIT_CO2 = RETIREMENTS_CO2(R_CO2_NUNIT)
            R_CO2_UNIT_MW = RETIREMENTS_MW(R_CO2_NUNIT)
            R_CO2_UNIT_MWH = RETIREMENTS_MWH(R_CO2_NUNIT)
            R_CO2_UNIT_PRICE = RETIREMENTS_CO2_PRICE(R_CO2_NUNIT)
!            R_CO2_UNIT_REV_PER_MW = RETIREMENT_REV_PER_MW(R_CO2_NUNIT)
            EXIT
         END DO
         NEXT_MRX_RETIREMENT = COUNTER+1
!         CO2_COUNTER = COUNTER-1
!         IF(COUNTER > 0) THEN
         IF(COUNTER <= ANN_ECON_RETIRE_COUNTER) THEN
            MRX_RETIRE_THIS_UNIT = .TRUE.
            R_CO2_END_LIST = .FALSE.
         ELSE
            MRX_RETIRE_THIS_UNIT = .FALSE.
            R_CO2_END_LIST = .TRUE.
         ENDIF
! THIS CAN BE MOVED AND BUILD A LIST OF RETIREMENTS TO TEST
! AND THEN RETIRE IN A SEPARATE ROUTINE.
         IF(MRX_RETIRE_THIS_UNIT) THEN
!
!            RETIREMENT_CANDIDATE(R_CO2_NUNIT) = 'F' !MOVED TO CL_CAPACITY_TEMP_RETIRE_UNIT AIG 09
            TEMP_R4 = CL_CAPACITY_PLANNING_ADJUSTMENTS(
     +                                CURRENT_YEAR,R_CO2_NUNIT,2,.TRUE.)
            TEMP_I2 = CL_CAPACITY_TEMP_RETIRE_UNIT(CURRENT_YEAR,
     +                                             R_CO2_NUNIT)
            WRITE(9,1008) "Retirement",UNITNM(R_CO2_NUNIT),
     +                                    CURRENT_YEAR,
     +                                    R_CO2_UNIT_MW,
     +                                    R_CO2_UNIT_CO2,
     +                                    R_CO2_UNIT_PRICE,
     +                                    R_CO2_UNIT_MWH
         ENDIF
!
      RETURN
 1008 FORMAT(3X,A,3X,A,3X,I4,3X,F7.2,3X,F12.0,3X,F12.2)
 1009 FORMAT(1X,I4,5X,I4,4X,I4,2X,A,2X,A,1X,F9.1,F12.0,F12.2)
C***********************************************************************
      ENTRY RETIRE_CO2_THERMAL_UNIT(      R_CO2_NUNIT,
     +                                    R_CO2_UNIT_MW,
     +                                    R_CO2_UNIT_CO2,
     +                                    R_CO2_UNIT_PRICE)
C***********************************************************************
!
         CURRENT_YEAR = YEAR+BASE_YEAR
         TEMP_I2 =
     +            CL_CAPACITY_TEMP_RETIRE_UNIT(CURRENT_YEAR,R_CO2_NUNIT)
!         RETIREMENT_CANDIDATE(R_CO2_NUNIT) = 'F' ! MOVED TO CL_CAPAICTY_TEMP_RETIRE_UNIT AUG 09
         IF(.NOT. GRX_RETIRE_THIS_YEAR) THEN
            TEMP_R4 = CL_CAPACITY_PLANNING_ADJUSTMENTS(
     +                                CURRENT_YEAR,R_CO2_NUNIT,2,.TRUE.)
         ENDIF
         WRITE(9,1009) INT4(PRT_ENDPOINT()),
     +                 CURRENT_YEAR,
     +                 CURRENT_YEAR,
     +                 "Retirement",
     +                 UNITNM(R_CO2_NUNIT),
     +                 R_CO2_UNIT_MW,
     +                 R_CO2_UNIT_CO2,
     +                 R_CO2_UNIT_PRICE
!
      RETURN
C***********************************************************************
      ENTRY RETROFIT_ACTIVE_ID(RR_CO2_NUNIT)
C***********************************************************************
        IF(RETROFIT_ACTIVE(RR_CO2_NUNIT)) THEN
            RETROFIT_ACTIVE_ID = RETROFIT_PROJECT_ID(RR_CO2_NUNIT)
        ELSE
            RETROFIT_ACTIVE_ID = 0
        ENDIF
      RETURN
C***********************************************************************
      ENTRY RETROFIT_PROJECT_ACTIVE(RR_CO2_NUNIT)
C***********************************************************************
        IF(RETROFIT_ACTIVE(RR_CO2_NUNIT)) THEN
            RETROFIT_ACTIVE_ID = RETROFIT_PROJECT_ID(RR_CO2_NUNIT)
            CALL RETRO_PROJECT_AVAILABLE(RETROFIT_ACTIVE_ID,YEAR,
     +                                   TEMP_L1)
            RETROFIT_PROJECT_ACTIVE = TEMP_L1
        ELSE
            RETROFIT_ACTIVE_ID = 0
            RETROFIT_PROJECT_ACTIVE= .FALSE.
        ENDIF
      RETURN
C***********************************************************************
      ENTRY RETROFIT_CO2_THERMAL_UNIT(R_CO2_NUNIT,
     +                                    R_CO2_UNIT_MW,
     +                                    R_CO2_UNIT_CO2,
     +                                    R_CO2_UNIT_PRICE,
     +                                    R_CO2_RETIRE_OR_RETRO)
C***********************************************************************
         RETROFIT_ACTIVE(R_CO2_NUNIT) = .TRUE.
         RETROFIT_CO2_THERMAL_UNIT = .TRUE.
         CALL GRX_RETROFIT_UNIT_LIST(R_CO2_NUNIT,
     +                               R_CO2_RETIRE_OR_RETRO,
     +                               R_CO2_UNIT_PRICE)
         CURRENT_YEAR = YEAR+BASE_YEAR
         WRITE(9,1009)  INT4(PRT_ENDPOINT()),
     +                  CURRENT_YEAR,
     +                  CURRENT_YEAR,
     +                  "Retrofit",
     +                  UNITNM(R_CO2_NUNIT),
     +                  R_CO2_UNIT_MW,
     +                  R_CO2_UNIT_CO2,
     +                  R_CO2_UNIT_PRICE
!         TEMP_I2 = RETROFIT_PROJECT_ID(R_CO2_NUNIT)
      RETURN
CC***********************************************************************
      ENTRY TRANS_ANNUAL_UNIT_RETIREMENT() ! (R_NUNITS)
C***********************************************************************
!
! POSSIBLE RETIREMENT CRITERIA:
!
!     LOOSES $ X MILLIONS GROSS MARGIN PLUS ANNUALIZED CAPITAL COSTS.
!     SAME AS ABOVE, BUT OVER Y YEARS.
!
!        TEST CRITERIA
!        IF CRITERIA MET:
!           CHANGE OFF LINE YEAR
!           CALL CL_PLANNING_REMOVALS
!
         TRANS_ANNUAL_UNIT_RETIREMENT = .FALSE.
      RETURN
C***********************************************************************
      ENTRY GET_THERMAL_STATE_INDEX(R_NUNITS)
C***********************************************************************
         GET_THERMAL_STATE_INDEX = State_Index(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_THERMAL_RPS_DATA(R_NUNITS,R_PM,R_ST_TG,R_ST,
     +                                                    R_RPS_CONTRIB)
C***********************************************************************
         R_PM =  PRIMARY_MOVER_INDEX_DB(PRIMARY_MOVER_STR(R_NUNITS))
         R_ST_TG = State_TG_Index(R_NUNITS)
         R_ST = State_Index(R_NUNITS)
         R_RPS_CONTRIB = RPS_CONTRIBUTION_PERCENT(R_NUNITS)* 0.01
         GET_THERMAL_RPS_DATA = .TRUE.
      RETURN
C***********************************************************************
      ENTRY PUT_THERMAL_RPS_ENRG_CAP(R_NUNITS,R_ENRG,R_CAP,R_YEAR,
     +                                                     R_ISEAS)
C***********************************************************************
         TEMP_RPS_NO = RPS_PROGRAM_NUMBER(R_NUNITS)
         TEMP_PM = PRIMARY_MOVER_INDEX_DB(PRIMARY_MOVER_STR(R_NUNITS))
         LOCAL_RPS_CONTRIB_PERCENT = RPS_CONTRIBUTION_PERCENT(R_NUNITS)
         IF(LOCAL_RPS_CONTRIB_PERCENT < -0.01) THEN
            LOCAL_RPS_CONTRIB_PERCENT = 0.01 *
     +               ESCALATED_MONTHLY_VALUE(LOCAL_RPS_CONTRIB_PERCENT,
     +                    ABS(INT2(RPS_CONTRIBUTION_PERCENT(R_NUNITS))),
     +                                           R_YEAR,INT2(1),INT2(1))
         ELSE
            LOCAL_RPS_CONTRIB_PERCENT =
     +                                  0.01 * LOCAL_RPS_CONTRIB_PERCENT
         ENDIF
         TEMP_ENRG = R_ENRG * LOCAL_RPS_CONTRIB_PERCENT
         TEMP_CAP = R_CAP * LOCAL_RPS_CONTRIB_PERCENT
     +
         TEMP_L1 = PUT_RPS_ENRG_CAP(TEMP_RPS_NO,TEMP_PM,
     +                              TEMP_ENRG,TEMP_CAP)
         PUT_THERMAL_RPS_ENRG_CAP = .TRUE.
      RETURN
C***********************************************************************
      ENTRY GET_CL_BASECASE_MARKET_ID(R_NUNITS,R_MARKET_ID)  ! L1
C***********************************************************************
         R_MARKET_ID = BASECASE_MARKET_AREA_ID(R_NUNITS)
         GET_CL_BASECASE_MARKET_ID = .TRUE.
      RETURN
C***********************************************************************
      ENTRY GET_MONTHLY_FUEL_INDEX(R_NUNITS,R_ISEAS)
C***********************************************************************
         IF(MONTHLY_FUEL_INDEX(R_NUNITS) == 0) THEN
            GET_MONTHLY_FUEL_INDEX = 1.
         ELSE
            GET_MONTHLY_FUEL_INDEX =
     +            GET_VAR(FLOAT(ABS(MONTHLY_FUEL_INDEX(R_NUNITS))),
     +                                         R_ISEAS,UNITNM(R_NUNITS))
         ENDIF
      RETURN
C***********************************************************************
      ENTRY GET_PRIMARY_MOVER(R_NUNITS)
C***********************************************************************
         GET_PRIMARY_MOVER = PRIMARY_MOVER(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY SET_TRANS_FOR_DATA_BASE()
C***********************************************************************
         IF(ALLOCATED(TRANS_GROUP_FOR_DATA_BASE))
     +                             DEALLOCATE(TRANS_GROUP_FOR_DATA_BASE)
         ALLOCATE(TRANS_GROUP_FOR_DATA_BASE(MAX_TRANS_DATA_BASES))
         TRANS_GROUP_FOR_DATA_BASE = 0
         DO M = 1, MAX_DAY_TYPES
            DO I = 1, MAX_TRANS_GROUPS
               RTEMP = DAY_TYPE_TRANS_GROUP_PAIR(M,I)
               IF( RTEMP > 0) THEN
                  TRANS_GROUP_FOR_DATA_BASE(RTEMP) = I
               ENDIF
            ENDDO
         ENDDO
         SET_TRANS_FOR_DATA_BASE = MAX_TRANS_DATA_BASES
      RETURN
C***********************************************************************
      ENTRY GET_ASSET_CLASS_NUM(R_NUNITS)
C***********************************************************************
         GET_ASSET_CLASS_NUM = ASSET_CLASS_NUM(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY GET_TRANS_FOR_DATA_BASE(R_DATA_BASE)
C***********************************************************************
         GET_TRANS_FOR_DATA_BASE =
     +                            TRANS_GROUP_FOR_DATA_BASE(R_DATA_BASE)
      RETURN
C***********************************************************************
      ENTRY GET_DATA_BASE_FOR_TRANS(R_TRANS_GROUP,R_DAY_TYPE)
C***********************************************************************
         GET_DATA_BASE_FOR_TRANS =
     +               DAY_TYPE_TRANS_GROUP_PAIR(R_DAY_TYPE,R_TRANS_GROUP)
      RETURN
C***********************************************************************
      ENTRY GET_DATA_BASE_FOR_UNIT(R_NUNITS,R_DAY_TYPE)
C***********************************************************************
         IF(R_DAY_TYPE <= 2*MAX_DAY_TYPES) THEN
            GET_DATA_BASE_FOR_UNIT =
     +                           DATA_BASE_POSITION(R_DAY_TYPE,R_NUNITS)
         ELSE
            GET_DATA_BASE_FOR_UNIT = 0
         ENDIF
      RETURN
C***********************************************************************
      ENTRY GET_MAX_TRANS_ID_USED()
C***********************************************************************
         GET_MAX_TRANS_ID_USED =  MAX_TRANS_ID_USED
      RETURN
C***********************************************************************
      ENTRY GET_MAX_DATA_BASES()
C***********************************************************************
         GET_MAX_DATA_BASES = MAX_TRANS_DATA_BASES
      RETURN
C***********************************************************************
      ENTRY GET_NUNITS()
C***********************************************************************
         GET_NUNITS = NUNITS
      RETURN
C***********************************************************************
      ENTRY TRANSACTION_GROUP(R_NUNITS)
     +                 RESULT(R_TRANSACTION_GROUP)
C***********************************************************************
         R_TRANSACTION_GROUP = TRANSACTION_GROUP_ID(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY DAY_TYPE_FOR_RESOURCE(R_NUNITS)
C***********************************************************************
         DAY_TYPE_FOR_RESOURCE = DAY_TYPE_ID(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY NUC_FUEL_PRICE_SOURCE_IS_NFILE(R_NUNITS)
C***********************************************************************
         NUC_FUEL_PRICE_SOURCE_IS_NFILE =
     +                          NUC_FUEL_PRICES_FROM_FUEL_FILE(R_NUNITS)
      RETURN
CC***********************************************************************
C      ENTRY SPECIAL_ID_NAME(R_NUNITS)
CC***********************************************************************
C         SPECIAL_ID_NAME = SPECIAL_UNIT_ID(R_NUNITS)
C      RETURN
CC***********************************************************************
C      ENTRY RETURN_UNITNM(R_NUNITS)
CC***********************************************************************
C         RETURN_UNITNM = UNITNM(R_NUNITS)
C      RETURN
C***********************************************************************
      ENTRY RETURN_SHADOW_UNIT_NUMBER(R_NUNITS)
C***********************************************************************
         RETURN_SHADOW_UNIT_NUMBER = SHADOW_UNIT_NUMBER(R_NUNITS)
      RETURN
C***********************************************************************
      ENTRY NUMBER_OF_CL_UNITS
C***********************************************************************
         NUMBER_OF_CL_UNITS = NUNITS
      RETURN
C***********************************************************************
      ENTRY RESET_CL_UNITS
C***********************************************************************
         DO I = 1, INSTALLED_POINTER
            UNIT_NO = TEMP_RETIRED_UNIT_NO(I)
            OFLINE(UNIT_NO) = TEMP_RETIRED_OFF_LINE(I)
            RETIREMENT_CANDIDATE(UNIT_NO) = TEMP_RETIREMENT_SWITCH(I)
            FIRST_RETIREMENT_YEAR(UNIT_NO) =
     +                                     TEMP_FIRST_RETIREMENT_YEAR(I)
         ENDDO
         NUNITS = AVAILABLE_CL_UNITS
         RESET_CL_UNITS = NUNITS
         INSTALLED_POINTER = 0
      RETURN
C***********************************************************************
      ENTRY RETURN_CL_UNITS_B4_ADDITIONS
C***********************************************************************
         RETURN_CL_UNITS_B4_ADDITIONS = BASE_CL_UNITS
      RETURN
C***********************************************************************
      ENTRY RETURN_UNIT_ADDITIONS
C***********************************************************************
         RETURN_UNIT_ADDITIONS = max(0,NUNITS - BASE_CL_UNITS)
      RETURN
C********************************************************************
      ENTRY INCREMENT_HARDWIRED_CL_UNITS
C***********************************************************************
         BASE_PLUS_HARDWIRED_CL_UNITS = NUNITS
         INCREMENT_HARDWIRED_CL_UNITS = BASE_PLUS_HARDWIRED_CL_UNITS
      RETURN
C********************************************************************
      ENTRY INCREMENT_AVAILABLE_CL_UNITS
C***********************************************************************
         AVAILABLE_CL_UNITS = NUNITS
         INCREMENT_AVAILABLE_CL_UNITS = AVAILABLE_CL_UNITS
      RETURN
C********************************************************************
      ENTRY ADD_NEW_CL_UNIT(UNIT_ON_LINE_YEAR,
     +                      OPERATION_LIFE,
     +                      POINTER,
     +                      R_ON_LINE_MONTH,
     +                      R_ASSET_CLASS,
     +                      R_ALLOCATION_VECTOR,
     +                      R_CL_RESOURCE_ID, ! PER ANDERSON. 3/13/98.GAT
     +                      R_POINTER) ! FOR ICAP REPORT. 4/5/02.
C***********************************************************************
C
! ADDED 7/28/98. GAT.
            ADD_NEW_CL_UNIT = 0
!
!
            NUNITS = NUNITS + 1
            IF(END_POINT == 2 .AND. YEAR == 23 .AND.
     +                                             NUNITS == 12008) THEN
               NUNITS = NUNITS
            ENDIF
            IF(NUNITS > MAX_CL_UNITS) THEN
c               CALL LOCATE(20,0)
c               WRITE(6,'("&",A,I5,A)') 'More than ',
c     +                                  MAX_CL_UNITS,' capacity-limited'
c               WRITE(6,*)'units are in the capacity-limited'
c               WRITE(6,*) 'file after expansion planning for endpoint',
c     +                     INT4(PRT_ENDPOINT())
               WRITE(SCREEN_MESSAGES,'(A,I5,A)')
     +                     'More than ',MAX_CL_UNITS,' capacity-limited'
               CALL MG_LOCATE_WRITE(20,0,trim(SCREEN_MESSAGES),
     +                                                   ALL_VERSIONS,1)
               CALL MG_LOCATE_WRITE(21,0,
     +                              'units are in the capacity-limited',
     +                                                   ALL_VERSIONS,1)
               WRITE(SCREEN_MESSAGES,'(A,I5)')
     +            'file after expansion planning for endpoint',END_POINT
               CALL MG_LOCATE_WRITE(22,0,trim(SCREEN_MESSAGES),
     +                                                   ALL_VERSIONS,1)
               er_message='stop requested from Cla_objt SIID25'
               call end_program(er_message)
            ENDIF
            INQUIRE(UNIT=13,OPENED=NEW_CL_UNIT_OPENED)
            IF(.NOT. NEW_CL_UNIT_OPENED) THEN
               WRITE(4,*) "READ ERROR IN EXPANSION OPERATIONS FILE"
               WRITE(4,*) '*** line 2789 CLA_OBJT.FOR ***'
               er_message='See WARNING MESSAGES'
               call end_program(er_message)
            ENDIF
           READ(13,REC=POINTER) DELETE,UNITNM(NUNITS),
     +                     CL_LOAD_TYPE,
     +                     TEMP_EXPENSE_ASSIGNMENT,  ! EXPENSE_ASSIGNMENT(NUNITS),
     +                     TEMP_EXPENSE_COLLECTION,  ! EXPENSE_COLLECTION(NUNITS),
     +                     GENGRP(NUNITS),CAP_FRAC_OWN(NUNITS),
     +                     ON_LINE_MONTH_TEMP,OFF_LINE_MONTH(NUNITS),
     +                     FUEL_MIX_PTR(NUNITS), ! FUELMX(NUNITS), REPLACED 5/17/01 MSG
     +                     PBTUCT(NUNITS),PFESCR(NUNITS),SBTUCT(NUNITS),
     +                     SFESCR(NUNITS),
     +                     FUELADJ(NUNITS),EFOR(NUNITS),
     +                     (MNRATE(NUNITS,M),M=1,12),
     +                     VCPMWH_IN(NUNITS),OMESCR(NUNITS),
     +                     FIXED_COST_IN(NUNITS),
     +                     FIXED_COST_ESCALATOR(NUNITS),
     +                     DISPADJ(NUNITS),HR_FACTOR(NUNITS),
     +                     (INPUT_MW(M,NUNITS),M=1,2),
     +                     CAP_PLANNING_FAC(NUNITS),
     +                     (COEFF(M,NUNITS),M=1,3),
     +                     CL_AI_CAPACITY_RATE(NUNITS),
     +                     CL_AI_CAPACITY_ESCALATOR(NUNITS),
     +                     CL_AI_ENERGY_RATE(NUNITS),
     +                     CL_AI_ENERGY_ESCALATOR(NUNITS),
     +                     P_SO2(NUNITS),P_NOX(NUNITS),
     +                     P_PARTICULATES(NUNITS),
     +                     LOCAL_CL_POOL_FRAC_OWN(NUNITS),
     +                     P_EMIS_OTH2(NUNITS),
     +                     P_EMIS_OTH3(NUNITS),
     +                     DISPADJ2(NUNITS),
     +                     CL_RESOURCE_ID(NUNITS),
     +                     FUEL_SUPPLY_ID(NUNITS),
     +                     P_NOX_BK2(NUNITS),
     +                     SEC_FUEL_EMISS_PTR(NUNITS),
     +                     EMISS_FUEL_COST(NUNITS),
     +                     EMISS_FUEL_ESCAL(NUNITS),
     +                     EMISS_FUEL_EMISS_PTR(NUNITS),
     +                     EMISS_BLENDING_RATE(NUNITS),
     +                     PRIM_FUEL_EMISS_PTR(NUNITS),
     +                     TEMP_PRIM_FUEL_TYPE_STR,
     +                     TEMP_SEC_FUEL_TYPE,  ! SEC_FUEL_TYPE(NUNITS),
     +                     TEMP_EMISS_FUEL_TYPE,  ! EMISS_FUEL_TYPE(NUNITS),
     +                     TIE_CONSTRAINT_GROUP(NUNITS),
     +                     MONTHLY_CAPACITY_POINTER(NUNITS),
     +                     ANNUAL_CL_FIXED_COST(NUNITS),
     +                     ANNUAL_CL_FIXED_COST_ESC(NUNITS),
     +                     MAINT_DAYS(NUNITS),
     +                     DISPATCH_MULT(NUNITS),
     +                     EXCESS_ENERGY_SALES(NUNITS),
     +                     AI_CL_REMAINING_LIFE(NUNITS),
     +                     AI_CL_TAX_LIFE(NUNITS),
     +                     AI_CL_ADR_LIFE(NUNITS),
     +                     ASSET_CLASS_NUM(NUNITS),
     +                     ASSET_CLASS_VECTOR(NUNITS),
     +                     INTRA_COMPANY_CLASS_ID(NUNITS),
     +                     TEMP_INTRA_COMPANY_TRANSACTION, ! INTRA_COMPANY_TRANSACTION(NUNITS),
     +                     SPECIAL_UNIT_ID(NUNITS),
     +                     MINIMUM_CAPACITY_FACTOR(NUNITS),
     +                     MAXIMUM_CAPACITY_FACTOR(NUNITS),
     +                     TRANSACTION_GROUP_ID(NUNITS),
     +                     DAY_TYPE_ID(NUNITS),
     +                     TEMP_UNIT_ACTIVE,
     +                     BASECASE_PLANT_ID(NUNITS),
     +                     BASECASE_UNIT_ID,
     +                     BASECASE_MARKET_AREA_ID(NUNITS),
     +                     BASECASE_TRANS_AREA_ID,
     +                     BASECASE_PLANT_NERC_SUB_ID,
     +                     BASECASE_PLANT_OWNER_ID,
     +                     TEMP_UTILITY_OWNED, ! UTILITY_OWNED,
     +                     MONTHLY_FUEL_INDEX(NUNITS),
     +                     START_UP_COSTS(NUNITS),
     +                     TEMP_START_UP_LOGIC, ! START_UP_LOGIC(NUNITS),
     +                     RAMP_RATE(NUNITS),
     +                     MIN_DOWN_TIME(NUNITS),
     +                     TEMP_REPORT_THIS_UNIT, ! REPORT_THIS_UNIT(NUNITS),
     +                     P_FUEL_DELIVERY_1(NUNITS),
     +                     P_FUEL_DELIVERY_2(NUNITS),
     +                     P_FUEL_DELIVERY_3(NUNITS),
     +                     MIN_UP_TIME(NUNITS),
     +                     HESI_UNIT_ID_NUM(NUNITS), ! PLACEHOLDER
     +                     FOR_FREQUENCY(NUNITS),
     +                     FOR_DURATION(NUNITS),
     +                     WINTER_TOTAL_CAPACITY,
     +                     TEMP_CONTRIBUTES_TO_SPIN, ! CONTRIBUTES_TO_SPIN(NUNITS),
     +                     H2_UNIT_ID_NUM(NUNITS),
     +                     POWERDAT_PLANT_ID(NUNITS),
     +                     TEMP_APPLY_NOX_SEASON_DATE, ! APPLY_NOX_SEASON_DATE(NUNITS),
     +                     NOX_SEASON_DATE(NUNITS),
     +                     RAMP_DOWN_RATE(NUNITS),
     +                     NOX_CONTROL_PERCENT(NUNITS),
     +                     NOX_CONTROL_DATE(NUNITS),
     +                     EMERGENCY_CAPACITY(NUNITS),
     +                     EMERGENCY_HEATRATE(NUNITS),
     +                     TEMP_MARKET_RESOURCE, ! MARKET_RESOURCE(NUNITS),
     +                     PRIMARY_MOVER_STR(NUNITS),
     +                     COUNTY,
     +                     STATE_PROVINCE,
     +                     NOX_VOM(NUNITS),
     +                     NOX_FOM(NUNITS),
     +                     S_FUEL_DELIVERY(NUNITS),
     +                     S_FUEL_DELIVERY_2(NUNITS),
     +                     S_FUEL_DELIVERY_3(NUNITS),
     +                     CONSTANT_POLY,
     +                     FIRST_POLY,
     +                     SECOND_POLY,
     +                     THIRD_POLY,
     +                     TEMP_USE_POLY_HEAT_RATES, ! USE_POLY_HEAT_RATES,
     +                     NEWGEN_UNIT_STATUS,
     +                     MONTHLY_MUST_RUN_VECTOR(NUNITS),
     +                     EMISSION_MARKET_LINK(NUNITS),
     +                     TEMP_WVPA_RATE_TRACKER, ! WVPA_RATE_TRACKER(NUNITS),
     +                     TEMP_ALLOW_DECOMMIT, ! ALLOW_DECOMMIT(NUNITS),
     +                     MIN_SPIN_CAP(NUNITS),
     +                     MAX_SPIN_CAP(NUNITS),
     +                     TEMP_WVPA_RES_TRACKER, ! WVPA_RES_TRACKER(NUNITS),
     +                     TEMP_WVPA_FUEL_TRACKER, !WVPA_FUEL_TRACKER(NUNITS),
     +                     TEMP_MONTE_OR_FREQ, ! MONTE_OR_FREQ(NUNITS),
     +                     TEMP_WVPA_MEM_TRACKER, ! WVPA_MEM_TRACKER(NUNITS),
     +                     MONTHLY_DECOMMIT_VECTOR(NUNITS),
     +                     TRANS_BUS_ID(NUNITS),
     +                     SOX_CONTROL_PERCENT(NUNITS),
     +                     SOX_CONTROL_DATE(NUNITS),
     +                     SOX_VOM(NUNITS),
     +                     SOX_FOM(NUNITS),
     +                     LATITUDE(NUNITS),
     +                     LONGITUDE(NUNITS),
     +                     MW_INSIDE_FENCE,
     +                     (INTER_BLOCKS(M,NUNITS),M=1,3),
     +                     FIRST_YEAR_DECOMM_AVAIALABLE(NUNITS),  ! 155
     +                     DECOMMISSIONING_BASE_YR_COST(NUNITS),
     +                     DECOM_CONTINUING_COST_ESCALATION(NUNITS),
     +                     ANNUAL_ENERGY_PLANNING_FACTOR(NUNITS),   ! 158
     +                     TEMP_AGGREGATE_THIS_UNIT, ! AGGREGATE_THIS_UNIT(NUNITS),             ! 159
     +                     NAME_PLATE_CAPACITY(NUNITS),
     +                     FUEL_BLENDING_IS(NUNITS),   ! NO, FIXED BLEND, MODEL DETERMINED IF ONLY ONE FUEL ELSE USER OPTION
     +                     FuelRatio(1,Nunits),
     +                     FuelRatio(2,Nunits),
     +                     FuelRatio(3,Nunits),         ! 164
     +                     FuelRatio(4,Nunits),
     +                     FuelRatio(5,Nunits),         ! 166
     +                     BlendableFuelsPtr(1,Nunits), ! 167
     +                     BlendableFuelsPtr(2,Nunits), ! 168
     +                     BlendableFuelsPtr(3,Nunits),
     +                     BlendableFuelsPtr(4,Nunits),
     +                     FuelTransportationCost(1,Nunits),
     +                     FuelTransportationCost(2,Nunits),  ! 172
     +                     FuelTransportationCost(3,Nunits),
     +                     FuelTransportationCost(4,Nunits),
     +                     BlendedEnthalpyUp(Nunits),
     +                     BlendedEnthalpyLo(Nunits),
     +                     BlendedSO2Up(Nunits),                  ! 177
     +                     BettermentProjectID(Nunits),
     +                     DECOM_CONTINUING_COST(Nunits),
     +                     DECOM_CONTINUING_COST_ESCALATION(Nunits),
     +                     EnrgPatternPointer(Nunits), ! 181
     +                     TEMP_EMISSION_DATA_UNITS, ! EMISSION_DATA_UNITS(Nunits),
     +                     EmissRedRate(1,Nunits),
     +                     EmissRedRate(2,Nunits),
     +                     EmissRedRate(3,Nunits),
     +                     EmissRedRate(4,Nunits),              ! 186
     +                     EmissRedRate(5,Nunits),
     +                     EmissMaxRate(1,Nunits),
     +                     EmissMaxRate(2,Nunits),
     +                     EmissMaxRate(3,Nunits),
     +                     EmissMaxRate(4,Nunits),
     +                     EmissMaxRate(5,Nunits),
     +                     MaxEnergyLimit(1,Nunits),
     +                     MaxEnergyLimit(2,Nunits),
     +                     MaxEnergyLimit(3,Nunits),
     +                     TECH_TYPE(Nunits),
     +                     TEMP_LINKED_BETTERMENT_OPTION, ! LINKED_BETTERMENT_OPTION(Nunits),
     +                     CO2_CONTROL_PERCENT(NUNITS),
     +                     HG_CONTROL_PERCENT(NUNITS),
     +                     OTHER3_CONTROL_PERCENT(NUNITS),
     +                     CO2_CONTROL_DATE(NUNITS),
     +                     HG_CONTROL_DATE(NUNITS),
     +                     OTHER3_CONTROL_DATE(NUNITS),
     +                     CO2_VOM(NUNITS),
     +                     CO2_FOM(NUNITS),
     +                     HG_VOM(NUNITS),
     +                     HG_FOM(NUNITS),
     +                     OTHER3_VOM(NUNITS),
     +                     OTHER3_FOM(NUNITS),
     +                     MARKET_FLOOR(NUNITS),
     +                     MARKET_CEILING(NUNITS),
     +                     START_UP_COSTS_ESCALATION(NUNITS),  ! 212
     +                     CAPACITY_MARKET_TYPE(NUNITS),
     +                     CAPACITY_MARKET_MONTH(NUNITS),
     +                     CAPACITY_MARKET_POINTER(NUNITS),
     +                     CAPACITY_MARKET_COST_ASSIGN(NUNITS),
     +                     CAPACITY_MARKET_EXP_COLLECT(NUNITS),
     +                     CAPACITY_MARKET_COIN_ADJ_FACT(NUNITS),
     +                     TEMP_PRIMARY_FUEL_CATEGORY,
     +                     TEMP_SECONDARY_FUEL_CATEGORY,
     +                     TEMP_EMISSIONS_FUEL_CATEGORY,
     +                     RPS_CONTRIBUTION_PERCENT(NUNITS),
     +                     TEMP_RETIREMENT_CANDIDATE,
     +                     TEMP_RETROFIT_CANDIDATE,
     +                     RETROFIT_PROJECT_ID(NUNITS),
     +                     CO2_BASIN_NAME,
     +                     CO2_PIPELINE_DISTANCE(NUNITS),
     +                     STATE_PROV_NAME, ! 228
     +                     CO2_RETRO_HEAT_MULT(NUNITS),
     +                     CO2_RETRO_CAP_MULT(NUNITS),
     +                     THERMAL_GUID,
     +                     THERMAL_PARENT_ID, ! 232
     +                     THERMAL_AGGREGATED_UNIT,
     +                     FIRST_RETIREMENT_YEAR(NUNITS),
     +                     UNIT_TYPE,
     +                     UNIT_TYPE_CATEGORY,
     +                     RPS_PROGRAM_NUMBER(NUNITS)
!
! added 3/31/11 for coal model
!
            IF(INDEX(TEMP_PRIMARY_FUEL_CATEGORY,"Coal")/=0)THEN
               EXPANSION_UNIT_LOCATION(NUNITS) = POINTER
            ENDIF
!
! 10/03/02. FOR REGIONAL CONSOLIDATION. NOTE REASSIGNMENT.
!
            TRANSACTION_GROUP_ID(NUNITS) =
     +                GET_BELONGS_TO_GROUP(TRANSACTION_GROUP_ID(NUNITS))
!
!
            TRANS_ID = TRANSACTION_GROUP_ID(NUNITS)
            IF(DELETE > 7 .OR. TEMP_UNIT_ACTIVE(1:1) == 'F') THEN
! ADDED 10/13/99.
               NUNITS = NUNITS - 1
!
               RETURN
            ENDIF
            FIRST_RETIREMENT_YEAR(NUNITS) =
     +                    100*(FIRST_RETIREMENT_YEAR(NUNITS) - 1900)
            CAP_MARKET_MONTH_NO(NUNITS) =
     +          CAP_MARKET_MONTH_NO_INDEX(CAPACITY_MARKET_MONTH(NUNITS))
! CONVERT TO PERCENT
! 112204 MODIFIED
!
            IF(INPUT_MW(2,NUNITS) > 1. .AND. MW_INSIDE_FENCE > .1) THEN
               PERCENT_INSIDE_FENCE = MIN(1.,
     +                               MW_INSIDE_FENCE/INPUT_MW(2,NUNITS))
            ELSE
               PERCENT_INSIDE_FENCE = 0.
            ENDIF
!
            IF(RUN_TRANSACT .AND.
     +                  (.NOT.  TRANS_GROUP_ACTIVE_SWITCH(TRANS_ID) .OR.
     +                   .NOT. IN_ACTIVE_THERMAL_MARKET_AREA(
     +                         BASECASE_MARKET_AREA_ID(NUNITS))) .OR.
     +                                       PERCENT_INSIDE_FENCE > .995
     +                                                            ) THEN
               WRITE(4,*) UNITNM(NUNITS)," was not added to expansion"
               WRITE(4,*) "because it did not have a valid Transaction"
               WRITE(4,*) "Group ID = ",TRANSACTION_GROUP_ID(NUNITS)
! ADDED 10/13/99.
               NUNITS = NUNITS - 1
!
               RETURN
            ENDIF
! 100504
            IF(PERCENT_INSIDE_FENCE > .005) THEN
               CAP_FRAC_OWN(NUNITS) = CAP_FRAC_OWN(NUNITS) *
     +                                         (1.-PERCENT_INSIDE_FENCE)
            ENDIF
C            IF(TEMP_UNIT_ACTIVE(1:1) == 'F') THEN
C               WRITE(4,*) "In the Expansion Plant Operations file"
C               WRITE(4,*) "the unit type ",UNITNM(NUNITS)," has Unit"
C               WRITE(4,*) "Active switch set to false. Unit was"
C               WRITE(4,*) "added to the simulation."
C            ENDIF
!
! 10/21/03. PER BURESH.
!
            IF(EMISSION_MARKET_LINK(NUNITS) == -9999) THEN
               EMISSION_MARKET_LINK(NUNITS) = R_ASSET_CLASS
            ENDIF
!
            POINTER_FOR_NEW_CL_UNIT(NUNITS) = R_POINTER
C
C ADDED SO THAT SP COMPATIBLE CL FILE OUTPUT
C
            EXPENSE_ASSIGNMENT(NUNITS) = TEMP_EXPENSE_ASSIGNMENT(1:1)
            EXPENSE_COLLECTION(NUNITS) = TEMP_EXPENSE_COLLECTION(1:1)
            SEC_FUEL_TYPE(NUNITS) = TEMP_SEC_FUEL_TYPE(1:1)
            EMISS_FUEL_TYPE(NUNITS) = TEMP_EMISS_FUEL_TYPE(1:1)
            INTRA_COMPANY_TRANSACTION(NUNITS) =
     +                               TEMP_INTRA_COMPANY_TRANSACTION(1:1)
            START_UP_LOGIC(NUNITS) = TEMP_START_UP_LOGIC(1:1)
            REPORT_THIS_UNIT(NUNITS) = TEMP_REPORT_THIS_UNIT(1:1)
            CONTRIBUTES_TO_SPIN(NUNITS) = TEMP_CONTRIBUTES_TO_SPIN(1:1)
            APPLY_NOX_SEASON_DATE(NUNITS) =
     +                                   TEMP_APPLY_NOX_SEASON_DATE(1:1)
            MARKET_RESOURCE(NUNITS) = TEMP_MARKET_RESOURCE(1:1)
            USE_POLY_HEAT_RATES = TEMP_USE_POLY_HEAT_RATES(1:1)
            WVPA_RATE_TRACKER(NUNITS) = TEMP_WVPA_RATE_TRACKER(1:1)
            ALLOW_DECOMMIT(NUNITS) = TEMP_ALLOW_DECOMMIT(1:1)
            WVPA_RES_TRACKER(NUNITS) = TEMP_WVPA_RES_TRACKER(1:1)
            WVPA_FUEL_TRACKER(NUNITS) = TEMP_WVPA_FUEL_TRACKER(1:1)
            MONTE_OR_FREQ(NUNITS) = TEMP_MONTE_OR_FREQ(1:1)
            WVPA_MEM_TRACKER(NUNITS) = TEMP_WVPA_MEM_TRACKER(1:1)
            AGGREGATE_THIS_UNIT(NUNITS) = TEMP_AGGREGATE_THIS_UNIT(1:1)
            EMISSION_DATA_UNITS(NUNITS) = TEMP_EMISSION_DATA_UNITS(1:1)
            LINKED_BETTERMENT_OPTION(NUNITS) =
     +                                TEMP_LINKED_BETTERMENT_OPTION(1:1)
            PRIMARY_FUEL_CATEGORY(NUNITS) =
     +                                   TEMP_PRIMARY_FUEL_CATEGORY(1:1)
            SECONDARY_FUEL_CATEGORY(NUNITS) =
     +                                 TEMP_SECONDARY_FUEL_CATEGORY(1:1)
            EMISSIONS_FUEL_CATEGORY(NUNITS) =
     +                                 TEMP_EMISSIONS_FUEL_CATEGORY(1:1)
            RETIREMENT_CANDIDATE(NUNITS) =
     +                                    TEMP_RETIREMENT_CANDIDATE(1:1)
!            FIRST_RETIREMENT_YEAR(NUNITS) =
!     +                                     FIRST_RETIREMENT_YEAR(NUNITS)
            RETROFIT_CANDIDATE(NUNITS) =
     +                                    TEMP_RETROFIT_CANDIDATE(1:1)
!
! MOVED UP 9/20/01. GAT.
!
            R_ON_LINE_MONTH = ON_LINE_MONTH_TEMP
            ON_LINE_MONTH = ABS(ON_LINE_MONTH_TEMP)
            WRITE(YEAR_CHR,'(I4)') UNIT_ON_LINE_YEAR
            IF(NUNITS < 10) THEN
               WRITE(NUNITS_CHR,'(I1)') NUNITS
            ELSEIF(NUNITS < 100) THEN
               WRITE(NUNITS_CHR,'(I2)') NUNITS
            ELSEIF(NUNITS < 1000) THEN
               WRITE(NUNITS_CHR,'(I3)') NUNITS
            ELSEIF(NUNITS < 1000) THEN
               WRITE(NUNITS_CHR,'(I4)') NUNITS
            ELSE
               WRITE(NUNITS_CHR,'(I5)') NUNITS
            ENDIF
! 020410. CAUSING BOMB AFTER 12000 UNITS.
            MARKETSYM_UNIT = MIN(14000,MAX_CL_UNITS,NUNITS)
            MARKETSYM_UNIT_NAME(MARKETSYM_UNIT) = UNITNM(NUNITS)
!            MARKETSYM_UNIT_NAME(NUNITS) = UNITNM(MARKETSYM_UNIT)
            UNITNM(NUNITS) = YEAR_CHR(3:)//'/'//trim(NUNITS_CHR)//
     +                                       ' '//trim(UNITNM(NUNITS))
!
! CREATE RESULT CL FILES TO USE AS INPUT 12/06/06 DR.G
            TG = GET_TRANS_GROUP_POSITION(TRANSACTION_GROUP_ID(NUNITS))
!            WRITE(9,*) "SAVE_S ",SAVE_SCENARIO_MRX_PLANS
!            WRITE(9,*) "SAVE_TG ",SAVE_MRX_EXPANSION_PLAN(TG)
            IF(((CAPACITY_PLANNING_METHOD() == 'MX' .AND.
     +                         .NOT. GREEN_MRX_METHOD() == 'GX') .OR.
     +          (CAPACITY_PLANNING_METHOD() == 'MX' .AND.
     +             GREEN_MRX_METHOD() == 'GX' .AND. GRX_ITERATIONS > 0))
     +         .AND.   (SAVE_SCENARIO_MRX_PLANS == 'A' .OR.
     +               (SAVE_SCENARIO_MRX_PLANS == 'G' .AND.
     +                       SAVE_MRX_EXPANSION_PLAN(TG)=='T'))) THEN
               IF(END_POINT > END_POINT_CHECK .AND. .FALSE. .AND.
     +                                .NOT. MRX_TEXT_FILE_OPEN) THEN
                  CPO_REC = RPTREC(9979_2)
                  WRITE(9979,'(A1)',REC=CPO_REC) ENDFILE_MARK
                  CLOSE(9979,IOSTAT=IOS)
                  END_POINT_CHECK = END_POINT
                  MRX_TEXT_FILE_OPEN = .TRUE.
               ENDIF
               INQUIRE(UNIT=9979,OPENED=MRX_TEXT_FILE_OPEN)
               IF(.NOT. MRX_TEXT_FILE_OPEN) THEN
                  SEQU_NO = MRX_SEQUENCE_NUMBER + END_POINT - 1
                  FILE_NAME = TRIM(OUTPUT_DIRECTORY())//
     +                          MRX_EXPANSION_PLAN_FILE_CODE//"O"//
     +                          MRX_EXPANSION_PLAN_FILE_NAME//
     +                          TRIM(CONVERT_2_STR(SEQU_NO,3))//'.DAT'
                  OPEN(9979,FILE=FILE_NAME,ACCESS='DIRECT',
     +                     FORM='FORMATTED',RECL=2048, STATUS='REPLACE')
                  WRITE(9979,"(A,I4,',')",REC=1)"9,    ,",YEAR+BASE_YEAR
                  CPO_REC = 2
                  YEAR_CHECK = YEAR
                  IREC_SAVED = RPTREC(9979_2,SAVE_REC=CPO_REC,
     +                            REC_LENGHT=2048_2,FILE_NAME=FILE_NAME)
                  END_POINT_CHECK = END_POINT
                  MRX_TEXT_FILE_OPEN = .FALSE.
                  RESET_REC = 2
               ELSEIF(RPTREC(9979_2,CURRENT_REC=.TRUE.)==2) THEN
                  WRITE(9979,"(A,I4,',')",REC=1)"9,    ,",YEAR+BASE_YEAR
                  YEAR_CHECK = YEAR
               ELSEIF(YEAR > YEAR_CHECK .OR.
     +                RPTREC(9979_2,CURRENT_REC=.TRUE.)==RESET_REC) THEN
                  RESET_REC = RPTREC(9979_2)
                  WRITE(9979,"(A,I4,',')",REC=RESET_REC)
     +                                    CRLF//"7,    ,",YEAR+BASE_YEAR
!                  IREC_SAVED = RPTREC(9979_2,SAVE_REC=RESET_REC)
!                  CPO_REC = CPO_REC + 1
                  YEAR_CHECK = YEAR
               ENDIF
               RECLN = '1,'//TRIM(CONVERT_2_STR(UNITNM(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(CL_LOAD_TYPE))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TEMP_EXPENSE_ASSIGNMENT))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TEMP_EXPENSE_COLLECTION))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(GENGRP(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(CAP_FRAC_OWN(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(ON_LINE_MONTH_TEMP))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(UNIT_ON_LINE_YEAR))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(OFF_LINE_MONTH(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(UNIT_ON_LINE_YEAR
     +                                               + OPERATION_LIFE)) ! 10
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(FUEL_MIX_PTR(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(PBTUCT(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(PFESCR(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(SBTUCT(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(SFESCR(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(FUELADJ(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(EFOR(NUNITS)))
               DO M = 1, 12
                  RECLN = TRIM(RECLN)//','//
     +                             TRIM(CONVERT_2_STR(MNRATE(NUNITS,M)))
               ENDDO
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(VCPMWH_IN(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(OMESCR(NUNITS)))               ! 31
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(FIXED_COST_IN(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(FIXED_COST_ESCALATOR(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(DISPADJ(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(HR_FACTOR(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(INPUT_MW(1,NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(INPUT_MW(2,NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(CAP_PLANNING_FAC(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(COEFF(1,NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(COEFF(2,NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(COEFF(3,NUNITS)))
               RECLN = TRIM(RECLN)//','//','//   ! 42 extra comment is for the comment space
     +            TRIM(CONVERT_2_STR(P_SO2(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(P_NOX(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(P_PARTICULATES(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(LOCAL_CL_POOL_FRAC_OWN(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(P_EMIS_OTH2(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(P_EMIS_OTH3(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            "False"  !  PHASE_I_STR))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(DISPADJ2(NUNITS)))  ! 50
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(CL_RESOURCE_ID(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(FUEL_SUPPLY_ID(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(P_NOX_BK2(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(SEC_FUEL_EMISS_PTR(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(EMISS_FUEL_COST(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(EMISS_FUEL_ESCAL(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(EMISS_FUEL_EMISS_PTR(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(EMISS_BLENDING_RATE(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(PRIM_FUEL_EMISS_PTR(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(TEMP_PRIM_FUEL_TYPE_STR)           ! 60
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TEMP_SEC_FUEL_TYPE))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TEMP_EMISS_FUEL_TYPE))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TIE_CONSTRAINT_GROUP(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(MONTHLY_CAPACITY_POINTER(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(CL_AI_CAPACITY_RATE(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(CL_AI_CAPACITY_ESCALATOR(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(CL_AI_ENERGY_RATE(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(CL_AI_ENERGY_ESCALATOR(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(AI_CL_REMAINING_LIFE(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(ANNUAL_CL_FIXED_COST(NUNITS))) ! 70
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(ANNUAL_CL_FIXED_COST_ESC(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(MAINT_DAYS(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(DISPATCH_MULT(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(EXCESS_ENERGY_SALES(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(AI_CL_TAX_LIFE(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(AI_CL_ADR_LIFE(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(ASSET_CLASS_NUM(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(ASSET_CLASS_VECTOR(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(INTRA_COMPANY_CLASS_ID(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TEMP_INTRA_COMPANY_TRANSACTION)) ! 80
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(SPECIAL_UNIT_ID(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(MINIMUM_CAPACITY_FACTOR(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(MAXIMUM_CAPACITY_FACTOR(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TRANSACTION_GROUP_ID(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(DAY_TYPE_ID(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TEMP_UNIT_ACTIVE))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(BASECASE_PLANT_ID(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(BASECASE_UNIT_ID))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(BASECASE_MARKET_AREA_ID(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(BASECASE_TRANS_AREA_ID))  ! 90
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(BASECASE_PLANT_NERC_SUB_ID))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(BASECASE_PLANT_OWNER_ID))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TEMP_UTILITY_OWNED))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(MONTHLY_FUEL_INDEX(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(START_UP_COSTS(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TEMP_START_UP_LOGIC))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(RAMP_RATE(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(MIN_DOWN_TIME(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TEMP_REPORT_THIS_UNIT))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(P_FUEL_DELIVERY_1(NUNITS)))   ! 100
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(P_FUEL_DELIVERY_2(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(P_FUEL_DELIVERY_3(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(MIN_UP_TIME(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(HESI_UNIT_ID_NUM(NUNITS))) ! PLACEHOLDER
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(FOR_FREQUENCY(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(FOR_DURATION(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(WINTER_TOTAL_CAPACITY))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TEMP_CONTRIBUTES_TO_SPIN))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(H2_UNIT_ID_NUM(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(POWERDAT_PLANT_ID(NUNITS)))  ! 110
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TEMP_APPLY_NOX_SEASON_DATE))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(NOX_SEASON_DATE(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(RAMP_DOWN_RATE(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(NOX_CONTROL_PERCENT(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(NOX_CONTROL_DATE(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(EMERGENCY_CAPACITY(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(EMERGENCY_HEATRATE(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TEMP_MARKET_RESOURCE))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(PRIMARY_MOVER_STR(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(COUNTY))                     ! 120
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(STATE_PROVINCE))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(NOX_VOM(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(NOX_FOM(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(S_FUEL_DELIVERY(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(S_FUEL_DELIVERY_2(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(S_FUEL_DELIVERY_3(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(CONSTANT_POLY))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(FIRST_POLY))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(SECOND_POLY))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(THIRD_POLY))               ! 130
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TEMP_USE_POLY_HEAT_RATES))
               RECLN = TRIM(RECLN)//','//
     +            "07-Forecasted"  ! NEWGEN_UNIT_STATUS,
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(MONTHLY_MUST_RUN_VECTOR(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(EMISSION_MARKET_LINK(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TEMP_WVPA_RATE_TRACKER))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TEMP_ALLOW_DECOMMIT))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(MIN_SPIN_CAP(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(MAX_SPIN_CAP(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TEMP_WVPA_RES_TRACKER))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TEMP_WVPA_FUEL_TRACKER))   ! 140
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TEMP_MONTE_OR_FREQ))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TEMP_WVPA_MEM_TRACKER))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(MONTHLY_DECOMMIT_VECTOR(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TRANS_BUS_ID(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(SOX_CONTROL_PERCENT(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(SOX_CONTROL_DATE(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(SOX_VOM(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(SOX_FOM(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(LATITUDE(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(LONGITUDE(NUNITS)))        ! 150
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(MW_INSIDE_FENCE))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(INTER_BLOCKS(1,NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(INTER_BLOCKS(2,NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(INTER_BLOCKS(3,NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                           FIRST_YEAR_DECOMM_AVAIALABLE(NUNITS)))  ! 155
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                           DECOMMISSIONING_BASE_YR_COST(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                       DECOM_CONTINUING_COST_ESCALATION(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                          ANNUAL_ENERGY_PLANNING_FACTOR(NUNITS)))   ! 158
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TEMP_AGGREGATE_THIS_UNIT))             ! 159
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(NAME_PLATE_CAPACITY(NUNITS)))    ! 160
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(FUEL_BLENDING_IS(NUNITS)))   ! NO)) FIXED BLEND)) MODEL DETERMINED IF ONLY ONE FUEL ELSE USER OPTION
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(FuelRatio(1,Nunits)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(FuelRatio(2,Nunits)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(FuelRatio(3,Nunits)))         ! 164
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(FuelRatio(4,Nunits)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(FuelRatio(5,Nunits)))         ! 166
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(BlendableFuelsPtr(1,Nunits))) ! 167
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(BlendableFuelsPtr(2,Nunits))) ! 168
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(BlendableFuelsPtr(3,Nunits)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(BlendableFuelsPtr(4,Nunits)))  ! 170
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                               FuelTransportationCost(1,Nunits)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                               FuelTransportationCost(2,Nunits)))  ! 172
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                               FuelTransportationCost(3,Nunits)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                               FuelTransportationCost(4,Nunits)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(BlendedEnthalpyUp(Nunits)))      ! 175
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(BlendedEnthalpyLo(Nunits)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(BlendedSO2Up(Nunits)))                  ! 177
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(BettermentProjectID(Nunits)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(DECOM_CONTINUING_COST(Nunits)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                       DECOM_CONTINUING_COST_ESCALATION(Nunits)))   ! 180
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(EnrgPatternPointer(Nunits))) ! 181
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TEMP_EMISSION_DATA_UNITS))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(EmissRedRate(1,Nunits)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(EmissRedRate(2,Nunits)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(EmissRedRate(3,Nunits)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(EmissRedRate(4,Nunits)))              ! 186
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(EmissRedRate(5,Nunits)))    ! 187
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(EmissMaxRate(1,Nunits)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(EmissMaxRate(2,Nunits)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(EmissMaxRate(3,Nunits)))    ! 190
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(EmissMaxRate(4,Nunits)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(EmissMaxRate(5,Nunits)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(MaxEnergyLimit(1,Nunits)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(MaxEnergyLimit(2,Nunits)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(MaxEnergyLimit(3,Nunits)))  ! 195
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TECH_TYPE(Nunits)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(TEMP_LINKED_BETTERMENT_OPTION))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(CO2_CONTROL_PERCENT(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(HG_CONTROL_PERCENT(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(OTHER3_CONTROL_PERCENT(NUNITS))) ! 200
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(CO2_CONTROL_DATE(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(HG_CONTROL_DATE(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(OTHER3_CONTROL_DATE(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(CO2_VOM(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(CO2_FOM(NUNITS)))   ! 205
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(HG_VOM(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(HG_FOM(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(OTHER3_VOM(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(OTHER3_FOM(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(MARKET_FLOOR(NUNITS)))  ! 210
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(MARKET_CEILING(NUNITS)))  ! 211
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(START_UP_COSTS_ESCALATION(NUNITS)))  ! 212
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(CAPACITY_MARKET_TYPE(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(CAPACITY_MARKET_MONTH(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(CAPACITY_MARKET_POINTER(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                             CAPACITY_MARKET_COST_ASSIGN(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                             CAPACITY_MARKET_EXP_COLLECT(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                           CAPACITY_MARKET_COIN_ADJ_FACT(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                           TEMP_PRIMARY_FUEL_CATEGORY))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                           TEMP_SECONDARY_FUEL_CATEGORY))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                           TEMP_EMISSIONS_FUEL_CATEGORY))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                           RPS_CONTRIBUTION_PERCENT(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                           TEMP_RETIREMENT_CANDIDATE))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                           TEMP_RETROFIT_CANDIDATE))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                     RETROFIT_PROJECT_ID(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                     CO2_BASIN_NAME))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                     CO2_PIPELINE_DISTANCE(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                     STATE_PROV_NAME))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                     CO2_RETRO_HEAT_MULT(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                     CO2_RETRO_CAP_MULT(NUNITS)))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                     THERMAL_GUID))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                     THERMAL_PARENT_ID))
               RECLN = TRIM(RECLN)//','//
     +            TRIM(CONVERT_2_STR(
     +                     THERMAL_AGGREGATED_UNIT))
               RECLN = CRLF//TRIM(RECLN)//',,,,,,,,,,,,,,,,,,,,,'
               CPO_REC = RPTREC(9979_2)
               WRITE(9979,'(A)',REC=CPO_REC) TRIM(RECLN)
            ENDIF
! 01/15/03.
!
! 11/17/04. BROUGHT FROM EXISTING UNITS
!
!
            IF(LOCAL_MW(1) > 0. .AND. LOCAL_MW(2) > 0.) THEN
               IF(USE_POLY_HEAT_RATES == 'T' .AND.
     +                                         .NOT. TURN_OFF_POLY) THEN
!
! TOM TO ASSOCIATE VARIABLES HERE (AND IN NEW_CL_UNITS_READ).
!
!
                  COEFF(1,NUNITS) = 1000. *
     +               (CONSTANT_POLY +
     +                FIRST_POLY * LOCAL_MW(1) +
     +                SECOND_POLY *
     +                           LOCAL_MW(1)*LOCAL_MW(1) +
     +                THIRD_POLY *
     +                     LOCAL_MW(1)*LOCAL_MW(1)*
     +                                              LOCAL_MW(1))/
     +                                                LOCAL_MW(1)
                  COEFF(2,NUNITS) = 1000. *
     +                (FIRST_POLY +
     +                2. * SECOND_POLY * LOCAL_MW(1) +
     +                3. * THIRD_POLY *
     +                            LOCAL_MW(1)*LOCAL_MW(1))
                  COEFF(3,NUNITS) = 1000. *
     +                (FIRST_POLY +
     +                2. * SECOND_POLY * LOCAL_MW(2) +
     +                3. * THIRD_POLY *
     +                            LOCAL_MW(2)*LOCAL_MW(2))
!
               ELSE
!                  ASSUMES ORIGINAL COEFF'S EXIST
               ENDIF
!
!
! 1/17/03.
! A+BX+CX^2
!
               IF(LOCAL_MW(2) > LOCAL_MW(1)) THEN
!
                  CUBIC_HEAT_CURVE(1,NUNITS) =
     +                     (COEFF(2,NUNITS)-COEFF(3,NUNITS))/
     +                     (-2.*(LOCAL_MW(2)-LOCAL_MW(1)))
                  CUBIC_HEAT_CURVE(2,NUNITS) =
     +                  COEFF(2,NUNITS) -
     +                             (COEFF(2,NUNITS) - COEFF(3,NUNITS)) *
     +                        LOCAL_MW(1)/
     +                     (-1.*(LOCAL_MW(2)-LOCAL_MW(1)))
                  CUBIC_HEAT_CURVE(3,NUNITS) =
     +                ((COEFF(1,NUNITS)-CUBIC_HEAT_CURVE(2,NUNITS))*
     +                               LOCAL_MW(1)) -
     +                        CUBIC_HEAT_CURVE(1,NUNITS)*
     +                             LOCAL_MW(1)*LOCAL_MW(1)
               ELSE
               ENDIF
            ELSE ! NEED TO CHECK THIS WITH TOM.
               CUBIC_HEAT_CURVE(2,NUNITS) = COEFF(1,NUNITS)
            ENDIF
! 07/09/03.
            CUBIC_HEAT_CURVE(0,NUNITS) = CONSTANT_POLY
            CUBIC_HEAT_CURVE(2,NUNITS) = SECOND_POLY
            CUBIC_HEAT_CURVE(3,NUNITS) = THIRD_POLY
            IF(CONSTANT_POLY <= 0. .AND. FIRST_POLY <= 0. .AND.
     +                                           SECOND_POLY <= 0.) THEN
               IF(COEFF(1,NUNITS) > 0.) THEN
                  CUBIC_HEAT_CURVE(1,NUNITS) = COEFF(1,NUNITS)*.001
               ELSE
                  CUBIC_HEAT_CURVE(1,NUNITS) = 10.
               ENDIF
            ELSE
               CUBIC_HEAT_CURVE(1,NUNITS) = FIRST_POLY
            ENDIF
!
! 02/03/06.
!
!
            TEMP_STATE = STATE_PROVINCE(1:2)
            TEMP_I2 = STATE_ID_LOOKUP(TEMP_STATE)
            State_Index(NUNITS) = TEMP_I2
            TEMP_I2 = STATE_ID_LOOKUP(STATE_PROVINCE)
            State_TG_Index(NUNITS) = TEMP_I2
            IF( TEMP_I2 > 0 .AND.
     +                          STATE_PROVINCE_INDEX(TEMP_I2) == 0) THEN
               MAX_STATE_PROVINCE_NO = MAX_STATE_PROVINCE_NO + 1
               STATE_PROVINCE_ADDRESS(MAX_STATE_PROVINCE_NO) = TEMP_I2
               STATE_PROVINCE_INDEX(TEMP_I2) = MAX_STATE_PROVINCE_NO
               STATE_PROVINCE_NAMES(MAX_STATE_PROVINCE_NO) =
     +                                                    STATE_PROVINCE
            ENDIF
            UNIT_STATE_PROVINCE_INDEX(NUNITS) =
     +                                     STATE_PROVINCE_INDEX(TEMP_I2)
! 091309. COMPLETE REWRITE.
            TEMP_I2 = STATE_2_GAS_REGION_LOOKUP(STATE_PROVINCE)
            IF(YES_GSP_IS_ST_TG(TEMP_I2)) THEN
               TEMP_STATE = STATE_PROVINCE
            ELSE
               TEMP_STATE = STATE_PROVINCE(1:2)
            ENDIF
            UNIT_GAS_REGION_INDEX(NUNITS) =
     +                             STATE_2_GAS_REGION_LOOKUP(TEMP_STATE)
! 120606.
!            IF(YES_REGION_POWER_MAP) THEN
!               TEMP_STATE = STATE_PROVINCE(1:2)
!               UNIT_GAS_REGION_INDEX(NUNITS) =
!     +                             STATE_2_GAS_REGION_LOOKUP(TEMP_STATE)
!            ELSE
!               UNIT_GAS_REGION_INDEX(NUNITS) = TEMP_I2
!            ENDIF
!            UNIT_GAS_REGION_INDEX(NUNITS) =
!     +                         STATE_2_GAS_REGION_LOOKUP(STATE_PROVINCE)
C
! MOVED UP 8/16/01. GAT.
!
            ON_LINE_YEAR = UNIT_ON_LINE_YEAR
            OFF_LINE_YEAR(NUNITS) = UNIT_ON_LINE_YEAR + OPERATION_LIFE
C
            ONLINE(NUNITS) = 100*(ON_LINE_YEAR-1900) + ON_LINE_MONTH
            OFLINE(NUNITS) = 100*(OFF_LINE_YEAR(NUNITS)-1900) +
     +                                            OFF_LINE_MONTH(NUNITS)
            IF(MAINT_DAYS(NUNITS) /= 0.)
     +                                SAVE_DETAILED_MAINTENANCE = .TRUE.
            ASSET_CLASS_NUM(NUNITS) = R_ASSET_CLASS
            ASSET_CLASS_VECTOR(NUNITS) = R_ALLOCATION_VECTOR
!
! 11/18/04.  THIS CAN CAUSE A PROBLEM IF NOT DEFINED. FOUND IN EV DATA.
!
            CL_RESOURCE_ID(NUNITS) = R_CL_RESOURCE_ID ! 3/13/98. GAT.
!
! 11/12/01.
            NOX_SEASON_DATE(NUNITS) = NOX_SEASON_DATE(NUNITS) + 10000
! 5/23/02.
            NOX_CONTROL_PERCENT(NUNITS) =
     +             MIN(100.,MAX(0.,1.-NOX_CONTROL_PERCENT(NUNITS)/100.))
            NOX_CONTROL_DATE(NUNITS) = NOX_CONTROL_DATE(NUNITS) + 10000
!
            SOX_CONTROL_PERCENT(NUNITS) =
     +             MIN(100.,MAX(0.,1.-SOX_CONTROL_PERCENT(NUNITS)/100.))
            SOX_CONTROL_DATE(NUNITS) = SOX_CONTROL_DATE(NUNITS) + 10000
            CO2_CONTROL_PERCENT(NUNITS) =
     +             MIN(100.,MAX(0.,1.-CO2_CONTROL_PERCENT(NUNITS)/100.))
            CO2_CONTROL_DATE(NUNITS) = CO2_CONTROL_DATE(NUNITS) + 10000
            HG_CONTROL_PERCENT(NUNITS) =
     +             MIN(100.,MAX(0.,1.-HG_CONTROL_PERCENT(NUNITS)/100.))
            HG_CONTROL_DATE(NUNITS) = HG_CONTROL_DATE(NUNITS) + 10000
            OTHER3_CONTROL_PERCENT(NUNITS) =
     +             MIN(100.,
     +                   MAX(0.,1.-OTHER3_CONTROL_PERCENT(NUNITS)/100.))
            OTHER3_CONTROL_DATE(NUNITS) =
     +                               OTHER3_CONTROL_DATE(NUNITS) + 10000
!
! 10/1/00. GAT. MOVED FROM MARGOBJ.FOR
!
            LOCAL_RESOURCE_ID = CL_RESOURCE_ID(NUNITS)
            IF(NUMBER_OF_RESOURCE_ID(LOCAL_RESOURCE_ID) == 0) THEN
               RESOURCE_ID_TO_UNIT(LOCAL_RESOURCE_ID) = NUNITS ! FIRST OCCURANCE
            ENDIF
            NUMBER_OF_RESOURCE_ID(LOCAL_RESOURCE_ID) =
     +                      NUMBER_OF_RESOURCE_ID(LOCAL_RESOURCE_ID) + 1
!
            IF(START_UP_LOGIC(NUNITS) /= 'F') THEN
               TOTAL_START_UP_UNITS = TOTAL_START_UP_UNITS + 1
               START_UP_INDEX(NUNITS) = TOTAL_START_UP_UNITS
            ENDIF
!
            CALL SET_ASSET_CLASSES(ASSET_CLASS_NUM(NUNITS),
     +                             NUMBER_OF_CAP_LIMITED_CLASSES,
     +	                          MAX_CAP_LIMITED_CLASS_ID_NUM,
     +                             CAP_LIMITED_CLASS_POINTER)
!
!
! 1/17/99. GAT.
!
            CALL UPC(TEMP_PRIM_FUEL_TYPE_STR,PRIM_FUEL_TYPE_STR)
            PRIMARY_MOVER(NUNITS) =
     +                        FUEL_TYPE_2_PRIM_MOVER(PRIM_FUEL_TYPE_STR)
!            IF(PRIM_FUEL_TYPE_STR == 'SUB   ' .OR.
!     +                     PRIM_FUEL_TYPE_STR == 'ANT   ' .OR.
!     +                     PRIM_FUEL_TYPE_STR == 'BIT   ' .OR.
!     +                     PRIM_FUEL_TYPE_STR == 'WC    ' .OR. ! ADDED FOR BURESH 02/11/02.
!     +                     PRIM_FUEL_TYPE_STR == 'COAL  ' .OR.
!     +                              PRIM_FUEL_TYPE_STR == 'LIG   ') THEN
!               PRIMARY_MOVER(NUNITS) = 1
!            ELSEIF(PRIM_FUEL_TYPE_STR == 'GAS   ' .OR.
!     +                  PRIM_FUEL_TYPE_STR == 'G     ' .OR.
!     +                              PRIM_FUEL_TYPE_STR == 'NG    ') THEN
!               PRIMARY_MOVER(NUNITS) = 2
!            ELSEIF(PRIM_FUEL_TYPE_STR(1:2) == 'FO' .OR.
!     +                             PRIM_FUEL_TYPE_STR == 'DFO    ') THEN
!               PRIMARY_MOVER(NUNITS) = 3
!            ELSEIF(PRIM_FUEL_TYPE_STR == 'UR    ' .OR.
!     +                  PRIM_FUEL_TYPE_STR == 'URA   ' .OR.
!     +                  PRIM_FUEL_TYPE_STR(1:3) == 'NUC') THEN
!               PRIMARY_MOVER(NUNITS) = 4
!            ELSEIF(PRIM_FUEL_TYPE_STR == 'WAT   ') THEN
!               PRIMARY_MOVER(NUNITS) = 5
!            ELSEIF(           PRIM_FUEL_TYPE_STR == 'SUN   ' .OR.
!     +                        PRIM_FUEL_TYPE_STR == 'SOLAR ') THEN
!               PRIMARY_MOVER(NUNITS) = 8
!            ELSEIF(           PRIM_FUEL_TYPE_STR == 'WND   ') THEN
!               PRIMARY_MOVER(NUNITS) = 9
!            ELSE
!               PRIMARY_MOVER(NUNITS) = 6
!            ENDIF
!
            TRANS_ID = TRANSACTION_GROUP_ID(NUNITS)
            IF(TRANS_ID > 0 .AND. ON_LINE_YEAR <= LAST_STUDY_YEAR) THEN
               DAY_ID = DAY_TYPE_ID(NUNITS)
               MAX_TRANS_ID_USED = MAX(MAX_TRANS_ID_USED, TRANS_ID)
               IF(DAY_ID > 0 .AND. DAY_ID <= MAX_DAY_TYPES ) THEN
                  IF(DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,TRANS_ID) == 0)
     +                                                              THEN
                     MAX_TRANS_DATA_BASES = MAX_TRANS_DATA_BASES + 1
                     DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,TRANS_ID) =
     +                                              MAX_TRANS_DATA_BASES
                  ENDIF
!
                  DATA_BASE_POSITION(1,NUNITS) =
     +                        DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,TRANS_ID)
                  DATA_BASE_POSITION(2,NUNITS) =
     +                        DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,0)
               ELSEIF(DAY_ID < 0) THEN
                  DAY_TYPE_COUNTER = 1
                  DO
                     DAY_ID = INT(GET_VAR(FLOAT(DAY_TYPE_ID(NUNITS)),
     +                                DAY_TYPE_COUNTER,"FIND DAY TYPE"))
                     IF(DAY_ID <= 0 .OR. DAY_ID > MAX_DAY_TYPES) EXIT
                     IF(DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,TRANS_ID) == 0)
     +                                                              THEN
                        MAX_TRANS_DATA_BASES = MAX_TRANS_DATA_BASES + 1
                        DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,TRANS_ID) =
     +                                              MAX_TRANS_DATA_BASES
                     ENDIF
      !
                     DATA_BASE_POSITION(2*DAY_TYPE_COUNTER-1,NUNITS) =
     +                        DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,TRANS_ID)
                     DATA_BASE_POSITION(2*DAY_TYPE_COUNTER,NUNITS) =
     +                               DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,0)
                     DAY_TYPE_COUNTER = DAY_TYPE_COUNTER + 1
                  ENDDO
               ELSEIF(DAY_ID == 0) THEN
                  DO M = 1, MAX_DAY_TYPES
                     IF(DAY_TYPE_TRANS_GROUP_PAIR(M,TRANS_ID) == 0) THEN
                        MAX_TRANS_DATA_BASES = MAX_TRANS_DATA_BASES + 1
                        DAY_TYPE_TRANS_GROUP_PAIR(M,TRANS_ID) =
     +                                              MAX_TRANS_DATA_BASES
                     ENDIF
                     DATA_BASE_POSITION(2*M-1,NUNITS) =
     +                             DAY_TYPE_TRANS_GROUP_PAIR(M,TRANS_ID)
                     DATA_BASE_POSITION(2*M,NUNITS) =
     +                                    DAY_TYPE_TRANS_GROUP_PAIR(M,0)
                  ENDDO
               ELSE
                  WRITE(4,*) "DAY TYPE DESIGNATION",DAY_ID
                  WRITE(4,*) "OUTSIDE THE RANGE OF POSSIBLE OUTCOMES"
                  WRITE(4,*) "MAXIMUM DAY TYPES DEFINED = ",
     +                                                     MAX_DAY_TYPES
                  WRITE(4,*) '*** line 3020 CLA_OBJT.FOR ***'
                  er_message='See WARNING MESSAGES'
                  call end_program(er_message)
               ENDIF
            ENDIF
!
            DISP_ADDER_ESCR(NUNITS) = PFESCR(NUNITS)
            PRIM_FUEL_TYPE(NUNITS) = PRIM_FUEL_TYPE_STR(1:1)
            NUC_FUEL_PRICES_FROM_FUEL_FILE(NUNITS) =
     +                      INDEX(PRIM_FUEL_TYPE_STR,'Nuc-NF') /= 0 .OR.
     +                           INDEX(PRIM_FUEL_TYPE_STR,'NUC-NF') /= 0
            LDTYPE(NUNITS) = CL_LOAD_TYPE(1:1)
            ECONOMY_TRANS_TYPE(NUNITS) = 'T'
            IF(CL_LOAD_TYPE(2:2) == 'S') ECONOMY_TRANS_TYPE(NUNITS)='S'
            IF(CL_LOAD_TYPE(2:2) == 'B') ECONOMY_TRANS_TYPE(NUNITS)='B'
            IF(CL_LOAD_TYPE(2:2) == 'N') ECONOMY_TRANS_TYPE(NUNITS)='N'
!            IF(GENGRP(NUNITS) > MAX_REPORTING_GROUPS .OR.
!     +                            GENGRP(NUNITS) < 1) GENGRP(NUNITS) = 0
            IF(EFORS0) EFOR(NUNITS) = 0.
            IF(SORS0) THEN
               MAINT_DAYS(NUNITS) = 0
               DO M = 1, 12
                  MNRATE(NUNITS,M) = 0.
               ENDDO
            ENDIF
            PBTUCT_SAVE(NUNITS) = PBTUCT(NUNITS)
            SBTUCT_SAVE(NUNITS) = SBTUCT(NUNITS)
            FUELADJ_SAVE(NUNITS) = FUELADJ(NUNITS)
            VCPMWH_IN_SAVE(NUNITS) = VCPMWH_IN(NUNITS)
            FIXED_COST_SAVE(NUNITS) = FIXED_COST_IN(NUNITS)
            ANNUAL_CL_FIXED_COST_SAVE(NUNITS) =
     +                                      ANNUAL_CL_FIXED_COST(NUNITS)
            DISPATCH_MULT_SAVE(NUNITS) = DISPATCH_MULT(NUNITS)
            EXCESS_ENERGY_SALES_SAVE(NUNITS) =
     +                                       EXCESS_ENERGY_SALES(NUNITS)
            DISPADJ_SAVE(NUNITS) = DISPADJ(NUNITS)
            DISPADJ2_SAVE(NUNITS) = DISPADJ2(NUNITS)
            CL_AI_CAPACITY_RATE_SAVE(NUNITS)=CL_AI_CAPACITY_RATE(NUNITS)
            CL_AI_ENERGY_RATE_SAVE(NUNITS) = CL_AI_ENERGY_RATE(NUNITS)
            CL_AI_REMAINING_LIFE_SAVE(NUNITS) =
     +                                      AI_CL_REMAINING_LIFE(NUNITS)
            DISPADJ2_SAVE(NUNITS) = DISPADJ2(NUNITS)
            EMISS_FUEL_COST_SAVE(NUNITS) = EMISS_FUEL_COST(NUNITS)
C 1/23/95. GAT. CHANGED THIS BECAUSE PLANNING_FAC MULTIPLIED TWICE.
            ADD_NEW_CL_UNIT = NUNITS
C           ADD_NEW_CL_UNIT=INPUT_MW(2,NUNITS)*CAP_PLANNING_FAC(NUNITS)
C
! 11/22/94. GAT. ADDED TO NEW UNITS
            SHADOW_UNIT_NUMBER(NUNITS) = 0
            IF(FUEL_SUPPLY_ID(NUNITS) > 0 .AND.
     +                    FUEL_MIX_PTR(NUNITS) > 0. .AND.
     +                               START_UP_LOGIC(NUNITS) == 'F') THEN ! FUELMX(NUNITS) >0.) THEN
               I = NUNITS
               NUNITS = I + 1
               SHADOW_UNIT_NUMBER(NUNITS) = I
               SHADOW_UNIT_NUMBER(I) = NUNITS
               UNITNM(NUNITS) = '+'//UNITNM(I)
               FUEL_MIX_PTR(NUNITS) = 0. ! FUELMX(NUNITS) = 0 replaced 5/17/01
               LDTYPE(NUNITS) = 'S'
               EXPENSE_ASSIGNMENT(NUNITS) = EXPENSE_ASSIGNMENT(I)
               EXPENSE_COLLECTION(NUNITS) = EXPENSE_COLLECTION(I)
               ASSET_CLASS_NUM(NUNITS) = ASSET_CLASS_NUM(I)
               ASSET_CLASS_VECTOR(NUNITS) = ASSET_CLASS_VECTOR(I)
               INTRA_COMPANY_CLASS_ID(NUNITS)=INTRA_COMPANY_CLASS_ID(I)
               INTRA_COMPANY_TRANSACTION(NUNITS) =
     +                                      INTRA_COMPANY_TRANSACTION(I)
               SPECIAL_UNIT_ID(NUNITS) = SPECIAL_UNIT_ID(I)
               MINIMUM_CAPACITY_FACTOR(NUNITS) =
     +                                        MINIMUM_CAPACITY_FACTOR(I)
               MAXIMUM_CAPACITY_FACTOR(NUNITS) =
     +                                        MAXIMUM_CAPACITY_FACTOR(I)
               TRANSACTION_GROUP_ID(NUNITS) = TRANSACTION_GROUP_ID(I)
               REPORT_THIS_UNIT(NUNITS) = REPORT_THIS_UNIT(I)
               ECONOMY_TRANS_TYPE(NUNITS) = ECONOMY_TRANS_TYPE(I)
               CL_CAP_AREA_LINKED(NUNITS) = CL_CAP_AREA_LINKED(I)
               GENGRP(NUNITS) = GENGRP(I)
               CAP_FRAC_OWN(NUNITS) = CAP_FRAC_OWN(I)
               ONLINE(NUNITS) = ONLINE(I)
               OFLINE(NUNITS) = OFLINE(I)
               OFF_LINE_YEAR(NUNITS) = OFF_LINE_YEAR(I)
               SBTUCT(NUNITS) = SBTUCT(I)
               SBTUCT(I) = 0.
               SFESCR(NUNITS) = SFESCR(I)
               SFESCR(I) = 0
               FUELADJ(NUNITS) = FUELADJ(I)
               EFOR(NUNITS) = EFOR(I)
               MAINT_DAYS(NUNITS) = MAINT_DAYS(I)
               DO M = 1, 12
                  MNRATE(NUNITS,M) = MNRATE(I,M)
               ENDDO
               VCPMWH_IN(NUNITS) = VCPMWH_IN(I)
               OMESCR(NUNITS) = OMESCR(I)
               FIXED_COST_IN(NUNITS) = 0.
               FIXED_COST_SAVE(NUNITS) = 0.
               ANNUAL_CL_FIXED_COST(NUNITS) = 0.
               ANNUAL_CL_FIXED_COST_SAVE(NUNITS) = 0.
               FIXED_COST_ESCALATOR(NUNITS) = 0.
               ANNUAL_CL_FIXED_COST_ESC(NUNITS) = 0.
               DISPADJ(NUNITS) = DISPADJ(I)
               DISPATCH_MULT(NUNITS) = DISPATCH_MULT(I)
               EXCESS_ENERGY_SALES(NUNITS) = EXCESS_ENERGY_SALES(I)
               HR_FACTOR(NUNITS) = HR_FACTOR(I)
               INPUT_MW(1,NUNITS) = INPUT_MW(1,I)
               INPUT_MW(2,NUNITS) = INPUT_MW(2,I)
               COEFF(1,NUNITS) = COEFF(1,I)
               COEFF(2,NUNITS) = COEFF(2,I)
               COEFF(3,NUNITS) = COEFF(3,I)
               CL_AI_CAPACITY_RATE(NUNITS) = CL_AI_CAPACITY_RATE(I)
               CL_AI_CAPACITY_ESCALATOR(NUNITS) =
     +                                       CL_AI_CAPACITY_ESCALATOR(I)
               CL_AI_ENERGY_RATE(NUNITS) = CL_AI_ENERGY_RATE(I)
               CL_AI_ENERGY_ESCALATOR(NUNITS)=CL_AI_ENERGY_ESCALATOR(I)
               AI_CL_REMAINING_LIFE(NUNITS) = AI_CL_REMAINING_LIFE(I)
               AI_CL_TAX_LIFE(NUNITS) = AI_CL_TAX_LIFE(I)
               AI_CL_ADR_LIFE(NUNITS) = AI_CL_ADR_LIFE(I)
               SEC_FUEL_EMISS_PTR(NUNITS) = SEC_FUEL_EMISS_PTR(I)
               SEC_FUEL_EMISS_PTR(I) = 0
               CL_RESOURCE_ID(NUNITS) = CL_RESOURCE_ID(I)
               DISPADJ2(NUNITS) = DISPADJ2(I)
               PHASE_I_UNIT(NUNITS) = PHASE_I_UNIT(I)
               LOCAL_CL_POOL_FRAC_OWN(NUNITS) =
     +                                         LOCAL_CL_POOL_FRAC_OWN(I)
C
C SINCE ONLY THE SECONDARY FUEL IS USED ZERO PRIMARLY AND EMISSIONS FUEL
C DATA
C
               FUEL_SUPPLY_ID(NUNITS) = FUEL_SUPPLY_ID(I)
               CAP_PLANNING_FAC(NUNITS) = 0.
               PBTUCT(NUNITS) = PBTUCT(I)
               PFESCR(NUNITS) = PFESCR(I)
               DISP_ADDER_ESCR(NUNITS) = DISP_ADDER_ESCR(I)
               P_SO2(NUNITS) = P_SO2(I)
               P_NOX(NUNITS) = P_NOX(I)
               P_PARTICULATES(NUNITS) = P_PARTICULATES(I)
               P_EMIS_OTH2(NUNITS) = P_EMIS_OTH2(I)
               P_EMIS_OTH3(NUNITS) = P_EMIS_OTH3(I)
               P_NOX_BK2(NUNITS) = P_NOX_BK2(I)
               EMISS_FUEL_COST(NUNITS) = EMISS_FUEL_COST(I)
               EMISS_FUEL_ESCAL(NUNITS) = EMISS_FUEL_ESCAL(I)
               EMISS_FUEL_EMISS_PTR(NUNITS) = 0.
               EMISS_BLENDING_RATE(NUNITS) = EMISS_BLENDING_RATE(I)
               PRIM_FUEL_EMISS_PTR(NUNITS) = PRIM_FUEL_EMISS_PTR(I)
C 6/10/93. GAT. NO ALLOCATION OF FUEL TYPES BETWEEN SHADOWS
               PRIM_FUEL_TYPE(NUNITS) = " "
               NUC_FUEL_PRICES_FROM_FUEL_FILE(NUNITS) = .FALSE.
               SEC_FUEL_TYPE(NUNITS) = SEC_FUEL_TYPE(I)
               SEC_FUEL_TYPE(I) = " "
               EMISS_FUEL_TYPE(NUNITS) = " "
               TIE_CONSTRAINT_GROUP(NUNITS) = TIE_CONSTRAINT_GROUP(I)
               PBTUCT_SAVE(NUNITS) = PBTUCT(I)
C               SBTUCT_SAVE(NUNITS) = SBTUCT(I) ! 9/28/95. GAT.
               SBTUCT_SAVE(NUNITS) = SBTUCT(NUNITS)
               FUELADJ_SAVE(NUNITS) = FUELADJ(I)
               VCPMWH_IN_SAVE(NUNITS) = VCPMWH_IN(I)
C               FIXED_COST_SAVE(NUNITS) = FIXED_COST_IN(I)
C               ANNUAL_CL_FIXED_COST_SAVE(NUNITS)=ANNUAL_CL_FIXED_COST(I)
               DISPATCH_MULT_SAVE(NUNITS) = DISPATCH_MULT(I)
               EXCESS_ENERGY_SALES_SAVE(NUNITS) = EXCESS_ENERGY_SALES(I)
               MONTHLY_CAPACITY_POINTER(NUNITS) =
     +                                       MONTHLY_CAPACITY_POINTER(I)
               DISPADJ_SAVE(NUNITS) = DISPADJ(I)
               DISPADJ2_SAVE(NUNITS) = DISPADJ2(I)
               CL_AI_CAPACITY_RATE_SAVE(NUNITS) = CL_AI_CAPACITY_RATE(I)
               CL_AI_ENERGY_RATE_SAVE(NUNITS) = CL_AI_ENERGY_RATE(I)
               CL_AI_REMAINING_LIFE_SAVE(NUNITS)=AI_CL_REMAINING_LIFE(I)
               DISPADJ2_SAVE(NUNITS) = DISPADJ2(I)
               EMISS_FUEL_COST_SAVE(NUNITS) = EMISS_FUEL_COST(I)
!
! 072106. TEMP FOR BURESH.
!
!                  IF(PRIM_FUEL_TYPE_STR == 'SUB   ' .OR.
!     +                     PRIM_FUEL_TYPE_STR == 'ANT   ' .OR.
!     +                     PRIM_FUEL_TYPE_STR == 'BIT   ' .OR.
!     +                     PRIM_FUEL_TYPE_STR == 'WC    ' .OR. ! ADDED FOR BURESH 02/11/02.
!     +                     PRIM_FUEL_TYPE_STR == 'BLQ   ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'COL   ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'SC    ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'PC    ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'COAL  ' .OR.
!     +                              PRIM_FUEL_TYPE_STR == 'LIG   ') THEN
!                     PRIMARY_MOVER(NUNITS) = 1
!                  ELSEIF(PRIM_FUEL_TYPE_STR == 'GAS   ' .OR.
!     +                  PRIM_FUEL_TYPE_STR == 'G     ' .OR.
!     +                     PRIM_FUEL_TYPE_STR == 'BFG   ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'OG    ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'WH    ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'MTE   ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                              PRIM_FUEL_TYPE_STR == 'NG    ') THEN
!                     PRIMARY_MOVER(NUNITS) = 2
!                  ELSEIF(PRIM_FUEL_TYPE_STR(1:2) == 'FO' .OR.
!     +                     PRIM_FUEL_TYPE_STR == 'DSL   ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'JF    ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'KER   ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'OIL   ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'WO    ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                     PRIM_FUEL_TYPE_STR == 'RFO   ' .OR. ! ADDED FOR BURESH 07/21/06.
!     +                              PRIM_FUEL_TYPE_STR == 'DFO   ') THEN
!                     PRIMARY_MOVER(NUNITS) = 3
!                  ELSEIF(PRIM_FUEL_TYPE_STR == 'UR    ' .OR.
!     +                  PRIM_FUEL_TYPE_STR == 'URA   ' .OR.
!     +                  PRIM_FUEL_TYPE_STR(1:3) == 'NUC') THEN
!                     PRIMARY_MOVER(NUNITS) = 4
!                  ELSEIF(PRIM_FUEL_TYPE_STR == 'WAT   ') THEN
!                     PRIMARY_MOVER(NUNITS) = 5
!                  ELSEIF(PRIM_FUEL_TYPE_STR == 'SUN   ' .OR.
!     +                        PRIM_FUEL_TYPE_STR == 'SOLAR ') THEN
!                     PRIMARY_MOVER(NUNITS) = 8
!                  ELSEIF(PRIM_FUEL_TYPE_STR == 'WND   ') THEN
!                     PRIMARY_MOVER(NUNITS) = 9
!                  ELSE
!                     PRIMARY_MOVER(NUNITS) = 6
!                  ENDIF

!
! ADDED 6/29/98. GAT.
               TRANS_ID = TRANSACTION_GROUP_ID(NUNITS)
!
               IF(TRANS_ID > 0 .AND.
     +                             ON_LINE_YEAR <= LAST_STUDY_YEAR) THEN
                  DAY_ID = DAY_TYPE_ID(NUNITS)
                  MAX_TRANS_ID_USED = MAX(MAX_TRANS_ID_USED,TRANS_ID)
                  IF(DAY_ID > 0 .AND. DAY_ID <= MAX_DAY_TYPES ) THEN
                     IF(DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,TRANS_ID)
     +                                                        == 0) THEN
                        MAX_TRANS_DATA_BASES = MAX_TRANS_DATA_BASES + 1
                        DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,TRANS_ID) =
     +                                              MAX_TRANS_DATA_BASES
                     ENDIF
!
                     DATA_BASE_POSITION(1,NUNITS) =
     +                        DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,TRANS_ID)
                     DATA_BASE_POSITION(2,NUNITS) =
     +                               DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,0)
                  ELSEIF(DAY_ID < 0) THEN
                     DAY_TYPE_COUNTER = 1
                     DO
                        DAY_ID = INT(GET_VAR(FLOAT(DAY_TYPE_ID(NUNITS)),
     +                                DAY_TYPE_COUNTER,"FIND DAY TYPE"))
                        IF(DAY_ID <= 0 .OR. DAY_ID > MAX_DAY_TYPES) EXIT
                        IF(DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,TRANS_ID)
     +                                                        == 0) THEN
                           MAX_TRANS_DATA_BASES =
     +                                          MAX_TRANS_DATA_BASES + 1
                           DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,TRANS_ID) =
     +                                              MAX_TRANS_DATA_BASES
                        ENDIF
      !
                        DATA_BASE_POSITION(
     +                                    2*DAY_TYPE_COUNTER-1,NUNITS) =
     +                        DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,TRANS_ID)
                        DATA_BASE_POSITION(2*DAY_TYPE_COUNTER,NUNITS) =
     +                               DAY_TYPE_TRANS_GROUP_PAIR(DAY_ID,0)
                        DAY_TYPE_COUNTER = DAY_TYPE_COUNTER + 1
                     ENDDO
                  ELSEIF(DAY_ID == 0) THEN
                     DO M = 1, MAX_DAY_TYPES
                        IF(DAY_TYPE_TRANS_GROUP_PAIR(M,TRANS_ID)
     +                                                        == 0) THEN
                           MAX_TRANS_DATA_BASES =
     +                                          MAX_TRANS_DATA_BASES + 1
                           DAY_TYPE_TRANS_GROUP_PAIR(M,TRANS_ID) =
     +                                              MAX_TRANS_DATA_BASES
                        ENDIF
                        DATA_BASE_POSITION(2*M-1,NUNITS) =
     +                             DAY_TYPE_TRANS_GROUP_PAIR(M,TRANS_ID)
                        DATA_BASE_POSITION(2*M,NUNITS) =
     +                                    DAY_TYPE_TRANS_GROUP_PAIR(M,0)
                     ENDDO
                  ELSE
                     WRITE(4,*) "DAY TYPE DESIGNATION",DAY_ID
                     WRITE(4,*) "OUTSIDE THE RANGE OF POSSIBLE OUTCOMES"
                     WRITE(4,*)
     +                      "MAXIMUM DAY TYPES DEFINED = ",MAX_DAY_TYPES
                     WRITE(4,*) '*** line 3278 CLA_OBJT.FOR ***'
                     er_message='See WARNING MESSAGES'
                     call end_program(er_message)
                  ENDIF
               ENDIF
            ENDIF ! SHADOW UNITS
!
!            IF(START_UP_LOGIC(NUNITS) /= 'F') THEN
!               TOTAL_START_UP_UNITS = TOTAL_START_UP_UNITS + 1
!               START_UP_INDEX(NUNITS) = TOTAL_START_UP_UNITS
!            ENDIF
C
C           ADD_NEW_CL_UNIT =
C    +                CL_CAPACITY_PLANNING_ADDITIONS(INPUT_MW(2,NUNITS))
! 051310. TO GENERATE MONTHLY CAPACITIES
         IF(NUNITS > 0) THEN
            SAVE_DETAILED_MAINTENANCE = .TRUE.
         ENDIF
      RETURN
C***************************************************************
      ENTRY INIT_CAP_MARKET_REVENUE()
C***************************************************************
!
! 091307. CAPACITY MARKET
!
         MON_CAP_SALE_MW_FROM = 0.0
         MON_CAP_SALE_REV_FROM = 0.0
         MON_CAP_PUCH_MW_FROM = 0.0
         MON_CAP_PUCH_COST_FROM = 0.0
!
         CL_TG_CAP_MARKET_MW = 0.0
         CL_TG_CAP_MARKET_REV = 0.0
!
         INIT_CAP_MARKET_REVENUE = .TRUE.
      RETURN
C***************************************************************
      ENTRY CALC_CL_CAP_MARKETS(R_YEAR,R_MONTH)
C***************************************************************
         IF(.NOT. ALLOCATED(ANNUAL_CL_CAPACITY)) THEN
            WRITE(4,*) 'CANNOT CALCULATE CAPACITY MARKETS'
            WRITE(4,*) 'THE MONTHLY CAPACITY IS NOT ALLOCATED'
            IF(.NOT. SAVE_DETAILED_MAINTENANCE) THEN
               WRITE(4,*) 'NO DETAILED MAINTENANCE'
            ENDIF
         ENDIF
         DATE_CHECK = 100*(R_YEAR+BASE_YEAR-1900) + R_MONTH
         DO I = 1, NUNITS
            IF(CAPACITY_MARKET_POINTER(I) <= 0 .OR.
     +                          CAPACITY_MARKET_TYPE(I) == 'NONE') CYCLE
            CAP_MARKET_SALE =  CAPACITY_MARKET_COST_ASSIGN(I) ==
     +                                            'Capacity Sales      '
            PRIMARY_FUEL_ID =
     +          -1.*(10000. + FLOAT(CAPACITY_MARKET_POINTER(I)))
            IF(PRIMARY_FUEL_ID < -32000.0) THEN
               PRIMARY_FUEL_ID = PRIMARY_FUEL_ID
            ENDIF
            CALL GET_A_CAP_MARKET_PRICE(
     +                         PRIMARY_FUEL_ID,
     +                         CAP_MARKET_RATE,
     +                         R_MONTH,
     +                         R_YEAR)
!
! IF AN ANNUAL CAPACITY CHARGE IN A GIVEN MONTH
!
            IF(CAP_MARKET_MONTH_NO(I) /= 13) THEN
               TEMP_I2 = CAP_MARKET_MONTH_NO(I)
            ELSE
!            CAP_MARKET_RATE = CAP_MARKET_RATE/12.
               TEMP_I2 = R_MONTH
            ENDIF
            CAP_MARKET_RATE = CAP_MARKET_RATE ! CONVERSION TO $mm
            IF(CAPACITY_MARKET_TYPE(I) == 'ICAP')THEN
               PLAN_FACTOR = 1.0
            ELSE
               IF(CAP_PLANNING_FAC(I) < 0.) THEN
                  LOCAL_YEAR = R_YEAR - BASE_YEAR
                  PLAN_FACTOR =
     +                  GET_VAR(CAP_PLANNING_FAC(I),
     +                                           LOCAL_YEAR,
     +                                           UNITNM(I))
               ELSE
                  PLAN_FACTOR = CAP_PLANNING_FAC(I)
               ENDIF
!               PLAN_FACTOR = CAP_PLANNING_FAC(I)
            ENDIF
!
            PLAN_FACTOR = PLAN_FACTOR *
     +                          CAPACITY_MARKET_COIN_ADJ_FACT(I)
!
! MOVE THIS INTO THERMAL UNITS
!
!            IF(TEMP_I2 < 1 .OR. TEMP_I2 > 12 .OR. I < 1 .OR.
!     +                                                I > NUNITS) THEN
!               WRITE(4,*) 'INVALID VALUE FOR CAPACITY MARKET'
!               WRITE(4,*) 'UNIT NAME = ', UNITNM(I)
!               WRITE(4,*) 'UNIT NUMUBER = ',I
!               WRITE(4,*) 'MONTH = ',TEMP_I2
!               STOP
!            ENDIF
!            WRITE(4,*) 'UNIT NAME FOR ICAP AND POSITON',UNITNM(I),I
!            IF(ALLOCATED(ANNUAL_CL_CAPACITY)) THEN
!               WRITE(4,*) 'ANNUAL_CL_CAPACITY ALLOCATED'
!            ELSE
!               WRITE(4,*) 'ANNUAL_CL_CAPACITY ***NOT*** ALLOCATED'
!            ENDIF
!            WRITE(4,*) 'PLAN FACTOR ',PLAN_FACTOR
!            WRITE(4,*) 'MONTH ',TEMP_I2
!            WRITE(4,*) 'MAX UNIT ',NUNITS
            IF(ONLINE(I) > DATE_CHECK .OR. OFLINE(I) < DATE_CHECK) THEN
               TEMP_R4 = 0.
            ELSE
               TEMP_R4 = ANNUAL_CL_CAPACITY(2,I,TEMP_I2)
            ENDIF
!
            IF(CAP_MARKET_SALE)THEN            ! L*1
               MON_CAP_SALE_MW_FROM(I) = TEMP_R4 * PLAN_FACTOR
               MON_CAP_SALE_REV_FROM(I) = 1000.*
     +                 MON_CAP_SALE_MW_FROM(I) * CAP_MARKET_RATE
            ELSE
               MON_CAP_PUCH_MW_FROM(I) = TEMP_R4 * PLAN_FACTOR
               MON_CAP_PUCH_COST_FROM(I) = 1000.*
     +                 MON_CAP_PUCH_MW_FROM(I) * CAP_MARKET_RATE
            ENDIF
! TRANSACT C REPORTING
            TG = TRANSACTION_GROUP_ID(I)
            TG = GET_TRANS_GROUP_POSITION(TG)
            CL_TG_CAP_MARKET_MW(TG) = CL_TG_CAP_MARKET_MW(TG) +
     +                             MON_CAP_PUCH_MW_FROM(I) +
     +                             MON_CAP_SALE_MW_FROM(I)
            CL_TG_CAP_MARKET_REV(TG) = CL_TG_CAP_MARKET_REV(TG) +
     +            (MON_CAP_SALE_REV_FROM(I) +
     +                                MON_CAP_PUCH_COST_FROM(I))
         ENDDO
         CALC_CL_CAP_MARKETS = .TRUE.
      RETURN
C***************************************************************
      ENTRY GET_CAP_MARKET_REVENUE(R_UNIT_NO)
C***************************************************************
         GET_CAP_MARKET_REVENUE = .000001 *
     +            (MON_CAP_SALE_REV_FROM(R_UNIT_NO) +
     +                                MON_CAP_PUCH_COST_FROM(R_UNIT_NO))
      RETURN
C***************************************************************
      ENTRY GET_CL_TG_CAP_MARKET_MW(R_TG)
C***************************************************************
         GET_CL_TG_CAP_MARKET_MW =  CL_TG_CAP_MARKET_MW(R_TG)
      RETURN
C***************************************************************
      ENTRY GET_CL_TG_CAP_MARKET_REV(R_TG)
C***************************************************************
         GET_CL_TG_CAP_MARKET_REV =  CL_TG_CAP_MARKET_REV(R_TG)
      RETURN
C***************************************************************
      ENTRY CAP_MARKET_ACTIVE(R_UNIT_NO)
C***************************************************************
         IF(CAPACITY_MARKET_POINTER(R_UNIT_NO) > 0 .AND.
     +                   CAPACITY_MARKET_TYPE(R_UNIT_NO) /= 'NONE') THEN
            CAP_MARKET_ACTIVE = .TRUE.
         ELSE
            CAP_MARKET_ACTIVE = .FALSE.
         ENDIF
      RETURN
C***************************************************************
      ENTRY GET_PRIMARY_MOVER_INDEX(R_UNIT_NO)
C***************************************************************
         GET_PRIMARY_MOVER_INDEX =
     +             PRIMARY_MOVER_INDEX_DB(PRIMARY_MOVER_STR(R_UNIT_NO))
         IF(GET_PRIMARY_MOVER_INDEX == 10 .AND.
     +                               PRIMARY_MOVER(R_UNIT_NO) > 3 ) THEN
            GET_PRIMARY_MOVER_INDEX = 7
         ENDIF
      RETURN
C***************************************************************
      ENTRY GET_POINTER_FOR_NEW_CL_UNIT(R_UNIT_NO)
C***************************************************************
         GET_POINTER_FOR_NEW_CL_UNIT =
     +                                POINTER_FOR_NEW_CL_UNIT(R_UNIT_NO)
      RETURN
C***********************************************************************
      ENTRY GET_CL_AFTER_PEAK(R_TG,R_YEAR)
C***********************************************************************
!         TG = GET_TRANS_GROUP_POSITION(R_TG)
         GET_CL_AFTER_PEAK = CL_TG_AFTER_PEAK(R_TG,
     +                                         MIN(R_YEAR,STUDY_PERIOD))

      RETURN
C***********************************************************************
      ENTRY GET_CL_TG_RETIRE(R_TG,R_YEAR)
C***********************************************************************
!         TG = GET_TRANS_GROUP_POSITION(R_TG)
         GET_CL_TG_RETIRE = CL_TG_RETIRE(R_TG,
     +                                         MIN(R_YEAR,STUDY_PERIOD))
      RETURN
C***********************************************************************
      ENTRY GET_CL_TG_CAP(R_FT,R_TG,R_YEAR,R_ST_P)
C***********************************************************************
!         TG = GET_TRANS_GROUP_POSITION(R_TG)
         GET_CL_TG_CAP = CL_TG_CAP(R_FT,R_TG,
     +                                  MIN(R_YEAR,STUDY_PERIOD),R_ST_P)
      RETURN
C***********************************************************************
      ENTRY GET_NEWGEN_CAP_BY_INDEX(R_NG,R_TG,R_YEAR)
C***********************************************************************
!         TG = GET_TRANS_GROUP_POSITION(R_TG)
         GET_NEWGEN_CAP_BY_INDEX = NEWGEN_CAP_BY_INDEX(R_NG,R_TG,
     +                                         MIN(R_YEAR,STUDY_PERIOD))
      RETURN
C***************************************************************
      ENTRY FIRST_YEAR_CL_CAPACITY(R_YEAR,R_UNIT_NO)
C***************************************************************
         UNIT_NO = R_UNIT_NO
         UNIT_CAPACITY = INPUT_MW(2,UNIT_NO)
         YEAR_START = R_YEAR - BASE_YEAR
         YEAR_END = OFF_LINE_YEAR(UNIT_NO)
C         OFLINE(UNIT_NO) = 100*(R_YEAR - 1900) + OFF_LINE_MONTH(UNIT_NO)
C
         CAP_MW = UNIT_CAPACITY
         IF(CAP_MW < 0.) THEN
            CAP_MW = GET_CL_MW_FROM_POINTR(CAP_MW,YEAR_START)
! ADDED PER JONES. 3/13/98. GAT.
            IF(CAP_MW < 0.)
     +         CAP_MW =
     +              GET_CL_MW_FROM_POINTR(CAP_MW,PEAK_MONTH(YEAR_START))
!
            CAP_MW = MAX(0.,CAP_MW)
         ELSE
C
C IF NO POINTER HAS BEEN SPECIFIED FOR THE PEAK MONTH
C
            CAP_MW = MAX(0.,CAP_MW)
         ENDIF

         IF(MONTHLY_CAPACITY_POINTER(UNIT_NO) /= 0 .AND.
     +                           .NOT. CL_CAP_AREA_LINKED(UNIT_NO)) THEN
            R_POINTR = FLOAT(ABS(MONTHLY_CAPACITY_POINTER(UNIT_NO)))
            MONTH_MULT = GET_CL_MW_FROM_POINTR(R_POINTR,
     +                                           PEAK_MONTH(YEAR_START))
            IF(MONTH_MULT > 2. .AND. CAP_MW /= 0.) THEN
               CAP_MW = MONTH_MULT
            ELSE
               CAP_MW = MONTH_MULT * CAP_MW
            ENDIF
         ELSEIF(MONTHLY_CAPACITY_POINTER(UNIT_NO) < 0 .AND.
     +                                 CL_CAP_AREA_LINKED(UNIT_NO)) THEN
            LOCAL_NAME = UNITNM(UNIT_NO)
            LOCAL_POINTER = ABS(MONTHLY_CAPACITY_POINTER(UNIT_NO))
            CAP_MW = MIN(GET_CLASS_PEAK_NET_DSM_FOR_CAP(
     +                      YEAR_START,LOCAL_NAME,LOCAL_POINTER),CAP_MW)
         ENDIF
C
C EFFECTIVE MW'S OF PLANNING CAPACITY
C
!
! 030822
!
         IF(CAP_PLANNING_FAC(UNIT_NO) < 0.) THEN
            PLAN_FACTOR =
     +                  GET_VAR(CAP_PLANNING_FAC(UNIT_NO),
     +                                        YEAR,
     +                                        UNITNM(UNIT_NO))
         ELSE
            PLAN_FACTOR = CAP_PLANNING_FAC(UNIT_NO)
         ENDIF
         CAP_MW = CAP_MW * CAP_FRAC_OWN(UNIT_NO) * PLAN_FACTOR * 0.01
!     +                                    CAP_PLANNING_FAC(UNIT_NO)/100.
         FIRST_YEAR_CL_CAPACITY = CAP_MW
      RETURN
C***************************************************************
      ENTRY CL_PLANNING_CAPACITY(R_CAP_TYPE,R_YEAR)
C***************************************************************
         IF(ALLOCATED(CL_ANN_CAP)) THEN
            IF(R_YEAR > STUDY_PERIOD) THEN
               CL_PLANNING_CAPACITY =
     +            CL_ANN_CAP(R_CAP_TYPE,STUDY_PERIOD,1) +
     +            CL_ANN_CAP(R_CAP_TYPE,STUDY_PERIOD,2)
            ELSE
               CL_PLANNING_CAPACITY = CL_ANN_CAP(R_CAP_TYPE,R_YEAR,1) +
     +                                CL_ANN_CAP(R_CAP_TYPE,R_YEAR,2)
            ENDIF
         ELSE
            CL_PLANNING_CAPACITY = 0.
         ENDIF
      RETURN
C***************************************************************
      ENTRY NEW_CL_PLANNING_CAPACITY(R_CAP_TYPE,R_YEAR)
C***************************************************************
         IF(ALLOCATED(CL_ANN_CAP)) THEN
            IF(R_YEAR > STUDY_PERIOD) THEN
               NEW_CL_PLANNING_CAPACITY =
     +            CL_ANN_CAP(R_CAP_TYPE,STUDY_PERIOD,2)
            ELSE
               NEW_CL_PLANNING_CAPACITY =
     +            CL_ANN_CAP(R_CAP_TYPE,R_YEAR,2)
            ENDIF
         ELSE
            NEW_CL_PLANNING_CAPACITY = 0.
         ENDIF
      RETURN
C***************************************************************
      ENTRY CL_PLANNING_LOAD_REDUCTION(R_YEAR)
C***************************************************************
         IF(ALLOCATED(CL_ANNUAL_LOAD_REDUCTION)) THEN
            IF(R_YEAR > STUDY_PERIOD) THEN
               CL_PLANNING_LOAD_REDUCTION =
     +               CL_ANNUAL_LOAD_REDUCTION(STUDY_PERIOD)
            ELSE
               CL_PLANNING_LOAD_REDUCTION =
     +               CL_ANNUAL_LOAD_REDUCTION(R_YEAR)
            ENDIF
         ELSE
            CL_PLANNING_LOAD_REDUCTION = 0.
         ENDIF
      RETURN
C***************************************************************
      ENTRY OLD_CL_PLANNING_CAPACITY(R_CAP_TYPE,R_YEAR)
C***************************************************************
         IF(ALLOCATED(CL_ANN_CAP)) THEN
            IF(R_YEAR > STUDY_PERIOD) THEN
               OLD_CL_PLANNING_CAPACITY =
     +            CL_ANN_CAP(R_CAP_TYPE,STUDY_PERIOD,1)
            ELSE
               OLD_CL_PLANNING_CAPACITY =
     +            CL_ANN_CAP(R_CAP_TYPE,R_YEAR,1)
            ENDIF
         ELSE
            OLD_CL_PLANNING_CAPACITY = 0.
         ENDIF
      RETURN
C***************************************************************
      ENTRY SET_AI_CL_REMAINING_LIFE(AI_REMAINING_LIFE)
C***************************************************************
         AI_CL_REMAINING_LIFE(NUNITS) = AI_REMAINING_LIFE
         CL_AI_REMAINING_LIFE_SAVE(NUNITS) = AI_REMAINING_LIFE
         SET_AI_CL_REMAINING_LIFE = AI_CL_REMAINING_LIFE(NUNITS)
      RETURN
C***************************************************************
!      ENTRY CL_CAPACITY_TEMP_RETIRE_UNIT(R_YEAR,R_UNIT_NO)
C***************************************************************
!         IF(.NOT. ALLOCATED(TEMP_RETIRED_UNIT_NO))
!     +                               ALLOCATE(TEMP_RETIRED_UNIT_NO(20),
!     +                                        TEMP_RETIRED_OFF_LINE(20))
!         INSTALLED_POINTER = 1 + INSTALLED_POINTER
!         TEMP_RETIRED_UNIT_NO(INSTALLED_POINTER) = R_UNIT_NO
!         TEMP_RETIRED_OFF_LINE(INSTALLED_POINTER) = OFLINE(R_UNIT_NO)
!         CL_CAPACITY_TEMP_RETIRE_UNIT = OFLINE(R_UNIT_NO)
!         OFLINE(R_UNIT_NO) = 100*(R_YEAR-1900)+OFF_LINE_MONTH(R_UNIT_NO)
!      RETURN
C******************************************************************
      ENTRY CL_RESET_PRICES
C******************************************************************
         DO I = 1, NUNITS
            PBTUCT(I) = PBTUCT_SAVE(I)
            SBTUCT(I) = SBTUCT_SAVE(I)
            FUELADJ(I) = FUELADJ_SAVE(I)
            VCPMWH_IN(I) = VCPMWH_IN_SAVE(I)
            FIXED_COST_IN(I) = FIXED_COST_SAVE(I)
            ANNUAL_CL_FIXED_COST(I) = ANNUAL_CL_FIXED_COST_SAVE(I)
            DISPATCH_MULT(I) = DISPATCH_MULT_SAVE(I)
            DISPADJ(I) = DISPADJ_SAVE(I)
            DISPADJ2(I) = DISPADJ2_SAVE(I)
            CL_AI_CAPACITY_RATE(I) = CL_AI_CAPACITY_RATE_SAVE(I)
            CL_AI_ENERGY_RATE(I) = CL_AI_ENERGY_RATE_SAVE(I)
            AI_CL_REMAINING_LIFE(I) = CL_AI_REMAINING_LIFE_SAVE(I)
            DISPADJ2(I) = DISPADJ2_SAVE(I)
            EMISS_FUEL_COST(I) = EMISS_FUEL_COST_SAVE(I)
         ENDDO
         CL_RESET_PRICES = .TRUE.
      RETURN
C******************************************************************
      ENTRY RETURN_CL_FUEL_POINTERS(R_P_BTU_COST_POINTR,
     +                              R_S_BTU_COST_POINTR,
     +                              R_E_BTU_COST_POINTR)
C******************************************************************
         DO I = 1, NUNITS
            R_P_BTU_COST_POINTR(I) = PBTUCT_SAVE(I)
            R_S_BTU_COST_POINTR(I) = SBTUCT_SAVE(I)
            R_E_BTU_COST_POINTR(I) = EMISS_FUEL_COST_SAVE(I)
         ENDDO
         RETURN_CL_FUEL_POINTERS = NUNITS
      RETURN
C******************************************************************
      ENTRY UPDATE_PRIMARY_FUEL_MIX_RATIO(R_YEAR)
C******************************************************************
         UPDATE_PRIMARY_FUEL_MIX_RATIO = 0
         DO I = 1, NUNITS
            IF(FUEL_MIX_PTR(I) <= -2.) THEN
               IF(R_YEAR > AVAIL_DATA_YEARS) THEN
                  FUELMX(I) = GET_VAR(FUEL_MIX_PTR(I),AVAIL_DATA_YEARS,
     +                                                        UNITNM(I))
               ELSE
                  FUELMX(I) = GET_VAR(FUEL_MIX_PTR(I),R_YEAR,UNITNM(I))
               ENDIF
               UPDATE_PRIMARY_FUEL_MIX_RATIO = 1 +
     +                                     UPDATE_PRIMARY_FUEL_MIX_RATIO
            ELSE
               FUELMX(I) = FUEL_MIX_PTR(I)
            ENDIF
         ENDDO
      RETURN
C******************************************************************
      ENTRY CL_PLANNING_ADDITIONS
C******************************************************************
         CL_PLANNING_ADDITIONS = AVAILABLE_CL_UNITS -
     +                                      BASE_PLUS_HARDWIRED_CL_UNITS
      RETURN
C******************************************************************
      ENTRY RETURN_CL_UNITS_AFTER_HARD_ADDS
C******************************************************************
         RETURN_CL_UNITS_AFTER_HARD_ADDS = BASE_PLUS_HARDWIRED_CL_UNITS
      RETURN
C******************************************************************
      ENTRY DETAILED_MAINTENANCE_IS_ACTIVE
C******************************************************************
         DETAILED_MAINTENANCE_IS_ACTIVE = SAVE_DETAILED_MAINTENANCE
      RETURN
C******************************************************************
      ENTRY DETAIL_MAINTENANCE_NOT_ACTIVE
C******************************************************************
         SAVE_DETAILED_MAINTENANCE = .FALSE.
         DETAIL_MAINTENANCE_NOT_ACTIVE = SAVE_DETAILED_MAINTENANCE
      RETURN
C******************************************************************
      ENTRY CALC_ANNUAL_CAP_AND_MAINT(R_YEAR)
C******************************************************************
         MAINTENANCE_IS_ACCUMULATED = ACCUMULATE_MAINTENANCE()
! 12/22/04.
         MAINTENANCE_IS_ACCUMULATED = .FALSE.
!
         IF(.NOT. (MAINTENANCE_REPORT() .OR.
     +               SAVE_DETAILED_MAINTENANCE .OR.
     +                     YES_UNIT_COMMITMENT_LOGIC() .OR.
     +                           MAINTENANCE_IS_ACCUMULATED) .OR.
!         IF(.NOT. (MAINTENANCE_REPORT() .AND.
!     +               SAVE_DETAILED_MAINTENANCE .AND.
!     +                     YES_UNIT_COMMITMENT_LOGIC() .AND.
!     +                             MAINTENANCE_IS_ACCUMULATED) .OR.
     +                                                   NUNITS==0) THEN
            CALC_ANNUAL_CAP_AND_MAINT = .FALSE.
            RETURN
         ENDIF
         IF(ALLOCATED(ANNUAL_CL_CAPACITY))
     +         DEALLOCATE(ANNUAL_CL_CAPACITY,ANNUAL_CL_MAINTENANCE,
     +                     ANNUAL_CL_MAINT_MW,MAINT_DIVISIBLE)
         ALLOCATE(ANNUAL_CL_CAPACITY(2,NUNITS,12))
      ALLOCATE(ANNUAL_CL_MAINTENANCE(NUNITS,13))
      ALLOCATE(ANNUAL_CL_MAINT_MW(NUNITS))
      ALLOCATE(MAINT_DIVISIBLE(NUNITS))
!
         IF(ALLOCATED(MAINT_INDEX)) DEALLOCATE(MAINT_INDEX,
     +                                         MAINT_INDEX_MW,
     +                                         MAINT_INDEX_DAYS,
     +                                         MAINT_INDEX_MONTHLY_MW)
         ALLOCATE(MAINT_INDEX(NUNITS))
         ALLOCATE(MAINT_INDEX_MW(NUNITS))
         ALLOCATE(MAINT_INDEX_DAYS(NUNITS))
         ALLOCATE(MAINT_INDEX_MONTHLY_MW(NUNITS,13))
!
!
         IF(ALLOCATED(MAINTENANCE_DAYS)) DEALLOCATE(MAINTENANCE_DAYS)
         ALLOCATE(MAINTENANCE_DAYS(NUNITS))
         MAINTENANCE_DAYS = 0.
         ANNUAL_CL_CAPACITY = 0.
         ANNUAL_CL_MAINTENANCE = 0.
         ANNUAL_CL_MAINT_MW = 0.
         MAINT_DIVISIBLE = FALSE_BYTE
         OFFSET_MAINTENANCE_ACTIVE = OFFSET_MAINTENANCE_VECTORS()
         BASE_DATE = (BASE_YEAR + R_YEAR - 1900) * 100
         BASE_YEAR_DATE = (BASE_YEAR - 1900) * 100
! MARKET_RESOURCE 7/5/02. FOR TVA
         IF(ALLOCATED(MARKET_RESOURCE_INDEX))
     +                                 DEALLOCATE(MARKET_RESOURCE_INDEX,
     +                                          MARKET_RESOURCE_COUNTER)
         ALLOCATE(MARKET_RESOURCE_INDEX(NUNITS))
         ALLOCATE(MARKET_RESOURCE_COUNTER(NUNITS))
!         CALL CINITW(MARKET_RESOURCE_COUNTER,INT(NUNITS),0)
         MARKET_RESOURCE_COUNTER = 0
         MARKET_COUNT = 0
C
         LAST_ACTIVE_UNIT = NUNITS
!
! 9/25/02. FOR REGIONAL MAINTENANCE PLANNING
!
! 10/16/02. MOVED MAINTENANCE_PENALTY FROM TF INTO CLA
!
         TEMP_L = GET_MONTHLY_MAINTENANCE_PENALTY(MAINTENANCE_PENALTY)
         YES_REGIONAL_OUTAGES_ACTIVE = REGIONAL_PARAMS_ACTIVE()
!
! MOVED 12/20/02.
!
!         MAX_FO_PER_MONTH = 1
!
! 10/24/03.
!
!
         FREQUENCY_DURATION = YES_FREQUENCY_DURATION()
!
         IF(FREQUENCY_DURATION .OR. UNIT_FREQUENCY_DURATION) THEN
            MAX_FO_PER_MONTH = 8
!            IF(ALLOCATED(DUR_UNIT_BEG_FO_HR))
!     +         DEALLOCATE(DUR_UNIT_BEG_FO_HR,DUR_UNIT_END_FO_HR)
!            ALLOCATE(DUR_UNIT_BEG_FO_HR(MAX_FO_PER_MONTH,12),
!     +               DUR_UNIT_END_FO_HR(MAX_FO_PER_MONTH,12))
         ELSE
            MAX_FO_PER_MONTH = 1
         ENDIF
!
         CALL INIT_MAINT_SCHEDULE(MAX_FO_PER_MONTH,NUNITS)
!
         DO PA = 1, MAX_MAINT_PLANNING_AREAS
            MAINT_INDEX_MW = 0.
            MAINT_INDEX_DAYS = 0.
            MAINT_INDEX_MONTHLY_MW = 0.
!            CALL CINITW(MAINT_INDEX,INT(NUNITS),0)
            MAINT_INDEX = 0
            K = 0
!
! 08/14/03. MADE LOOPS TO AVOID ASSIGNMENTS
!
            IF(REGIONAL_PA_MAINT_SCHEDULING) THEN
!
               DO I = 1, 12
                  MONTHLY_MAINTENANCE_PEAKS(I) =
     +                        GET_PA_PEAK(PA,I) * MAINTENANCE_PENALTY(I)
               ENDDO
!
!               MONTHLY_MAINTENANCE_PEAKS(1) =
!     +                  GET_PA_PEAK(PA,1) * MAINTENANCE_PENALTY(1)
            ELSEIF(REGIONAL_TG_MAINT_SCHEDULING) THEN
               DO I = 1, 12
                  MONTHLY_MAINTENANCE_PEAKS(I) =
     +               GET_TRANS_GROUP_PEAK(PA,I) * MAINTENANCE_PENALTY(I)
               ENDDO
!               MONTHLY_MAINTENANCE_PEAKS(1) =
!     +               GET_TRANS_GROUP_PEAK(PA,1) * MAINTENANCE_PENALTY(1)
            ELSE
               MONTHLY_MAINTENANCE_PEAKS(1) = FUT_PEAK(3,1) *
     +                                            MAINTENANCE_PENALTY(1)
               MONTHLY_MAINTENANCE_PEAKS(2) = FUT_PEAK(3,2) *
     +                                            MAINTENANCE_PENALTY(2)
               MONTHLY_MAINTENANCE_PEAKS(3) = FUT_PEAK(3,3) *
     +                                            MAINTENANCE_PENALTY(3)
               MONTHLY_MAINTENANCE_PEAKS(4) = FUT_PEAK(3,4) *
     +                                            MAINTENANCE_PENALTY(4)
               MONTHLY_MAINTENANCE_PEAKS(5) = FUT_PEAK(3,5) *
     +                                            MAINTENANCE_PENALTY(5)
               MONTHLY_MAINTENANCE_PEAKS(6) = FUT_PEAK(3,6) *
     +                                            MAINTENANCE_PENALTY(6)
               MONTHLY_MAINTENANCE_PEAKS(7) = FUT_PEAK(3,7) *
     +                                            MAINTENANCE_PENALTY(7)
               MONTHLY_MAINTENANCE_PEAKS(8) = FUT_PEAK(3,8) *
     +                                            MAINTENANCE_PENALTY(8)
               MONTHLY_MAINTENANCE_PEAKS(9) = FUT_PEAK(3,9) *
     +                                            MAINTENANCE_PENALTY(9)
               MONTHLY_MAINTENANCE_PEAKS(10) = FUT_PEAK(3,10) *
     +                                           MAINTENANCE_PENALTY(10)
               MONTHLY_MAINTENANCE_PEAKS(11) = FUT_PEAK(3,11) *
     +                                           MAINTENANCE_PENALTY(11)
               MONTHLY_MAINTENANCE_PEAKS(12) = FUT_PEAK(3,12) *
     +                                           MAINTENANCE_PENALTY(12)
            ENDIF
!
            DO I = 1, NUNITS
C
C 2/13/96 CORRECTION FOR SHADOW UNITS
C
C           IF(LDTYPE(I) == 'L') CYCLE
               IF(LDTYPE(I) == 'S') THEN
                  SHADOW_UNITS_ACTIVE = .TRUE.
                  CYCLE
               ENDIF
!
!
!
               IF(REGIONAL_PA_MAINT_SCHEDULING) THEN
                  TG = TRANSACTION_GROUP_ID(I)
                  TG = GET_TRANS_GROUP_POSITION(TG)
                  IF(TG_2_PLANNING_AREA(TG) /= PA) CYCLE
               ELSEIF(REGIONAL_TG_MAINT_SCHEDULING) THEN
                  TG = TRANSACTION_GROUP_ID(I)
                  TG = GET_TRANS_GROUP_POSITION(TG)
                  IF(TG /= PA) CYCLE
               ENDIF
!

! MOVED FROM BELOW. 9/23/98. GAT.
               DATE1 = BASE_DATE + 1
               DATE2 = BASE_DATE + 12
               IF(ONLINE(I) > DATE2 .OR. OFLINE(I) < DATE1) CYCLE
!
!            LAST_ACTIVE_UNIT = I
!
               IF(MAINT_DAYS(I) /= 0.) THEN
                  IF(MAINT_DAYS(I) < 0.) THEN
                     MAINTENANCE_DAYS(I) = GET_VAR(MAINT_DAYS(I),YEAR,
     +                                                        UNITNM(I))
                  ELSE
                     MAINTENANCE_DAYS(I) = MAINT_DAYS(I)
                  ENDIF
               ENDIF
!
               IF(MARKET_RESOURCE(I) == 'T' .OR.
     +                    MARKET_RESOURCE(I) == 'G' .OR.
     +                                   MARKET_RESOURCE(I) == 'D') THEN
                  MARKET_COUNT = MARKET_COUNT + 1
                  MARKET_RESOURCE_COUNTER(I) = MARKET_COUNT
                  MARKET_RESOURCE_INDEX(MARKET_COUNT) = I
               ENDIF
!
!            IF(EFOR(I) < 0.) THEN
!               EAVAIL(I) = (100. - GET_VAR(EFOR(I),YEAR,UNITNM(I)))/100.
!            ELSE
!               EAVAIL(I) = (100. - EFOR(I))/100.
!            ENDIF
               IF(MAINTENANCE_DAYS(I) > 52.14) THEN
                  WRITE(4,*) "AUTOMATIC MAINTENANCE FOR CL UNIT ",
     +                                                         UNITNM(I)
                  WRITE(4,*) "IN YEAR ",YEAR+BASE_YEAR,
     +                                               " EXCEEDS 52 WEEKS"
                  WRITE(4,*) "MAINTENANCE RESET TO 52 WEEKS"
                  WRITE(4,*) " "
                  MAINTENANCE_DAYS(I) = 52.14
               ENDIF
!
               IF(MAINTENANCE_DAYS(I) < 0.) THEN
                  WRITE(4,*) "AUTOMATIC MAINTENANCE FOR CL UNIT ",
     +                                                         UNITNM(I)
                  WRITE(4,*) "IN YEAR ",YEAR+BASE_YEAR," IS LESS THAN 0"
                  WRITE(4,*) "MAINTENANCE RESET TO 0 WEEKS"
                  WRITE(4,*) " "
                  MAINTENANCE_DAYS(I) = 0.
               ENDIF
C            IF(WABASH_VALLEY .AND. I == GIBSON_BACKUP_POINTER) THEN
C               ANNUAL_CL_CAPACITY(1,I) = ANNUAL_CL_CAPACITY(1,GIBSON_POINTER)
C               ANNUAL_CL_CAPACITY(2,I) = ANNUAL_CL_CAPACITY(2,GIBSON_POINTER)
C               ANNUAL_CL_MAINTENANCE(I,J) = 1.-
C     +                          ANNUAL_CL_MAINTENANCE(GIBSON_POINTER,J)
C               CYCLE
C            ENDIF
!
!            DATE1 = BASE_DATE + 1
!            DATE2 = BASE_DATE + 12
!            IF(ONLINE(I) > DATE2 .OR. OFLINE(I) < DATE1) CYCLE
!
               DO J = 1 , 12 ! CALCULATE CAPACITIES FOR ALL MONTHS
                  IF(MONTHLY_CAPACITY_POINTER(I) /= 0) THEN
                     IF(CL_CAP_AREA_LINKED(I)) THEN
                        PERIOD_RATE =
     +                              GET_CLASS_PEAK_NET_DSM(J,UNITNM(I),
     +                                 ABS(MONTHLY_CAPACITY_POINTER(I)))
                     ELSE
                        PERIOD_RATE = GET_VAR(FLOAT(
     +                    ABS(MONTHLY_CAPACITY_POINTER(I))),J,UNITNM(I))
                     ENDIF
                     DO M = 2 , 1, -1
                        IF(INPUT_MW(M,I) < 0.) THEN
                           MW_CAPACITY = GET_VAR(INPUT_MW(M,I),YEAR,
     +                                                        UNITNM(I))
                           IF(MW_CAPACITY < 0.) THEN
                              MW_CAPACITY = GET_VAR(MW_CAPACITY,J,
     +                                                        UNITNM(I))
                           ENDIF
                        ELSE
                           MW_CAPACITY = INPUT_MW(M,I)
                        ENDIF
                        IF(PERIOD_RATE > 2.) THEN
                           IF(MW_CAPACITY > 0.) THEN
                              PERIOD_RATE = PERIOD_RATE/MW_CAPACITY
                           ELSE
                              MW_CAPACITY = PERIOD_RATE
                              PERIOD_RATE = 1.
                           ENDIF
                        ENDIF
                        IF(MW_CAPACITY < 1. .AND. M == 1) THEN
                           ANNUAL_CL_CAPACITY(M,I,J) =
     +                                    MW_CAPACITY * UNIT_CAPACITY
                        ELSE
                           ANNUAL_CL_CAPACITY(M,I,J) =  MW_CAPACITY *
     +                              CAP_FRAC_OWN(I)/100. * PERIOD_RATE
                        ENDIF
                        IF(M == 2)
     +                           UNIT_CAPACITY=ANNUAL_CL_CAPACITY(M,I,J)
                     ENDDO
                  ELSE
                     DO M = 2, 1 , -1
                        IF(INPUT_MW(M,I) < 0.) THEN
                           ANNUAL_CL_CAPACITY(M,I,J) =
     +                             GET_VAR(INPUT_MW(M,I),YEAR,UNITNM(I))
                           IF(ANNUAL_CL_CAPACITY(M,I,J) < 0.) THEN
                              ANNUAL_CL_CAPACITY(M,I,J) =
     +                           GET_VAR(ANNUAL_CL_CAPACITY(M,I,J),J,
     +                                                        UNITNM(I))
                           ENDIF
                        ELSE
                           ANNUAL_CL_CAPACITY(M,I,J) = INPUT_MW(M,I)
                        ENDIF
                        IF(ANNUAL_CL_CAPACITY(M,I,J) < 1. .AND.
     +                                                        M==1) THEN
                           ANNUAL_CL_CAPACITY(1,I,J) =
     +                       ANNUAL_CL_CAPACITY(2,I,J) *
     +                                         ANNUAL_CL_CAPACITY(1,I,J)
                        ELSE
                           ANNUAL_CL_CAPACITY(M,I,J) =
     +                              ANNUAL_CL_CAPACITY(M,I,J)*
     +                                              CAP_FRAC_OWN(I)/100.
                        ENDIF
                     ENDDO
                     UNIT_CAPACITY = ANNUAL_CL_CAPACITY(2,I,J)
                  ENDIF
                  DATE1 = BASE_DATE + J
                  IF(RETROFIT_ACTIVE(I)) THEN
                     TEMP_I2 = RETROFIT_PROJECT_ID(I)
                     CALL RETROFIT_MINCAP_IMPACT(
     +                                        TEMP_I2,
     +                                        TEMP_R4)
                     ANNUAL_CL_CAPACITY(1,I,J) =
     +                               ANNUAL_CL_CAPACITY(1,I,J) * TEMP_R4
                     CALL RETROFIT_MAXCAP_IMPACT(
     +                                        TEMP_I2,
     +                                        TEMP_R4)
                     ANNUAL_CL_CAPACITY(2,I,J) =
     +                               ANNUAL_CL_CAPACITY(2,I,J) * TEMP_R4
                     UNIT_CAPACITY = ANNUAL_CL_CAPACITY(2,I,J)
!
! 050110.
!
                  ELSEIF(DATE1 >= CO2_CONTROL_DATE(I) .AND.
     +                        CO2_CONTROL_DATE(I) > BASE_YEAR_DATE) THEN
                     TEMP_R4 = CO2_RETRO_CAP_MULT(I)
                     ANNUAL_CL_CAPACITY(1,I,J) =
     +                               ANNUAL_CL_CAPACITY(1,I,J) * TEMP_R4
                     ANNUAL_CL_CAPACITY(2,I,J) =
     +                               ANNUAL_CL_CAPACITY(2,I,J) * TEMP_R4
                     UNIT_CAPACITY = ANNUAL_CL_CAPACITY(2,I,J)
                  ENDIF
                  IF(ONLINE(I) <= DATE1 .AND. OFLINE(I) >= DATE1 .AND.
     +                  (UNIT_CAPACITY > 0. .OR. LDTYPE(I) == 'L')) THEN
                     IF(MNRATE(I,J) < 0.) THEN
                        IF(OFFSET_MAINTENANCE_ACTIVE .AND.
     +                                           I > BASE_CL_UNITS) THEN
                           GET_YR =
     +                           YEAR-(ONLINE(I)/100+1900 - BASE_YEAR)+1
                        ELSE
                           GET_YR = YEAR
                        ENDIF
                        MN_RATE = GET_VAR(MNRATE(I,J),GET_YR,UNITNM(I))
C
                        TEMP_CL_MAINTENANCE = MIN(100.,MN_RATE)/100.
C
                     ELSE
                        TEMP_CL_MAINTENANCE = MIN(100.,MNRATE(I,J))/100.
                     ENDIF
                  ELSE
                     TEMP_CL_MAINTENANCE = 1.0
                     MAINTENANCE_DAYS(I) =
     +                     MIN(52.14,MAINTENANCE_DAYS(I) +
     +                       TEMP_CL_MAINTENANCE * DAYS_PER_MONTH(J)/7.)
                  ENDIF
                  IF(MAINTENANCE_IS_ACCUMULATED .AND.
     +               ONLINE(I) <= DATE1 .AND. OFLINE(I) >= DATE1 .AND.
     +               .NOT. (LDTYPE(I)=='N' .OR.
     +                                 EXPENSE_ASSIGNMENT(I)=='P')) THEN
                     MAINTENANCE_DAYS(I) = MAINTENANCE_DAYS(I) +
     +                        TEMP_CL_MAINTENANCE * DAYS_PER_MONTH(J)/7.
                  ELSE
                     ANNUAL_CL_MAINTENANCE(I,J) = TEMP_CL_MAINTENANCE
                  ENDIF
                  ANNUAL_CL_MAINTENANCE(I,13) =
     +               ANNUAL_CL_MAINTENANCE(I,13) +
     +                    ANNUAL_CL_MAINTENANCE(I,J) * DAYS_PER_MONTH(J)
                  ANNUAL_CL_MAINT_MW(I) = MAX(ANNUAL_CL_MAINT_MW(I),
     +                                        ANNUAL_CL_CAPACITY(2,I,J))
               ENDDO ! SEASONS
!
               K = K + 1
               MAINT_INDEX(K) = I
               MAINT_INDEX_DAYS(K) = MAINTENANCE_DAYS(I)
               MAINT_INDEX_MW(K) = ANNUAL_CL_MAINT_MW(I)
               MAINT_INDEX_MONTHLY_MW(K,1) = ANNUAL_CL_MAINTENANCE(I,1)
               MAINT_INDEX_MONTHLY_MW(K,2) = ANNUAL_CL_MAINTENANCE(I,2)
               MAINT_INDEX_MONTHLY_MW(K,3) = ANNUAL_CL_MAINTENANCE(I,3)
               MAINT_INDEX_MONTHLY_MW(K,4) = ANNUAL_CL_MAINTENANCE(I,4)
               MAINT_INDEX_MONTHLY_MW(K,5) = ANNUAL_CL_MAINTENANCE(I,5)
               MAINT_INDEX_MONTHLY_MW(K,6) = ANNUAL_CL_MAINTENANCE(I,6)
               MAINT_INDEX_MONTHLY_MW(K,7) = ANNUAL_CL_MAINTENANCE(I,7)
               MAINT_INDEX_MONTHLY_MW(K,8) = ANNUAL_CL_MAINTENANCE(I,8)
               MAINT_INDEX_MONTHLY_MW(K,9) = ANNUAL_CL_MAINTENANCE(I,9)
               MAINT_INDEX_MONTHLY_MW(K,10) =
     +                                       ANNUAL_CL_MAINTENANCE(I,10)
               MAINT_INDEX_MONTHLY_MW(K,11) =
     +                                       ANNUAL_CL_MAINTENANCE(I,11)
               MAINT_INDEX_MONTHLY_MW(K,12) =
     +                                       ANNUAL_CL_MAINTENANCE(I,12)
               MAINT_INDEX_MONTHLY_MW(K,13) =
     +                                       ANNUAL_CL_MAINTENANCE(I,13)
!
C
C               IF(WABASH_VALLEY) THEN !!!TOOK-OUT WVPA FOR NOW!!!
C
            ENDDO ! UNITS
C
C  SIMPLIFICATIONS FOR MAINTENANCE SCHEDULER:
C
C     (1) WABASH_VALLEY GIBSON CAPACITY IS TAKEN OUT
C     (2) DAILY SCHEDULING ONLY
C     (3) NO SPLITTING THE MAINTENANCE
C     (4) THE ALGORITHM IS LOOKING FOR SCHEDULED WEEKS, NOT DAYS
C     (5) MAINT SCHEDULED BEYOND DECEMBER 31 IT MOVES TO JAN 1 SAME YEAR
C
            IF(SAVE_DETAILED_MAINTENANCE .OR.
     +                     YES_UNIT_COMMITMENT_LOGIC() .OR.   ! TEST. 8/15/02. GAT.
     +                                  MAINTENANCE_IS_ACCUMULATED) THEN
!            CALL MAINT_SCHEDULER(NUNITS,LAST_ACTIVE_UNIT,
!     +                           ANNUAL_CL_MAINT_MW,
!     +                           MAINT_DIVISIBLE,'D',MAINTENANCE_DAYS,
!     +                           ANNUAL_CL_MAINTENANCE)
!
! MOVED 12/20/02.
!
!               MAX_FO_PER_MONTH = 1
!               CALL INIT_MAINT_SCHEDULE(MAX_FO_PER_MONTH,NUNITS)
!
               LAST_ACTIVE_UNIT = K
!
!
!            SCHEDULE_FO = YES_DETAILED_FOR()
!
               SCHEDULE_FO = .TRUE.
! TESTING. 10/16/02.

               DETAILED_MAINT = YES_DETAILED_MAINTENANCE()
!               SCHEDULE_FO = .FALSE.
!
               CALL SW_MAINT_DERATING(SCHEDULE_FO)
!
               SCHEDULE_FO = YES_DETAILED_FOR() ! PER 4/3/01 THIELKE E-MAIL.
! 3/30/02.
               VOID_LOGICAL = PICK_FOR_SEED_OPTIONS(FOR_SEED_OPTIONS)
    !
               IF(FOR_SEED_OPTIONS == 'Y') THEN
                  YEAR_OR_SCEN = R_YEAR
               ELSE
                  YEAR_OR_SCEN = END_POINT
               ENDIF
!
!            CALL MAINT_SCHEDULER(NUNITS,LAST_ACTIVE_UNIT,
!     +                           MAINT_INDEX_MW,
!     +                           MAINT_DIVISIBLE,'D',
!     +                           MAINT_INDEX_DAYS,
!     +                           MAINT_INDEX_MONTHLY_MW,
!     +                           SCHEDULE_FO,
!     +                           EAVAIL)
!
! 4/27/01. ADDED CURRENT YEAR AS SEED PARAMETER FOR REPRODUCABLE OUTAGES,
!          REMOVED EAVAIL AND ADDED MAINT_INDEX:
!           CALL MAINT_SCHEDULER(NUNITS,LAST_ACTIVE_UNIT,YEAR,
!    +                           MAINT_INDEX_MW,
!    +                           MAINT_DIVISIBLE,'D',
!    +                           MAINT_INDEX_DAYS,
!    +                           MAINT_INDEX_MONTHLY_MW,SCHEDULE_FO,
!    +                           MAINT_INDEX)
!
! 20010615 MAINT_SCHEDULER uses MAINT_INDEX, precluding compression & expansion:
!            CALL MAINT_SCHEDULER(NUNITS,LAST_ACTIVE_UNIT,YEAR,
!     +                           ANNUAL_CL_MAINT_MW,
!     +                           MAINT_DIVISIBLE,'D',
!     +                           MAINTENANCE_DAYS,
!     +                           ANNUAL_CL_MAINTENANCE,SCHEDULE_FO,
!     +                           MAINT_INDEX)
!
!               MAX_FO_PER_MONTH = 1
!
               IF(LAST_ACTIVE_UNIT == 0) CYCLE
!
               CALL MAINT_SCHEDULER(
     +                           NUNITS,
     +                           LAST_ACTIVE_UNIT,
!     +                           YEAR,
     +                           MAINT_DIVISIBLE,
     +                           'D',
     +                           MAINT_INDEX_MW,
     +                           MAINT_INDEX_DAYS,
     +                           MAINT_INDEX_MONTHLY_MW,
     +                           MAINT_INDEX,
     +                           SCHEDULE_FO,
     +                           DETAILED_MAINT,
     +                           MAX_FO_PER_MONTH,
     +                           MONTHLY_MAINTENANCE_PEAKS) ! ADDED 9/27/02.
!
! MAINT_INDEX above is needed even if active items in arrays are compressed;
! NUNITS above needed only for properly dimensioning MAINT_INDEX_MONTHLY_MW;
! if subscript order on MAINT_INDEX_MONTHLY_MW were reversed, we could avoid
! passing NUNITS, making MAINT_SCHEDULER simpler and more elegant.
!
!
!
! 11/17/98. GAT. FOR SCENARIO MAKER.
!
               DO J = 1, 12
                  MONTHLY_NUCLEAR_AVAIL_MULT(J) =
     +                              GET_SCENARIO_NUCLEAR_AVAIL(R_YEAR,J)
                  MONTHLY_COAL_AVAIL_MULT(J) =
     +                                 GET_SCENARIO_COAL_AVAIL(R_YEAR,J)
                  MONTHLY_GAS_AVAIL_MULT(J) =
     +                                 GET_SCENARIO_GAS_AVAIL(R_YEAR,J)
                  MONTHLY_OIL_AVAIL_MULT(J) =
     +                                 GET_SCENARIO_OIL_AVAIL(R_YEAR,J)
                  MONTHLY_OTHER_AVAIL_MULT(J) =
     +                                GET_SCENARIO_OTHER_AVAIL(R_YEAR,J)
                  MONTHLY_HYDRO_WATER_YEAR_MULT(J) =
     +                         GET_SCENARIO_HYDRO_WATER_YEAR(R_YEAR,J)
               ENDDO
!
               REGIONAL_MONTHLY_MULT = 1.
!
               DO K = 1, LAST_ACTIVE_UNIT
                  I = MAINT_INDEX(K)
                  ANNUAL_CL_MAINTENANCE(I,1) =
     +                                       MAINT_INDEX_MONTHLY_MW(K,1)
                  ANNUAL_CL_MAINTENANCE(I,2) =
     +                                       MAINT_INDEX_MONTHLY_MW(K,2)
                  ANNUAL_CL_MAINTENANCE(I,3) =
     +                                       MAINT_INDEX_MONTHLY_MW(K,3)
                  ANNUAL_CL_MAINTENANCE(I,4) =
     +                                       MAINT_INDEX_MONTHLY_MW(K,4)
                  ANNUAL_CL_MAINTENANCE(I,5) =
     +                                       MAINT_INDEX_MONTHLY_MW(K,5)
                  ANNUAL_CL_MAINTENANCE(I,6) =
     +                                       MAINT_INDEX_MONTHLY_MW(K,6)
                  ANNUAL_CL_MAINTENANCE(I,7) =
     +                                       MAINT_INDEX_MONTHLY_MW(K,7)
                  ANNUAL_CL_MAINTENANCE(I,8) =
     +                                       MAINT_INDEX_MONTHLY_MW(K,8)
                  ANNUAL_CL_MAINTENANCE(I,9) =
     +                                       MAINT_INDEX_MONTHLY_MW(K,9)
                  ANNUAL_CL_MAINTENANCE(I,10) =
     +                                      MAINT_INDEX_MONTHLY_MW(K,10)
                  ANNUAL_CL_MAINTENANCE(I,11) =
     +                                      MAINT_INDEX_MONTHLY_MW(K,11)
                  ANNUAL_CL_MAINTENANCE(I,12) =
     +                                      MAINT_INDEX_MONTHLY_MW(K,12)
                  ANNUAL_CL_MAINTENANCE(I,13) =
     +                                      MAINT_INDEX_MONTHLY_MW(K,13)
!            ONE_FO_PER_MONTH = .TRUE.
!             IF(ONE_FO_PER_MONTH) THEN
!
                  FT = PRIMARY_MOVER(I)
!
                  IF(YES_REGIONAL_OUTAGES_ACTIVE) THEN

                    TG = TRANSACTION_GROUP_ID(I)
                     DO J = 1, 12
                        REGIONAL_MONTHLY_MULT(J) =
     +                               GET_MONTHLY_REGIONAL_OUTAGE(R_YEAR,
     +                                                          J,TG,FT)
                     ENDDO
                  ENDIF
!
!
                  IF(EFOR(I) < 0.) THEN
                     TEMP_R4 = GET_VAR(EFOR(I),R_YEAR,UNITNM(I))
                     DO J = 1, 12
                        IF(TEMP_R4 < 0.) THEN
                           MONTHLY_EAVAIL(J) =
     +                        (100. - GET_VAR(TEMP_R4,J,UNITNM(I)))/100.
                        ELSE
                           MONTHLY_EAVAIL(J) = (100. - TEMP_R4)/100.
                        ENDIF
!
                        IF(FT == 1) THEN
                           MONTHLY_EAVAIL(J) =
     +                        MIN(MONTHLY_EAVAIL(J) *
     +                           REGIONAL_MONTHLY_MULT(J) *
     +                                   MONTHLY_COAL_AVAIL_MULT(J),1.0)
                        ELSEIF(FT ==2) THEN
                           MONTHLY_EAVAIL(J) =
     +                        MIN(MONTHLY_EAVAIL(J) *
     +                           REGIONAL_MONTHLY_MULT(J) *
     +                                   MONTHLY_GAS_AVAIL_MULT(J),1.0)
                        ELSEIF(FT == 3) THEN
                           MONTHLY_EAVAIL(J) =
     +                        MIN(MONTHLY_EAVAIL(J) *
     +                           REGIONAL_MONTHLY_MULT(J) *
     +                                   MONTHLY_OIL_AVAIL_MULT(J),1.0)
                        ELSEIF(FT == 4) THEN
                           MONTHLY_EAVAIL(J) =
     +                        MIN(MONTHLY_EAVAIL(J) *
     +                           REGIONAL_MONTHLY_MULT(J) *
     +                                MONTHLY_NUCLEAR_AVAIL_MULT(J),1.0)
                        ELSEIF(FT == 5) THEN
                           MONTHLY_EAVAIL(J) =
     +                         MONTHLY_EAVAIL(J) *
     +                           REGIONAL_MONTHLY_MULT(J) *
     +                                  MONTHLY_HYDRO_WATER_YEAR_MULT(J)
                        ELSEIF(FT == 6) THEN
                           MONTHLY_EAVAIL(J) =
     +                        MIN(MONTHLY_EAVAIL(J) *
     +                           REGIONAL_MONTHLY_MULT(J) *
     +                                  MONTHLY_OTHER_AVAIL_MULT(J),1.0)
                        ENDIF
                     ENDDO
                  ELSE
                     DO J = 1, 12
!
                        MONTHLY_EAVAIL(J) = (100. - EFOR(I))/100.
!
                        IF(FT == 1) THEN
                           MONTHLY_EAVAIL(J) =
     +                        MIN(MONTHLY_EAVAIL(J) *
     +                           REGIONAL_MONTHLY_MULT(J) *
     +                                   MONTHLY_COAL_AVAIL_MULT(J),1.0)
                        ELSEIF(FT ==2) THEN
                           MONTHLY_EAVAIL(J) =
     +                        MIN(MONTHLY_EAVAIL(J) *
     +                           REGIONAL_MONTHLY_MULT(J) *
     +                                   MONTHLY_GAS_AVAIL_MULT(J),1.0)
                        ELSEIF(FT == 3) THEN
                           MONTHLY_EAVAIL(J) =
     +                        MIN(MONTHLY_EAVAIL(J) *
     +                           REGIONAL_MONTHLY_MULT(J) *
     +                                   MONTHLY_OIL_AVAIL_MULT(J),1.0)
                        ELSEIF(FT == 4) THEN
                           MONTHLY_EAVAIL(J) =
     +                        MIN(MONTHLY_EAVAIL(J) *
     +                           REGIONAL_MONTHLY_MULT(J) *
     +                                MONTHLY_NUCLEAR_AVAIL_MULT(J),1.0)
                        ELSEIF(FT == 5) THEN
                           MONTHLY_EAVAIL(J) =
     +                         MONTHLY_EAVAIL(J) *
     +                           REGIONAL_MONTHLY_MULT(J) *
     +                                  MONTHLY_HYDRO_WATER_YEAR_MULT(J)
                        ELSEIF(FT == 6) THEN
                           MONTHLY_EAVAIL(J) =
     +                        MIN(MONTHLY_EAVAIL(J) *
     +                           REGIONAL_MONTHLY_MULT(J) *
     +                                  MONTHLY_OTHER_AVAIL_MULT(J),1.0)
                        ENDIF
                     ENDDO
!
!                  EAVAIL(I) = (100. - EFOR(I))/100.
                  ENDIF
!
!                  CALL GET_FO_HRS1(I,MONTHLY_EAVAIL(INT2(1)),
!
! 11/10/03. DETAILED CONDITIONS.
!
! 02/10/04. TOOK OUT DETAILED_MAIN CONDITION
!
!                  IF(DETAILED_MAINT .AND.
! 070806. ADDED EXTRA CONDITION

                  IF( (FREQUENCY_DURATION .AND.
     +                              MONTE_OR_FREQ(I) == 'G').OR.
     +                 (SCHEDULE_FO .AND.MONTE_OR_FREQ(I) == 'F') ) THEN
                     CALL GET_FO_HRS2(
     +                         I,
     +                         K,
     +                         FOR_FREQUENCY(I),
     +                         FOR_DURATION(I),
     +                         MONTHLY_EAVAIL(INT2(1)))
 !    +                         DUR_UNIT_BEG_FO_HR,DUR_UNIT_END_FO_HR)
                  ELSEIF(SCHEDULE_FO) THEN ! DO I REALLY NEED TO DO DETAILED REGARDLESS OF DETAILED SWITCH?
!                     CALL GET_FO_HRS1(K,MONTHLY_EAVAIL,YEAR_OR_SCEN)
                     CALL GET_FO_HRS1(
     +                         I,
     +                         K,
     +                         MONTHLY_EAVAIL,
     +                         YEAR_OR_SCEN)! 11/24/03. K INDEX
                  ENDIF
!             ELSE
!                CALL GET_FO_HRS2(I,MAX_FO_PER_MONTH,FO_FREQ(I),
!     +               FO_DURA(I),EAVAIL(I),UNIT_BEG_FO_HR,UNIT_END_FO_HR)
!             END IF
!
               ENDDO ! K COUNTER FOR ACTIVE UNITS
               IF(SHADOW_UNITS_ACTIVE) THEN
                  DO I = 1, NUNITS
                     IF(LDTYPE(I) == 'S') THEN
                        MY_SHADOW = SHADOW_UNIT_NUMBER(I)
                        ANNUAL_CL_MAINT_MW(I) =
     +                                     ANNUAL_CL_MAINT_MW(MY_SHADOW)
                        DO MO = 1, 12  ! 7/31/96. GAT. ADDED ANNUAL_CL_CAPACITY.
!
                           ANNUAL_CL_CAPACITY(1,I,MO) =
     +                                ANNUAL_CL_CAPACITY(1,MY_SHADOW,MO)
                           ANNUAL_CL_CAPACITY(2,I,MO) =
     +                                ANNUAL_CL_CAPACITY(2,MY_SHADOW,MO)
!
                           ANNUAL_CL_MAINTENANCE(I,MO) =
     +                               ANNUAL_CL_MAINTENANCE(MY_SHADOW,MO)
                        ENDDO
                        ANNUAL_CL_MAINTENANCE(I,13) =
     +                               ANNUAL_CL_MAINTENANCE(MY_SHADOW,13)
                     ENDIF
                  ENDDO
               ENDIF ! SHADOW UNITS
            ENDIF ! ENDIF FOR MAINT_SCHEDULER
!
! 02/10/04. MOVED THE ADVANCED MAINTENANCE REPORT UP.
!
            IF(MAINTENANCE_REPORT() .AND. .NOT. TESTING_PLAN) THEN
               CALL WRITE_YEARS_CMD_FILE(MAINT_INDEX)
            ENDIF
         ENDDO ! PA PLANNING AREA LOOP
!
!         IF(MAINTENANCE_REPORT() .AND. .NOT. TESTING_PLAN) THEN
         IF(1 == 2) THEN
!
! 11/06/03.
!
!            CALL WRITE_YEARS_CMD_FILE(MAINT_INDEX)
!
            IF(MAINTENANCE_REPORT_NOT_OPEN) THEN
               MAINTENANCE_REPORT_NOT_OPEN = .FALSE.
               CL_MAINT_NO=MAINTENANCE_HEADER(MW_MAINT_NO,
     +                                        CL_MAINT_REC,
     +                                        MW_MAINT_REC)
            ENDIF
            GROUP_MW_MAINTENANCE = 0.
            TOTAL_MONTHLY_MAINTENANCE = 0.
            DO I = 1, NUNITS
C
C CALCULATE MONTHLY MAINTENANCE CAPACITY BY REPORTING GROUP
C
               IF(ONLINE(I) <= DATE1 .AND. OFLINE(I) >= DATE1) THEN
                  GGI = GENGRP(I)
                  IF(GGI < 1 .OR. GGI > MAX_REPORTING_GROUPS) GGI = 0
                  DO MO = 1, 12
                     MAINTENANCE_CAPACITY = ANNUAL_CL_MAINTENANCE(I,MO)*
     +                                        ANNUAL_CL_CAPACITY(2,I,MO)
                     GROUP_MW_MAINTENANCE(MO,GGI)=MAINTENANCE_CAPACITY +
     +                                      GROUP_MW_MAINTENANCE(MO,GGI)
                     TOTAL_MONTHLY_MAINTENANCE(MO)=MAINTENANCE_CAPACITY+
     +                                     TOTAL_MONTHLY_MAINTENANCE(MO)
                     GROUP_MW_MAINTENANCE(0,GGI)=MAINTENANCE_CAPACITY *
     +                                              DAYS_PER_MONTH(MO) +
     +                                       GROUP_MW_MAINTENANCE(0,GGI)
                     TOTAL_MONTHLY_MAINTENANCE(0)=MAINTENANCE_CAPACITY *
     +                                              DAYS_PER_MONTH(MO) +
     +                                      TOTAL_MONTHLY_MAINTENANCE(0)
                  ENDDO
               ENDIF
C
               IF(EFOR(I) < 0.) THEN
                  FOR_MT = (100. - GET_VAR(EFOR(I),YEAR,UNITNM(I)))/100.
               ELSE
                  FOR_MT = (100. - EFOR(I))/100.
               ENDIF
               WRITE(CL_MAINT_NO,REC=CL_MAINT_REC)
     +              PRT_ENDPOINT(),
     +              FLOAT(YEAR+BASE_YEAR),
     +              UNITNM(I),
     +              (ANNUAL_CL_MAINTENANCE(I,J)*100.,J=1,12),
     +              100.*ANNUAL_CL_MAINTENANCE(I,13)/DAYS_PER_MONTH(13),
     +              (DAYS_PER_MONTH(J) *
     +                          ANNUAL_CL_MAINTENANCE(I,J),J=1,12),
     +              ANNUAL_CL_MAINTENANCE(I,13),
     +              (100.*(1. - ANNUAL_CL_MAINTENANCE(I,J))*
     +                                                   FOR_MT,J=1,12),
     +              (1.-ANNUAL_CL_MAINTENANCE(I,13)/DAYS_PER_MONTH(13))
     +                                                     *100.* FOR_MT
               CL_MAINT_REC = CL_MAINT_REC + 1
            ENDDO
            DO GGI = 0,MAX_REPORTING_GROUPS
               GROUP_MW_MAINTENANCE(0,GGI)=GROUP_MW_MAINTENANCE(0,GGI)/
     +                                                DAYS_PER_MONTH(13)
               WRITE(MW_MAINT_NO,REC=MW_MAINT_REC)
     +              PRT_ENDPOINT(),
     +              FLOAT(YEAR+BASE_YEAR),
     +              GROUP_NAME(GGI),
     +              (GROUP_MW_MAINTENANCE(MO,GGI),MO=0,12)
               MW_MAINT_REC = MW_MAINT_REC + 1
            ENDDO
            TOTAL_MONTHLY_MAINTENANCE(0)= TOTAL_MONTHLY_MAINTENANCE(0)/
     +                                                DAYS_PER_MONTH(13)
            WRITE(MW_MAINT_NO,REC=MW_MAINT_REC)
     +             PRT_ENDPOINT(),
     +              FLOAT(YEAR+BASE_YEAR),
     +              'Totals   ',
     +              (TOTAL_MONTHLY_MAINTENANCE(MO),MO=0,12)
            MW_MAINT_REC = MW_MAINT_REC + 1
         ENDIF
!
         CALC_ANNUAL_CAP_AND_MAINT = .TRUE.
      RETURN
!
C***********************************************************************
      ENTRY GET_MAX_FO_PER_MONTH
C***********************************************************************
         GET_MAX_FO_PER_MONTH = MAX_FO_PER_MONTH
      RETURN
! 030207. CALLED ANNUALLY FROM TRANSOBJ.FOR
C***********************************************************************
      ENTRY PROCESS_MARKET_RESOURCES(R_TG,R_AREA_PRICE)
C***********************************************************************
!
! 09/23/03. CHANGED TO CYCLE OVER MULTIPLE TRANSACTION GROUPS (R_TG).
! ONLY ACTIVE IN TRANSACT C.
!
         PROCESS_MARKET_RESOURCES = .FALSE.
         DO TG = 1, R_TG
            IF(YES_RUN_TRANSACT() .AND. (MARKET_COUNT > 0 .OR.
     +                       GET_NUM_ANNUAL_DERIVATIVES(TG) > 0)) THEN
!
               IF(R_AREA_PRICE) THEN
                  FILE_NAME = trim(PRB_FILE_DIRECTORY())//"PRB"//
     +                       trim(GET_HOURLY_PRICE_NAME(TG))//
     +                        LOAD_FILE_CHAR_EXT(END_POINT)//".P"//
     +                   LOAD_FILE_CHAR_EXT(GET_MARKET_PRICE_YEAR(YEAR))
!
! 10/02/03. ADDED FOR FE. GO GET THE FIRST END_POINT AGAIN.
!
                  INQUIRE(FILE=FILE_NAME,EXIST=FILE_EXISTS)
                  IF(.NOT. FILE_EXISTS .AND. END_POINT > 1) THEN
                     FILE_NAME = trim(PRB_FILE_DIRECTORY())//"PRB"//
     +                       trim(GET_HOURLY_PRICE_NAME(TG))//
     +                        LOAD_FILE_CHAR_EXT(INT2(1))//".P"//
     +                   LOAD_FILE_CHAR_EXT(GET_MARKET_PRICE_YEAR(YEAR))
                  ENDIF
!
               ELSE
                  CALL GET_NEW_MARKET_PRICE_NAME(MARKET_PRICE_NAME)
                  FILE_NAME = trim(PRB_FILE_DIRECTORY())//"PRB"//
     +                              trim(MARKET_PRICE_NAME)//".P"//
     +                   LOAD_FILE_CHAR_EXT(GET_MARKET_PRICE_YEAR(YEAR))
               ENDIF
!
               CALL READ_USER_MARKET_ANNUAL(YEAR,
     +                              YEAR+BASE_YEAR,
     +                              TG, ! TRANS_GROUP
     +                              FILE_NAME, ! PRICE FILE NAME
     +                              END_POINT,
     +                              R_AREA_PRICE) ! ENDPOINT
!
!
! 10/14/02. FOR FIRST ENERGY
!
               TEMP_L = ANNUAL_CALL_PUT_CAPACITY(YEAR+BASE_YEAR,TG)
!
!
!            THIS_YEAR = YEAR + BASE_YEAR
!            TEMP_L = ANNUAL_CALL_PUT_CAPACITY(
!     +                     TG,
!     +                     THIS_YEAR)
!
               IF(MARKET_COUNT > 0) THEN
                  CALL PickHrStrInitArrays(MARKET_COUNT,
     +                               INT2(2),
     +                               INT2(8800))
                  CALL SortPricesForYear(YEAR+BASE_YEAR)
                  DO I = 1, MARKET_COUNT
                     J = MARKET_RESOURCE_INDEX(I)
!
                     LOCAL_COEFF(1) = COEFF(1,J)
                     LOCAL_COEFF(2) = COEFF(2,J)
                     LOCAL_COEFF(3) = COEFF(3,J)
!
                     CALL GET_MONTHLY_DISP_COST_BY_UNIT(
     +                                            J,
     +                                            LOCAL_COEFF,
     +                                            MONTHLY_DISPATCH_COST)
!     +                     TWO_BLOCK,
!     +                     MONTHLY_DISPATCH_COST,
!     +                     MONTHLY_DISP_BTU_COST,
!     +                     DISP_BTU_TAX_ADDER)
!               CALL CINITD(MONTHLY_DISPATCH_COST,INT(24),20.)
                     DO MO = 1, 12
                        MONTHLY_CAPACITY(1,MO) =
     +                                        ANNUAL_CL_CAPACITY(1,J,MO)
                        MONTHLY_CAPACITY(2,MO) =
     +                     MAX(0.,ANNUAL_CL_CAPACITY(2,J,MO) -
     +                                       ANNUAL_CL_CAPACITY(1,J,MO))
                        IF(ANNUAL_CL_MAINTENANCE(J,MO) == 1.) THEN
                           MONTHLY_INTEGER(MO) = 0
                        ELSE
                           IF(MONTHLY_CAPACITY_POINTER(J) < 0) THEN
!                              MONTHLY_INTEGER(MO) =
                              TEMP_R4 = GET_VAR(FLOAT(
     +                                     MONTHLY_CAPACITY_POINTER(J)),
     +                                                     MO,UNITNM(J))
                              IF(TEMP_R4 < .001) THEN
                                 MONTHLY_INTEGER(MO) = 0
                              ELSE
                                 MONTHLY_INTEGER(MO) = 1
                              ENDIF
                           ELSE
                              MONTHLY_INTEGER(MO) = 1
                           ENDIF
                        ENDIF
                     ENDDO
!
! 10/29/03. TESTING.
!
                     STARTS_ONLY = .TRUE.
!
                     CALL PickStrikesForUnit(
     +                  I,
     +                  2_2,
     +                  MONTHLY_CAPACITY,
     +                  MONTHLY_DISPATCH_COST,
     +                  INT2(MINIMUM_CAPACITY_FACTOR(J)),
     +                  INT2(MAXIMUM_CAPACITY_FACTOR(J)),
     +                  MONTHLY_INTEGER,
     +                  STARTS_ONLY)
                  ENDDO
               ENDIF
               PROCESS_MARKET_RESOURCES = .TRUE.
            ENDIF
         ENDDO
       RETURN
C***********************************************************************
      ENTRY IS_A_MARKET_RESOURCE(R_UNIT_NO)
C***********************************************************************
         IS_A_MARKET_RESOURCE = MARKET_RESOURCE(R_UNIT_NO) == 'T' .OR.
     +                                 MARKET_RESOURCE(R_UNIT_NO) == 'D'
      RETURN
C***********************************************************************
      ENTRY IS_STRICT_MARKET_RESOURCE(R_UNIT_NO,R_MARKET_RESOURCE_STR)
C***********************************************************************
!         DSM_MARKET_W_LOAD_BALIS_STRICT_MARKET_RESOURCE = MARKET_RESOURCE(R_UNIT_NO) == 'M'
         R_MARKET_RESOURCE_STR = MARKET_RESOURCE(R_UNIT_NO)
         IF(MARKET_RESOURCE(R_UNIT_NO) == 'M') THEN
            IS_STRICT_MARKET_RESOURCE = .TRUE.
         ELSE
            IS_STRICT_MARKET_RESOURCE = .FALSE.
         ENDIF
      RETURN
C***********************************************************************
      ENTRY GET_MARKET_RESOURCE_INDEX(R_UNIT_NO)
C***********************************************************************
         GET_MARKET_RESOURCE_INDEX = MARKET_RESOURCE_INDEX(R_UNIT_NO)
      RETURN
C***********************************************************************
      ENTRY GET_MARKET_RESOURCE_COUNTER(R_UNIT_NO)
C***********************************************************************
         IF(ALLOCATED(MARKET_RESOURCE_COUNTER) .AND.
     +                                         R_UNIT_NO <= NUNITS) THEN
            GET_MARKET_RESOURCE_COUNTER =
     +                               MARKET_RESOURCE_COUNTER(R_UNIT_NO)
         ELSE
            GET_MARKET_RESOURCE_COUNTER = 0
         ENDIF
      RETURN
C***********************************************************************
      ENTRY GET_FUEL_DELIVERY(  R_I,
     +                          R_FUEL_DELIVERY_1,
     +                          R_FUEL_DELIVERY_2,
     +                          R_FUEL_DELIVERY_3)
C***********************************************************************
         R_FUEL_DELIVERY_1 = P_FUEL_DELIVERY_1(R_I)
         R_FUEL_DELIVERY_2 = P_FUEL_DELIVERY_2(R_I)
         R_FUEL_DELIVERY_3 = P_FUEL_DELIVERY_3(R_I)
         GET_FUEL_DELIVERY = PBTUCT(R_I)
      RETURN
C***********************************************************************
      ENTRY GET_SECOND_FUEL_DELIVERY(
     +                          R_I,
     +                          R_FUEL_DELIVERY_1,
     +                          R_FUEL_DELIVERY_2,
     +                          R_FUEL_DELIVERY_3)
C***********************************************************************
         R_FUEL_DELIVERY_1 = S_FUEL_DELIVERY(R_I)
         R_FUEL_DELIVERY_2 = S_FUEL_DELIVERY_2(R_I)
         R_FUEL_DELIVERY_3 = S_FUEL_DELIVERY_3(R_I)
         GET_SECOND_FUEL_DELIVERY = SBTUCT(R_I)
      RETURN
C***********************************************************************
      ENTRY UNSCHEDULED_MAINT_HOURS(R_UNIT_NO)
C***********************************************************************
         IF(MAINT_DAYS(R_UNIT_NO) /= 0.) THEN
            IF(MAINT_DAYS(R_UNIT_NO) < 0.) THEN
               UNSCHEDULED_MAINT_HOURS = GET_VAR(MAINT_DAYS(R_UNIT_NO),
     +                                           YEAR,UNITNM(R_UNIT_NO))
            ELSE
               UNSCHEDULED_MAINT_HOURS = MAINT_DAYS(R_UNIT_NO)
            ENDIF
         ENDIF
         UNSCHEDULED_MAINT_HOURS = UNSCHEDULED_MAINT_HOURS*7.*24.
      RETURN
C***********************************************************************
      ENTRY UPDATE_PERIOD_CAPACITY(R_I,R_J)
C***********************************************************************
         UPDATE_PERIOD_CAPACITY = .FALSE.
         IF(.NOT. ALLOCATED(ANNUAL_CL_CAPACITY)) RETURN
         I = R_I
         J = R_J
         IF(I/=NUNITS) THEN
            UPDATE_PERIOD_CAPACITY = .FALSE.
            RETURN
         ENDIF
c         CALL MOVBYTES(
c     +           ANNUAL_CL_CAPACITY,2*(J-1)*NUNITS*4+1,MW,1,2*NUNITS*4)
         DO J = 1, NUNITS
            DO I = 1, 2
              MW(I,J) = ANNUAL_CL_CAPACITY(I,J,R_J)
            ENDDO
         ENDDO
         UPDATE_PERIOD_CAPACITY = .TRUE.
      RETURN
C***********************************************************************
      ENTRY GET_ANNUAL_CL_CAPACITY(R_I,R_J,R_MONTH)
C***********************************************************************
         IF(ALLOCATED(ANNUAL_CL_CAPACITY) .AND. R_J <= NUNITS) THEN
            GET_ANNUAL_CL_CAPACITY = ANNUAL_CL_CAPACITY(R_I,R_J,R_MONTH)
         ELSE
            GET_ANNUAL_CL_CAPACITY = 0.
         ENDIF
      RETURN
C***********************************************************************
      ENTRY GET_MAINTENANCE_RATE_FOR_MONTH(R_UNIT_NO,R_MONTH)
C***********************************************************************
         IF(ALLOCATED(ANNUAL_CL_MAINTENANCE)) THEN
            GET_MAINTENANCE_RATE_FOR_MONTH =
     +                          ANNUAL_CL_MAINTENANCE(R_UNIT_NO,R_MONTH)
         ELSE
            GET_MAINTENANCE_RATE_FOR_MONTH = 0.
         ENDIF
      RETURN
C***********************************************************************
      ENTRY UPDATE_PERIOD_MAINTENANCE(R_I,R_J,MAINTENANCE_RATE)
C***********************************************************************
         I = R_I
         J = R_J
         IF(I/=NUNITS) THEN
            UPDATE_PERIOD_MAINTENANCE = .FALSE.
            RETURN
         ENDIF
c         CALL MOVBYTES(ANNUAL_CL_MAINTENANCE,(J-1)*NUNITS*4+1,
c     +                                      MAINTENANCE_RATE,1,NUNITS*4)
         DO I = 1, NUNITS
            MAINTENANCE_RATE(I) = ANNUAL_CL_MAINTENANCE(I,J)
         ENDDO
         UPDATE_PERIOD_MAINTENANCE = .TRUE.
      RETURN
C***********************************************************************
      ENTRY UPDATE_PR_ESCALATIONS(R_YEAR,R_POINTER)
C***********************************************************************
C
C
      VOID_INT2 =
     +     ESCALATE_ONE_VALUE_FOR_ADDITIONS(PBTUCT(R_POINTER),R_POINTER,
     +                       PFESCR(R_POINTER),UNITNM(R_POINTER),R_YEAR)
      VOID_INT2 =
     +     ESCALATE_ONE_VALUE_FOR_ADDITIONS(SBTUCT(R_POINTER),R_POINTER,
     +                       SFESCR(R_POINTER),UNITNM(R_POINTER),R_YEAR)
      VOID_INT2 =
     +      ESCALATE_ONE_VALUE_FOR_ADDITIONS(EMISS_FUEL_COST(R_POINTER),
     +                     R_POINTER,EMISS_FUEL_ESCAL(R_POINTER),
     +                                         UNITNM(R_POINTER),R_YEAR)
      VOID_INT2 =
     +  ESCALATE_ONE_VALUE_FOR_ADDITIONS(VCPMWH_IN(R_POINTER),R_POINTER,
     +                       OMESCR(R_POINTER),UNITNM(R_POINTER),R_YEAR)
      VOID_INT2 =
     +    ESCALATE_ONE_VALUE_FOR_ADDITIONS(CL_AI_ENERGY_RATE(R_POINTER),
     +               R_POINTER,CL_AI_ENERGY_ESCALATOR(R_POINTER),
     +                                         UNITNM(R_POINTER),R_YEAR)
      VOID_INT2 =
     +  ESCALATE_ONE_VALUE_FOR_ADDITIONS(CL_AI_CAPACITY_RATE(R_POINTER),
     +            R_POINTER,CL_AI_CAPACITY_ESCALATOR(R_POINTER),
     +                                         UNITNM(R_POINTER),R_YEAR)
      VOID_INT2 =
     + ESCALATE_ONE_VALUE_FOR_ADDITIONS(FIXED_COST_IN(R_POINTER),
     +                        R_POINTER,FIXED_COST_ESCALATOR(R_POINTER),
     +                        UNITNM(R_POINTER),R_YEAR)
      VOID_INT2 =
     + ESCALATE_ONE_VALUE_FOR_ADDITIONS(ANNUAL_CL_FIXED_COST(R_POINTER),
     +            R_POINTER,ANNUAL_CL_FIXED_COST_ESC(R_POINTER),
     +                                         UNITNM(R_POINTER),R_YEAR)
C         VOID_INT2 = ESCALATE_FUEL_ADDER_VALUES(FUELADJ(R_POINTER),
C     +                             PFESCR(R_POINTER))
C
      UPDATE_PR_ESCALATIONS = R_POINTER
C
      RETURN
C***********************************************************************
!      ENTRY INIT_MON_MDS_CL_UNITS(R_NUNITS,R_LAST_NUNITS)
      ENTRY INIT_MON_MDS_CL_UNITS(R_NUNITS)
C***********************************************************************
!
!         IF(R_NUNITS /= R_LAST_NUNITS) THEN
            IF(ALLOCATED(MON_MDS_CL_UNIT_FUEL_COST))
     +         DEALLOCATE(MON_MDS_CL_UNIT_EMISSIONS, ! DONE
     +                    MON_MDS_CL_UNIT_EMISSIONS_COST,
     +                    MON_MDS_CL_UNIT_CAPACITY, ! DONE
     +                    MON_MDS_CL_UNIT_ENERGY, ! DONE
     +                    MON_MDS_CL_UNIT_FUEL_COST, ! DONE
     +                    MON_MDS_CL_UNIT_VAR_COST, ! DONE
     +                    MON_MDS_CL_UNIT_FIXED_COST, ! DONE
     +                    MON_MDS_NUC_FUEL_ADDER_COST, ! DONE
     +                    MON_MDS_ECO_SALES_REV_FROM, ! DONE
     +                    MON_MDS_ECO_SALES_ENRG_FROM, ! DONE
     +                    MON_MDS_ECO_PUCH_COST_FROM, ! DONE
     +                    MON_MDS_ECO_PUCH_ENRG_FROM, ! DONE
     +                    MON_MDS_ICAP_REVENUES,
     +                    MON_MDS_CL_UNIT_MMBTUS) ! DONE
!
            ALLOCATE(MON_MDS_CL_UNIT_EMISSIONS(
     +                          NUMBER_OF_EMISSION_TYPES,R_NUNITS,0:12))
            ALLOCATE(MON_MDS_CL_UNIT_EMISSIONS_COST(
     +                          NUMBER_OF_EMISSION_TYPES,R_NUNITS,0:12))
            ALLOCATE(MON_MDS_CL_UNIT_CAPACITY(R_NUNITS,0:12))
            ALLOCATE(MON_MDS_CL_UNIT_ENERGY(R_NUNITS,0:12))
            ALLOCATE(MON_MDS_CL_UNIT_FUEL_COST(R_NUNITS,0:12))
            ALLOCATE(MON_MDS_CL_UNIT_VAR_COST(R_NUNITS,0:12))
            ALLOCATE(MON_MDS_CL_UNIT_FIXED_COST(R_NUNITS,0:12))
            ALLOCATE(MON_MDS_NUC_FUEL_ADDER_COST(R_NUNITS,0:12))
            ALLOCATE(MON_MDS_ECO_SALES_REV_FROM(R_NUNITS,0:12))
            ALLOCATE(MON_MDS_ECO_SALES_ENRG_FROM(R_NUNITS,0:12))
            ALLOCATE(MON_MDS_ECO_PUCH_COST_FROM(R_NUNITS,0:12))
            ALLOCATE(MON_MDS_ECO_PUCH_ENRG_FROM(R_NUNITS,0:12))
            ALLOCATE(MON_MDS_ICAP_REVENUES(R_NUNITS,0:12))
            ALLOCATE(MON_MDS_CL_UNIT_MMBTUS(R_NUNITS,0:12))
!         ENDIF
!
         MON_MDS_CL_UNIT_CAPACITY = 0.
         MON_MDS_CL_UNIT_ENERGY = 0.
         MON_MDS_CL_UNIT_FUEL_COST = 0.
         MON_MDS_CL_UNIT_VAR_COST = 0.
         MON_MDS_CL_UNIT_FIXED_COST = 0.
         MON_MDS_NUC_FUEL_ADDER_COST = 0.
         MON_MDS_ECO_SALES_REV_FROM = 0.
         MON_MDS_ECO_SALES_ENRG_FROM = 0.
         MON_MDS_ECO_PUCH_COST_FROM = 0.
         MON_MDS_ECO_PUCH_ENRG_FROM = 0.
         MON_MDS_ICAP_REVENUES = 0.
!
         MON_MDS_CL_UNIT_MMBTUS = 0.0D0
!
         MON_MDS_CL_UNIT_EMISSIONS = 0.
         MON_MDS_CL_UNIT_EMISSIONS_COST = 0.
!
         INIT_MON_MDS_CL_UNITS = .TRUE.
! 8/30/01
         PRICE_ONLY_WHOLESALE_REV = APPLY_TRANS_REV_TO_WHOLESALE()
! 9/02/01
         DETAILED_TRANSFER_PRICING = YES_DETAILED_TRANSFER_PRICING()
!
      RETURN
C***********************************************************************
      ENTRY MON_MDS_CL_VAR(R_ISEAS,R_YR,R_UNITNO,R_FUEL_COST,
     +                     R_ENRG,R_HEAT,R_EMIS,R_VOM_COST)
C***********************************************************************
! MONTH
			MON_MDS_CL_UNIT_ENERGY(R_UNITNO,R_ISEAS) = R_ENRG +
     +                          MON_MDS_CL_UNIT_ENERGY(R_UNITNO,R_ISEAS)
			MON_MDS_CL_UNIT_FUEL_COST(R_UNITNO,R_ISEAS) =
     +                     MON_MDS_CL_UNIT_FUEL_COST(R_UNITNO,R_ISEAS) +
     +                                                       R_FUEL_COST
			MON_MDS_CL_UNIT_VAR_COST(R_UNITNO,R_ISEAS) =
     +                  MON_MDS_CL_UNIT_VAR_COST(R_UNITNO,R_ISEAS) +
     +                                      R_VOM_COST
			MON_MDS_CL_UNIT_MMBTUS(R_UNITNO,R_ISEAS) =
     +                        MON_MDS_CL_UNIT_MMBTUS(R_UNITNO,R_ISEAS) +
     +                                                            R_HEAT
			MON_MDS_CL_UNIT_EMISSIONS(:,R_UNITNO,R_ISEAS) =
     +                     MON_MDS_CL_UNIT_EMISSIONS(:,R_UNITNO,R_ISEAS)
     +                     + R_EMIS(:)
C			MON_MDS_CL_UNIT_EMISSIONS(1,R_UNITNO,R_ISEAS) =
C     +                   MON_MDS_CL_UNIT_EMISSIONS(1,R_UNITNO,R_ISEAS) +
C     +                                                         R_EMIS(1)C
C			MON_MDS_CL_UNIT_EMISSIONS(2,R_UNITNO,R_ISEAS) =
C     +                   MON_MDS_CL_UNIT_EMISSIONS(2,R_UNITNO,R_ISEAS) +
C     +                                                         R_EMIS(2)C
C			MON_MDS_CL_UNIT_EMISSIONS(3,R_UNITNO,R_ISEAS) =
C     +                   MON_MDS_CL_UNIT_EMISSIONS(3,R_UNITNO,R_ISEAS) +
C     +                                                         R_EMIS(3)
C			MON_MDS_CL_UNIT_EMISSIONS(4,R_UNITNO,R_ISEAS) =
C     +                   MON_MDS_CL_UNIT_EMISSIONS(4,R_UNITNO,R_ISEAS) +
C     +                                                         R_EMIS(4)
C			MON_MDS_CL_UNIT_EMISSIONS(5,R_UNITNO,R_ISEAS) =
C     +                   MON_MDS_CL_UNIT_EMISSIONS(5,R_UNITNO,R_ISEAS) +
C     +                                                         R_EMIS(5)
         DO I4 =  1, 5
            MON_MDS_CL_UNIT_EMISSIONS_COST(I4,R_UNITNO,R_ISEAS) =
     +            MON_MDS_CL_UNIT_EMISSIONS_COST(I4,R_UNITNO,R_ISEAS)
     +            + R_EMIS(I4) * 0.002 *
     +               TRANS_DISPATCH_EMIS_ADDER(I4,R_ISEAS,R_YR,R_UNITNO)
            MON_MDS_CL_UNIT_EMISSIONS_COST(I4,R_UNITNO,0) =
     +            MON_MDS_CL_UNIT_EMISSIONS_COST(I4,R_UNITNO,0)
     +            + R_EMIS(I4) * 0.002 *
     +               TRANS_DISPATCH_EMIS_ADDER(I4,R_ISEAS,R_YR,R_UNITNO)
         ENDDO
! ANNUAL
			MON_MDS_CL_UNIT_ENERGY(R_UNITNO,0) = R_ENRG
     +                              + MON_MDS_CL_UNIT_ENERGY(R_UNITNO,0)
			MON_MDS_CL_UNIT_FUEL_COST(R_UNITNO,0) =
     +                             MON_MDS_CL_UNIT_FUEL_COST(R_UNITNO,0)
     +                             + R_FUEL_COST
			MON_MDS_CL_UNIT_VAR_COST(R_UNITNO,0) =
     +                              MON_MDS_CL_UNIT_VAR_COST(R_UNITNO,0)
     +                              + R_VOM_COST
			MON_MDS_CL_UNIT_MMBTUS(R_UNITNO,0) =
     +                                MON_MDS_CL_UNIT_MMBTUS(R_UNITNO,0)
     +                                + R_HEAT
			MON_MDS_CL_UNIT_EMISSIONS(:,R_UNITNO,0) =
     +                   MON_MDS_CL_UNIT_EMISSIONS(:,R_UNITNO,0)
     +                   + R_EMIS(:)
C			MON_MDS_CL_UNIT_EMISSIONS(1,R_UNITNO,0) =
C     +                   MON_MDS_CL_UNIT_EMISSIONS(1,R_UNITNO,0) +
C     +                                                         R_EMIS(1)
C			MON_MDS_CL_UNIT_EMISSIONS(2,R_UNITNO,0) =
C     +                   MON_MDS_CL_UNIT_EMISSIONS(2,R_UNITNO,0) +
C     +                                                         R_EMIS(2)
C			MON_MDS_CL_UNIT_EMISSIONS(3,R_UNITNO,0) =
C     +                   MON_MDS_CL_UNIT_EMISSIONS(3,R_UNITNO,0) +
C     +                                                         R_EMIS(3)
C			MON_MDS_CL_UNIT_EMISSIONS(4,R_UNITNO,0) =
C     +                   MON_MDS_CL_UNIT_EMISSIONS(4,R_UNITNO,0) +
C     +                                                         R_EMIS(4)
C			MON_MDS_CL_UNIT_EMISSIONS(5,R_UNITNO,0) =
C     +                   MON_MDS_CL_UNIT_EMISSIONS(5,R_UNITNO,0) +
C     +                                                         R_EMIS(5)
!
            MON_MDS_CL_VAR = .TRUE.
!
      RETURN
!
C***********************************************************************
      ENTRY MON_MDS_CL_FIXED(R_ISEAS,R_UNITNO,R_FIXED_COST,R_CAP)
C***********************************************************************
! MONTH
	   MON_MDS_CL_UNIT_CAPACITY(R_UNITNO,R_ISEAS) = R_CAP +
     +                        MON_MDS_CL_UNIT_CAPACITY(R_UNITNO,R_ISEAS)
	   MON_MDS_CL_UNIT_FIXED_COST(R_UNITNO,R_ISEAS) =
     +                  MON_MDS_CL_UNIT_FIXED_COST(R_UNITNO,R_ISEAS) +
     +                                                      R_FIXED_COST
!
!     SALES
         MON_MDS_ECO_SALES_REV_FROM(R_UNITNO,R_ISEAS) =
     +                    MON_MDS_ECO_SALES_REV_FROM(R_UNITNO,R_ISEAS) +
     +                                  MON_ECO_SALES_REV_FROM(R_UNITNO)
         MON_MDS_ECO_SALES_ENRG_FROM(R_UNITNO,R_ISEAS) =
     +                   MON_MDS_ECO_SALES_ENRG_FROM(R_UNITNO,R_ISEAS) +
     +                                 MON_ECO_SALES_ENRG_FROM(R_UNITNO)
!     PURCHASES
!         IF(.NOT. PRICE_ONLY_WHOLESALE_REV) THEN
         MON_MDS_ECO_PUCH_COST_FROM(R_UNITNO,R_ISEAS) =
     +                    MON_MDS_ECO_PUCH_COST_FROM(R_UNITNO,R_ISEAS) +
     +                                  MON_ECO_PUCH_COST_FROM(R_UNITNO)
         MON_MDS_ECO_PUCH_ENRG_FROM(R_UNITNO,R_ISEAS) =
     +                    MON_MDS_ECO_PUCH_ENRG_FROM(R_UNITNO,R_ISEAS) +
     +                                  MON_ECO_PUCH_ENRG_FROM(R_UNITNO)
!         ENDIF
! ANNUAL
	   MON_MDS_CL_UNIT_CAPACITY(R_UNITNO,0) = R_CAP +
     +                        MON_MDS_CL_UNIT_CAPACITY(R_UNITNO,0)
	   MON_MDS_CL_UNIT_FIXED_COST(R_UNITNO,0) =
     +                  MON_MDS_CL_UNIT_FIXED_COST(R_UNITNO,0) +
     +                                                      R_FIXED_COST
!
!     SALES
         MON_MDS_ECO_SALES_REV_FROM(R_UNITNO,0) =
     +                    MON_MDS_ECO_SALES_REV_FROM(R_UNITNO,0) +
     +                                  MON_ECO_SALES_REV_FROM(R_UNITNO)
         MON_MDS_ECO_SALES_ENRG_FROM(R_UNITNO,0) =
     +                   MON_MDS_ECO_SALES_ENRG_FROM(R_UNITNO,0) +
     +                                 MON_ECO_SALES_ENRG_FROM(R_UNITNO)
!     PURCHASES
!         IF(.NOT. PRICE_ONLY_WHOLESALE_REV) THEN
         MON_MDS_ECO_PUCH_COST_FROM(R_UNITNO,0) =
     +                    MON_MDS_ECO_PUCH_COST_FROM(R_UNITNO,0) +
     +                                  MON_ECO_PUCH_COST_FROM(R_UNITNO)
         MON_MDS_ECO_PUCH_ENRG_FROM(R_UNITNO,0) =
     +                    MON_MDS_ECO_PUCH_ENRG_FROM(R_UNITNO,0) +
     +                                  MON_ECO_PUCH_ENRG_FROM(R_UNITNO)
!         ENDIF
! ICAP REVENUES
         MON_MDS_ICAP_REVENUES(R_UNITNO,R_ISEAS) =
     +                MON_MDS_ICAP_REVENUES(R_UNITNO,R_ISEAS) +
     +                                   MONTHLY_ICAP_REVENUES(R_UNITNO)
         MON_MDS_ICAP_REVENUES(R_UNITNO,0) =
     +                MON_MDS_ICAP_REVENUES(R_UNITNO,0) +
     +                                   MONTHLY_ICAP_REVENUES(R_UNITNO)
!
         MON_MDS_CL_FIXED = .TRUE.
      RETURN
C***********************************************************************
      ENTRY MON_MDS_NUC_ADDER(R_ISEAS,R_UNITNO,
     +                        R_NUC_UNIT_FUEL_ADDER_COST)
C***********************************************************************
! MONTHLY
         MON_MDS_NUC_FUEL_ADDER_COST(R_UNITNO,R_ISEAS) =
     +                                        R_NUC_UNIT_FUEL_ADDER_COST
! ANNUAL
         MON_MDS_NUC_FUEL_ADDER_COST(R_UNITNO,0) =
     +                  MON_MDS_NUC_FUEL_ADDER_COST(R_UNITNO,0) +
     +                     MON_MDS_NUC_FUEL_ADDER_COST(R_UNITNO,R_ISEAS)
         MON_MDS_NUC_ADDER = .TRUE.
      RETURN
C***********************************************************************
      ENTRY RETURN_MAX_CL_CLASS_NUM
C***********************************************************************
         RETURN_MAX_CL_CLASS_NUM = MAX_CAP_LIMITED_CLASS_ID_NUM
      RETURN
C***********************************************************************
      ENTRY GET_CL_ASSET_CLASS_INFO(R_ASSET_CLASS_NUM,R_ASSET_VECTOR)
C***********************************************************************
         DO I = 1, NUNITS
            R_ASSET_CLASS_NUM(I) = ASSET_CLASS_NUM(I)
            R_ASSET_VECTOR(I) = ASSET_CLASS_VECTOR(I)
         ENDDO
         GET_CL_ASSET_CLASS_INFO = NUMBER_OF_CAP_LIMITED_CLASSES
      RETURN
C***********************************************************************
      ENTRY SET_UP_CL_CLASS_ARRAYS
C***********************************************************************
C
         IF(ALLOCATED(ASSET_CLASS_POINTER))
     +                                   DEALLOCATE(ASSET_CLASS_POINTER)
         CALL RETURN_INITIALIZATION_CLASSES(
     +                                    NUMBER_OF_CAP_LIMITED_CLASSES,
     +                                     MAX_CAP_LIMITED_CLASS_ID_NUM)
         IF(MAX_CAP_LIMITED_CLASS_ID_NUM > 0) THEN
            ALLOCATE(ASSET_CLASS_POINTER(MAX_CAP_LIMITED_CLASS_ID_NUM))
            CALL RETURN_INITIALIZATION_POINTER(ASSET_CLASS_POINTER)
         ENDIF
         IF(ALLOCATED(CL_ANN_CLASS_FUEL_COST))
     +                    DEALLOCATE(CL_ANN_CLASS_FUEL_COST,
     +                               CL_ANN_MULT_FUEL_COST,
     +                               FE_ANN_MULT_FUEL_COST,
     +                               NF_FUEL_LEASED_BY_CLASS,
     +                               NUC_FUEL_LEASED_BURN_BY_CLASS,
     +                               NUC_FUEL_OWNED_BURN_BY_CLASS,
     +                               NUCLEAR_MWH_BY_CLASS,
     +                               NUCLEAR_MMBTU_BY_CLASS,
     +                               NF_FUEL_OWNED_BY_CLASS,
     +                               CL_ANN_CLASS_VAR_COST,
     +                               CL_ANN_CLASS_FIXED_COST,
     +                               CL_ANN_CLASS_REVENUE,
     +                               CL_ANN_CLASS_CAPACITY,
     +                               CL_ANN_CLASS_PURCHASES,
     +                               CL_ANN_CLASS_ENERGY,
     +                               CL_ANN_CLASS_EMISSIONS,
     +                               CL_ANN_MULT_VAR_COST,
     +                               CL_ANN_MULT_FIXED_COST,
     +                               CL_ANN_MULT_REVENUE,
     +                               CL_ANN_MULT_CAPACITY,
     +                               CL_ANN_MULT_PURCHASES,
     +                               CL_ANN_MULT_ENERGY,
     +                               INTRA_COMPANY_REVENUES,
     +                               INTRA_COMPANY_NF_BURN,
     +                               MON_MDS_CL_CLASS_FUEL_COST,
     +                               MON_MDS_CL_MULT_FUEL_COST,
     +                               MON_MDS_CL_MULT_VAR_COST,
     +                               MON_MDS_CL_MULT_FIXED_COST,
     +                               MON_MDS_CL_MULT_CAPACITY,
     +                               MON_MDS_CL_MULT_ENERGY,
     +                               MON_MDS_CL_MULT_PURCHASES,
     +                               MON_MDS_CL_CLASS_VAR_COST,
     +                               MON_MDS_CL_CLASS_FIXED_COST,
     +                               MON_MDS_CL_CLASS_REVENUE,
     +                               MON_MDS_CL_CAP_REVENUE,
     +                               MON_MDS_CL_CLASS_CAPACITY,
     +                               MON_MDS_CL_CLASS_PURCHASES,
     +                               MON_MDS_CL_CAP_PURCHASES,
     +                               MON_MDS_CL_CLASS_ENERGY,
     +                               MON_MDS_CL_CLASS_EMISSIONS,
     +                               MON_MDS_CL_CLASS_EMISSIONS_COST,
     +                               MON_MDS_INTRA_COMPANY_REVENUES,
     +                               MON_MDS_INTRA_COMPANY_NF_BURN,
     +                               MON_MDS_NF_FUEL_LEASED_BC,
     +                               MON_MDS_NF_FUEL_OWNED_BC,
     +                               MON_MDS_NUC_FUEL_LEASE_BURN_BC,
     +                               MON_MDS_NUC_FUEL_OWNED_BURN_BC,
     +                               MON_MDS_NUCLEAR_MWH_BY_CLASS,
     +                               MON_MDS_NUCLEAR_MMBTU_BY_CLASS,
     +                               MON_MDS_ICAP_REV_BY_CLASS,
     +                               MONTHLY_AC_WHOLESALE_PROD_COST,
     +                               MONTHLY_AC_ECITY_VAR_PROD_COST,
     +                               MONTHLY_AC_ECITY_NEW_FIX_COST)
         ALLOCATE(
     +       CL_ANN_CLASS_FUEL_COST(0:NUMBER_OF_CAP_LIMITED_CLASSES,4))
         ALLOCATE(CL_ANN_MULT_FUEL_COST(0:NUMBER_OF_CAP_LIMITED_CLASSES,
     +                                             NUM_FUEL_CATEGORIES))
         ALLOCATE(FE_ANN_MULT_FUEL_COST(0:NUMBER_OF_CAP_LIMITED_CLASSES,
     +                                             NUM_FUEL_CATEGORIES))
         ALLOCATE(NF_FUEL_LEASED_BY_CLASS(
     +                               0:NUMBER_OF_CAP_LIMITED_CLASSES,4))
         ALLOCATE(NF_FUEL_OWNED_BY_CLASS(
     +                               0:NUMBER_OF_CAP_LIMITED_CLASSES,4))
         ALLOCATE(CL_ANN_CLASS_VAR_COST(
     +                               0:NUMBER_OF_CAP_LIMITED_CLASSES,4))
         ALLOCATE(CL_ANN_CLASS_FIXED_COST(
     +                               0:NUMBER_OF_CAP_LIMITED_CLASSES,4))
         ALLOCATE(CL_ANN_CLASS_CAPACITY(
     +                               0:NUMBER_OF_CAP_LIMITED_CLASSES,4))
         ALLOCATE(CL_ANN_CLASS_ENERGY(
     +                               0:NUMBER_OF_CAP_LIMITED_CLASSES,4))
         ALLOCATE(CL_ANN_CLASS_REVENUE(
     +                               0:NUMBER_OF_CAP_LIMITED_CLASSES,5))
         ALLOCATE(CL_ANN_CLASS_PURCHASES(
     +                               0:NUMBER_OF_CAP_LIMITED_CLASSES,5))
         ALLOCATE(CL_ANN_CLASS_EMISSIONS(NUMBER_OF_EMISSION_TYPES,
     +                                 0:NUMBER_OF_CAP_LIMITED_CLASSES))
         ALLOCATE(CL_ANN_MULT_VAR_COST(0:NUMBER_OF_CAP_LIMITED_CLASSES,
     +                                             NUM_FUEL_CATEGORIES))
         ALLOCATE(
     +           CL_ANN_MULT_FIXED_COST(0:NUMBER_OF_CAP_LIMITED_CLASSES,
     +                                             NUM_FUEL_CATEGORIES))
         ALLOCATE(CL_ANN_MULT_REVENUE(0:NUMBER_OF_CAP_LIMITED_CLASSES,
     +                                             NUM_FUEL_CATEGORIES))
         ALLOCATE(CL_ANN_MULT_CAPACITY(0:NUMBER_OF_CAP_LIMITED_CLASSES,
     +                                             NUM_FUEL_CATEGORIES))
         ALLOCATE(CL_ANN_MULT_ENERGY(0:NUMBER_OF_CAP_LIMITED_CLASSES,
     +                                             NUM_FUEL_CATEGORIES))
         ALLOCATE(CL_ANN_MULT_PURCHASES(0:NUMBER_OF_CAP_LIMITED_CLASSES,
     +                                             NUM_FUEL_CATEGORIES))
         ALLOCATE(NUC_FUEL_LEASED_BURN_BY_CLASS(
     +                                 0:NUMBER_OF_CAP_LIMITED_CLASSES))
         ALLOCATE(NUC_FUEL_OWNED_BURN_BY_CLASS(
     +                                 0:NUMBER_OF_CAP_LIMITED_CLASSES))
         ALLOCATE(NUCLEAR_MWH_BY_CLASS(0:NUMBER_OF_CAP_LIMITED_CLASSES))
         ALLOCATE(NUCLEAR_MMBTU_BY_CLASS(
     +                                 0:NUMBER_OF_CAP_LIMITED_CLASSES))
         ALLOCATE(INTRA_COMPANY_REVENUES(0:1024,0:3))
         ALLOCATE(INTRA_COMPANY_NF_BURN(0:1024))
         ALLOCATE(MON_MDS_CL_CLASS_FUEL_COST
     +                         (0:NUMBER_OF_CAP_LIMITED_CLASSES,4,0:12))
         ALLOCATE(MON_MDS_CL_MULT_FUEL_COST
     +                         (0:NUMBER_OF_CAP_LIMITED_CLASSES,
     +                                        NUM_FUEL_CATEGORIES,0:12))
         ALLOCATE(MON_MDS_CL_MULT_VAR_COST
     +                         (0:NUMBER_OF_CAP_LIMITED_CLASSES,
     +                                        NUM_FUEL_CATEGORIES,0:12))
         ALLOCATE(MON_MDS_CL_MULT_FIXED_COST
     +                         (0:NUMBER_OF_CAP_LIMITED_CLASSES,
     +                                        NUM_FUEL_CATEGORIES,0:12))
         ALLOCATE(MON_MDS_CL_MULT_CAPACITY
     +                         (0:NUMBER_OF_CAP_LIMITED_CLASSES,
     +                                        NUM_FUEL_CATEGORIES,0:12))
         ALLOCATE(MON_MDS_CL_MULT_ENERGY
     +                         (0:NUMBER_OF_CAP_LIMITED_CLASSES,
     +                                        NUM_FUEL_CATEGORIES,0:12))
         ALLOCATE(MON_MDS_CL_MULT_PURCHASES
     +                         (0:NUMBER_OF_CAP_LIMITED_CLASSES,
     +                                        NUM_FUEL_CATEGORIES,0:12))
         ALLOCATE(MON_MDS_CL_CLASS_VAR_COST
     +                         (0:NUMBER_OF_CAP_LIMITED_CLASSES,4,0:12))
         ALLOCATE(MON_MDS_CL_CLASS_FIXED_COST
     +                         (0:NUMBER_OF_CAP_LIMITED_CLASSES,4,0:12))
         ALLOCATE(MON_MDS_CL_CLASS_REVENUE
     +                         (0:NUMBER_OF_CAP_LIMITED_CLASSES,5,0:12))
         ALLOCATE(MON_MDS_CL_CAP_REVENUE
     +                         (0:NUMBER_OF_CAP_LIMITED_CLASSES,5,0:12))
         ALLOCATE(MON_MDS_CL_CLASS_CAPACITY
     +                         (0:NUMBER_OF_CAP_LIMITED_CLASSES,4,0:12))
         ALLOCATE(MON_MDS_CL_CLASS_PURCHASES
     +                         (0:NUMBER_OF_CAP_LIMITED_CLASSES,5,0:12))
         ALLOCATE(MON_MDS_CL_CAP_PURCHASES
     +                         (0:NUMBER_OF_CAP_LIMITED_CLASSES,5,0:12))
         ALLOCATE(MON_MDS_CL_CLASS_ENERGY
     +                         (0:NUMBER_OF_CAP_LIMITED_CLASSES,4,0:12))
         ALLOCATE(MON_MDS_CL_CLASS_EMISSIONS(NUMBER_OF_EMISSION_TYPES,
     +                            0:NUMBER_OF_CAP_LIMITED_CLASSES,0:12))
         ALLOCATE(MON_MDS_CL_CLASS_EMISSIONS_COST(
     +         NUMBER_OF_EMISSION_TYPES,0:NUMBER_OF_CAP_LIMITED_CLASSES,
     +                                                            0:12))
!
         ALLOCATE(MON_MDS_INTRA_COMPANY_REVENUES(0:1024,0:3,0:12))
         ALLOCATE(MON_MDS_INTRA_COMPANY_NF_BURN(0:1024,0:12))
         ALLOCATE(MON_MDS_NF_FUEL_LEASED_BC
     +                         (0:NUMBER_OF_CAP_LIMITED_CLASSES,4,0:12))
         ALLOCATE(MON_MDS_NF_FUEL_OWNED_BC
     +                         (0:NUMBER_OF_CAP_LIMITED_CLASSES,4,0:12))
         ALLOCATE(MON_MDS_NUC_FUEL_LEASE_BURN_BC
     +                           (0:NUMBER_OF_CAP_LIMITED_CLASSES,0:12))
         ALLOCATE(MON_MDS_NUC_FUEL_OWNED_BURN_BC
     +                           (0:NUMBER_OF_CAP_LIMITED_CLASSES,0:12))
         ALLOCATE(MON_MDS_NUCLEAR_MWH_BY_CLASS
     +                           (0:NUMBER_OF_CAP_LIMITED_CLASSES,0:12))
         ALLOCATE(MON_MDS_NUCLEAR_MMBTU_BY_CLASS
     +                           (0:NUMBER_OF_CAP_LIMITED_CLASSES,0:12))
         ALLOCATE(MON_MDS_ICAP_REV_BY_CLASS
     +                           (0:NUMBER_OF_CAP_LIMITED_CLASSES,0:12))
         ALLOCATE(MONTHLY_AC_WHOLESALE_PROD_COST
     +                           (0:NUMBER_OF_CAP_LIMITED_CLASSES,0:12))
         ALLOCATE(MONTHLY_AC_ECITY_VAR_PROD_COST
     +                           (0:NUMBER_OF_CAP_LIMITED_CLASSES,0:12))
         ALLOCATE(MONTHLY_AC_ECITY_NEW_FIX_COST
     +                           (0:NUMBER_OF_CAP_LIMITED_CLASSES,0:12))
C
         SET_UP_CL_CLASS_ARRAYS = MAX_CAP_LIMITED_CLASS_ID_NUM
!
!
!
!         UPPER_TRANS_GROUP = GET_NUMBER_OF_ACTIVE_GROUPS()
         IF(UPPER_TRANS_GROUP > 0) THEN
            IF(ALLOCATED(PURCHASE_ASSET_CLASS_ID))
     +                               DEALLOCATE(PURCHASE_ASSET_CLASS_ID,
     +                                          PURCHASE_POWER_ASSIGN)
            ALLOCATE(PURCHASE_ASSET_CLASS_ID(0:UPPER_TRANS_GROUP))
            ALLOCATE(PURCHASE_POWER_ASSIGN(0:UPPER_TRANS_GROUP))
            DO I = 1, UPPER_TRANS_GROUP
!
! NEED TO CHECK WHETHER CLASS EXISTS
!
               PURCHASE_ASSET_CLASS_ID(I) =
     +                                    GET_PURCHASE_ASSET_CLASS_ID(I)
               VOID_LOGICAL = GET_PURCHASE_POWER_ASSIGN(I,
     +                                         PURCHASE_POWER_ASSIGN(I))
            ENDDO
         ENDIF
!
      RETURN
C***********************************************************************
      ENTRY ZERO_CL_CLASS_ARRAYS
C***********************************************************************
!
! MONTHLY INITIALIZATION. NECESSARY TO ACCUMULATE ANNUAL VALUES.
!
!
         MON_MDS_NF_FUEL_LEASED_BC = 0.
         MON_MDS_NF_FUEL_OWNED_BC = 0.
         MON_MDS_INTRA_COMPANY_REVENUES = 0.
         MON_MDS_INTRA_COMPANY_NF_BURN = 0.
         MON_MDS_NUC_FUEL_LEASE_BURN_BC = 0.
         MON_MDS_NUC_FUEL_OWNED_BURN_BC = 0.
         MON_MDS_NUCLEAR_MWH_BY_CLASS = 0.
         MON_MDS_NUCLEAR_MMBTU_BY_CLASS = 0.
         MON_MDS_ICAP_REV_BY_CLASS = 0.
         MONTHLY_AC_WHOLESALE_PROD_COST = 0.
         MONTHLY_AC_ECITY_VAR_PROD_COST = 0.
         MONTHLY_AC_ECITY_NEW_FIX_COST = 0.
         MON_MDS_CL_CLASS_VAR_COST = 0.
         MON_MDS_CL_CLASS_FUEL_COST = 0.
         MON_MDS_CL_CLASS_FIXED_COST = 0.
         MON_MDS_CL_CLASS_CAPACITY = 0.
         MON_MDS_CL_CLASS_ENERGY = 0.
         MON_MDS_CL_CLASS_REVENUE = 0.
         MON_MDS_CL_CAP_REVENUE = 0.
         MON_MDS_CL_CLASS_PURCHASES = 0.
         MON_MDS_CL_CAP_PURCHASES = 0.
         MON_MDS_CL_CLASS_EMISSIONS = 0.
         MON_MDS_CL_CLASS_EMISSIONS_COST = 0.

         MON_MDS_CL_MULT_FUEL_COST = 0.
         MON_MDS_CL_MULT_VAR_COST = 0.
         MON_MDS_CL_MULT_FIXED_COST = 0.
         MON_MDS_CL_MULT_CAPACITY = 0.
         MON_MDS_CL_MULT_ENERGY = 0.
         MON_MDS_CL_MULT_PURCHASES = 0.
!
         FIRST_YEAR_PRICE_MODE = GET_FIRST_YEAR_PRICE_MODE()

C
         ZERO_CL_CLASS_ARRAYS = NUMBER_OF_CAP_LIMITED_CLASSES
!
      RETURN
C***********************************************************************
      ENTRY MON_MDS_CL_EXP_2_AC(R_ISEAS)
C***********************************************************************
!         LOGICAL*1 BASE_EL_REVENUE_CASE,
!     +             PEAK_EL_REVENUE_CASE
C
         ALLOCATE(ASSET_CLASS_LIST(AVAIL_DATA_YEARS))
         ALLOCATE(ASSET_ALLOCATION_LIST(AVAIL_DATA_YEARS))
         CURRENT_YEAR = YEAR+BASE_YEAR
         CURRENT_YEAR_COMPARISON = (CURRENT_YEAR-1900)*100
!
!         VALUES_2_ZERO = INT((NUMBER_OF_CAP_LIMITED_CLASSES+1)*4)
!
!         CALL CINITD(NF_FUEL_LEASED_BY_CLASS,VALUES_2_ZERO,0.)
!         CALL CINITD(NF_FUEL_OWNED_BY_CLASS,VALUES_2_ZERO,0.)
!
!
!         CALL CINITD(INTRA_COMPANY_REVENUES,INT(1025*4),0.)
!         CALL CINITD(INTRA_COMPANY_NF_BURN,INT(1025),0.)
!
!         VALUES_2_ZERO = INT(NUMBER_OF_CAP_LIMITED_CLASSES+1)
!
!         CALL CINITD(NUC_FUEL_LEASED_BURN_BY_CLASS,VALUES_2_ZERO,0.)
!         CALL CINITD(NUC_FUEL_OWNED_BURN_BY_CLASS,VALUES_2_ZERO,0.)
!         CALL CINITD(NUCLEAR_MWH_BY_CLASS,VALUES_2_ZERO,0.)
!         CALL CINITD(NUCLEAR_MMBTU_BY_CLASS,VALUES_2_ZERO,0.)
!
!
!
! 08/13/04. REDEFINED.
         ECITIES = ECITY_COMPANY() ! YES_ECITIES_UNITS_ACTIVE()
!
         MAX_INTRA_CLASS = 0
         INTRA_FOSSIL_FUEL_EXPENSES = 0.
         INTRA_LEASED_NUC_FUEL_EXPENSES = 0.
         INTRA_OWNED_NUC_FUEL_EXPENSES = 0.
         INTRA_NUC_OWN_BURN = 0.
         INTRA_NUC_LEASE_BURN = 0.
         INTRA_PURCHASE_EXPENSES = 0.
         BASE_MARKET_ENRG_SALES = 0.
         BASE_MARKET_REVENUES = 0.
         PEAK_MARKET_ENRG_SALES = 0.
         PEAK_MARKET_REVENUES = 0.
         MON_MDS_CL_EXP_2_AC = UNUM
C
         DO UNUM = 1, NUNITS
C
            IF(ONLINE(UNUM) - CURRENT_YEAR_COMPARISON > 12  .OR.
     +                CURRENT_YEAR_COMPARISON - OFLINE(UNUM) > 12) CYCLE
C
C
C           IF(ASSET_CLASS < 0) THEN
C              CALL GET_ASSET_VAR(ABS(ASSET_CLASS),
C    +                                 DUMMY_TYPE,ASSET_CLASS_LIST)
C              CALL GET_ASSET_VAR(ABS(ASSET_ALLOCATION_VECTOR),
C    +                                 DUMMY_TYPE,ASSET_ALLOCATION_LIST)
C           ELSE
C              ASSET_CLASS_LIST(1) = ASSET_CLASS
C              ASSET_CLASS_LIST(2) = 0.
C              ASSET_ALLOCATION_LIST(1) = 100.
C              ASSET_ALLOCATION_LIST(2) = 0.
C           ENDIF
            CLASS_POINTER = 1
! 07/18/03.
            IF(MON_MDS_CL_UNIT_ENERGY(UNUM,R_ISEAS) > .45) THEN
               PERCENT_RETAIL = 1. -
     +               MON_MDS_ECO_SALES_ENRG_FROM(UNUM,R_ISEAS)/
     +                              MON_MDS_CL_UNIT_ENERGY(UNUM,R_ISEAS)
            ELSE
               PERCENT_RETAIL = 1. ! 100 %
            ENDIF
! PER KATHY ANDERSON
            IF(PRICE_ONLY_WHOLESALE_REV) THEN
               OLD_ADJ_LOGIC = .FALSE. ! THIS WILL INVOKE THE IPL FAC
            ELSE
               OLD_ADJ_LOGIC = .TRUE.
            ENDIF
C
            IF(INTRA_COMPANY_CLASS_ID(UNUM) >= 0 .AND.
     +                      INTRA_COMPANY_TRANSACTION(UNUM) == 'Y') THEN
               ASSET_CLASS = INTRA_COMPANY_CLASS_ID(UNUM)
               CALL CHECK_IF_CLASS_DEFINED(ASSET_CLASS)
               ASSET_CLASS = ASSET_CLASS + 1
               MAX_INTRA_CLASS = MAX(MAX_INTRA_CLASS,ASSET_CLASS)
C
               SELECT CASE (EXPENSE_ASSIGNMENT(UNUM))
               CASE('F')  ! FUEL REVENUES
                  COLLECTION = MAX(1,
     +                           INDEX('BA',(EXPENSE_COLLECTION(UNUM))))
                  IF(COLLECTION /=1 .OR. PERCENT_RETAIL > .9999 .OR.
     +                                               OLD_ADJ_LOGIC) THEN
                     MON_MDS_INTRA_COMPANY_REVENUES(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) =
     +                  MON_MDS_INTRA_COMPANY_REVENUES(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) +
     +                           MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS)
     +                                      *CL_POOL_FRAC_OWN(UNUM)/100.
                  ELSE
                     MON_MDS_INTRA_COMPANY_REVENUES(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) =
     +                  MON_MDS_INTRA_COMPANY_REVENUES(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) +
     +                           MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS)
     +                       *PERCENT_RETAIL*CL_POOL_FRAC_OWN(UNUM)/100.
                     MON_MDS_INTRA_COMPANY_REVENUES(
     +                                 ASSET_CLASS,2,R_ISEAS) =
     +                  MON_MDS_INTRA_COMPANY_REVENUES(
     +                                 ASSET_CLASS,2,R_ISEAS) +
     +                           MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS)
     +                  *(1.-PERCENT_RETAIL)*CL_POOL_FRAC_OWN(UNUM)/100.
                  ENDIF
               CASE('L','O')  ! FUEL REVENUES
                  COLLECTION = MAX(1,
     +                           INDEX('BA',(EXPENSE_COLLECTION(UNUM))))
                  IF(COLLECTION /=1 .OR. PERCENT_RETAIL > .9999 .OR.
     +                                               OLD_ADJ_LOGIC) THEN
                     MON_MDS_INTRA_COMPANY_REVENUES(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) =
     +                  MON_MDS_INTRA_COMPANY_REVENUES(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) +
     +                           MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS)
     +                                      *CL_POOL_FRAC_OWN(UNUM)/100.
                  ELSE
                     MON_MDS_INTRA_COMPANY_REVENUES(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) =
     +                  MON_MDS_INTRA_COMPANY_REVENUES(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) +
     +                           MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS)
     +                       *PERCENT_RETAIL*CL_POOL_FRAC_OWN(UNUM)/100.
                     MON_MDS_INTRA_COMPANY_REVENUES(
     +                                 ASSET_CLASS,2,R_ISEAS) =
     +                  MON_MDS_INTRA_COMPANY_REVENUES(
     +                                 ASSET_CLASS,2,R_ISEAS) +
     +                           MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS)
     +                  *(1.-PERCENT_RETAIL)*CL_POOL_FRAC_OWN(UNUM)/100.
                  ENDIF
                  MON_MDS_INTRA_COMPANY_NF_BURN(ASSET_CLASS,R_ISEAS) =
     +              MON_MDS_INTRA_COMPANY_NF_BURN(ASSET_CLASS,R_ISEAS) +
     +                      (MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS) -
     +                        MON_MDS_NUC_FUEL_ADDER_COST(UNUM,R_ISEAS))
     +                                      *CL_POOL_FRAC_OWN(UNUM)/100.
               CASE('P')  ! PURCHASE REVENUES
                  MON_MDS_INTRA_COMPANY_REVENUES(
     +                                          ASSET_CLASS,3,R_ISEAS) =
     +                   MON_MDS_INTRA_COMPANY_REVENUES(
     +                                          ASSET_CLASS,3,R_ISEAS) +
     +                        (MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS) +
     +                          MON_MDS_CL_UNIT_VAR_COST(UNUM,R_ISEAS) +
     +                         MON_MDS_CL_UNIT_FIXED_COST(UNUM,R_ISEAS))
     +                                      *CL_POOL_FRAC_OWN(UNUM)/100.
               CASE DEFAULT
               END SELECT
C
               SELECT CASE (EXPENSE_ASSIGNMENT(UNUM))
               CASE('F')  ! FUEL EXPENSES
                  INTRA_FOSSIL_FUEL_EXPENSES =
     +                   INTRA_FOSSIL_FUEL_EXPENSES +
     +                           MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS)
     +                                      *CL_POOL_FRAC_OWN(UNUM)/100.
               CASE('L')  ! NUCLEAR FUEL EXPENSES
                  INTRA_LEASED_NUC_FUEL_EXPENSES =
     +                      INTRA_LEASED_NUC_FUEL_EXPENSES +
     +                           MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS)
     +                                      *CL_POOL_FRAC_OWN(UNUM)/100.
                  INTRA_NUC_LEASE_BURN = INTRA_NUC_LEASE_BURN +
     +                        (MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS) -
     +                        MON_MDS_NUC_FUEL_ADDER_COST(UNUM,R_ISEAS))
     +                                      *CL_POOL_FRAC_OWN(UNUM)/100.
               CASE('O')  ! NUCLEAR FUEL EXPENSES
                  INTRA_OWNED_NUC_FUEL_EXPENSES =
     +                    INTRA_OWNED_NUC_FUEL_EXPENSES +
     +                           MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS)
     +                                      *CL_POOL_FRAC_OWN(UNUM)/100.
                  INTRA_NUC_OWN_BURN = INTRA_NUC_OWN_BURN +
     +                      (MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS) -
     +                        MON_MDS_NUC_FUEL_ADDER_COST(UNUM,R_ISEAS))
     +                                      *CL_POOL_FRAC_OWN(UNUM)/100.
               CASE('P')  ! PURCHASE EXPENSES
                  INTRA_PURCHASE_EXPENSES = INTRA_PURCHASE_EXPENSES +
     +                        (MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS) +
     +                          MON_MDS_CL_UNIT_VAR_COST(UNUM,R_ISEAS) +
     +                         MON_MDS_CL_UNIT_FIXED_COST(UNUM,R_ISEAS))
     +                                      *CL_POOL_FRAC_OWN(UNUM)/100.
               CASE DEFAULT
               END SELECT
            ENDIF
C
            COLLECTION = INDEX('ABNX',(EXPENSE_COLLECTION(UNUM)))
            IF(COLLECTION == 0) COLLECTION = 3
            ASSET_CLASS = ASSET_CLASS_NUM(UNUM)
            ASSET_ALLOCATION_VECTOR = ASSET_CLASS_VECTOR(UNUM)
C
            VOID_LOGICAL=RETURN_ASSET_CLASS_LISTS(ASSET_CLASS,
     +                                          ASSET_CLASS_LIST,
     +                                          ASSET_ALLOCATION_VECTOR,
     +                                          ASSET_ALLOCATION_LIST)
!
            FT = PRIMARY_MOVER(UNUM)
! 030310.
            if(FT==0)  FT = 11
            TT = 10
!
C
            DO
               ASSET_CLASS = ASSET_CLASS_LIST(CLASS_POINTER)
               CALL CHECK_IF_CLASS_DEFINED(ASSET_CLASS)
C
C IDENTIFYING BASE AND PEAK EL REVENUE CLASSED
C
               BASE_EL_REVENUE_CASE = ASSET_CLASS == 10
               PEAK_EL_REVENUE_CASE = ASSET_CLASS == 19
C
               ASSET_CLASS = ASSET_CLASS + 1
               IF(ASSET_CLASS <= 0 .OR.
     +                 ASSET_CLASS > MAX_CAP_LIMITED_CLASS_ID_NUM) CYCLE
               ASSET_CLASS = ASSET_CLASS_POINTER(ASSET_CLASS)
               IF(ASSET_ALLOCATION_LIST(CLASS_POINTER) < 0.) THEN
                  ALLOCATION_VECTOR =
     +                         ABS(ASSET_ALLOCATION_LIST(CLASS_POINTER))
                  CALL GET_ASSET_VAR(ALLOCATION_VECTOR,
     +                                      DUMMY_TYPE,ALLOCATION_VALUE)
                  ASSET_ALLOCATOR = CL_POOL_FRAC_OWN(UNUM)/100. *
     +                 ALLOCATION_VALUE(MIN(YEAR,AVAIL_DATA_YEARS))/100.
               ELSE
                  ASSET_ALLOCATOR =
     +                       ASSET_ALLOCATION_LIST(CLASS_POINTER)/100. *
     +                       CL_POOL_FRAC_OWN(UNUM)/100.
               ENDIF
C
               DO I = 1, NUMBER_OF_EMISSION_TYPES
                  MON_MDS_CL_CLASS_EMISSIONS(I,ASSET_CLASS,R_ISEAS) =
     +                 MON_MDS_CL_CLASS_EMISSIONS(I,ASSET_CLASS,R_ISEAS)
     +                 + ASSET_ALLOCATOR *
     +                         MON_MDS_CL_UNIT_EMISSIONS(I,UNUM,R_ISEAS)
               ENDDO
               MON_MDS_CL_CLASS_EMISSIONS_COST(:,ASSET_CLASS,R_ISEAS) =
     +            MON_MDS_CL_CLASS_EMISSIONS_COST(:,ASSET_CLASS,R_ISEAS)
     +            + ASSET_ALLOCATOR *
     +                    MON_MDS_CL_UNIT_EMISSIONS_COST(:,UNUM,R_ISEAS)

               IF(EXPENSE_ASSIGNMENT(UNUM) == 'L') THEN
                  IF(COLLECTION /=1 .OR. PERCENT_RETAIL > .9999 .OR.
     +                                               OLD_ADJ_LOGIC) THEN
                     MON_MDS_NF_FUEL_LEASED_BC(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) =
     +                 MON_MDS_NF_FUEL_LEASED_BC(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) +
     +                  ASSET_ALLOCATOR *
     +                           MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS)
                  ELSE
                     MON_MDS_NF_FUEL_LEASED_BC(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) =
     +                 MON_MDS_NF_FUEL_LEASED_BC(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) +
     +                  ASSET_ALLOCATOR * PERCENT_RETAIL *
     +                           MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS)
                     MON_MDS_NF_FUEL_LEASED_BC(
     +                                 ASSET_CLASS,2,R_ISEAS) =
     +                 MON_MDS_NF_FUEL_LEASED_BC(
     +                                 ASSET_CLASS,2,R_ISEAS) +
     +                  ASSET_ALLOCATOR * (1.-PERCENT_RETAIL) *
     +                           MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS)
                  ENDIF
                  MON_MDS_NUC_FUEL_LEASE_BURN_BC(ASSET_CLASS,R_ISEAS) =
     +                MON_MDS_NUC_FUEL_LEASE_BURN_BC(
     +                                            ASSET_CLASS,R_ISEAS) +
     +                ASSET_ALLOCATOR *
     +                      (MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS) -
     +                        MON_MDS_NUC_FUEL_ADDER_COST(UNUM,R_ISEAS))
                  MON_MDS_NUCLEAR_MWH_BY_CLASS(ASSET_CLASS,R_ISEAS) =
     +                     MON_MDS_NUCLEAR_MWH_BY_CLASS(
     +                                            ASSET_CLASS,R_ISEAS) +
     +                     ASSET_ALLOCATOR *
     +                              MON_MDS_CL_UNIT_ENERGY(UNUM,R_ISEAS)
                  MON_MDS_NUCLEAR_MMBTU_BY_CLASS(ASSET_CLASS,R_ISEAS) =
     +                  MON_MDS_NUCLEAR_MMBTU_BY_CLASS(
     +                                            ASSET_CLASS,R_ISEAS) +
     +                     ASSET_ALLOCATOR *
     +                     MON_MDS_CL_UNIT_MMBTUS(UNUM,R_ISEAS)
               ELSEIF(EXPENSE_ASSIGNMENT(UNUM) == 'O') THEN
                  IF(COLLECTION /=1 .OR. PERCENT_RETAIL > .9999 .OR.
     +                                               OLD_ADJ_LOGIC) THEN
                     MON_MDS_NF_FUEL_OWNED_BC(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) =
     +                  MON_MDS_NF_FUEL_OWNED_BC(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) +
     +                  ASSET_ALLOCATOR *
     +                           MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS)
                  ELSE
                     MON_MDS_NF_FUEL_OWNED_BC(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) =
     +                  MON_MDS_NF_FUEL_OWNED_BC(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) +
     +                  ASSET_ALLOCATOR * PERCENT_RETAIL *
     +                           MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS)
                     MON_MDS_NF_FUEL_OWNED_BC(
     +                                 ASSET_CLASS,2,R_ISEAS) =
     +                  MON_MDS_NF_FUEL_OWNED_BC(
     +                                 ASSET_CLASS,2,R_ISEAS) +
     +                  ASSET_ALLOCATOR * (1.-PERCENT_RETAIL) *
     +                           MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS)
                  ENDIF
                  MON_MDS_NUC_FUEL_OWNED_BURN_BC(ASSET_CLASS,R_ISEAS) =
     +                MON_MDS_NUC_FUEL_OWNED_BURN_BC(
     +                                            ASSET_CLASS,R_ISEAS) +
     +                ASSET_ALLOCATOR *
     +                        (MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS) -
     +                        MON_MDS_NUC_FUEL_ADDER_COST(UNUM,R_ISEAS))
                  MON_MDS_NUCLEAR_MWH_BY_CLASS(ASSET_CLASS,R_ISEAS) =
     +               MON_MDS_NUCLEAR_MWH_BY_CLASS(ASSET_CLASS,R_ISEAS) +
     +                     ASSET_ALLOCATOR *
     +                     MON_MDS_CL_UNIT_ENERGY(UNUM,R_ISEAS)
                  MON_MDS_NUCLEAR_MMBTU_BY_CLASS(ASSET_CLASS,R_ISEAS) =
     +                  MON_MDS_NUCLEAR_MMBTU_BY_CLASS(
     +                                            ASSET_CLASS,R_ISEAS) +
     +                     ASSET_ALLOCATOR *
     +                     MON_MDS_CL_UNIT_MMBTUS(UNUM,R_ISEAS)
               ELSEIF(EXPENSE_ASSIGNMENT(UNUM) == 'P') THEN
                  IF(COLLECTION /=1 .OR. PERCENT_RETAIL > .9999 .OR.
     +                                               OLD_ADJ_LOGIC) THEN
                     MON_MDS_CL_CLASS_PURCHASES(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) =
     +                  MON_MDS_CL_CLASS_PURCHASES(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) +
     +                        ASSET_ALLOCATOR *
     +                        (MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS) +
     +                          MON_MDS_CL_UNIT_VAR_COST(UNUM,R_ISEAS) +
     +                         MON_MDS_CL_UNIT_FIXED_COST(UNUM,R_ISEAS))
                  ELSE
                     MON_MDS_CL_CLASS_PURCHASES(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) =
     +                  MON_MDS_CL_CLASS_PURCHASES(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) +
     +                        ASSET_ALLOCATOR * PERCENT_RETAIL *
     +                        (MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS) +
     +                          MON_MDS_CL_UNIT_VAR_COST(UNUM,R_ISEAS) +
     +                         MON_MDS_CL_UNIT_FIXED_COST(UNUM,R_ISEAS))
                     MON_MDS_CL_CLASS_PURCHASES(
     +                                 ASSET_CLASS,2,R_ISEAS) =
     +                  MON_MDS_CL_CLASS_PURCHASES(
     +                                 ASSET_CLASS,2,R_ISEAS) +
     +                        ASSET_ALLOCATOR * (1.-PERCENT_RETAIL) *
     +                        (MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS) +
     +                          MON_MDS_CL_UNIT_VAR_COST(UNUM,R_ISEAS) +
     +                         MON_MDS_CL_UNIT_FIXED_COST(UNUM,R_ISEAS))
                  ENDIF
                  MON_MDS_CL_CLASS_CAPACITY(ASSET_CLASS,2,R_ISEAS) =
     +                MON_MDS_CL_CLASS_CAPACITY(ASSET_CLASS,2,R_ISEAS) +
     +                   ASSET_ALLOCATOR *
     +                     MON_MDS_CL_UNIT_CAPACITY(UNUM,R_ISEAS)
                  MON_MDS_CL_CLASS_ENERGY(ASSET_CLASS,2,R_ISEAS) =
     +                  MON_MDS_CL_CLASS_ENERGY(ASSET_CLASS,2,R_ISEAS) +
     +                     ASSET_ALLOCATOR *
     +                     MON_MDS_CL_UNIT_ENERGY(UNUM,R_ISEAS)
!
! 01/06/04. FOR FE
!
                  MON_MDS_CL_MULT_PURCHASES(ASSET_CLASS,FT,R_ISEAS) =
     +               MON_MDS_CL_MULT_PURCHASES(ASSET_CLASS,FT,R_ISEAS) +
     +                        ASSET_ALLOCATOR *
     +                        (MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS) +
     +                         MON_MDS_CL_UNIT_VAR_COST(UNUM,R_ISEAS) +
     +                         MON_MDS_CL_UNIT_FIXED_COST(UNUM,R_ISEAS))
!
               ELSE
                  IF(COLLECTION /=1 .OR. PERCENT_RETAIL > .9999 .OR.
     +                                               OLD_ADJ_LOGIC) THEN
                     MON_MDS_CL_CLASS_FUEL_COST(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) =
     +                  MON_MDS_CL_CLASS_FUEL_COST(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) +
     +                  ASSET_ALLOCATOR *
     +                           MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS)
                  ELSE
! 07/18/03. FOR IPL, KCPL AND OTHERS
                     MON_MDS_CL_CLASS_FUEL_COST(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) =
     +                  MON_MDS_CL_CLASS_FUEL_COST(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) +
     +                  ASSET_ALLOCATOR * PERCENT_RETAIL *
     +                           MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS)
!
! ASSIGN THE BALANCE OF THE ADJ TO UNCOLLECTED PER KATHY ANDERSON.
!
                     MON_MDS_CL_CLASS_FUEL_COST(
     +                                 ASSET_CLASS,2,R_ISEAS) =
     +                  MON_MDS_CL_CLASS_FUEL_COST(
     +                                 ASSET_CLASS,2,R_ISEAS) +
     +                  ASSET_ALLOCATOR * (1.-PERCENT_RETAIL) *
     +                           MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS)
                  ENDIF
! 02/14/03
                  MON_MDS_CL_MULT_FUEL_COST(
     +                                 ASSET_CLASS,FT,R_ISEAS) =
     +                  MON_MDS_CL_MULT_FUEL_COST(
     +                                 ASSET_CLASS,FT,R_ISEAS) +
     +                  ASSET_ALLOCATOR *
     +                           MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS)
               ENDIF
               IF(EXPENSE_ASSIGNMENT(UNUM) /= 'P') THEN
                  MON_MDS_CL_CLASS_VAR_COST(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) =
     +                MON_MDS_CL_CLASS_VAR_COST(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) +
     +                   ASSET_ALLOCATOR *
     +                            MON_MDS_CL_UNIT_VAR_COST(UNUM,R_ISEAS)
                  MON_MDS_CL_CLASS_FIXED_COST(
     +                                  ASSET_CLASS,COLLECTION,R_ISEAS)=
     +                 MON_MDS_CL_CLASS_FIXED_COST(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) +
     +                     ASSET_ALLOCATOR *
     +                          MON_MDS_CL_UNIT_FIXED_COST(UNUM,R_ISEAS)
                  MON_MDS_CL_CLASS_CAPACITY(ASSET_CLASS,1,R_ISEAS) =
     +                MON_MDS_CL_CLASS_CAPACITY(ASSET_CLASS,1,R_ISEAS) +
     +                         ASSET_ALLOCATOR *
     +                         MON_MDS_CL_UNIT_CAPACITY(UNUM,R_ISEAS)
                  MON_MDS_CL_CLASS_ENERGY(ASSET_CLASS,1,R_ISEAS) =
     +                  MON_MDS_CL_CLASS_ENERGY(ASSET_CLASS,1,R_ISEAS) +
     +                     ASSET_ALLOCATOR *
     +                     MON_MDS_CL_UNIT_ENERGY(UNUM,R_ISEAS)
                  MON_MDS_ICAP_REV_BY_CLASS(ASSET_CLASS,R_ISEAS) =
     +                MON_MDS_ICAP_REV_BY_CLASS(ASSET_CLASS,R_ISEAS) +
     +                     ASSET_ALLOCATOR *
     +                     MON_MDS_ICAP_REVENUES(UNUM,R_ISEAS)
!
                  MON_MDS_CL_MULT_VAR_COST(ASSET_CLASS,FT,R_ISEAS) =
     +                MON_MDS_CL_MULT_VAR_COST(ASSET_CLASS,FT,R_ISEAS) +
     +                      ASSET_ALLOCATOR *
     +                            MON_MDS_CL_UNIT_VAR_COST(UNUM,R_ISEAS)
                  MON_MDS_CL_MULT_FIXED_COST(
     +                                  ASSET_CLASS,FT,R_ISEAS)=
     +                 MON_MDS_CL_MULT_FIXED_COST(
     +                                 ASSET_CLASS,FT,R_ISEAS) +
     +                     ASSET_ALLOCATOR *
     +                          MON_MDS_CL_UNIT_FIXED_COST(UNUM,R_ISEAS)
                  MON_MDS_CL_MULT_CAPACITY(ASSET_CLASS,FT,R_ISEAS) =
     +                MON_MDS_CL_MULT_CAPACITY(ASSET_CLASS,FT,R_ISEAS) +
     +                         ASSET_ALLOCATOR *
     +                         MON_MDS_CL_UNIT_CAPACITY(UNUM,R_ISEAS)
                  MON_MDS_CL_MULT_ENERGY(ASSET_CLASS,FT,R_ISEAS) =
     +                  MON_MDS_CL_MULT_ENERGY(ASSET_CLASS,FT,R_ISEAS) +
     +                     ASSET_ALLOCATOR *
     +                     MON_MDS_CL_UNIT_ENERGY(UNUM,R_ISEAS)
               ENDIF
               IF(MON_MDS_ECO_SALES_ENRG_FROM(UNUM,R_ISEAS) /= 0.) THEN
                  MON_MDS_CL_CLASS_REVENUE(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) =
     +                MON_MDS_CL_CLASS_REVENUE(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) +
     +                        ASSET_ALLOCATOR *
     +                         MON_MDS_ECO_SALES_REV_FROM(UNUM,R_ISEAS)
                  MON_MDS_CL_CLASS_ENERGY(ASSET_CLASS,3,R_ISEAS) =
     +                  MON_MDS_CL_CLASS_ENERGY(ASSET_CLASS,3,R_ISEAS) +
     +                       ASSET_ALLOCATOR *
     +                         MON_MDS_ECO_SALES_ENRG_FROM(UNUM,R_ISEAS)
                  IF(MON_MDS_CL_UNIT_ENERGY(UNUM,R_ISEAS) > 0.) THEN
!
                     TT_PERCENT =
     +                     MON_MDS_ECO_SALES_ENRG_FROM(UNUM,R_ISEAS)/
     +                              MON_MDS_CL_UNIT_ENERGY(UNUM,R_ISEAS)
!
                     MON_MDS_CL_MULT_FUEL_COST(ASSET_CLASS,TT,R_ISEAS) =
     +                  MON_MDS_CL_MULT_FUEL_COST(
     +                                         ASSET_CLASS,TT,R_ISEAS) +
     +                  ASSET_ALLOCATOR *
     +                       MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS) *
     +                                                        TT_PERCENT
                     MON_MDS_CL_MULT_VAR_COST(ASSET_CLASS,TT,R_ISEAS) =
     +                  MON_MDS_CL_MULT_VAR_COST(
     +                                         ASSET_CLASS,TT,R_ISEAS) +
     +                 ASSET_ALLOCATOR *
     +                          MON_MDS_CL_UNIT_VAR_COST(UNUM,R_ISEAS) *
     +                                                        TT_PERCENT
                     MON_MDS_CL_MULT_CAPACITY(ASSET_CLASS,TT,R_ISEAS) =
     +                MON_MDS_CL_MULT_CAPACITY(ASSET_CLASS,TT,R_ISEAS) +
     +                         ASSET_ALLOCATOR *
     +                         MON_MDS_CL_UNIT_CAPACITY(UNUM,R_ISEAS) *
     +                                                        TT_PERCENT
                     MON_MDS_CL_MULT_ENERGY(ASSET_CLASS,TT,R_ISEAS) =
     +                  MON_MDS_CL_MULT_ENERGY(ASSET_CLASS,TT,R_ISEAS) +
     +                     ASSET_ALLOCATOR *
     +                     MON_MDS_CL_UNIT_ENERGY(UNUM,R_ISEAS) *
     +                                                        TT_PERCENT
                  ENDIF
                  IF(BASE_EL_REVENUE_CASE) THEN
                     BASE_MARKET_ENRG_SALES = BASE_MARKET_ENRG_SALES +
     +                       ASSET_ALLOCATOR *
     +                         MON_MDS_ECO_SALES_ENRG_FROM(UNUM,R_ISEAS)
                     BASE_MARKET_REVENUES = BASE_MARKET_REVENUES +
     +                        ASSET_ALLOCATOR *
     +                        MON_MDS_ECO_SALES_REV_FROM(UNUM,R_ISEAS)
                  ELSEIF(PEAK_EL_REVENUE_CASE) THEN
                     PEAK_MARKET_ENRG_SALES = PEAK_MARKET_ENRG_SALES +
     +                       ASSET_ALLOCATOR *
     +                       MON_MDS_ECO_SALES_ENRG_FROM(UNUM,R_ISEAS)
                     PEAK_MARKET_REVENUES = PEAK_MARKET_REVENUES +
     +                        ASSET_ALLOCATOR *
     +                       MON_MDS_ECO_SALES_REV_FROM(UNUM,R_ISEAS)
                  ENDIF
               ENDIF ! MON_MDS_ECO_SALES_ENRG_FROM /= 0.
!
! 091407. FOR CAPACITY_MARKETS
!
               IF(ABS(MON_CAP_SALE_MW_FROM(UNUM)) >  0.1) THEN
                  IF(CAPACITY_MARKET_COST_ASSIGN(UNUM) ==
     +                                 'Capacity Sales      ') THEN
                     LOCAL_COLLECTION =
     +                 INDEX('ABNX',(
     +                          CAPACITY_MARKET_EXP_COLLECT(UNUM)(1:1)))
                     MON_MDS_CL_CAP_REVENUE(
     +                           ASSET_CLASS,LOCAL_COLLECTION,R_ISEAS) =
     +                  MON_MDS_CL_CAP_REVENUE(
     +                           ASSET_CLASS,LOCAL_COLLECTION,R_ISEAS) +
     +                        ASSET_ALLOCATOR *
     +                              MON_CAP_SALE_REV_FROM(UNUM)
                  ENDIF
               ENDIF
               IF(ABS(MON_CAP_PUCH_MW_FROM(UNUM)) >  0.1) THEN
                  LOCAL_COLLECTION =
     +                 INDEX('ABNX',(
     +                          CAPACITY_MARKET_EXP_COLLECT(UNUM)(1:1)))
                  IF(CAPACITY_MARKET_COST_ASSIGN(UNUM) ==
     +                                 'Capacity Purchases  ') THEN
                     MON_MDS_CL_CAP_PURCHASES(
     +                           ASSET_CLASS,LOCAL_COLLECTION,R_ISEAS) =
     +                  MON_MDS_CL_CAP_PURCHASES(
     +                           ASSET_CLASS,LOCAL_COLLECTION,R_ISEAS) -
     +                        ASSET_ALLOCATOR *
     +                             MON_CAP_PUCH_COST_FROM(UNUM)
                  ELSEIF(CAPACITY_MARKET_COST_ASSIGN(UNUM) ==
     +                                 'Purchased Power     ') THEN
                     MON_MDS_CL_CLASS_PURCHASES(
     +                           ASSET_CLASS,LOCAL_COLLECTION,R_ISEAS) =
     +                  MON_MDS_CL_CLASS_PURCHASES(
     +                           ASSET_CLASS,LOCAL_COLLECTION,R_ISEAS) -
     +                        ASSET_ALLOCATOR *
     +                             MON_CAP_PUCH_COST_FROM(UNUM)
! ELSE NOT COLLECTED
                  ENDIF
               ENDIF
!
!               IF(MON_MDS_ECO_PUCH_ENRG_FROM(UNUM,R_ISEAS) /= 0.) THEN
!                  MON_MDS_CL_CLASS_PURCHASES(
!     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) =
!     +                  MON_MDS_CL_CLASS_PURCHASES(
!     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) +
!     +                        ASSET_ALLOCATOR *
!     +                        MON_MDS_ECO_PUCH_COST_FROM(UNUM,R_ISEAS)
!                  MON_MDS_CL_CLASS_ENERGY(ASSET_CLASS,4,R_ISEAS) =
!     +                  MON_MDS_CL_CLASS_ENERGY(ASSET_CLASS,4,R_ISEAS) +
!     +                        ASSET_ALLOCATOR *
!     +                        MON_MDS_ECO_PUCH_ENRG_FROM(UNUM,R_ISEAS)
!               ENDIF
!
               IF(MON_ECO_PUCH_ENRG_FROM(UNUM) /= 0.) THEN
! 08/07/01. CHANGE VARIABLE LIST TO WORK WITH MONTHLY MIDAS.
                  IF(UPPER_TRANS_GROUP > 0) THEN
                     TG = TRANSACTION_GROUP_ID(UNUM) ! NOTE DOUBLE ASSIGNMENT
                     TG = GET_TRANS_GROUP_POSITION(TG)
                     IF(PURCHASE_POWER_ASSIGN(TG) /= 'U') THEN
                        TG_ASSET_CLASS = PURCHASE_ASSET_CLASS_ID(TG)
!                        TG_ASSET_CLASS = 15
                        CALL CHECK_IF_CLASS_DEFINED(TG_ASSET_CLASS)
                        TG_ASSET_CLASS = TG_ASSET_CLASS + 1
                        IF(TG_ASSET_CLASS > 0 .AND. TG_ASSET_CLASS <=
     +                                MAX_CAP_LIMITED_CLASS_ID_NUM) THEN
                           TG_ASSET_CLASS =
     +                               ASSET_CLASS_POINTER(TG_ASSET_CLASS)
                           MON_MDS_CL_CLASS_PURCHASES(TG_ASSET_CLASS,
     +                                             COLLECTION,R_ISEAS) =
     +                        MON_MDS_CL_CLASS_PURCHASES(TG_ASSET_CLASS,
     +                                             COLLECTION,R_ISEAS) +
     +                        MON_MDS_ECO_PUCH_COST_FROM(UNUM,R_ISEAS)
!     +                                      MON_ECO_PUCH_COST_FROM(UNUM)
                           MON_ECO_PUCH_COST_FROM(UNUM) = 0.
                        ENDIF
                     ENDIF
                  ENDIF
!
!
                  IF(COLLECTION /=1 .OR. PERCENT_RETAIL > .9999 .OR.
     +                                               OLD_ADJ_LOGIC) THEN
                     MON_MDS_CL_CLASS_PURCHASES(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) =
     +                     MON_MDS_CL_CLASS_PURCHASES(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) +
     +                    ASSET_ALLOCATOR * MON_ECO_PUCH_COST_FROM(UNUM)
                  ELSE
                     MON_MDS_CL_CLASS_PURCHASES(
     +                                 ASSET_CLASS,2,R_ISEAS) =
     +                     MON_MDS_CL_CLASS_PURCHASES(
     +                                 ASSET_CLASS,2,R_ISEAS) +
     +                    ASSET_ALLOCATOR * MON_ECO_PUCH_COST_FROM(UNUM)
                  ENDIF
                  MON_MDS_CL_CLASS_ENERGY(ASSET_CLASS,4,R_ISEAS) =
     +                  MON_MDS_CL_CLASS_ENERGY(ASSET_CLASS,4,R_ISEAS) +
     +                    ASSET_ALLOCATOR * MON_ECO_PUCH_ENRG_FROM(UNUM)
!
                  IF(MON_ECO_PUCH_ENRG_FROM(UNUM) +
     +                   MON_MDS_CL_UNIT_ENERGY(UNUM,R_ISEAS) > 0.) THEN
!
                        TT_PERCENT =  MON_ECO_PUCH_ENRG_FROM(UNUM)/
     +                                   (MON_ECO_PUCH_ENRG_FROM(UNUM) +
     +                                      ANNUAL_CL_UNIT_ENERGY(UNUM))
!
                        MON_MDS_CL_MULT_CAPACITY(
     +                                        ASSET_CLASS,TT+1,R_ISEAS)=
     +                            MON_MDS_CL_MULT_CAPACITY(
     +                                         ASSET_CLASS,TT+1,R_ISEAS)
     +                              + ASSET_ALLOCATOR *
     +                          MON_MDS_CL_UNIT_CAPACITY(UNUM,R_ISEAS) *
     +                                                        TT_PERCENT
                        MON_MDS_CL_MULT_ENERGY(
     +                                       ASSET_CLASS,TT+1,R_ISEAS) =
     +                          MON_MDS_CL_MULT_ENERGY(
     +                                         ASSET_CLASS,TT+1,R_ISEAS)
     +                                 + ASSET_ALLOCATOR *
     +                                      MON_ECO_PUCH_ENRG_FROM(UNUM)
!     +                                     ANNUAL_CL_UNIT_ENERGY(UNUM) *
!     +                                                        TT_PERCENT
! INVOKED 1/8/02.
!                        CL_ANN_MULT_PURCHASES(ASSET_CLASS,TT+1) =
!     +                         CL_ANN_MULT_PURCHASES(ASSET_CLASS,TT+1) +
!     +                        ASSET_ALLOCATOR * ECO_PUCH_COST_FROM(UNUM)
! 01/06/04.
                        MON_MDS_CL_MULT_PURCHASES(
     +                                       ASSET_CLASS,TT+1,R_ISEAS) =
     +                        MON_MDS_CL_MULT_PURCHASES(
     +                                       ASSET_CLASS,TT+1,R_ISEAS) +
     +                    ASSET_ALLOCATOR * MON_ECO_PUCH_COST_FROM(UNUM)
!
                  ENDIF
!
               ENDIF
!
               IF(ECITIES) THEN
!
                  TOTAL_VARIABLE_COST =
     +               ASSET_ALLOCATOR *
     +                         (MON_MDS_CL_UNIT_VAR_COST(UNUM,R_ISEAS) +
     +                 MON_MDS_CL_UNIT_FUEL_COST(UNUM,R_ISEAS))/1000000.
                  IF(ASSET_ALLOCATOR *
     +                   MON_MDS_CL_UNIT_ENERGY(UNUM,R_ISEAS) > .1) THEN
                     AVERAGE_PRODUCTION_COSTS = TOTAL_VARIABLE_COST/
     +                           (ASSET_ALLOCATOR *
     +                             MON_MDS_CL_UNIT_ENERGY(UNUM,R_ISEAS))
                  ELSE
                     AVERAGE_PRODUCTION_COSTS = 0.
                  ENDIF
                  WHOLESALE_PRODUCTION_COST =
     +                  AVERAGE_PRODUCTION_COSTS *
     +                                     MON_ECO_SALES_ENRG_FROM(UNUM)
                  MONTHLY_AC_WHOLESALE_PROD_COST(
     +                                        ASSET_CLASS,R_ISEAS) =
     +                  MONTHLY_AC_WHOLESALE_PROD_COST(
     +                                        ASSET_CLASS,R_ISEAS) +
     +                                         WHOLESALE_PRODUCTION_COST
                  MONTHLY_AC_WHOLESALE_PROD_COST(ASSET_CLASS,0) =
     +                  MONTHLY_AC_WHOLESALE_PROD_COST(
     +                                           ASSET_CLASS,0) +
     +                                         WHOLESALE_PRODUCTION_COST
                  IF( (LDTYPE(UNUM) /= 'NUC' .AND.
     +                 SPECIAL_UNIT_ID(UNUM) == 'NONE') .OR.
     +                             EXPENSE_ASSIGNMENT(UNUM) == 'P') THEN
                     MONTHLY_AC_ECITY_VAR_PROD_COST(
     +                                        ASSET_CLASS,R_ISEAS) =
     +                  MONTHLY_AC_ECITY_VAR_PROD_COST(
     +                                        ASSET_CLASS,R_ISEAS) +
     +                                               TOTAL_VARIABLE_COST
                     MONTHLY_AC_ECITY_VAR_PROD_COST(
     +                                            ASSET_CLASS,0) =
     +                  MONTHLY_AC_ECITY_VAR_PROD_COST(
     +                                            ASSET_CLASS,0) +
     +                                               TOTAL_VARIABLE_COST
                  ENDIF
                  IF(MON_ECO_PUCH_ENRG_FROM(UNUM) /= 0.) THEN

                     MONTHLY_AC_ECITY_VAR_PROD_COST(
     +                                            ASSET_CLASS,R_ISEAS) =
     +                  MONTHLY_AC_ECITY_VAR_PROD_COST(
     +                                            ASSET_CLASS,R_ISEAS) +
     +                   ASSET_ALLOCATOR * MON_ECO_PUCH_COST_FROM(UNUM)/
     +                                                          1000000.
                     MONTHLY_AC_ECITY_VAR_PROD_COST(
     +                                            ASSET_CLASS,0) =
     +                  MONTHLY_AC_ECITY_VAR_PROD_COST(
     +                                            ASSET_CLASS,0) +
     +                   ASSET_ALLOCATOR * MON_ECO_PUCH_COST_FROM(UNUM)/
     +                                                          1000000.
                  ENDIF
                  IF(ONLINE(UNUM) > FIRST_YEAR_PRICE_MODE) THEN
                     MONTHLY_AC_ECITY_NEW_FIX_COST(
     +                                        ASSET_CLASS,R_ISEAS) =
     +                  MONTHLY_AC_ECITY_NEW_FIX_COST(
     +                                        ASSET_CLASS,R_ISEAS) +
     +                     ASSET_ALLOCATOR *
     +                     MON_MDS_CL_UNIT_FIXED_COST(UNUM,R_ISEAS)/
     +                                                          1000000.
                     MONTHLY_AC_ECITY_NEW_FIX_COST(
     +                                        ASSET_CLASS,0) =
     +                  MONTHLY_AC_ECITY_NEW_FIX_COST(
     +                                        ASSET_CLASS,0) +
     +                   ASSET_ALLOCATOR *
     +                     MON_MDS_CL_UNIT_FIXED_COST(UNUM,R_ISEAS)/
     +                                                          1000000.
                  ENDIF
               ENDIF
!
C
               CLASS_POINTER = CLASS_POINTER + 1
               IF(CLASS_POINTER > AVAIL_DATA_YEARS) EXIT
               IF(ASSET_CLASS_LIST(CLASS_POINTER) == 0. .OR.
     +                     ASSET_CLASS_LIST(CLASS_POINTER) == -99.) EXIT
            ENDDO ! ASSET CLASSES
         ENDDO ! CL UNITS
!
! 09/02/01. AMEREN TRANSFER PRICING CAPABILITY. TWO PARTY FOR NOW.
!           NEED A SWITCH TO DEFINE.
!
         IF(DETAILED_TRANSFER_PRICING) THEN
            CALL GET_MONTHLY_TRANSFER_REV_COST(
     +                                    R_ISEAS,
     +                                    R1_MONTHLY_TRANSFER_REV,
     +                                    R1_MONTHLY_TRANSFER_COST,
     +                                    R2_MONTHLY_TRANSFER_REV,
     +                                    R2_MONTHLY_TRANSFER_COST)
            TG = 1 ! ASSUME UE FOR NOW.
            TG_ASSET_CLASS = PURCHASE_ASSET_CLASS_ID(TG)
            CALL CHECK_IF_CLASS_DEFINED(TG_ASSET_CLASS)
            COLLECTION = 5 ! ASSUME
            TG_ASSET_CLASS = TG_ASSET_CLASS + 1
            IF(TG_ASSET_CLASS > 0 .AND. TG_ASSET_CLASS <=
     +                                MAX_CAP_LIMITED_CLASS_ID_NUM) THEN
               TG_ASSET_CLASS = ASSET_CLASS_POINTER(TG_ASSET_CLASS)
               MON_MDS_CL_CLASS_PURCHASES(
     +                              TG_ASSET_CLASS,COLLECTION,R_ISEAS) =
     +                      MON_MDS_CL_CLASS_PURCHASES(TG_ASSET_CLASS,
     +                                             COLLECTION,R_ISEAS) +
     +                                          R1_MONTHLY_TRANSFER_COST ! FROM TRANSACT MODULE
               MON_MDS_CL_CLASS_REVENUE(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) =
     +                  MON_MDS_CL_CLASS_REVENUE(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) +
     +                                          R1_MONTHLY_TRANSFER_REV ! FROM TRANSACT MODULE
            ENDIF
            TG = 2 ! ASSUME UE FOR NOW.
            TG_ASSET_CLASS = PURCHASE_ASSET_CLASS_ID(TG)
            CALL CHECK_IF_CLASS_DEFINED(TG_ASSET_CLASS)
            COLLECTION = 5 ! ASSUME
            TG_ASSET_CLASS = TG_ASSET_CLASS + 1
            IF(TG_ASSET_CLASS > 0 .AND. TG_ASSET_CLASS <=
     +                                MAX_CAP_LIMITED_CLASS_ID_NUM) THEN
               TG_ASSET_CLASS = ASSET_CLASS_POINTER(TG_ASSET_CLASS)
               MON_MDS_CL_CLASS_PURCHASES(
     +                              TG_ASSET_CLASS,COLLECTION,R_ISEAS) =
     +                      MON_MDS_CL_CLASS_PURCHASES(TG_ASSET_CLASS,
     +                                             COLLECTION,R_ISEAS) +
     +                                          R2_MONTHLY_TRANSFER_COST ! FROM TRANSACT MODULE
               MON_MDS_CL_CLASS_REVENUE(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) =
     +                  MON_MDS_CL_CLASS_REVENUE(
     +                                 ASSET_CLASS,COLLECTION,R_ISEAS) +
     +                                          R2_MONTHLY_TRANSFER_REV ! FROM TRANSACT MODULE
            ENDIF
         ENDIF
!

!
! 08/07/01. CHANGE VARIABLE LIST TO WORK WITH MONTHLY MIDAS.
!        GET COST OF SUPPLYING CAPACITY FOR A "SHORT" SYSTEM.
!
         RUN_TRANSACT = YES_RUN_TRANSACT() ! 10/28/03.
!
         IF(UPPER_TRANS_GROUP > 0 .AND. RUN_TRANSACT) THEN
!            COLLECTION = 1
            DO TG = 1, UPPER_TRANS_GROUP
               TEMP_I2 = 0
               CALL GET_ANNUAL_UNSERVED_COST(
     +                                    TG,
     +                                    TRANS_ANNUAL_UNSERVED_COST,
     +                                    TEMP_R4, ! UNSERVED MWH'S
     +                                    R_ISEAS) ! ANNUAL CALL 6/25/01.
!               IF(PURCHASE_POWER_ASSIGN(TG) /= 'U') THEN
                  IF(PURCHASE_POWER_ASSIGN(TG) == 'A') THEN
                     COLLECTION = 1
                  ELSEIF(PURCHASE_POWER_ASSIGN(TG) == 'B') THEN
                     COLLECTION = 2
                  ELSEIF(PURCHASE_POWER_ASSIGN(TG) == 'C') THEN
                     COLLECTION = 4
                  ELSE
                     COLLECTION = 3
                  ENDIF
                  TG_ASSET_CLASS = PURCHASE_ASSET_CLASS_ID(TG)
!                 TG_ASSET_CLASS = 15
                  CALL CHECK_IF_CLASS_DEFINED(TG_ASSET_CLASS)
                  TG_ASSET_CLASS = TG_ASSET_CLASS + 1
                  IF(TG_ASSET_CLASS > 0 .AND. TG_ASSET_CLASS <=
     +                                MAX_CAP_LIMITED_CLASS_ID_NUM) THEN
                     TG_ASSET_CLASS =
     +                               ASSET_CLASS_POINTER(TG_ASSET_CLASS)
                     MON_MDS_CL_CLASS_PURCHASES(
     +                              TG_ASSET_CLASS,COLLECTION,R_ISEAS) =
     +                      MON_MDS_CL_CLASS_PURCHASES(TG_ASSET_CLASS,
     +                                             COLLECTION,R_ISEAS) +
     +                                        TRANS_ANNUAL_UNSERVED_COST ! FROM TRANSACT MODULE
                     IF(WABASH_VALLEY .AND. TG == 1) THEN
                        CALL CL_REPORT_WHOLE_MARKET_COST(
     +                                          R_ISEAS,
     +                                          WHOLESALE_MARKET_COST)
!
                        MON_MDS_CL_CLASS_PURCHASES(
     +                              TG_ASSET_CLASS,COLLECTION,R_ISEAS) =
     +                      MON_MDS_CL_CLASS_PURCHASES(TG_ASSET_CLASS,
     +                                             COLLECTION,R_ISEAS) +
     +                                             WHOLESALE_MARKET_COST ! FROM TRANSACT MODULE
                        COLLECTION = 2
                        MON_MDS_CL_CLASS_PURCHASES(
     +                              TG_ASSET_CLASS,COLLECTION,R_ISEAS) =
     +                      MON_MDS_CL_CLASS_PURCHASES(TG_ASSET_CLASS,
     +                                             COLLECTION,R_ISEAS) -
     +                                             WHOLESALE_MARKET_COST ! FROM TRANSACT MODULE
                     ENDIF
                  ENDIF
!               ENDIF
            ENDDO
         ENDIF
         DEALLOCATE(ASSET_CLASS_LIST,ASSET_ALLOCATION_LIST)
C
C MARKET REVENUE PROXY FOR UNION EL UNITS 8/7/97
C
         EL_BASE_RATE = 0.
         EL_PEAK_RATE = 0.
         IF(BASE_MARKET_ENRG_SALES > 50 .AND.
     +                                  BASE_MARKET_REVENUES > 100) THEN
            EL_BASE_RATE = BASE_MARKET_REVENUES/BASE_MARKET_ENRG_SALES
         ENDIF
         IF(PEAK_MARKET_ENRG_SALES > 25 .AND.
     +                                   PEAK_MARKET_REVENUES > 50) THEN
            EL_PEAK_RATE = PEAK_MARKET_REVENUES/PEAK_MARKET_ENRG_SALES
         ENDIF
C
         DO COLLECTION = 0, 3
            DO CLASS = 1, MAX_INTRA_CLASS
               MON_MDS_INTRA_COMPANY_REVENUES(0,COLLECTION,R_ISEAS) =
     +                  MON_MDS_INTRA_COMPANY_REVENUES(
     +                                           0,COLLECTION,R_ISEAS) +
     +                        MON_MDS_INTRA_COMPANY_REVENUES(
     +                                         CLASS,COLLECTION,R_ISEAS)
            ENDDO
         ENDDO
         DO CLASS = 1, MAX_INTRA_CLASS
            MON_MDS_INTRA_COMPANY_NF_BURN(0,R_ISEAS) =
     +               MON_MDS_INTRA_COMPANY_NF_BURN(0,R_ISEAS) +
     +                      MON_MDS_INTRA_COMPANY_NF_BURN(CLASS,R_ISEAS)
         ENDDO
C
         DO CLASS = 1, NUMBER_OF_CAP_LIMITED_CLASSES
! UNITS
            MON_MDS_NUC_FUEL_LEASE_BURN_BC(CLASS,R_ISEAS) =
     +            MON_MDS_NUC_FUEL_LEASE_BURN_BC(CLASS,R_ISEAS)/1000000.
            MON_MDS_NUC_FUEL_OWNED_BURN_BC(CLASS,R_ISEAS) =
     +            MON_MDS_NUC_FUEL_OWNED_BURN_BC(CLASS,R_ISEAS)/1000000.
! TOTAL ACROSS CLASSES
            MON_MDS_NUC_FUEL_LEASE_BURN_BC(0,R_ISEAS) =
     +               MON_MDS_NUC_FUEL_LEASE_BURN_BC(0,R_ISEAS) +
     +                     MON_MDS_NUC_FUEL_LEASE_BURN_BC(CLASS,R_ISEAS)
            MON_MDS_NUC_FUEL_OWNED_BURN_BC(0,R_ISEAS) =
     +              MON_MDS_NUC_FUEL_OWNED_BURN_BC(0,R_ISEAS) +
     +                     MON_MDS_NUC_FUEL_OWNED_BURN_BC(CLASS,R_ISEAS)
            MON_MDS_NUCLEAR_MWH_BY_CLASS(0,R_ISEAS) =
     +         MON_MDS_NUCLEAR_MWH_BY_CLASS(0,R_ISEAS) +
     +                       MON_MDS_NUCLEAR_MWH_BY_CLASS(CLASS,R_ISEAS)
            MON_MDS_NUCLEAR_MMBTU_BY_CLASS(0,R_ISEAS) =
     +            MON_MDS_NUCLEAR_MMBTU_BY_CLASS(0,R_ISEAS) +
     +                     MON_MDS_NUCLEAR_MMBTU_BY_CLASS(CLASS,R_ISEAS)
            MON_MDS_ICAP_REV_BY_CLASS(0,R_ISEAS) =
     +               MON_MDS_ICAP_REV_BY_CLASS(0,R_ISEAS)/1000000.
! TOTAL ACROSS MONTHS
            MON_MDS_NUC_FUEL_LEASE_BURN_BC(CLASS,0) =
     +               MON_MDS_NUC_FUEL_LEASE_BURN_BC(CLASS,0) +
     +                     MON_MDS_NUC_FUEL_LEASE_BURN_BC(CLASS,R_ISEAS)
            MON_MDS_NUC_FUEL_OWNED_BURN_BC(CLASS,0) =
     +              MON_MDS_NUC_FUEL_OWNED_BURN_BC(CLASS,0) +
     +                     MON_MDS_NUC_FUEL_OWNED_BURN_BC(CLASS,R_ISEAS)
            MON_MDS_NUCLEAR_MWH_BY_CLASS(CLASS,0) =
     +         MON_MDS_NUCLEAR_MWH_BY_CLASS(CLASS,0) +
     +                       MON_MDS_NUCLEAR_MWH_BY_CLASS(CLASS,R_ISEAS)
            MON_MDS_NUCLEAR_MMBTU_BY_CLASS(CLASS,0) =
     +            MON_MDS_NUCLEAR_MMBTU_BY_CLASS(CLASS,0) +
     +                     MON_MDS_NUCLEAR_MMBTU_BY_CLASS(CLASS,R_ISEAS)
            MON_MDS_ICAP_REV_BY_CLASS(CLASS,R_ISEAS) =
     +                  MON_MDS_ICAP_REV_BY_CLASS(CLASS,R_ISEAS) +
     +                       MON_MDS_ICAP_REV_BY_CLASS(CLASS,R_ISEAS)
! TOTAL ACROSS CLASSES AND MONTHS
            MON_MDS_NUC_FUEL_LEASE_BURN_BC(0,0) =
     +               MON_MDS_NUC_FUEL_LEASE_BURN_BC(0,0) +
     +                     MON_MDS_NUC_FUEL_LEASE_BURN_BC(CLASS,R_ISEAS)
            MON_MDS_NUC_FUEL_OWNED_BURN_BC(0,0) =
     +              MON_MDS_NUC_FUEL_OWNED_BURN_BC(0,0) +
     +                     MON_MDS_NUC_FUEL_OWNED_BURN_BC(CLASS,R_ISEAS)
            MON_MDS_NUCLEAR_MWH_BY_CLASS(0,0) =
     +         MON_MDS_NUCLEAR_MWH_BY_CLASS(0,0) +
     +                       MON_MDS_NUCLEAR_MWH_BY_CLASS(CLASS,R_ISEAS)
            MON_MDS_NUCLEAR_MMBTU_BY_CLASS(0,0) =
     +            MON_MDS_NUCLEAR_MMBTU_BY_CLASS(0,0) +
     +                     MON_MDS_NUCLEAR_MMBTU_BY_CLASS(CLASS,R_ISEAS)
            MON_MDS_ICAP_REV_BY_CLASS(0,0) =
     +                  MON_MDS_ICAP_REV_BY_CLASS(0,0) +
     +                          MON_MDS_ICAP_REV_BY_CLASS(CLASS,R_ISEAS)
!
!
            DO EMISS_TYPE = 1, NUMBER_OF_EMISSION_TYPES
! TOTAL ACROSS CLASSES
               MON_MDS_CL_CLASS_EMISSIONS(EMISS_TYPE,0,R_ISEAS) =
     +             MON_MDS_CL_CLASS_EMISSIONS(EMISS_TYPE,0,R_ISEAS) +
     +              MON_MDS_CL_CLASS_EMISSIONS(EMISS_TYPE,CLASS,R_ISEAS)
! TOTAL ACROSS MONTHS
               MON_MDS_CL_CLASS_EMISSIONS(EMISS_TYPE,CLASS,0) =
     +             MON_MDS_CL_CLASS_EMISSIONS(EMISS_TYPE,CLASS,0) +
     +              MON_MDS_CL_CLASS_EMISSIONS(EMISS_TYPE,CLASS,R_ISEAS)
! TOTAL ACROSS CLASSES AND MONTHS
               MON_MDS_CL_CLASS_EMISSIONS(EMISS_TYPE,0,0) =
     +             MON_MDS_CL_CLASS_EMISSIONS(EMISS_TYPE,0,0) +
     +              MON_MDS_CL_CLASS_EMISSIONS(EMISS_TYPE,CLASS,R_ISEAS)
            ENDDO
!
            DO I = 1, 4
! UNITS
               MON_MDS_CL_CLASS_VAR_COST(CLASS,I,R_ISEAS) =
     +               MON_MDS_CL_CLASS_VAR_COST(CLASS,I,R_ISEAS)/1000000.
               MON_MDS_CL_CLASS_FUEL_COST(CLASS,I,R_ISEAS)  =
     +              MON_MDS_CL_CLASS_FUEL_COST(CLASS,I,R_ISEAS)/1000000.
               MON_MDS_NF_FUEL_LEASED_BC(CLASS,I,R_ISEAS) =
     +               MON_MDS_NF_FUEL_LEASED_BC(CLASS,I,R_ISEAS)/1000000.
               MON_MDS_NF_FUEL_OWNED_BC(CLASS,I,R_ISEAS) =
     +                MON_MDS_NF_FUEL_OWNED_BC(CLASS,I,R_ISEAS)/1000000.
               MON_MDS_CL_CLASS_FIXED_COST(CLASS,I,R_ISEAS) =
     +             MON_MDS_CL_CLASS_FIXED_COST(CLASS,I,R_ISEAS)/1000000.
               MON_MDS_CL_CLASS_REVENUE(CLASS,I,R_ISEAS) =
     +                MON_MDS_CL_CLASS_REVENUE(CLASS,I,R_ISEAS)/1000000.
               MON_MDS_CL_CAP_REVENUE(CLASS,I,R_ISEAS) =
     +                MON_MDS_CL_CAP_REVENUE(CLASS,I,R_ISEAS)/1000000.
               MON_MDS_CL_CLASS_CAPACITY(CLASS,I,R_ISEAS) =
     +               MON_MDS_CL_CLASS_CAPACITY(CLASS,I,R_ISEAS)/1000000.
               MON_MDS_CL_CLASS_ENERGY(CLASS,I,R_ISEAS) =
     +                 MON_MDS_CL_CLASS_ENERGY(CLASS,I,R_ISEAS)/1000000.
               MON_MDS_CL_CLASS_PURCHASES(CLASS,I,R_ISEAS) =
     +              MON_MDS_CL_CLASS_PURCHASES(CLASS,I,R_ISEAS)/1000000.
               MON_MDS_CL_CAP_PURCHASES(CLASS,I,R_ISEAS) =
     +              MON_MDS_CL_CAP_PURCHASES(CLASS,I,R_ISEAS)/1000000.
! TOTAL ACROSS CLASSES
               MON_MDS_CL_CLASS_VAR_COST(0,I,R_ISEAS) =
     +               MON_MDS_CL_CLASS_VAR_COST(0,I,R_ISEAS) +
     +                        MON_MDS_CL_CLASS_VAR_COST(CLASS,I,R_ISEAS)
               MON_MDS_CL_CLASS_FUEL_COST(0,I,R_ISEAS) =
     +                   MON_MDS_CL_CLASS_FUEL_COST(0,I,R_ISEAS) +
     +                       MON_MDS_CL_CLASS_FUEL_COST(CLASS,I,R_ISEAS)
               MON_MDS_NF_FUEL_LEASED_BC(0,I,R_ISEAS) =
     +                   MON_MDS_NF_FUEL_LEASED_BC(0,I,R_ISEAS) +
     +                        MON_MDS_NF_FUEL_LEASED_BC(CLASS,I,R_ISEAS)
               MON_MDS_NF_FUEL_OWNED_BC(0,I,R_ISEAS) =
     +                  MON_MDS_NF_FUEL_OWNED_BC(0,I,R_ISEAS) +
     +                         MON_MDS_NF_FUEL_OWNED_BC(CLASS,I,R_ISEAS)
               MON_MDS_CL_CLASS_FIXED_COST(0,I,R_ISEAS) =
     +               MON_MDS_CL_CLASS_FIXED_COST(0,I,R_ISEAS) +
     +                      MON_MDS_CL_CLASS_FIXED_COST(CLASS,I,R_ISEAS)
               MON_MDS_CL_CLASS_REVENUE(0,I,R_ISEAS) =
     +               MON_MDS_CL_CLASS_REVENUE(0,I,R_ISEAS) +
     +                         MON_MDS_CL_CLASS_REVENUE(CLASS,I,R_ISEAS)
               MON_MDS_CL_CAP_REVENUE(0,I,R_ISEAS) =
     +               MON_MDS_CL_CAP_REVENUE(0,I,R_ISEAS) +
     +                         MON_MDS_CL_CAP_REVENUE(CLASS,I,R_ISEAS)
               MON_MDS_CL_CLASS_CAPACITY(0,I,R_ISEAS) =
     +                  MON_MDS_CL_CLASS_CAPACITY(0,I,R_ISEAS) +
     +                        MON_MDS_CL_CLASS_CAPACITY(CLASS,I,R_ISEAS)
               MON_MDS_CL_CLASS_ENERGY(0,I,R_ISEAS) =
     +                  MON_MDS_CL_CLASS_ENERGY(0,I,R_ISEAS) +
     +                          MON_MDS_CL_CLASS_ENERGY(CLASS,I,R_ISEAS)
               MON_MDS_CL_CLASS_PURCHASES(0,I,R_ISEAS) =
     +                  MON_MDS_CL_CLASS_PURCHASES(0,I,R_ISEAS) +
     +                       MON_MDS_CL_CLASS_PURCHASES(CLASS,I,R_ISEAS)
               MON_MDS_CL_CAP_PURCHASES(0,I,R_ISEAS) =
     +                  MON_MDS_CL_CAP_PURCHASES(0,I,R_ISEAS) +
     +                       MON_MDS_CL_CAP_PURCHASES(CLASS,I,R_ISEAS)
! TOTAL ACROSS MONTHS
               MON_MDS_CL_CLASS_VAR_COST(CLASS,I,0) =
     +               MON_MDS_CL_CLASS_VAR_COST(CLASS,I,0) +
     +                        MON_MDS_CL_CLASS_VAR_COST(CLASS,I,R_ISEAS)
               MON_MDS_CL_CLASS_FUEL_COST(CLASS,I,0) =
     +                   MON_MDS_CL_CLASS_FUEL_COST(CLASS,I,0) +
     +                       MON_MDS_CL_CLASS_FUEL_COST(CLASS,I,R_ISEAS)
               MON_MDS_NF_FUEL_LEASED_BC(CLASS,I,0) =
     +                   MON_MDS_NF_FUEL_LEASED_BC(CLASS,I,0) +
     +                        MON_MDS_NF_FUEL_LEASED_BC(CLASS,I,R_ISEAS)
               MON_MDS_NF_FUEL_OWNED_BC(CLASS,I,0) =
     +                  MON_MDS_NF_FUEL_OWNED_BC(CLASS,I,0) +
     +                         MON_MDS_NF_FUEL_OWNED_BC(CLASS,I,R_ISEAS)
               MON_MDS_CL_CLASS_FIXED_COST(CLASS,I,0) =
     +               MON_MDS_CL_CLASS_FIXED_COST(CLASS,I,0) +
     +                      MON_MDS_CL_CLASS_FIXED_COST(CLASS,I,R_ISEAS)
               MON_MDS_CL_CLASS_REVENUE(CLASS,I,0) =
     +               MON_MDS_CL_CLASS_REVENUE(CLASS,I,0) +
     +                         MON_MDS_CL_CLASS_REVENUE(CLASS,I,R_ISEAS)
               MON_MDS_CL_CAP_REVENUE(CLASS,I,0) =
     +               MON_MDS_CL_CAP_REVENUE(CLASS,I,0) +
     +                         MON_MDS_CL_CAP_REVENUE(CLASS,I,R_ISEAS)
               MON_MDS_CL_CLASS_CAPACITY(CLASS,I,0) =
     +                  MON_MDS_CL_CLASS_CAPACITY(CLASS,I,0) +
     +                        MON_MDS_CL_CLASS_CAPACITY(CLASS,I,R_ISEAS)
               MON_MDS_CL_CLASS_ENERGY(CLASS,I,0) =
     +                  MON_MDS_CL_CLASS_ENERGY(CLASS,I,0) +
     +                          MON_MDS_CL_CLASS_ENERGY(CLASS,I,R_ISEAS)
               MON_MDS_CL_CLASS_PURCHASES(CLASS,I,0) =
     +                  MON_MDS_CL_CLASS_PURCHASES(CLASS,I,0) +
     +                       MON_MDS_CL_CLASS_PURCHASES(CLASS,I,R_ISEAS)
               MON_MDS_CL_CAP_PURCHASES(CLASS,I,0) =
     +                  MON_MDS_CL_CAP_PURCHASES(CLASS,I,0) +
     +                       MON_MDS_CL_CAP_PURCHASES(CLASS,I,R_ISEAS)
! TOTAL ACROSS CLASSES AND MONTHS
               MON_MDS_CL_CLASS_VAR_COST(0,I,0) =
     +               MON_MDS_CL_CLASS_VAR_COST(0,I,0) +
     +                        MON_MDS_CL_CLASS_VAR_COST(CLASS,I,R_ISEAS)
               MON_MDS_CL_CLASS_FUEL_COST(0,I,0) =
     +                   MON_MDS_CL_CLASS_FUEL_COST(0,I,0) +
     +                       MON_MDS_CL_CLASS_FUEL_COST(CLASS,I,R_ISEAS)
               MON_MDS_NF_FUEL_LEASED_BC(0,I,0) =
     +                   MON_MDS_NF_FUEL_LEASED_BC(0,I,0) +
     +                        MON_MDS_NF_FUEL_LEASED_BC(CLASS,I,R_ISEAS)
               MON_MDS_NF_FUEL_OWNED_BC(0,I,0) =
     +                  MON_MDS_NF_FUEL_OWNED_BC(0,I,0) +
     +                         MON_MDS_NF_FUEL_OWNED_BC(CLASS,I,R_ISEAS)
               MON_MDS_CL_CLASS_FIXED_COST(0,I,0) =
     +               MON_MDS_CL_CLASS_FIXED_COST(0,I,0) +
     +                      MON_MDS_CL_CLASS_FIXED_COST(CLASS,I,R_ISEAS)
               MON_MDS_CL_CLASS_REVENUE(0,I,0) =
     +               MON_MDS_CL_CLASS_REVENUE(0,I,0) +
     +                         MON_MDS_CL_CLASS_REVENUE(CLASS,I,R_ISEAS)
               MON_MDS_CL_CAP_REVENUE(0,I,0) =
     +               MON_MDS_CL_CAP_REVENUE(0,I,0) +
     +                         MON_MDS_CL_CAP_REVENUE(CLASS,I,R_ISEAS)
               MON_MDS_CL_CLASS_CAPACITY(0,I,0) =
     +                  MON_MDS_CL_CLASS_CAPACITY(0,I,0) +
     +                        MON_MDS_CL_CLASS_CAPACITY(CLASS,I,R_ISEAS)
               MON_MDS_CL_CLASS_ENERGY(0,I,0) =
     +                  MON_MDS_CL_CLASS_ENERGY(0,I,0) +
     +                          MON_MDS_CL_CLASS_ENERGY(CLASS,I,R_ISEAS)
               MON_MDS_CL_CLASS_PURCHASES(0,I,0) =
     +                  MON_MDS_CL_CLASS_PURCHASES(0,I,0) +
     +                       MON_MDS_CL_CLASS_PURCHASES(CLASS,I,R_ISEAS)
               MON_MDS_CL_CAP_PURCHASES(0,I,0) =
     +                  MON_MDS_CL_CAP_PURCHASES(0,I,0) +
     +                       MON_MDS_CL_CAP_PURCHASES(CLASS,I,R_ISEAS)
            ENDDO
            DO I = 1, NUM_FUEL_CATEGORIES
! UNITS
               MON_MDS_CL_MULT_FUEL_COST(CLASS,I,R_ISEAS)  =
     +               MON_MDS_CL_MULT_FUEL_COST(CLASS,I,R_ISEAS)/1000000.
 !              IF(FIRST_ENERGY) THEN
 !                 FE_ANN_MULT_FUEL_COST(CLASS,I)  =
 !    +                           FE_ANN_MULT_FUEL_COST(CLASS,I)/1000000.
 !                 FE_ANN_MULT_FUEL_COST(0,I) =
 !    +                           FE_ANN_MULT_FUEL_COST(0,I) +
 !    +                                    FE_ANN_MULT_FUEL_COST(CLASS,I)
 !              ENDIF
               MON_MDS_CL_MULT_VAR_COST(CLASS,I,R_ISEAS) =
     +                MON_MDS_CL_MULT_VAR_COST(CLASS,I,R_ISEAS)/1000000.
               MON_MDS_CL_MULT_FIXED_COST(CLASS,I,R_ISEAS) =
     +              MON_MDS_CL_MULT_FIXED_COST(CLASS,I,R_ISEAS)/1000000.
               MON_MDS_CL_MULT_CAPACITY(CLASS,I,R_ISEAS) =
     +              MON_MDS_CL_MULT_CAPACITY(CLASS,I,R_ISEAS)/1000000.
               MON_MDS_CL_MULT_ENERGY(CLASS,I,R_ISEAS) =
     +              MON_MDS_CL_MULT_ENERGY(CLASS,I,R_ISEAS)/1000000.
               MON_MDS_CL_MULT_PURCHASES(CLASS,I,R_ISEAS) =
     +              MON_MDS_CL_MULT_PURCHASES(CLASS,I,R_ISEAS)/1000000.
!
!               CL_ANN_MULT_FIXED_COST(CLASS,I) =
!     +                         CL_ANN_MULT_FIXED_COST(CLASS,I)/1000000.
!               CL_ANN_MULT_REVENUE(CLASS,I) =
!     +                            CL_ANN_MULT_REVENUE(CLASS,I)/1000000.
!               CL_ANN_MULT_CAPACITY(CLASS,I) =
!     +                           CL_ANN_MULT_CAPACITY(CLASS,I)/1000000.
!               CL_ANN_MULT_ENERGY(CLASS,I) =
!     +                             CL_ANN_MULT_ENERGY(CLASS,I)/1000000.
!               CL_ANN_MULT_PURCHASES(CLASS,I) =
!     +                          CL_ANN_MULT_PURCHASES(CLASS,I)/1000000.
!
! CLASSES
!
               MON_MDS_CL_MULT_FUEL_COST(0,I,R_ISEAS) =
     +               MON_MDS_CL_MULT_FUEL_COST(0,I,R_ISEAS) +
     +                        MON_MDS_CL_MULT_FUEL_COST(CLASS,I,R_ISEAS)
               MON_MDS_CL_MULT_VAR_COST(0,I,R_ISEAS) =
     +               MON_MDS_CL_MULT_VAR_COST(0,I,R_ISEAS) +
     +                        MON_MDS_CL_MULT_VAR_COST(CLASS,I,R_ISEAS)
               MON_MDS_CL_MULT_FIXED_COST(0,I,R_ISEAS) =
     +               MON_MDS_CL_MULT_FIXED_COST(0,I,R_ISEAS) +
     +                       MON_MDS_CL_MULT_FIXED_COST(CLASS,I,R_ISEAS)
               MON_MDS_CL_MULT_CAPACITY(0,I,R_ISEAS) =
     +               MON_MDS_CL_MULT_CAPACITY(0,I,R_ISEAS) +
     +                         MON_MDS_CL_MULT_CAPACITY(CLASS,I,R_ISEAS)
               MON_MDS_CL_MULT_ENERGY(0,I,R_ISEAS) =
     +               MON_MDS_CL_MULT_ENERGY(0,I,R_ISEAS) +
     +                           MON_MDS_CL_MULT_ENERGY(CLASS,I,R_ISEAS)
               MON_MDS_CL_MULT_PURCHASES(0,I,R_ISEAS) =
     +               MON_MDS_CL_MULT_PURCHASES(0,I,R_ISEAS) +
     +                        MON_MDS_CL_MULT_PURCHASES(CLASS,I,R_ISEAS)
!               CL_ANN_MULT_FIXED_COST(0,I) =
!     +                                  CL_ANN_MULT_FIXED_COST(0,I) +
!     +                                  CL_ANN_MULT_FIXED_COST(CLASS,I)
!               CL_ANN_MULT_REVENUE(0,I) = CL_ANN_MULT_REVENUE(0,I) +
!     +                                     CL_ANN_MULT_REVENUE(CLASS,I)
!               CL_ANN_MULT_CAPACITY(0,I) = CL_ANN_MULT_CAPACITY(0,I) +
!     +                                    CL_ANN_MULT_CAPACITY(CLASS,I)
!               CL_ANN_MULT_ENERGY(0,I) = CL_ANN_MULT_ENERGY(0,I) +
!     +                                      CL_ANN_MULT_ENERGY(CLASS,I)
!               CL_ANN_MULT_PURCHASES(0,I) = CL_ANN_MULT_PURCHASES(0,I) +
!     +                                   CL_ANN_MULT_PURCHASES(CLASS,I)
! MONTHS
!
               MON_MDS_CL_MULT_FUEL_COST(CLASS,I,0) =
     +               MON_MDS_CL_MULT_FUEL_COST(CLASS,I,0) +
     +                        MON_MDS_CL_MULT_FUEL_COST(CLASS,I,R_ISEAS)
               MON_MDS_CL_MULT_VAR_COST(CLASS,I,0) =
     +               MON_MDS_CL_MULT_VAR_COST(CLASS,I,0) +
     +                         MON_MDS_CL_MULT_VAR_COST(CLASS,I,R_ISEAS)
               MON_MDS_CL_MULT_FIXED_COST(CLASS,I,0) =
     +               MON_MDS_CL_MULT_FIXED_COST(CLASS,I,0) +
     +                       MON_MDS_CL_MULT_FIXED_COST(CLASS,I,R_ISEAS)
               MON_MDS_CL_MULT_CAPACITY(CLASS,I,0) =
     +               MON_MDS_CL_MULT_CAPACITY(CLASS,I,0) +
     +                       MON_MDS_CL_MULT_CAPACITY(CLASS,I,R_ISEAS)
               MON_MDS_CL_MULT_ENERGY(CLASS,I,0) =
     +               MON_MDS_CL_MULT_ENERGY(CLASS,I,0) +
     +                       MON_MDS_CL_MULT_ENERGY(CLASS,I,R_ISEAS)
               MON_MDS_CL_MULT_PURCHASES(CLASS,I,0) =
     +               MON_MDS_CL_MULT_PURCHASES(CLASS,I,0) +
     +                       MON_MDS_CL_MULT_PURCHASES(CLASS,I,R_ISEAS)
!
! CLASSES AND MONTHS
!
               MON_MDS_CL_MULT_FUEL_COST(0,I,0) =
     +               MON_MDS_CL_MULT_FUEL_COST(0,I,0) +
     +                        MON_MDS_CL_MULT_FUEL_COST(CLASS,I,R_ISEAS)
               MON_MDS_CL_MULT_VAR_COST(0,I,0) =
     +               MON_MDS_CL_MULT_VAR_COST(0,I,0) +
     +                         MON_MDS_CL_MULT_VAR_COST(CLASS,I,R_ISEAS)
               MON_MDS_CL_MULT_FIXED_COST(0,I,0) =
     +               MON_MDS_CL_MULT_FIXED_COST(0,I,0) +
     +                       MON_MDS_CL_MULT_FIXED_COST(CLASS,I,R_ISEAS)
               MON_MDS_CL_MULT_CAPACITY(0,I,0) =
     +               MON_MDS_CL_MULT_CAPACITY(0,I,0) +
     +                       MON_MDS_CL_MULT_CAPACITY(CLASS,I,R_ISEAS)
               MON_MDS_CL_MULT_ENERGY(0,I,0) =
     +               MON_MDS_CL_MULT_ENERGY(0,I,0) +
     +                       MON_MDS_CL_MULT_ENERGY(CLASS,I,R_ISEAS)
               MON_MDS_CL_MULT_PURCHASES(0,I,0) =
     +               MON_MDS_CL_MULT_PURCHASES(0,I,0) +
     +                       MON_MDS_CL_MULT_PURCHASES(CLASS,I,R_ISEAS)
            ENDDO
         ENDDO
      RETURN
C***********************************************************************
      ENTRY RETURN_ECITIES_OBJ_VARS(R_CLASS,
     +                              R_ECITIES_WHOLESALE_PROD_COST,  ! 684  C-PROD
     +                              R_ECITIES_VAR_PROD_COST,        ! 685  C-SUPP
     +                              R_ECITIES_NEW_FIXED_COST,       ! 686  C-CAP
     +                              R_ECITIES_MARKET_ENERGY_SALES,  ! 687  R
     +                              R_ECITIES_TRANSMISSION_FEES)     ! 688  C-FEES
C***********************************************************************
         IF(R_CLASS <= MAX_CAP_LIMITED_CLASS_ID_NUM .AND. ECITIES) THEN
            IF(R_CLASS ==0) THEN
               CLASS = 0
            ELSE
               CLASS = ASSET_CLASS_POINTER(R_CLASS)
            ENDIF
            IF(CLASS > 0 .OR. R_CLASS == 0) THEN
               THIS_YEAR = YEAR + BASE_YEAR
               DO MO = 0, 12
!
                  TEMP_L =
     +                  POWER_DERIV_REV_EXP_BY_CLASS( R_CLASS,
     +                                             MO,
     +                                             TOTAL_DERIV_REV,
     +                                             TOTAL_DERIV_EXP)
!
                  R_MONTH_AC_WHOLESALE_PROD_COST(MO) =
     +                   MONTHLY_AC_WHOLESALE_PROD_COST(CLASS,MO)
                  R_MONTH_AC_ECITY_VAR_PROD_COST(MO) =
     +                   MONTHLY_AC_ECITY_VAR_PROD_COST(CLASS,MO)
                  R_MONTH_AC_ECITY_NEW_FIX_COST(MO) =
     +                    MONTHLY_AC_ECITY_NEW_FIX_COST(CLASS,MO)
                  R_MONTH_AC_ECITY_SUPP(MO) =
!     +                  MON_MDS_CL_CLASS_PURCHASES(CLASS,1,MO) +
!     +                  MON_MDS_CL_CLASS_PURCHASES(CLASS,2,MO) +
!     +                  MON_MDS_CL_CLASS_PURCHASES(CLASS,3,MO) +
!     +                  MON_MDS_CL_CLASS_PURCHASES(CLASS,4,MO) +
     +                  MONTHLY_AC_ECITY_VAR_PROD_COST(CLASS,MO)
                  R_MONTH_AC_ECITY_REVENUE(MO) =
     +                  MON_MDS_CL_CLASS_REVENUE(CLASS,1,MO)
     +                  + MON_MDS_CL_CLASS_REVENUE(CLASS,2,MO)
     +                  + MON_MDS_CL_CLASS_REVENUE(CLASS,3,MO)
     +                  + MON_MDS_CL_CLASS_REVENUE(CLASS,4,MO)
     +                  + TOTAL_DERIV_REV
                  R_MONTH_AC_ECITY_FEES(MO) = TOTAL_DERIV_EXP
!
!  CHECK UNITS, KATHY TO PASS EXAMPLE
!
                  R_WTB(MO) =  R_MONTH_AC_ECITY_REVENUE(MO)  ! DONE.
     +                         - R_MONTH_AC_WHOLESALE_PROD_COST(MO)  ! DONE.
     +                         - R_MONTH_AC_ECITY_SUPP(MO)  ! DONE.
     +                         - R_MONTH_AC_ECITY_FEES(MO)  ! DONE.
     +                         - R_MONTH_AC_ECITY_NEW_FIX_COST(MO) ! DONE.
!
                  ECITY_OBJ_REPORT = .TRUE. ! HARD-WIRED FOR NOW.
                  IF(ECITY_OBJ_REPORT) THEN
!
                     IF(ECITY_OBJ_REPORT_NOT_OPEN) THEN
                        ECITY_OBJ_REPORT_NOT_OPEN = .FALSE.
                        ECITY_VARIABLE_NUMBER = 8
                        ECITY_OBJ_UNIT =
     +                     ECITY_OBJ_HEADER(ECITY_VARIABLE_NUMBER,
     +                                                    ECITY_OBJ_REC)
                     ENDIF
!
                     IF(MO > 0) THEN
                        LOCAL_MONTH = MO
                     ELSE
                        LOCAL_MONTH = 13
                     ENDIF
!
                     WRITE(ECITY_OBJ_UNIT,REC=ECITY_OBJ_REC)
     +                        PRT_ENDPOINT(),
     +                        FLOAT(THIS_YEAR),
     +                        FLOAT(R_CLASS-1),
     +                        CL_MONTH_NAME(LOCAL_MONTH),
     +                        R_WTB(MO),
     +                        R_MONTH_AC_ECITY_REVENUE(MO),
     +                        R_MONTH_AC_WHOLESALE_PROD_COST(MO),
     +                        R_MONTH_AC_ECITY_SUPP(MO),
     +                        R_MONTH_AC_ECITY_FEES(MO),
     +                        R_MONTH_AC_ECITY_NEW_FIX_COST(MO),
     +                        TOTAL_DERIV_REV,
     +                        TOTAL_DERIV_EXP
                     ECITY_OBJ_REC = ECITY_OBJ_REC + 1
!
                  ENDIF
               ENDDO
!
            ELSE ! ASSET CLASSES NOT ACTIVE
!
               DO MO = 0, 12
                  R_WTB(MO) = 0.
                  R_MONTH_AC_ECITY_REVENUE(MO) = 0.  ! DONE.
                  R_MONTH_AC_WHOLESALE_PROD_COST(MO) = 0.  ! DONE.
                  R_MONTH_AC_ECITY_SUPP(MO) = 0.  ! DONE.
                  R_MONTH_AC_ECITY_FEES(MO) = 0.  ! DONE.
                  R_MONTH_AC_ECITY_NEW_FIX_COST(MO) = 0. ! DONE.
               ENDDO
!
            ENDIF
            RETURN_ECITIES_OBJ_VARS = R_WTB(0)
            R_ECITIES_WHOLESALE_PROD_COST =
     +                                 R_MONTH_AC_WHOLESALE_PROD_COST(0)  ! 684  C-PROD
            R_ECITIES_VAR_PROD_COST = R_MONTH_AC_ECITY_SUPP(0)        ! 685  C-SUPP
            R_ECITIES_NEW_FIXED_COST = R_MONTH_AC_ECITY_NEW_FIX_COST(0)       ! 686  C-CAP
            R_ECITIES_MARKET_ENERGY_SALES = R_MONTH_AC_ECITY_REVENUE(0)  ! 687  R
            R_ECITIES_TRANSMISSION_FEES = R_MONTH_AC_ECITY_FEES(0)     ! 688  C-FEES
         ELSE
            RETURN_ECITIES_OBJ_VARS = 0.
            R_ECITIES_WHOLESALE_PROD_COST = 0.
            R_ECITIES_VAR_PROD_COST = 0.
            R_ECITIES_NEW_FIXED_COST = 0.
            R_ECITIES_MARKET_ENERGY_SALES = 0.
            R_ECITIES_TRANSMISSION_FEES = 0.
         ENDIF
      RETURN
C***********************************************************************
      ENTRY CL_EXPENSES_2_ASSET_CLASSES()
C***********************************************************************
!         LOGICAL*1 BASE_EL_REVENUE_CASE,
!     +             PEAK_EL_REVENUE_CASE
C
         ALLOCATE(ASSET_CLASS_LIST(AVAIL_DATA_YEARS))
         ALLOCATE(ASSET_ALLOCATION_LIST(AVAIL_DATA_YEARS))
         CURRENT_YEAR = YEAR+BASE_YEAR
         CURRENT_YEAR_COMPARISON = (CURRENT_YEAR-1900)*100
         CL_ANN_CLASS_VAR_COST = 0.
         CL_ANN_CLASS_FUEL_COST = 0.
         NF_FUEL_LEASED_BY_CLASS = 0.
         NF_FUEL_OWNED_BY_CLASS = 0.
         CL_ANN_CLASS_FIXED_COST = 0.
         CL_ANN_CLASS_CAPACITY = 0.
         CL_ANN_CLASS_ENERGY = 0.
C SLOT 5 RESERVED FOR AMEREN 12/11/01
         CL_ANN_CLASS_PURCHASES = 0.
         CL_ANN_CLASS_REVENUE = 0.
         CL_ANN_CLASS_EMISSIONS = 0.
         INTRA_COMPANY_REVENUES = 0.
         INTRA_COMPANY_NF_BURN = 0.
         NUC_FUEL_LEASED_BURN_BY_CLASS = 0.
         NUC_FUEL_OWNED_BURN_BY_CLASS = 0.
         NUCLEAR_MWH_BY_CLASS = 0.
         NUCLEAR_MMBTU_BY_CLASS = 0.
C
         MAX_INTRA_CLASS = 0
         INTRA_FOSSIL_FUEL_EXPENSES = 0.
         INTRA_LEASED_NUC_FUEL_EXPENSES = 0.
         INTRA_OWNED_NUC_FUEL_EXPENSES = 0.
         INTRA_NUC_OWN_BURN = 0.
         INTRA_NUC_LEASE_BURN = 0.
         INTRA_PURCHASE_EXPENSES = 0.
         BASE_MARKET_ENRG_SALES = 0.
         BASE_MARKET_REVENUES = 0.
         PEAK_MARKET_ENRG_SALES = 0.
         PEAK_MARKET_REVENUES = 0.
         CL_EXPENSES_2_ASSET_CLASSES = UNUM
!
         CL_ANN_MULT_FUEL_COST = 0.
         FE_ANN_MULT_FUEL_COST = 0.
         CL_ANN_MULT_VAR_COST = 0.
         CL_ANN_MULT_FIXED_COST = 0.
         CL_ANN_MULT_REVENUE = 0.
         CL_ANN_MULT_CAPACITY = 0.
         CL_ANN_MULT_ENERGY = 0.
         CL_ANN_MULT_PURCHASES = 0.
C
         DO UNUM = 1, NUNITS
C
            IF(ONLINE(UNUM) - CURRENT_YEAR_COMPARISON > 12  .OR.
     +                CURRENT_YEAR_COMPARISON - OFLINE(UNUM) > 12) CYCLE
C
C
            IF(INTRA_COMPANY_CLASS_ID(UNUM) >= 0 .AND.
     +                      INTRA_COMPANY_TRANSACTION(UNUM) == 'Y') THEN
               ASSET_CLASS = INTRA_COMPANY_CLASS_ID(UNUM)
               CALL CHECK_IF_CLASS_DEFINED(ASSET_CLASS)
               ASSET_CLASS = ASSET_CLASS + 1
               MAX_INTRA_CLASS = MAX(MAX_INTRA_CLASS,ASSET_CLASS)
C
               SELECT CASE (EXPENSE_ASSIGNMENT(UNUM))
               CASE('F')  ! FUEL REVENUES
                  COLLECTION = MAX(1,
     +                           INDEX('BA',(EXPENSE_COLLECTION(UNUM))))
                  INTRA_COMPANY_REVENUES(ASSET_CLASS,COLLECTION) =
     +                  INTRA_COMPANY_REVENUES(ASSET_CLASS,COLLECTION) +
     +                                    ANNUAL_CL_UNIT_FUEL_COST(UNUM)
     +                                      *CL_POOL_FRAC_OWN(UNUM)/100.
               CASE('L','O')  ! FUEL REVENUES
                  COLLECTION = MAX(1,
     +                           INDEX('BA',(EXPENSE_COLLECTION(UNUM))))
                  INTRA_COMPANY_REVENUES(ASSET_CLASS,COLLECTION) =
     +                  INTRA_COMPANY_REVENUES(ASSET_CLASS,COLLECTION) +
     +                                    ANNUAL_CL_UNIT_FUEL_COST(UNUM)
     +                                      *CL_POOL_FRAC_OWN(UNUM)/100.
                  INTRA_COMPANY_NF_BURN(ASSET_CLASS) =
     +                           INTRA_COMPANY_NF_BURN(ASSET_CLASS) +
     +                           (ANNUAL_CL_UNIT_FUEL_COST(UNUM)-
     +                            ANNUAL_NUC_UNIT_FUEL_ADDER_COST(UNUM))
     +                                      *CL_POOL_FRAC_OWN(UNUM)/100.
               CASE('P')  ! PURCHASE REVENUES
                  INTRA_COMPANY_REVENUES(ASSET_CLASS,3) =
     +                   INTRA_COMPANY_REVENUES(ASSET_CLASS,3) +
     +                                  (ANNUAL_CL_UNIT_FUEL_COST(UNUM)+
     +                                   ANNUAL_CL_UNIT_VAR_COST(UNUM) +
     +                                  ANNUAL_CL_UNIT_FIXED_COST(UNUM))
     +                                      *CL_POOL_FRAC_OWN(UNUM)/100.
               CASE DEFAULT
               END SELECT
C
               SELECT CASE (EXPENSE_ASSIGNMENT(UNUM))
               CASE('F')  ! FUEL EXPENSES
                  INTRA_FOSSIL_FUEL_EXPENSES =
     +                                    INTRA_FOSSIL_FUEL_EXPENSES +
     +                                    ANNUAL_CL_UNIT_FUEL_COST(UNUM)
     +                                      *CL_POOL_FRAC_OWN(UNUM)/100.
               CASE('L')  ! NUCLEAR FUEL EXPENSES
                  INTRA_LEASED_NUC_FUEL_EXPENSES =
     +                                  INTRA_LEASED_NUC_FUEL_EXPENSES +
     +                                  ANNUAL_CL_UNIT_FUEL_COST(UNUM)
     +                                      *CL_POOL_FRAC_OWN(UNUM)/100.
                  INTRA_NUC_LEASE_BURN = INTRA_NUC_LEASE_BURN +
     +                           (ANNUAL_CL_UNIT_FUEL_COST(UNUM)-
     +                            ANNUAL_NUC_UNIT_FUEL_ADDER_COST(UNUM))
     +                                      *CL_POOL_FRAC_OWN(UNUM)/100.
               CASE('O')  ! NUCLEAR FUEL EXPENSES
                  INTRA_OWNED_NUC_FUEL_EXPENSES =
     +                                   INTRA_OWNED_NUC_FUEL_EXPENSES +
     +                                   ANNUAL_CL_UNIT_FUEL_COST(UNUM)
     +                                      *CL_POOL_FRAC_OWN(UNUM)/100.
                  INTRA_NUC_OWN_BURN = INTRA_NUC_OWN_BURN +
     +                           (ANNUAL_CL_UNIT_FUEL_COST(UNUM)-
     +                            ANNUAL_NUC_UNIT_FUEL_ADDER_COST(UNUM))
     +                                      *CL_POOL_FRAC_OWN(UNUM)/100.
               CASE('P')  ! PURCHASE EXPENSES
                  INTRA_PURCHASE_EXPENSES = INTRA_PURCHASE_EXPENSES +
     +                                  (ANNUAL_CL_UNIT_FUEL_COST(UNUM)+
     +                                   ANNUAL_CL_UNIT_VAR_COST(UNUM) +
     +                                  ANNUAL_CL_UNIT_FIXED_COST(UNUM))
     +                                      *CL_POOL_FRAC_OWN(UNUM)/100.
               CASE DEFAULT
               END SELECT
            ENDIF
C
            COLLECTION = INDEX('ABNX',(EXPENSE_COLLECTION(UNUM)))
            IF(COLLECTION == 0) COLLECTION = 3
C
            ASSET_CLASS = ASSET_CLASS_NUM(UNUM)
            ASSET_ALLOCATION_VECTOR = ASSET_CLASS_VECTOR(UNUM)
C
C
            VOID_LOGICAL=RETURN_ASSET_CLASS_LISTS(ASSET_CLASS,
     +                                          ASSET_CLASS_LIST,
     +                                          ASSET_ALLOCATION_VECTOR,
     +                                          ASSET_ALLOCATION_LIST)
!
            FT = PRIMARY_MOVER(UNUM)
! 030310.
            if(ft == 0) ft = 11
            TT = 10
!
C
C           IF(ASSET_CLASS < 0) THEN
C              CALL GET_ASSET_VAR(ABS(ASSET_CLASS),
C    +                                 DUMMY_TYPE,ASSET_CLASS_LIST)
C              CALL GET_ASSET_VAR(ABS(ASSET_ALLOCATION_VECTOR),
C    +                                 DUMMY_TYPE,ASSET_ALLOCATION_LIST)
C           ELSE
C              ASSET_CLASS_LIST(1) = ASSET_CLASS
C              ASSET_CLASS_LIST(2) = 0.
C              ASSET_ALLOCATION_LIST(1) = 100.
C              ASSET_ALLOCATION_LIST(2) = 0.
C           ENDIF
            CLASS_POINTER = 1
            DO
               ASSET_CLASS = ASSET_CLASS_LIST(CLASS_POINTER)
               CALL CHECK_IF_CLASS_DEFINED(ASSET_CLASS)
C
C IDENTIFYING BASE AND PEAK EL REVENUE CLASSED
C
               BASE_EL_REVENUE_CASE = ASSET_CLASS == 10
               PEAK_EL_REVENUE_CASE = ASSET_CLASS == 19
C
               ASSET_CLASS = ASSET_CLASS + 1
               IF(ASSET_CLASS <= 0 .OR.
     +                 ASSET_CLASS > MAX_CAP_LIMITED_CLASS_ID_NUM) CYCLE
               ASSET_CLASS = ASSET_CLASS_POINTER(ASSET_CLASS)
               IF(ASSET_ALLOCATION_LIST(CLASS_POINTER) < 0.) THEN
                  ALLOCATION_VECTOR =
     +                         ABS(ASSET_ALLOCATION_LIST(CLASS_POINTER))
                  CALL GET_ASSET_VAR(ALLOCATION_VECTOR,
     +                                      DUMMY_TYPE,ALLOCATION_VALUE)
                  ASSET_ALLOCATOR = CL_POOL_FRAC_OWN(UNUM)/100. *
     +                 ALLOCATION_VALUE(MIN(YEAR,AVAIL_DATA_YEARS))/100.
               ELSE
                  ASSET_ALLOCATOR =
     +                       ASSET_ALLOCATION_LIST(CLASS_POINTER)/100. *
     +                       CL_POOL_FRAC_OWN(UNUM)/100.
               ENDIF
C
               DO I = 1, NUMBER_OF_EMISSION_TYPES
                  CL_ANN_CLASS_EMISSIONS(I,ASSET_CLASS) =
     +                           CL_ANN_CLASS_EMISSIONS(I,ASSET_CLASS) +
     +                              ASSET_ALLOCATOR *
     +                                  ANNUAL_CL_UNIT_EMISSIONS(I,UNUM)
               ENDDO
               IF(EXPENSE_ASSIGNMENT(UNUM) == 'L') THEN
                  NF_FUEL_LEASED_BY_CLASS(ASSET_CLASS,COLLECTION) =
     +                 NF_FUEL_LEASED_BY_CLASS(ASSET_CLASS,COLLECTION) +
     +                  ASSET_ALLOCATOR * ANNUAL_CL_UNIT_FUEL_COST(UNUM)
                  NUC_FUEL_LEASED_BURN_BY_CLASS(ASSET_CLASS) =
     +                NUC_FUEL_LEASED_BURN_BY_CLASS(ASSET_CLASS) +
     +                ASSET_ALLOCATOR * (ANNUAL_CL_UNIT_FUEL_COST(UNUM)-
     +                            ANNUAL_NUC_UNIT_FUEL_ADDER_COST(UNUM))
                  NUCLEAR_MWH_BY_CLASS(ASSET_CLASS) =
     +                     NUCLEAR_MWH_BY_CLASS(ASSET_CLASS) +
     +                     ASSET_ALLOCATOR * ANNUAL_CL_UNIT_ENERGY(UNUM)
                  NUCLEAR_MMBTU_BY_CLASS(ASSET_CLASS) =
     +                     NUCLEAR_MMBTU_BY_CLASS(ASSET_CLASS) +
     +                     ASSET_ALLOCATOR * ANNUAL_CL_UNIT_MMBTUS(UNUM)
               ELSEIF(EXPENSE_ASSIGNMENT(UNUM) == 'O') THEN
                  NF_FUEL_OWNED_BY_CLASS(ASSET_CLASS,COLLECTION) =
     +                  NF_FUEL_OWNED_BY_CLASS(ASSET_CLASS,COLLECTION) +
     +                  ASSET_ALLOCATOR *
     +                                   ANNUAL_CL_UNIT_FUEL_COST(UNUM)
                  NUC_FUEL_OWNED_BURN_BY_CLASS(ASSET_CLASS) =
     +                NUC_FUEL_OWNED_BURN_BY_CLASS(ASSET_CLASS) +
     +                ASSET_ALLOCATOR * (
     +                                   ANNUAL_CL_UNIT_FUEL_COST(UNUM)-
     +                            ANNUAL_NUC_UNIT_FUEL_ADDER_COST(UNUM))
                  NUCLEAR_MWH_BY_CLASS(ASSET_CLASS) =
     +                     NUCLEAR_MWH_BY_CLASS(ASSET_CLASS) +
     +                     ASSET_ALLOCATOR * ANNUAL_CL_UNIT_ENERGY(UNUM)
                  NUCLEAR_MMBTU_BY_CLASS(ASSET_CLASS) =
     +                     NUCLEAR_MMBTU_BY_CLASS(ASSET_CLASS) +
     +                     ASSET_ALLOCATOR * ANNUAL_CL_UNIT_MMBTUS(UNUM)
               ELSEIF(EXPENSE_ASSIGNMENT(UNUM) == 'P') THEN
                  CL_ANN_CLASS_PURCHASES(ASSET_CLASS,COLLECTION) =
     +                  CL_ANN_CLASS_PURCHASES(ASSET_CLASS,COLLECTION) +
     +                        ASSET_ALLOCATOR *
     +                             (ANNUAL_CL_UNIT_FUEL_COST(UNUM) +
     +                                ANNUAL_CL_UNIT_VAR_COST(UNUM) +
     +                                  ANNUAL_CL_UNIT_FIXED_COST(UNUM))
                  CL_ANN_CLASS_CAPACITY(ASSET_CLASS,2) =
     +                            CL_ANN_CLASS_CAPACITY(ASSET_CLASS,2) +
     +                   ASSET_ALLOCATOR * ANNUAL_CL_UNIT_CAPACITY(UNUM)
                  CL_ANN_CLASS_ENERGY(ASSET_CLASS,2) =
     +                              CL_ANN_CLASS_ENERGY(ASSET_CLASS,2) +
     +                     ASSET_ALLOCATOR * ANNUAL_CL_UNIT_ENERGY(UNUM)
! INVOKED 1/8/02.
!                  CL_ANN_MULT_PURCHASES(ASSET_CLASS,FT) =
!     +                           CL_ANN_MULT_PURCHASES(ASSET_CLASS,FT) +
!     +                        ASSET_ALLOCATOR *
!     +                             (ANNUAL_CL_UNIT_FUEL_COST(UNUM) +
!     +                                ANNUAL_CL_UNIT_VAR_COST(UNUM) +
!     +                                  ANNUAL_CL_UNIT_FIXED_COST(UNUM))
!
! 01/06/04. FOR FE
!
!                  MON_MDS_CL_MULT_PURCHASES(ASSET_CLASS,FT,0) =
!     +                     MON_MDS_CL_MULT_PURCHASES(ASSET_CLASS,FT,0) +
!     +                        ASSET_ALLOCATOR *
!     +                             (ANNUAL_CL_UNIT_FUEL_COST(UNUM) +
!     +                                ANNUAL_CL_UNIT_VAR_COST(UNUM) +
!     +                                  ANNUAL_CL_UNIT_FIXED_COST(UNUM))
!
               ELSE
                  CL_ANN_CLASS_FUEL_COST(ASSET_CLASS,COLLECTION) =
     +                  CL_ANN_CLASS_FUEL_COST(ASSET_CLASS,COLLECTION) +
     +                  ASSET_ALLOCATOR * ANNUAL_CL_UNIT_FUEL_COST(UNUM)
                  CL_ANN_MULT_FUEL_COST(ASSET_CLASS,FT) =
     +                  CL_ANN_MULT_FUEL_COST(ASSET_CLASS,FT) +
     +                  ASSET_ALLOCATOR * ANNUAL_CL_UNIT_FUEL_COST(UNUM)
                  IF(FIRST_ENERGY) THEN
                     IF(SPECIAL_UNIT_ID(UNUM) == 'BayShore') THEN
                        FE_ANN_MULT_FUEL_COST(ASSET_CLASS,3) =
     +                     FE_ANN_MULT_FUEL_COST(ASSET_CLASS,3) +
     +                     ASSET_ALLOCATOR *
     +                                    ANNUAL_CL_UNIT_FUEL_COST(UNUM)
!                     ELSEIF(SPECIAL_UNIT_ID(UNUM) == 'EastLake') THEN
!                        FE_ANN_MULT_FUEL_COST(ASSET_CLASS,5) =
!     +                     FE_ANN_MULT_FUEL_COST(ASSET_CLASS,5) +
!     +                     ASSET_ALLOCATOR *
!     +                                    ANNUAL_CL_UNIT_FUEL_COST(UNUM)
                     ELSEIF(PRIMARY_MOVER(UNUM) == 3 .OR.
     +                                    PRIMARY_MOVER(UNUM) == 5) THEN
                        FE_ANN_MULT_FUEL_COST(ASSET_CLASS,6) =
     +                     FE_ANN_MULT_FUEL_COST(ASSET_CLASS,6) +
     +                     ASSET_ALLOCATOR *
     +                                    ANNUAL_CL_UNIT_FUEL_COST(UNUM)
                     ELSE
                        FE_ANN_MULT_FUEL_COST(ASSET_CLASS,FT) =
     +                     FE_ANN_MULT_FUEL_COST(ASSET_CLASS,FT) +
     +                     ASSET_ALLOCATOR *
     +                                    ANNUAL_CL_UNIT_FUEL_COST(UNUM)
                     ENDIF
                  ENDIF
               ENDIF
               IF(EXPENSE_ASSIGNMENT(UNUM) /= 'P') THEN
                  CL_ANN_CLASS_VAR_COST(ASSET_CLASS,COLLECTION) =
     +                   CL_ANN_CLASS_VAR_COST(ASSET_CLASS,COLLECTION) +
     +                   ASSET_ALLOCATOR * ANNUAL_CL_UNIT_VAR_COST(UNUM)
                  CL_ANN_CLASS_FIXED_COST(ASSET_CLASS,COLLECTION)=
     +                 CL_ANN_CLASS_FIXED_COST(ASSET_CLASS,COLLECTION) +
     +                     ASSET_ALLOCATOR *
     +                                   ANNUAL_CL_UNIT_FIXED_COST(UNUM)
                  CL_ANN_CLASS_CAPACITY(ASSET_CLASS,1) =
     +                            CL_ANN_CLASS_CAPACITY(ASSET_CLASS,1) +
     +                   ASSET_ALLOCATOR * ANNUAL_CL_UNIT_CAPACITY(UNUM)
                  CL_ANN_CLASS_ENERGY(ASSET_CLASS,1) =
     +                              CL_ANN_CLASS_ENERGY(ASSET_CLASS,1) +
     +                     ASSET_ALLOCATOR * ANNUAL_CL_UNIT_ENERGY(UNUM)
!
                  CL_ANN_MULT_VAR_COST(ASSET_CLASS,FT) =
     +                   CL_ANN_MULT_VAR_COST(ASSET_CLASS,FT) +
     +                   ASSET_ALLOCATOR * ANNUAL_CL_UNIT_VAR_COST(UNUM)
                  CL_ANN_MULT_FIXED_COST(ASSET_CLASS,FT)=
     +                 CL_ANN_MULT_FIXED_COST(ASSET_CLASS,FT) +
     +                     ASSET_ALLOCATOR *
     +                                   ANNUAL_CL_UNIT_FIXED_COST(UNUM)
                  CL_ANN_MULT_CAPACITY(ASSET_CLASS,FT) =
     +                            CL_ANN_MULT_CAPACITY(ASSET_CLASS,FT) +
     +                   ASSET_ALLOCATOR * ANNUAL_CL_UNIT_CAPACITY(UNUM)
                  CL_ANN_MULT_ENERGY(ASSET_CLASS,FT) =
     +                              CL_ANN_MULT_ENERGY(ASSET_CLASS,FT) +
     +                     ASSET_ALLOCATOR * ANNUAL_CL_UNIT_ENERGY(UNUM)
               ENDIF
               IF(ECO_SALES_ENRG_FROM(UNUM) /= 0.) THEN
                  CL_ANN_CLASS_REVENUE(ASSET_CLASS,COLLECTION) =
     +                    CL_ANN_CLASS_REVENUE(ASSET_CLASS,COLLECTION) +
     +                        ASSET_ALLOCATOR * ECO_SALES_REV_FROM(UNUM)
                  CL_ANN_CLASS_ENERGY(ASSET_CLASS,3) =
     +                              CL_ANN_CLASS_ENERGY(ASSET_CLASS,3) +
     +                       ASSET_ALLOCATOR * ECO_SALES_ENRG_FROM(UNUM)
!
                  IF(ANNUAL_CL_UNIT_ENERGY(UNUM) > 0.) THEN
!
                     TT_PERCENT =  ECO_SALES_ENRG_FROM(UNUM)/
     +                                       ANNUAL_CL_UNIT_ENERGY(UNUM)
!
                     CL_ANN_MULT_FUEL_COST(ASSET_CLASS,TT) =
     +                  CL_ANN_MULT_FUEL_COST(ASSET_CLASS,TT) +
     +                  ASSET_ALLOCATOR *
     +                       ANNUAL_CL_UNIT_FUEL_COST(UNUM) * TT_PERCENT
                     CL_ANN_MULT_VAR_COST(ASSET_CLASS,TT) =
     +                   CL_ANN_MULT_VAR_COST(ASSET_CLASS,TT) +
     +                 ASSET_ALLOCATOR * ANNUAL_CL_UNIT_VAR_COST(UNUM) *
     +                                                        TT_PERCENT
                     CL_ANN_MULT_CAPACITY(ASSET_CLASS,TT) =
     +                            CL_ANN_MULT_CAPACITY(ASSET_CLASS,TT) +
     +                 ASSET_ALLOCATOR * ANNUAL_CL_UNIT_CAPACITY(UNUM) *
     +                                                        TT_PERCENT
                     CL_ANN_MULT_ENERGY(ASSET_CLASS,TT) =
     +                              CL_ANN_MULT_ENERGY(ASSET_CLASS,TT) +
     +                   ASSET_ALLOCATOR * ANNUAL_CL_UNIT_ENERGY(UNUM) *
     +                                                        TT_PERCENT
                  ENDIF
!
                  IF(BASE_EL_REVENUE_CASE) THEN
                     BASE_MARKET_ENRG_SALES = BASE_MARKET_ENRG_SALES +
     +                       ASSET_ALLOCATOR * ECO_SALES_ENRG_FROM(UNUM)
                     BASE_MARKET_REVENUES = BASE_MARKET_REVENUES +
     +                        ASSET_ALLOCATOR * ECO_SALES_REV_FROM(UNUM)
                  ELSEIF(PEAK_EL_REVENUE_CASE) THEN
                     PEAK_MARKET_ENRG_SALES = PEAK_MARKET_ENRG_SALES +
     +                       ASSET_ALLOCATOR * ECO_SALES_ENRG_FROM(UNUM)
                     PEAK_MARKET_REVENUES = PEAK_MARKET_REVENUES +
     +                        ASSET_ALLOCATOR * ECO_SALES_REV_FROM(UNUM)
                  ENDIF
               ENDIF
               IF(ECO_PUCH_ENRG_FROM(UNUM) /= 0.) THEN
! THIS WILL WORK ONLY FOR ASSET ANALYST.
                  IF(UPPER_TRANS_GROUP > 0) THEN
                     TG = TRANSACTION_GROUP_ID(UNUM) ! NOTE DOUBLE ASSIGNMENT
                     TG = GET_TRANS_GROUP_POSITION(TG)
                     IF(PURCHASE_POWER_ASSIGN(TG) /= 'U') THEN
                        TG_ASSET_CLASS = PURCHASE_ASSET_CLASS_ID(TG)
!                        TG_ASSET_CLASS = 15
                        CALL CHECK_IF_CLASS_DEFINED(TG_ASSET_CLASS)
                        TG_ASSET_CLASS = TG_ASSET_CLASS + 1
                        IF(TG_ASSET_CLASS > 0 .AND. TG_ASSET_CLASS <=
     +                                MAX_CAP_LIMITED_CLASS_ID_NUM) THEN
                           TG_ASSET_CLASS =
     +                               ASSET_CLASS_POINTER(TG_ASSET_CLASS)
                           CL_ANN_CLASS_PURCHASES(TG_ASSET_CLASS,
     +                                                     COLLECTION) =
     +                        CL_ANN_CLASS_PURCHASES(TG_ASSET_CLASS,
     +                                                     COLLECTION) +
     +                                          ECO_PUCH_COST_FROM(UNUM)
                           ECO_PUCH_COST_FROM(UNUM) = 0.
                        ENDIF
                     ENDIF
                  ENDIF
!
!
                  CL_ANN_CLASS_PURCHASES(ASSET_CLASS,COLLECTION) =
     +                  CL_ANN_CLASS_PURCHASES(ASSET_CLASS,COLLECTION) +
     +                        ASSET_ALLOCATOR * ECO_PUCH_COST_FROM(UNUM)
                  CL_ANN_CLASS_ENERGY(ASSET_CLASS,4) =
     +                              CL_ANN_CLASS_ENERGY(ASSET_CLASS,4) +
     +                        ASSET_ALLOCATOR * ECO_PUCH_ENRG_FROM(UNUM)
!
!                  IF(ECO_PUCH_ENRG_FROM(UNUM) +
!     +                            ANNUAL_CL_UNIT_ENERGY(UNUM) > 0.) THEN
!
!                        TT_PERCENT =  ECO_PUCH_ENRG_FROM(UNUM)/
!     +                                    (ECO_PUCH_ENRG_FROM(UNUM) +
!     +                                      ANNUAL_CL_UNIT_ENERGY(UNUM))
!
!                        CL_ANN_MULT_CAPACITY(ASSET_CLASS,TT+1)=
!     +                            CL_ANN_MULT_CAPACITY(ASSET_CLASS,TT+1)
!     +                              + ASSET_ALLOCATOR *
!     +                                   ANNUAL_CL_UNIT_CAPACITY(UNUM) *
!     +                                                        TT_PERCENT
!                        CL_ANN_MULT_ENERGY(ASSET_CLASS,TT+1) =
!     +                              CL_ANN_MULT_ENERGY(ASSET_CLASS,TT+1)
!     +                                 + ASSET_ALLOCATOR *
!     +                                          ECO_PUCH_ENRG_FROM(UNUM)
!     +                                     ANNUAL_CL_UNIT_ENERGY(UNUM) *
!     +                                                        TT_PERCENT
! INVOKED 1/8/02.
!                        CL_ANN_MULT_PURCHASES(ASSET_CLASS,TT+1) =
!     +                         CL_ANN_MULT_PURCHASES(ASSET_CLASS,TT+1) +
!     +                        ASSET_ALLOCATOR * ECO_PUCH_COST_FROM(UNUM)
! 01/06/04.
!                        MON_MDS_CL_MULT_PURCHASES(ASSET_CLASS,TT+1,0) =
!     +                   MON_MDS_CL_MULT_PURCHASES(ASSET_CLASS,TT+1,0) +
!     +                        ASSET_ALLOCATOR * ECO_PUCH_COST_FROM(UNUM)
!
!                  ENDIF
!
               ENDIF
C
               CLASS_POINTER = CLASS_POINTER + 1
               IF(CLASS_POINTER > AVAIL_DATA_YEARS) EXIT
               IF(ASSET_CLASS_LIST(CLASS_POINTER) == 0. .OR.
     +                     ASSET_CLASS_LIST(CLASS_POINTER) == -99.) EXIT
            ENDDO ! ASSET CLASSES
         ENDDO ! CL UNITS
!
! 09/02/01. AMEREN TRANSFER PRICING CAPABILITY. TWO PARTY FOR NOW.
!           NEED A SWITCH TO DEFINE.
!
         IF(DETAILED_TRANSFER_PRICING) THEN
            TEMP_I2 = 0
            CALL GET_MONTHLY_TRANSFER_REV_COST(
     +                                    TEMP_I2,
     +                                    R1_MONTHLY_TRANSFER_REV,
     +                                    R1_MONTHLY_TRANSFER_COST,
     +                                    R2_MONTHLY_TRANSFER_REV,
     +                                    R2_MONTHLY_TRANSFER_COST)
            TG = 1 ! ASSUME UE FOR NOW.
            TG_ASSET_CLASS = PURCHASE_ASSET_CLASS_ID(TG)
            CALL CHECK_IF_CLASS_DEFINED(TG_ASSET_CLASS)
            COLLECTION = 5 ! ASSUME
            TG_ASSET_CLASS = TG_ASSET_CLASS + 1
            IF(TG_ASSET_CLASS > 0 .AND. TG_ASSET_CLASS <=
     +                                MAX_CAP_LIMITED_CLASS_ID_NUM) THEN
               TG_ASSET_CLASS = ASSET_CLASS_POINTER(TG_ASSET_CLASS)
               CL_ANN_CLASS_PURCHASES(TG_ASSET_CLASS,COLLECTION) =
     +               CL_ANN_CLASS_PURCHASES(TG_ASSET_CLASS,COLLECTION) +
     +                                          R1_MONTHLY_TRANSFER_COST ! FROM TRANSACT MODULE
               CL_ANN_CLASS_REVENUE(TG_ASSET_CLASS,COLLECTION) =
     +                 CL_ANN_CLASS_REVENUE(TG_ASSET_CLASS,COLLECTION) +
     +                                          R1_MONTHLY_TRANSFER_REV ! FROM TRANSACT MODULE
            ENDIF
            TG = 2 ! ASSUME UE FOR NOW.
            TG_ASSET_CLASS = PURCHASE_ASSET_CLASS_ID(TG)
            CALL CHECK_IF_CLASS_DEFINED(TG_ASSET_CLASS)
            COLLECTION = 5 ! ASSUME
            TG_ASSET_CLASS = TG_ASSET_CLASS + 1
            IF(TG_ASSET_CLASS > 0 .AND. TG_ASSET_CLASS <=
     +                                MAX_CAP_LIMITED_CLASS_ID_NUM) THEN
               TG_ASSET_CLASS = ASSET_CLASS_POINTER(TG_ASSET_CLASS)
               CL_ANN_CLASS_PURCHASES(TG_ASSET_CLASS,COLLECTION) =
     +               CL_ANN_CLASS_PURCHASES(TG_ASSET_CLASS,COLLECTION) +
     +                                          R2_MONTHLY_TRANSFER_COST ! FROM TRANSACT MODULE
               CL_ANN_CLASS_REVENUE(TG_ASSET_CLASS,COLLECTION) =
     +                 CL_ANN_CLASS_REVENUE(TG_ASSET_CLASS,COLLECTION) +
     +                                          R2_MONTHLY_TRANSFER_REV ! FROM TRANSACT MODULE
            ENDIF
         ENDIF
!
! GET COST OF SUPPLYING CAPACITY FOR A "SHORT" SYSTEM.
!
         RUN_TRANSACT = YES_RUN_TRANSACT() ! 10/28/03.
!
         IF(UPPER_TRANS_GROUP > 0 .AND. RUN_TRANSACT) THEN
!            COLLECTION = 1
            DO TG = 1, UPPER_TRANS_GROUP
!            TG = TRANSACTION_GROUP_ID(UNUM) ! NOTE DOUBLE ASSIGNMENT
!               TG = GET_TRANS_GROUP_INDEX(UNUM)
               TEMP_I2 = 0
               CALL GET_ANNUAL_UNSERVED_COST(
     +                                    TG,
     +                                    TRANS_ANNUAL_UNSERVED_COST,
     +                                    TEMP_R4, ! UNSERVED MWH'S
     +                                    TEMP_I2) ! ANNUAL CALL 6/25/01.
!               IF(PURCHASE_POWER_ASSIGN(TG) /= 'U') THEN
                  IF(PURCHASE_POWER_ASSIGN(TG) == 'A') THEN
                     COLLECTION = 1
                  ELSEIF(PURCHASE_POWER_ASSIGN(TG) == 'B') THEN
                     COLLECTION = 2
                  ELSEIF(PURCHASE_POWER_ASSIGN(TG) == 'C') THEN
                     COLLECTION = 4
                  ELSE
                     COLLECTION = 3
                  ENDIF
                  TG_ASSET_CLASS = PURCHASE_ASSET_CLASS_ID(TG)
!                 TG_ASSET_CLASS = 15
                  CALL CHECK_IF_CLASS_DEFINED(TG_ASSET_CLASS)
                  TG_ASSET_CLASS = TG_ASSET_CLASS + 1
                  IF(TG_ASSET_CLASS > 0 .AND. TG_ASSET_CLASS <=
     +                                MAX_CAP_LIMITED_CLASS_ID_NUM) THEN
                     TG_ASSET_CLASS =
     +                               ASSET_CLASS_POINTER(TG_ASSET_CLASS)
                     CL_ANN_CLASS_PURCHASES(TG_ASSET_CLASS,COLLECTION) =
     +                      CL_ANN_CLASS_PURCHASES(TG_ASSET_CLASS,
     +                                                     COLLECTION) +
     +                                        TRANS_ANNUAL_UNSERVED_COST ! FROM TRANSACT MODULE
                  ENDIF
!               ENDIF
            ENDDO
         ENDIF
!
         DEALLOCATE(ASSET_CLASS_LIST,ASSET_ALLOCATION_LIST)
C
C MARKET REVENUE PROXY FOR UNION EL UNITS 8/7/97
C
         EL_BASE_RATE = 0.
         EL_PEAK_RATE = 0.
         IF(BASE_MARKET_ENRG_SALES > 50 .AND.
     +                                  BASE_MARKET_REVENUES > 100) THEN
            EL_BASE_RATE = BASE_MARKET_REVENUES/BASE_MARKET_ENRG_SALES
         ENDIF
         IF(PEAK_MARKET_ENRG_SALES > 25 .AND.
     +                                   PEAK_MARKET_REVENUES > 50) THEN
            EL_PEAK_RATE = PEAK_MARKET_REVENUES/PEAK_MARKET_ENRG_SALES
         ENDIF
C
         DO COLLECTION = 0, 3
            DO CLASS = 1, MAX_INTRA_CLASS
               INTRA_COMPANY_REVENUES(0,COLLECTION) =
     +                          INTRA_COMPANY_REVENUES(0,COLLECTION) +
     +                          INTRA_COMPANY_REVENUES(CLASS,COLLECTION)
            ENDDO
         ENDDO
         DO CLASS = 1, MAX_INTRA_CLASS
            INTRA_COMPANY_NF_BURN(0) = INTRA_COMPANY_NF_BURN(0) +
     +                                      INTRA_COMPANY_NF_BURN(CLASS)
         ENDDO
C
         DO CLASS = 1, NUMBER_OF_CAP_LIMITED_CLASSES
            NUC_FUEL_LEASED_BURN_BY_CLASS(CLASS) =
     +                     NUC_FUEL_LEASED_BURN_BY_CLASS(CLASS)/1000000.
            NUC_FUEL_LEASED_BURN_BY_CLASS(0) =
     +                              NUC_FUEL_LEASED_BURN_BY_CLASS(0) +
     +                              NUC_FUEL_LEASED_BURN_BY_CLASS(CLASS)
            NUC_FUEL_OWNED_BURN_BY_CLASS(CLASS) =
     +                      NUC_FUEL_OWNED_BURN_BY_CLASS(CLASS)/1000000.
            NUC_FUEL_OWNED_BURN_BY_CLASS(0) =
     +                               NUC_FUEL_OWNED_BURN_BY_CLASS(0) +
     +                               NUC_FUEL_OWNED_BURN_BY_CLASS(CLASS)
            NUCLEAR_MWH_BY_CLASS(0) = NUCLEAR_MWH_BY_CLASS(0) +
     +                                       NUCLEAR_MWH_BY_CLASS(CLASS)
            NUCLEAR_MMBTU_BY_CLASS(0) = NUCLEAR_MMBTU_BY_CLASS(0) +
     +                                     NUCLEAR_MMBTU_BY_CLASS(CLASS)
            DO EMISS_TYPE = 1, NUMBER_OF_EMISSION_TYPES
               CL_ANN_CLASS_EMISSIONS(EMISS_TYPE,0) =
     +                          CL_ANN_CLASS_EMISSIONS(EMISS_TYPE,0) +
     +                          CL_ANN_CLASS_EMISSIONS(EMISS_TYPE,CLASS)
            ENDDO
            DO I = 1, 4
               CL_ANN_CLASS_VAR_COST(CLASS,I) =
     +                           CL_ANN_CLASS_VAR_COST(CLASS,I)/1000000.
               CL_ANN_CLASS_FUEL_COST(CLASS,I)  =
     +                          CL_ANN_CLASS_FUEL_COST(CLASS,I)/1000000.
               NF_FUEL_LEASED_BY_CLASS(CLASS,I) =
     +                         NF_FUEL_LEASED_BY_CLASS(CLASS,I)/1000000.
               NF_FUEL_OWNED_BY_CLASS(CLASS,I) =
     +                          NF_FUEL_OWNED_BY_CLASS(CLASS,I)/1000000.
               CL_ANN_CLASS_FIXED_COST(CLASS,I) =
     +                         CL_ANN_CLASS_FIXED_COST(CLASS,I)/1000000.
               CL_ANN_CLASS_REVENUE(CLASS,I) =
     +                            CL_ANN_CLASS_REVENUE(CLASS,I)/1000000.
               CL_ANN_CLASS_CAPACITY(CLASS,I) =
     +                           CL_ANN_CLASS_CAPACITY(CLASS,I)/1000000.
               CL_ANN_CLASS_ENERGY(CLASS,I) =
     +                             CL_ANN_CLASS_ENERGY(CLASS,I)/1000000.
               CL_ANN_CLASS_PURCHASES(CLASS,I) =
     +                          CL_ANN_CLASS_PURCHASES(CLASS,I)/1000000.
C
               CL_ANN_CLASS_VAR_COST(0,I) = CL_ANN_CLASS_VAR_COST(0,I) +
     +                                    CL_ANN_CLASS_VAR_COST(CLASS,I)
               CL_ANN_CLASS_FUEL_COST(0,I)=CL_ANN_CLASS_FUEL_COST(0,I) +
     +                                   CL_ANN_CLASS_FUEL_COST(CLASS,I)
               NF_FUEL_LEASED_BY_CLASS(0,I) =
     +                                  NF_FUEL_LEASED_BY_CLASS(0,I) +
     +                                  NF_FUEL_LEASED_BY_CLASS(CLASS,I)
               NF_FUEL_OWNED_BY_CLASS(0,I)=NF_FUEL_OWNED_BY_CLASS(0,I) +
     +                                   NF_FUEL_OWNED_BY_CLASS(CLASS,I)
               CL_ANN_CLASS_FIXED_COST(0,I) =
     +                                  CL_ANN_CLASS_FIXED_COST(0,I) +
     +                                  CL_ANN_CLASS_FIXED_COST(CLASS,I)
               CL_ANN_CLASS_REVENUE(0,I) = CL_ANN_CLASS_REVENUE(0,I) +
     +                                     CL_ANN_CLASS_REVENUE(CLASS,I)
               CL_ANN_CLASS_CAPACITY(0,I) = CL_ANN_CLASS_CAPACITY(0,I) +
     +                                    CL_ANN_CLASS_CAPACITY(CLASS,I)
               CL_ANN_CLASS_ENERGY(0,I) = CL_ANN_CLASS_ENERGY(0,I) +
     +                                      CL_ANN_CLASS_ENERGY(CLASS,I)
               CL_ANN_CLASS_PURCHASES(0,I)=CL_ANN_CLASS_PURCHASES(0,I) +
     +                                   CL_ANN_CLASS_PURCHASES(CLASS,I)
            ENDDO
            DO I = 1, NUM_FUEL_CATEGORIES
               CL_ANN_MULT_FUEL_COST(CLASS,I)  =
     +                           CL_ANN_MULT_FUEL_COST(CLASS,I)/1000000.
               IF(FIRST_ENERGY) THEN
                  FE_ANN_MULT_FUEL_COST(CLASS,I)  =
     +                           FE_ANN_MULT_FUEL_COST(CLASS,I)/1000000.
                  FE_ANN_MULT_FUEL_COST(0,I) =
     +                           FE_ANN_MULT_FUEL_COST(0,I) +
     +                                    FE_ANN_MULT_FUEL_COST(CLASS,I)
               ENDIF
               CL_ANN_MULT_VAR_COST(CLASS,I) =
     +                           CL_ANN_MULT_VAR_COST(CLASS,I)/1000000.
               CL_ANN_MULT_FIXED_COST(CLASS,I) =
     +                         CL_ANN_MULT_FIXED_COST(CLASS,I)/1000000.
               CL_ANN_MULT_REVENUE(CLASS,I) =
     +                            CL_ANN_MULT_REVENUE(CLASS,I)/1000000.
               CL_ANN_MULT_CAPACITY(CLASS,I) =
     +                           CL_ANN_MULT_CAPACITY(CLASS,I)/1000000.
               CL_ANN_MULT_ENERGY(CLASS,I) =
     +                             CL_ANN_MULT_ENERGY(CLASS,I)/1000000.
               CL_ANN_MULT_PURCHASES(CLASS,I) =
     +                          CL_ANN_MULT_PURCHASES(CLASS,I)/1000000.
!
               CL_ANN_MULT_FUEL_COST(0,I)=CL_ANN_MULT_FUEL_COST(0,I) +
     +                                    CL_ANN_MULT_FUEL_COST(CLASS,I)
               CL_ANN_MULT_VAR_COST(0,I) = CL_ANN_MULT_VAR_COST(0,I) +
     +                                    CL_ANN_MULT_VAR_COST(CLASS,I)
               CL_ANN_MULT_FIXED_COST(0,I) =
     +                                  CL_ANN_MULT_FIXED_COST(0,I) +
     +                                  CL_ANN_MULT_FIXED_COST(CLASS,I)
               CL_ANN_MULT_REVENUE(0,I) = CL_ANN_MULT_REVENUE(0,I) +
     +                                     CL_ANN_MULT_REVENUE(CLASS,I)
               CL_ANN_MULT_CAPACITY(0,I) = CL_ANN_MULT_CAPACITY(0,I) +
     +                                    CL_ANN_MULT_CAPACITY(CLASS,I)
               CL_ANN_MULT_ENERGY(0,I) = CL_ANN_MULT_ENERGY(0,I) +
     +                                      CL_ANN_MULT_ENERGY(CLASS,I)
               CL_ANN_MULT_PURCHASES(0,I) = CL_ANN_MULT_PURCHASES(0,I) +
     +                                   CL_ANN_MULT_PURCHASES(CLASS,I)
            ENDDO
         ENDDO
      RETURN
C***********************************************************************
      ENTRY GET_CL_ENERGY_BY_TYPE(  R_ISEAS,
     +                              R_NUC_ENERGY,
     +                              R_STEAM_ENERGY,
     +                              R_PURCHASES_ENERGY,
     +                              R_ASSET_CLASS_900)
C***********************************************************************
         R_NUC_ENERGY = 0.
         R_STEAM_ENERGY = 0.
         R_PURCHASES_ENERGY = 0.
!
         ASSET_CLASS = 0 ! SYSTEM CLASS
!
         R_NUC_ENERGY = R_NUC_ENERGY +
     +           MON_MDS_NUCLEAR_MWH_BY_CLASS(ASSET_CLASS,R_ISEAS)/1000.
         R_PURCHASES_ENERGY = R_PURCHASES_ENERGY +
     +            MON_MDS_CL_CLASS_ENERGY(ASSET_CLASS,2,R_ISEAS) * 1000.
!
!
         R_ASSET_CLASS_900 = 0.
         DO I = 900, MAX_CAP_LIMITED_CLASS_ID_NUM
!
            ASSET_CLASS = ASSET_CLASS_POINTER(I)
            IF(ASSET_CLASS == 0) CYCLE
            R_ASSET_CLASS_900 = R_ASSET_CLASS_900 +
     +            MON_MDS_CL_CLASS_ENERGY(ASSET_CLASS,1,R_ISEAS) * 1000.
         ENDDO
         ASSET_CLASS = 0 ! SYSTEM CLASS
         R_STEAM_ENERGY = R_STEAM_ENERGY +
     +          MON_MDS_CL_CLASS_ENERGY(ASSET_CLASS,1,R_ISEAS) * 1000. -
     +                                  R_NUC_ENERGY - R_ASSET_CLASS_900
!
         GET_CL_ENERGY_BY_TYPE = 1
      RETURN
C***********************************************************************
      ENTRY EL_BASE_REVENUE_RATE
C***********************************************************************
         EL_BASE_REVENUE_RATE = EL_BASE_RATE
      RETURN
C***********************************************************************
      ENTRY EL_PEAK_REVENUE_RATE
C***********************************************************************
         EL_PEAK_REVENUE_RATE = EL_PEAK_RATE
      RETURN
C***********************************************************************
      ENTRY RETURN_CL_ASSET_CLASS_PROD(R_CLASS,
     +                                 R_CL_ANN_CLASS_CAPACITY,
     +                                 R_CL_ANN_CLASS_ENERGY)
C***********************************************************************
         RETURN_CL_ASSET_CLASS_PROD = .FALSE.
         DO I = 1, 4
            R_CL_ANN_CLASS_CAPACITY(I) = 0.
            R_CL_ANN_CLASS_ENERGY(I) = 0.
         ENDDO
C
C NOTE: 1 == PRODUCTION FROM RESOURCE TO MEET NATIVE LOAD
C       2 == DEFINED PURCHASE TO MEET NATIVE LOAD
C       3 == ECONOMY PURCHASE TO MEET NATIVE LOAD
C       4 == ECONOMY SALES WHICH INCREASE LOAD
C
         IF(R_CLASS <= MAX_CAP_LIMITED_CLASS_ID_NUM) THEN
            IF(R_CLASS ==0) THEN
               ASSET_CLASS = 0
            ELSE
               ASSET_CLASS = ASSET_CLASS_POINTER(R_CLASS)
            ENDIF
            IF(ASSET_CLASS > 0 .OR. R_CLASS == 0) THEN
               RETURN_CL_ASSET_CLASS_PROD = .TRUE.
               R_CL_ANN_CLASS_CAPACITY(1) =
     +                              CL_ANN_CLASS_CAPACITY(ASSET_CLASS,1)
               R_CL_ANN_CLASS_CAPACITY(2) =
     +                              CL_ANN_CLASS_CAPACITY(ASSET_CLASS,2)
               R_CL_ANN_CLASS_CAPACITY(3) =
     +                              CL_ANN_CLASS_CAPACITY(ASSET_CLASS,3)
               R_CL_ANN_CLASS_CAPACITY(4) =
     +                              CL_ANN_CLASS_CAPACITY(ASSET_CLASS,4)
C
               R_CL_ANN_CLASS_ENERGY(1) =
     +                                CL_ANN_CLASS_ENERGY(ASSET_CLASS,1)
               R_CL_ANN_CLASS_ENERGY(2) =
     +                                CL_ANN_CLASS_ENERGY(ASSET_CLASS,2)
               R_CL_ANN_CLASS_ENERGY(3) =
     +                                CL_ANN_CLASS_ENERGY(ASSET_CLASS,3)
               R_CL_ANN_CLASS_ENERGY(4) =
     +                                CL_ANN_CLASS_ENERGY(ASSET_CLASS,4)
            ENDIF
         ENDIF
C
      RETURN
C***********************************************************************
      ENTRY RETURN_CL_CLASS_TOTAL_PROD(R_CLASS,
     +                                    R_CL_ANN_TOTAL_CLASS_CAPACITY,
     +                                    R_CL_ANN_TOTAL_CLASS_ENERGY)
C***********************************************************************
         RETURN_CL_CLASS_TOTAL_PROD = .FALSE.
         R_CL_ANN_TOTAL_CLASS_CAPACITY = 0.
         R_CL_ANN_TOTAL_CLASS_ENERGY = 0.
C
C NOTE: 1 == PRODUCTION FROM RESOURCE TO MEET NATIVE LOAD
C       2 == DEFINED PURCHASE TO MEET NATIVE LOAD
C       3 == ECONOMY PURCHASE TO MEET NATIVE LOAD
C       4 == ECONOMY SALES WHICH INCREASE LOAD
C
         IF(R_CLASS <= MAX_CAP_LIMITED_CLASS_ID_NUM) THEN
            IF(R_CLASS ==0) THEN
               ASSET_CLASS = 0
            ELSE
               ASSET_CLASS = ASSET_CLASS_POINTER(R_CLASS)
            ENDIF
            IF(ASSET_CLASS > 0 .OR. R_CLASS == 0) THEN
               RETURN_CL_CLASS_TOTAL_PROD = .TRUE.
               R_CL_ANN_TOTAL_CLASS_CAPACITY =
     +                            CL_ANN_CLASS_CAPACITY(ASSET_CLASS,1) +
     +                            CL_ANN_CLASS_CAPACITY(ASSET_CLASS,2) +
     +                            CL_ANN_CLASS_CAPACITY(ASSET_CLASS,3)
C    +                          + CL_ANN_CLASS_CAPACITY(ASSET_CLASS,4)
C
               R_CL_ANN_TOTAL_CLASS_ENERGY =
     +                              CL_ANN_CLASS_ENERGY(ASSET_CLASS,1) +
     +                              CL_ANN_CLASS_ENERGY(ASSET_CLASS,2) +
     +                              CL_ANN_CLASS_ENERGY(ASSET_CLASS,3)
C    +                            + CL_ANN_CLASS_ENERGY(ASSET_CLASS,4)
            ENDIF
         ENDIF
      RETURN
C***********************************************************************
      ENTRY RETURN_FE_PNL_EXPENSES(R_CLASS,
     +                             R_PNL_FUEL_COST,
     +                             R_PNL_PURCHASE_POWER_EXPENSE,
     +                             R_PNL_VARIABLE_EXPENSE,
     +                             R_PNL_FIXED_EXPENSE,
     +                             R_PNL_TOTAL_SALES_REVENUE,
     +                             R_PNL_CL_ANN_TOTAL_CLASS_ENERGY,
     +                             R_PNL_CL_ANN_CLASS_CAPACITY,
     +                             R_BAY_SHORE_FUEL_EXPENSE)
C***********************************************************************
         RETURN_FE_PNL_EXPENSES = .FALSE.
         IF(R_CLASS <= MAX_CAP_LIMITED_CLASS_ID_NUM) THEN
            IF(R_CLASS ==0) THEN
               ASSET_CLASS = 0
            ELSE
               ASSET_CLASS = ASSET_CLASS_POINTER(R_CLASS)
            ENDIF
            IF(ASSET_CLASS > 0 .OR. R_CLASS == 0) THEN
               RETURN_FE_PNL_EXPENSES = .TRUE.
!
C              NEED TO GET NUCLEAR FUEL AND EMISSIONS CREDITS ELSEWHERE
C
               R_BAY_SHORE_FUEL_EXPENSE =
     +                              FE_ANN_MULT_FUEL_COST(ASSET_CLASS,3)
c               R_PNL_PURCHASE_POWER_EXPENSE(1) =
c     +                           CL_ANN_CLASS_PURCHASES(ASSET_CLASS,1)
c     +                           + CL_ANN_CLASS_PURCHASES(ASSET_CLASS,2)
c     +                           + CL_ANN_CLASS_PURCHASES(ASSET_CLASS,3)
c     +                           + CL_ANN_CLASS_PURCHASES(ASSET_CLASS,4)
               DO FT = 1, 6
!
c                  R_PNL_PURCHASE_POWER_EXPENSE(FT) =
c     +                             CL_ANN_MULT_PURCHASES(ASSET_CLASS,FT)
C
                  R_PNL_FUEL_COST(FT) =
     +                             CL_ANN_MULT_FUEL_COST(ASSET_CLASS,FT)
C
                  R_PNL_VARIABLE_EXPENSE(FT) =
     +                              CL_ANN_MULT_VAR_COST(ASSET_CLASS,FT)
C
!
! 10/28/03.
!
                  R_PNL_FIXED_EXPENSE(FT) =
!     +                      MON_MDS_CL_MULT_FIXED_COST(ASSET_CLASS,FT,0)
     +                            CL_ANN_MULT_FIXED_COST(ASSET_CLASS,FT)
!
                  R_PNL_TOTAL_SALES_REVENUE(FT) =
     +                               CL_ANN_MULT_REVENUE(ASSET_CLASS,FT)
               ENDDO
!
               DO FT = 1, NUM_FUEL_CATEGORIES
                  R_PNL_CL_ANN_TOTAL_CLASS_ENERGY(FT) =
     +                          MON_MDS_CL_MULT_ENERGY(ASSET_CLASS,FT,0) ! 02/04/04
!     +                                CL_ANN_MULT_ENERGY(ASSET_CLASS,FT)
                  R_PNL_CL_ANN_CLASS_CAPACITY(FT) =
     +                        MON_MDS_CL_MULT_CAPACITY(ASSET_CLASS,FT,0) ! 02/04/04
!     +                              CL_ANN_MULT_CAPACITY(ASSET_CLASS,FT)
!
                  R_PNL_PURCHASE_POWER_EXPENSE(FT) =
     +                       MON_MDS_CL_MULT_PURCHASES(ASSET_CLASS,FT,0)
                  IF(R_PNL_PURCHASE_POWER_EXPENSE(FT) > 0.1) THEN
                     TEMP_R4 = TEMP_R4
                  ENDIF
!     +                             CL_ANN_MULT_PURCHASES(ASSET_CLASS,FT)
!
               ENDDO
!
            ENDIF
         ENDIF
!
      RETURN
C***********************************************************************
      ENTRY RETURN_AMEREN_CL_CLASS_EXPENSES(R_CLASS,
     +                                      R_TOTAL_SALES_REVENUE, ! SECONDARY_SALES_REVENUES,
     +                                      R_WHOLESALE_FUEL_EXPENSE,
     +                                      R_WHOLESALE_VOM_EXPENSE)
C***********************************************************************
         R_TOTAL_SALES_REVENUE = 0.
         R_WHOLESALE_FUEL_EXPENSE = 0.
         R_WHOLESALE_VOM_EXPENSE = 0.
         IF(R_CLASS <= MAX_CAP_LIMITED_CLASS_ID_NUM) THEN
            IF(R_CLASS ==0) THEN
               ASSET_CLASS = 0
            ELSE
               ASSET_CLASS = ASSET_CLASS_POINTER(R_CLASS)
            ENDIF
            IF(ASSET_CLASS > 0 .OR. R_CLASS == 0) THEN
               R_TOTAL_SALES_REVENUE =
     +                             CL_ANN_CLASS_REVENUE(ASSET_CLASS,1)
     +                             + CL_ANN_CLASS_REVENUE(ASSET_CLASS,2)
     +                             + CL_ANN_CLASS_REVENUE(ASSET_CLASS,3)
C
               TT = 10
               R_WHOLESALE_FUEL_EXPENSE =
     +                             CL_ANN_MULT_FUEL_COST(ASSET_CLASS,TT)
C
               R_WHOLESALE_VOM_EXPENSE =
     +                              CL_ANN_MULT_VAR_COST(ASSET_CLASS,TT)
            ENDIF
         ENDIF
         RETURN_AMEREN_CL_CLASS_EXPENSES = 1
      RETURN
C***********************************************************************
      ENTRY RETURN_CL_ASSET_CLASS_EXPENSES(R_CLASS,R_CLASS_EXISTS,
     +                                   R_FUEL_COST,
     +                                   R_PURCHASE_POWER_EXPENSE,
     +                                   R_VARIABLE_EXPENSE,
     +                                   R_FIXED_EXPENSE,
     +                                   R_EXPENSE_COLLECTED_ADJ_CLAUSE,
     +                                   R_EXPENSE_COLLECTED_BASE_RATES,
     +                                   R_NOT_COLLECTED_IN_RATES,
     +                                   R_BTL_SALES_REVENUE,
     +                                   R_TOTAL_SALES_REVENUE,
     +                                   R_BTL_EXPENSES,
     +                                   R_WHOLESALE_FUEL_EXPENSE,
     +                                   R_WHOLESALE_VOM_EXPENSE,
     +                                   R_ICAP_REVENUES,
     +                                   R_WVPA_EMISSIONS_EXPENSE,
     +                                 R_CAPACITY_SALES_TO_LEVEL_RM,    ! 726
     +                                 R_CAPACITY_PURCHASES_TO_LEVEL_RM)  ! 725
C***********************************************************************
         R_CLASS_EXISTS = .FALSE.
         IF(R_CLASS <= MAX_CAP_LIMITED_CLASS_ID_NUM) THEN
            IF(R_CLASS ==0) THEN
               ASSET_CLASS = 0
            ELSE
               ASSET_CLASS = ASSET_CLASS_POINTER(R_CLASS)
            ENDIF
            IF(ASSET_CLASS > 0 .OR. R_CLASS == 0) THEN
               R_CLASS_EXISTS = .TRUE.
               MO = 0
C
               DO I = 1, NUMBER_OF_EMISSION_TYPES
                  MON_MDS_CL_CLASS_EMISSIONS_COST(I,ASSET_CLASS,0) =
     +                 SUM(MON_MDS_CL_CLASS_EMISSIONS_COST(I,
     +                                                  ASSET_CLASS,1:))
               ENDDO
               IF(WVPA()) R_WVPA_EMISSIONS_EXPENSE =
     +             SUM(MON_MDS_CL_CLASS_EMISSIONS_COST(:,ASSET_CLASS,0))
C
               R_ICAP_REVENUES = R_ICAP_REVENUES
     +                        + MON_MDS_ICAP_REV_BY_CLASS(ASSET_CLASS,0)
C
               R_PURCHASE_POWER_EXPENSE = R_PURCHASE_POWER_EXPENSE
     +                    + MON_MDS_CL_CLASS_PURCHASES(ASSET_CLASS,1,MO)
     +                    + MON_MDS_CL_CLASS_PURCHASES(ASSET_CLASS,2,MO)
     +                    + MON_MDS_CL_CLASS_PURCHASES(ASSET_CLASS,3,MO)
               R_CAPACITY_PURCHASES_TO_LEVEL_RM =
     +                      MON_MDS_CL_CAP_PURCHASES(ASSET_CLASS,1,MO)
     +                    + MON_MDS_CL_CAP_PURCHASES(ASSET_CLASS,2,MO)
     +                    + MON_MDS_CL_CAP_PURCHASES(ASSET_CLASS,3,MO)
c     +                           CL_ANN_CLASS_PURCHASES(ASSET_CLASS,1) +
c     +                           CL_ANN_CLASS_PURCHASES(ASSET_CLASS,2) +
c     +                           CL_ANN_CLASS_PURCHASES(ASSET_CLASS,3)
C
               R_FUEL_COST = R_FUEL_COST
     +                    + MON_MDS_CL_CLASS_FUEL_COST(ASSET_CLASS,1,MO)
     +                    + MON_MDS_CL_CLASS_FUEL_COST(ASSET_CLASS,2,MO)
     +                    + MON_MDS_CL_CLASS_FUEL_COST(ASSET_CLASS,3,MO)
c     +                           CL_ANN_CLASS_FUEL_COST(ASSET_CLASS,1) +
c     +                           CL_ANN_CLASS_FUEL_COST(ASSET_CLASS,2) +
c     +                           CL_ANN_CLASS_FUEL_COST(ASSET_CLASS,3)
C
               R_VARIABLE_EXPENSE = R_VARIABLE_EXPENSE
     +                     + MON_MDS_CL_CLASS_VAR_COST(ASSET_CLASS,1,MO)
     +                     + MON_MDS_CL_CLASS_VAR_COST(ASSET_CLASS,2,MO)
     +                     + MON_MDS_CL_CLASS_VAR_COST(ASSET_CLASS,3,MO)
c     +                            CL_ANN_CLASS_VAR_COST(ASSET_CLASS,1) +
c     +                            CL_ANN_CLASS_VAR_COST(ASSET_CLASS,2) +
c     +                            CL_ANN_CLASS_VAR_COST(ASSET_CLASS,3)
C
               R_FIXED_EXPENSE = R_FIXED_EXPENSE
     +                   + MON_MDS_CL_CLASS_FIXED_COST(ASSET_CLASS,1,MO)
     +                   + MON_MDS_CL_CLASS_FIXED_COST(ASSET_CLASS,2,MO)
     +                   + MON_MDS_CL_CLASS_FIXED_COST(ASSET_CLASS,3,MO)
c     +                          CL_ANN_CLASS_FIXED_COST(ASSET_CLASS,1) +
c     +                          CL_ANN_CLASS_FIXED_COST(ASSET_CLASS,2) +
c     +                          CL_ANN_CLASS_FIXED_COST(ASSET_CLASS,3)
               R_EXPENSE_COLLECTED_ADJ_CLAUSE =
     +                    R_EXPENSE_COLLECTED_ADJ_CLAUSE
     +                    + MON_MDS_CL_CLASS_PURCHASES(ASSET_CLASS,1,MO)
     +                    + MON_MDS_CL_CAP_PURCHASES(ASSET_CLASS,1,MO)
     +                    + MON_MDS_NF_FUEL_LEASED_BC(ASSET_CLASS,1,MO)
     +                    + MON_MDS_NF_FUEL_OWNED_BC(ASSET_CLASS,1,MO)
     +                    + MON_MDS_CL_CLASS_FUEL_COST(ASSET_CLASS,1,MO)
c     +                           CL_ANN_CLASS_PURCHASES(ASSET_CLASS,1) +
cC    +                           CL_ANN_CLASS_VAR_COST(ASSET_CLASS,1) +
cC    +                           CL_ANN_CLASS_FIXED_COST(ASSET_CLASS,1)+
c     +                           NF_FUEL_LEASED_BY_CLASS(ASSET_CLASS,1)+
c     +                           NF_FUEL_OWNED_BY_CLASS(ASSET_CLASS,1) +
c     +                           CL_ANN_CLASS_FUEL_COST(ASSET_CLASS,1)
               R_EXPENSE_COLLECTED_BASE_RATES =
     +                   R_EXPENSE_COLLECTED_BASE_RATES
     +                   + MON_MDS_CL_CLASS_PURCHASES(ASSET_CLASS,2,MO)
     +                   + MON_MDS_CL_CAP_PURCHASES(ASSET_CLASS,2,MO)
     +                   + MON_MDS_CL_CLASS_VAR_COST(ASSET_CLASS,2,MO)
     +                   + MON_MDS_CL_CLASS_FIXED_COST(ASSET_CLASS,2,MO)
     +                   + MON_MDS_NF_FUEL_LEASED_BC(ASSET_CLASS,2,MO)
     +                   + MON_MDS_NF_FUEL_OWNED_BC(ASSET_CLASS,2,MO)
     +                   + MON_MDS_CL_CLASS_FUEL_COST(ASSET_CLASS,2,MO)
c     +                           CL_ANN_CLASS_PURCHASES(ASSET_CLASS,2) +
c     +                           CL_ANN_CLASS_VAR_COST(ASSET_CLASS,2) +
c     +                           CL_ANN_CLASS_FIXED_COST(ASSET_CLASS,2)+
c     +                           NF_FUEL_LEASED_BY_CLASS(ASSET_CLASS,2)+
c     +                           NF_FUEL_OWNED_BY_CLASS(ASSET_CLASS,2) +
c     +                           CL_ANN_CLASS_FUEL_COST(ASSET_CLASS,2)
               R_NOT_COLLECTED_IN_RATES = R_NOT_COLLECTED_IN_RATES
     +                   + MON_MDS_CL_CLASS_PURCHASES(ASSET_CLASS,3,MO)
     +                   + MON_MDS_CL_CAP_PURCHASES(ASSET_CLASS,3,MO)
     +                   + MON_MDS_CL_CLASS_VAR_COST(ASSET_CLASS,3,MO)
     +                   + MON_MDS_CL_CLASS_FIXED_COST(ASSET_CLASS,3,MO)
     +                   + MON_MDS_NF_FUEL_LEASED_BC(ASSET_CLASS,3,MO)
     +                   + MON_MDS_NF_FUEL_OWNED_BC(ASSET_CLASS,3,MO)
     +                   + MON_MDS_CL_CLASS_FUEL_COST(ASSET_CLASS,3,MO)
c     +                           CL_ANN_CLASS_PURCHASES(ASSET_CLASS,3) +
c     +                           CL_ANN_CLASS_VAR_COST(ASSET_CLASS,3) +
c     +                           CL_ANN_CLASS_FIXED_COST(ASSET_CLASS,3)+
c     +                           NF_FUEL_LEASED_BY_CLASS(ASSET_CLASS,3)+
c     +                           NF_FUEL_OWNED_BY_CLASS(ASSET_CLASS,3) +
c     +                           CL_ANN_CLASS_FUEL_COST(ASSET_CLASS,3)
               R_TOTAL_SALES_REVENUE = R_TOTAL_SALES_REVENUE
     +                      + MON_MDS_CL_CLASS_REVENUE(ASSET_CLASS,1,MO)
     +                      + MON_MDS_CL_CLASS_REVENUE(ASSET_CLASS,2,MO)
     +                      + MON_MDS_CL_CLASS_REVENUE(ASSET_CLASS,3,MO)
               R_CAPACITY_SALES_TO_LEVEL_RM =
     +                        MON_MDS_CL_CAP_REVENUE(ASSET_CLASS,1,MO)
     +                      + MON_MDS_CL_CAP_REVENUE(ASSET_CLASS,2,MO)
     +                      + MON_MDS_CL_CAP_REVENUE(ASSET_CLASS,3,MO)
c     +                             CL_ANN_CLASS_REVENUE(ASSET_CLASS,1) +
c     +                             CL_ANN_CLASS_REVENUE(ASSET_CLASS,2) +
c     +                             CL_ANN_CLASS_REVENUE(ASSET_CLASS,3)
               R_SALES_REVENUE_NOT_IN_RATES =
     +                      R_SALES_REVENUE_NOT_IN_RATES
     +                      + MON_MDS_CL_CLASS_REVENUE(ASSET_CLASS,3,MO)
     +                      + MON_MDS_CL_CAP_REVENUE(ASSET_CLASS,3,MO)
c     +                               CL_ANN_CLASS_REVENUE(ASSET_CLASS,3)
               R_BTL_SALES_REVENUE = R_BTL_SALES_REVENUE
     +                      + MON_MDS_CL_CLASS_REVENUE(ASSET_CLASS,4,MO)
     +                      + MON_MDS_CL_CAP_REVENUE(ASSET_CLASS,4,MO)
c     +                               CL_ANN_CLASS_REVENUE(ASSET_CLASS,4)
               R_BTL_EXPENSES = R_BTL_EXPENSES
     +                   + MON_MDS_CL_CLASS_PURCHASES(ASSET_CLASS,4,MO)
     +                   + MON_MDS_CL_CAP_PURCHASES(ASSET_CLASS,4,MO)
     +                   + MON_MDS_CL_CLASS_VAR_COST(ASSET_CLASS,4,MO)
     +                   + MON_MDS_CL_CLASS_FIXED_COST(ASSET_CLASS,4,MO)
     +                   + MON_MDS_NF_FUEL_LEASED_BC(ASSET_CLASS,4,MO)
     +                   + MON_MDS_NF_FUEL_OWNED_BC(ASSET_CLASS,4,MO)
     +                   + MON_MDS_CL_CLASS_FUEL_COST(ASSET_CLASS,4,MO)
c     +                           CL_ANN_CLASS_PURCHASES(ASSET_CLASS,4) +
c     +                           CL_ANN_CLASS_VAR_COST(ASSET_CLASS,4) +
c     +                           CL_ANN_CLASS_FIXED_COST(ASSET_CLASS,4)+
c     +                           NF_FUEL_LEASED_BY_CLASS(ASSET_CLASS,4)+
c     +                           NF_FUEL_OWNED_BY_CLASS(ASSET_CLASS,4) +
c     +                           CL_ANN_CLASS_FUEL_COST(ASSET_CLASS,4)
               TT = 10
               R_WHOLESALE_FUEL_EXPENSE =
     +                      MON_MDS_CL_MULT_FUEL_COST(ASSET_CLASS,TT,MO)
!     +                             CL_ANN_MULT_FUEL_COST(ASSET_CLASS,TT)
               R_WHOLESALE_VOM_EXPENSE =
     +                      MON_MDS_CL_MULT_VAR_COST(ASSET_CLASS,TT,MO)
!     +                              CL_ANN_MULT_VAR_COST(ASSET_CLASS,TT)
           ENDIF
         ENDIF
         RETURN_CL_ASSET_CLASS_EXPENSES = 1
      RETURN
C***********************************************************************
      ENTRY RETURN_NUC_CL_ASSET_CLASS_EXPENSES(R_CLASS,R_CLASS_EXISTS,
     +                                   R_NUC_FUEL_OWNED,
     +                                   R_NUC_FUEL_LEASED,
     +                                   R_NF_BURN_IN_RATEBASE,
     +                                   R_NUC_FUEL_OWNED_BURN,
     +                                   R_NUC_FUEL_LEASED_BURN,
     +                                   R_DOE_NUC_FUEL_FEE,
     +                                   R_NUC_DECOMMISSIONING_COST,
     +                                   R_DOE_R300_DISPOSAL_COST)
C***********************************************************************
         R_CLASS_EXISTS = .FALSE.
         R_NUC_FUEL_OWNED_BURN = 0.
         R_NUC_FUEL_LEASED_BURN = 0.
         R_DOE_R300_DISPOSAL_COST = 0.
         IF(R_CLASS <= MAX_CAP_LIMITED_CLASS_ID_NUM) THEN
            IF(R_CLASS ==0) THEN
               ASSET_CLASS = 0
            ELSE
               ASSET_CLASS = ASSET_CLASS_POINTER(R_CLASS)
            ENDIF
            IF(ASSET_CLASS > 0 .OR. R_CLASS == 0) THEN
               R_CLASS_EXISTS = .TRUE.
               MO = 0
C
               R_NUC_FUEL_OWNED_BURN =
     +                      MON_MDS_NF_FUEL_OWNED_BC(ASSET_CLASS,1,MO)
     +                      + MON_MDS_NF_FUEL_OWNED_BC(ASSET_CLASS,2,MO)
     +                      + MON_MDS_NF_FUEL_OWNED_BC(ASSET_CLASS,3,MO)
c     +                         NUC_FUEL_OWNED_BURN_BY_CLASS(ASSET_CLASS)
c
               R_NUC_FUEL_LEASED_BURN =
     +                     MON_MDS_NF_FUEL_LEASED_BC(ASSET_CLASS,1,MO)
     +                     + MON_MDS_NF_FUEL_LEASED_BC(ASSET_CLASS,2,MO)
     +                     + MON_MDS_NF_FUEL_LEASED_BC(ASSET_CLASS,3,MO)
c     +                        NUC_FUEL_LEASED_BURN_BY_CLASS(ASSET_CLASS)
               MMBTU_ENERGY =
     +                    MON_MDS_NUCLEAR_MMBTU_BY_CLASS(ASSET_CLASS,MO)
               MWH_ENERGY =
     +                      MON_MDS_NUCLEAR_MWH_BY_CLASS(ASSET_CLASS,MO)
               R_DOE_NUC_FUEL_FEE = R_DOE_NUC_FUEL_FEE +
     +                     DOE_NF_DISPOSAL_COST(MMBTU_ENERGY,MWH_ENERGY)
               R_DOE_R300_DISPOSAL_COST =
     +                   DOE_R300_DISPOSAL_COST(MMBTU_ENERGY,MWH_ENERGY)
               R_NUC_DECOMMISSIONING_COST = R_NUC_DECOMMISSIONING_COST +
     +             NUCLEAR_DECOMMISSIONING_COST(MMBTU_ENERGY,MWH_ENERGY)
C
               R_NF_BURN_IN_RATEBASE = R_NF_BURN_IN_RATEBASE
     +                      + MON_MDS_NF_FUEL_OWNED_BC(ASSET_CLASS,1,MO)
     +                      + MON_MDS_NF_FUEL_OWNED_BC(ASSET_CLASS,2,MO)
     +                      + MON_MDS_NF_FUEL_OWNED_BC(ASSET_CLASS,3,MO)
!     +                           + NF_FUEL_OWNED_BY_CLASS(ASSET_CLASS,1)
!     +                           + NF_FUEL_OWNED_BY_CLASS(ASSET_CLASS,2)
!     +                           + NF_FUEL_OWNED_BY_CLASS(ASSET_CLASS,3)
C
               R_NUC_FUEL_LEASED = R_NUC_FUEL_LEASED
     +                     + MON_MDS_NF_FUEL_LEASED_BC(ASSET_CLASS,1,MO)
     +                     + MON_MDS_NF_FUEL_LEASED_BC(ASSET_CLASS,2,MO)
     +                     + MON_MDS_NF_FUEL_LEASED_BC(ASSET_CLASS,3,MO)
!     +                          + NF_FUEL_LEASED_BY_CLASS(ASSET_CLASS,1)
!     +                          + NF_FUEL_LEASED_BY_CLASS(ASSET_CLASS,2)
!     +                          + NF_FUEL_LEASED_BY_CLASS(ASSET_CLASS,3)
C
               R_NUC_FUEL_OWNED = R_NUC_FUEL_OWNED
     +                      + MON_MDS_NF_FUEL_OWNED_BC(ASSET_CLASS,1,MO)
     +                      + MON_MDS_NF_FUEL_OWNED_BC(ASSET_CLASS,2,MO)
     +                      + MON_MDS_NF_FUEL_OWNED_BC(ASSET_CLASS,3,MO)
!     +                           + NF_FUEL_OWNED_BY_CLASS(ASSET_CLASS,1)
!     +                           + NF_FUEL_OWNED_BY_CLASS(ASSET_CLASS,2)
!     +                           + NF_FUEL_OWNED_BY_CLASS(ASSET_CLASS,3)
C
           ENDIF
         ENDIF
         RETURN_NUC_CL_ASSET_CLASS_EXPENSES = 1
      RETURN
C***********************************************************************
      ENTRY RETURN_MONTHLY_CL_EXPENSES(R_CLASS,MONTH_VARS)
C***********************************************************************
C
         RETURN_MONTHLY_CL_EXPENSES = 1
         IF(.NOT. ALLOCATED(MON_MDS_NF_FUEL_OWNED_BC)) RETURN
         IF(R_CLASS <= MAX_CAP_LIMITED_CLASS_ID_NUM) THEN
            IF(R_CLASS ==0) THEN
               ASSET_CLASS = 0
            ELSE
               ASSET_CLASS = ASSET_CLASS_POINTER(R_CLASS)
            ENDIF
            IF(ASSET_CLASS > 0 .OR. R_CLASS == 0) THEN
C
               DO MO = 0, 12
                  IF(WVPA()) THEN
                     MONTH_VARS(MO,Emission Credits) =
     +                      MONTH_VARS(MO,Emission Credits)
     +                      + SUM(MON_MDS_CL_CLASS_EMISSIONS_COST(:,
     +                                                  ASSET_CLASS,MO))
                  ENDIF
                  MONTH_VARS(MO,Owned Nuclear Fuel) =
     +                      MONTH_VARS(MO,Owned Nuclear Fuel)
     +                      + MON_MDS_NF_FUEL_OWNED_BC(ASSET_CLASS,1,MO)
     +                      + MON_MDS_NF_FUEL_OWNED_BC(ASSET_CLASS,2,MO)
     +                      + MON_MDS_NF_FUEL_OWNED_BC(ASSET_CLASS,3,MO)
                  MONTH_VARS(MO,Leased Nuclear Fuel) =
     +                     MONTH_VARS(MO,Leased Nuclear Fuel)
     +                     + MON_MDS_NF_FUEL_LEASED_BC(ASSET_CLASS,1,MO)
     +                     + MON_MDS_NF_FUEL_LEASED_BC(ASSET_CLASS,2,MO)
     +                     + MON_MDS_NF_FUEL_LEASED_BC(ASSET_CLASS,3,MO)
                  MMBTU_ENERGY =
     +                    MON_MDS_NUCLEAR_MMBTU_BY_CLASS(ASSET_CLASS,MO)
                  MWH_ENERGY =
     +                      MON_MDS_NUCLEAR_MWH_BY_CLASS(ASSET_CLASS,MO)
! I ASSUME THAT THE FOLLOWING THREE VARIABLES ARE TIME INDEPENDENT. GAT. 5/26/98.
                  MONTH_VARS(MO,DOE Disposal) =
     +                   MONTH_VARS(MO,DOE Disposal) +
     +                   DOE_NF_DISPOSAL_COST(MMBTU_ENERGY,MWH_ENERGY) +
     +                   DOE_R300_DISPOSAL_COST(MMBTU_ENERGY,MWH_ENERGY)
                  MONTH_VARS(MO,DOE Decommissioning) =
     +             MONTH_VARS(MO,DOE Decommissioning) +
     +             NUCLEAR_DECOMMISSIONING_COST(MMBTU_ENERGY,MWH_ENERGY)
C
                  MONTH_VARS(MO,Purchased Power) =
     +                    MONTH_VARS(MO,Purchased Power)
     +                    + MON_MDS_CL_CLASS_PURCHASES(ASSET_CLASS,1,MO)
     +                    + MON_MDS_CL_CLASS_PURCHASES(ASSET_CLASS,2,MO)
     +                    + MON_MDS_CL_CLASS_PURCHASES(ASSET_CLASS,3,MO)
                  MONTH_VARS(MO,
     +               Monthly Expense Reserve Margin Capacity Purchase) =
     +                    + MON_MDS_CL_CAP_PURCHASES(ASSET_CLASS,1,MO)
     +                    + MON_MDS_CL_CAP_PURCHASES(ASSET_CLASS,2,MO)
     +                    + MON_MDS_CL_CAP_PURCHASES(ASSET_CLASS,3,MO)
C
                  MONTH_VARS(MO,Fossil Fuel) =
     +                    MONTH_VARS(MO,Fossil Fuel)
     +                    + MON_MDS_CL_CLASS_FUEL_COST(ASSET_CLASS,1,MO)
     +                    + MON_MDS_CL_CLASS_FUEL_COST(ASSET_CLASS,2,MO)
     +                    + MON_MDS_CL_CLASS_FUEL_COST(ASSET_CLASS,3,MO)
C
                  MONTH_VARS(MO,Variable OandM) =
     +                     MONTH_VARS(MO,Variable OandM)
     +                     + MON_MDS_CL_CLASS_VAR_COST(ASSET_CLASS,1,MO)
     +                     + MON_MDS_CL_CLASS_VAR_COST(ASSET_CLASS,2,MO)
     +                     + MON_MDS_CL_CLASS_VAR_COST(ASSET_CLASS,3,MO)
C
                  MONTH_VARS(MO,Fixed OandM) =
     +                   MONTH_VARS(MO,Fixed OandM)
     +                   + MON_MDS_CL_CLASS_FIXED_COST(ASSET_CLASS,1,MO)
     +                   + MON_MDS_CL_CLASS_FIXED_COST(ASSET_CLASS,2,MO)
     +                   + MON_MDS_CL_CLASS_FIXED_COST(ASSET_CLASS,3,MO)
C
                  MONTH_VARS(MO,BTL Expenses) =
     +                   MONTH_VARS(MO,BTL Expenses)
     +                   + MON_MDS_CL_CLASS_PURCHASES(ASSET_CLASS,4,MO)
     +                   + MON_MDS_CL_CAP_PURCHASES(ASSET_CLASS,4,MO)
     +                   + MON_MDS_CL_CLASS_VAR_COST(ASSET_CLASS,4,MO)
     +                   + MON_MDS_CL_CLASS_FIXED_COST(ASSET_CLASS,4,MO)
     +                   + MON_MDS_NF_FUEL_LEASED_BC(ASSET_CLASS,4,MO)
     +                   + MON_MDS_NF_FUEL_OWNED_BC(ASSET_CLASS,4,MO)
     +                   + MON_MDS_CL_CLASS_FUEL_COST(ASSET_CLASS,4,MO)
C$ifdefined(monthly_code)
C
C               R_NUC_FUEL_OWNED_BURN =
C     +               MON_MDS_NUC_FUEL_OWNED_BURN_BC(ASSET_CLASS,R_ISEAS)
C               R_NUC_FUEL_LEASED_BURN =
C     +               MON_MDS_NUC_FUEL_LEASE_BURN_BC(ASSET_CLASS,R_ISEAS)
C
C$endif
               ENDDO
            ENDIF
         ENDIF
      RETURN
C***********************************************************************
      ENTRY RETURN_MONTHLY_NF_OP_EXPENSES(R_CLASS,
     +                                 R_MONTHLY_OWNED_NF)
C     +                                 R_MONTHLY_LEASED_NF,
C     +                                 R_MONTHLY_DOE_DISPOSAL,
C     +                                 R_MONTHLY_DOE_DECOMMISSIONING)
C***********************************************************************
C
         RETURN_MONTHLY_NF_OP_EXPENSES = 1
         R_MONTHLY_OWNED_NF(:) = 0.
         IF(R_CLASS <= MAX_CAP_LIMITED_CLASS_ID_NUM .AND.
     +                         ALLOCATED(MON_MDS_NF_FUEL_OWNED_BC)) THEN
            IF(R_CLASS ==0) THEN
               ASSET_CLASS = 0
            ELSE
               ASSET_CLASS = ASSET_CLASS_POINTER(R_CLASS)
            ENDIF
            IF(ASSET_CLASS > 0 .OR. R_CLASS == 0) THEN
C

               R_MONTHLY_OWNED_NF(:) =
     +                       MON_MDS_NF_FUEL_OWNED_BC(ASSET_CLASS,1,:)
     +                       + MON_MDS_NF_FUEL_OWNED_BC(ASSET_CLASS,2,:)
     +                       + MON_MDS_NF_FUEL_OWNED_BC(ASSET_CLASS,3,:)
C               R_MONTHLY_LEASED_NF(:) =
C     +                      MON_MDS_NF_FUEL_LEASED_BC(ASSET_CLASS,1,:)
C     +                      + MON_MDS_NF_FUEL_LEASED_BC(ASSET_CLASS,2,:)
C     +                      + MON_MDS_NF_FUEL_LEASED_BC(ASSET_CLASS,3,:)
C               DO MO = 0, 12
C                  MMBTU_ENERGY =
C     +                    MON_MDS_NUCLEAR_MMBTU_BY_CLASS(ASSET_CLASS,MO)
C                  MWH_ENERGY =
C     +                      MON_MDS_NUCLEAR_MWH_BY_CLASS(ASSET_CLASS,MO)
! I ASSUME THAT THE FOLLOWING THREE VARIABLES ARE TIME INDEPENDENT. GAT. 5/26/98.
C                  R_MONTHLY_DOE_DISPOSAL(MO) =
C     +                 DOE_NF_DISPOSAL_COST(MMBTU_ENERGY,MWH_ENERGY)
C     +                 + DOE_R300_DISPOSAL_COST(MMBTU_ENERGY,MWH_ENERGY)
C                  R_MONTHLY_DOE_DECOMMISSIONING(MO) =
C     +             NUCLEAR_DECOMMISSIONING_COST(MMBTU_ENERGY,MWH_ENERGY)
C
C               ENDDO
            ENDIF
         ENDIF
      RETURN
C***********************************************************************
      ENTRY RETURN_MONTHLY_CL_CASH_EXPENSES(R_CLASS,MONTH_VARS)
C***********************************************************************
C
         RETURN_MONTHLY_CL_CASH_EXPENSES = 1
         IF(.NOT. ALLOCATED(MON_MDS_NF_FUEL_LEASED_BC)) RETURN
         IF(R_CLASS <= MAX_CAP_LIMITED_CLASS_ID_NUM) THEN
            IF(R_CLASS ==0) THEN
               ASSET_CLASS = 0
            ELSE
               ASSET_CLASS = ASSET_CLASS_POINTER(R_CLASS)
            ENDIF
            IF(ASSET_CLASS > 0 .OR. R_CLASS == 0) THEN
C
               DO MO = 0, 12
                  IF(WVPA()) THEN
                     MONTH_VARS(MO,Cash Emission Credits) =
     +                      MONTH_VARS(MO,Cash Emission Credits)
     +                      + SUM(MON_MDS_CL_CLASS_EMISSIONS_COST(:,
     +                                                  ASSET_CLASS,MO))
                  ENDIF

                  MONTH_VARS(MO,Cash Leased Nuclear Fuel) =
     +                    MONTH_VARS(MO,Cash Leased Nuclear Fuel) +
     +                    MON_MDS_NF_FUEL_LEASED_BC(ASSET_CLASS,1,MO) +
     +                    MON_MDS_NF_FUEL_LEASED_BC(ASSET_CLASS,2,MO) +
     +                    MON_MDS_NF_FUEL_LEASED_BC(ASSET_CLASS,3,MO)
! I ASSUME THAT THE FOLLOWING THREE VARIABLES ARE TIME INDEPENDENT. GAT. 5/26/98.
                  MMBTU_ENERGY =
     +                    MON_MDS_NUCLEAR_MMBTU_BY_CLASS(ASSET_CLASS,MO)
                  MWH_ENERGY =
     +                      MON_MDS_NUCLEAR_MWH_BY_CLASS(ASSET_CLASS,MO)
                  MONTH_VARS(MO,Cash DOE Disposal) =
     +                   MONTH_VARS(MO,Cash DOE Disposal) +
     +                   DOE_NF_DISPOSAL_COST(MMBTU_ENERGY,MWH_ENERGY) +
     +                   DOE_R300_DISPOSAL_COST(MMBTU_ENERGY,MWH_ENERGY)
                  MONTH_VARS(MO,Cash DOE Decommissioning) =
     +             MONTH_VARS(MO,Cash DOE Decommissioning) +
     +             NUCLEAR_DECOMMISSIONING_COST(MMBTU_ENERGY,MWH_ENERGY)
C
                  MONTH_VARS(MO,Cash Purchased Power) =
     +                    MONTH_VARS(MO,Cash Purchased Power) +
     +                    MON_MDS_CL_CLASS_PURCHASES(ASSET_CLASS,1,MO) +
     +                    MON_MDS_CL_CLASS_PURCHASES(ASSET_CLASS,2,MO) +
     +                    MON_MDS_CL_CLASS_PURCHASES(ASSET_CLASS,3,MO)
                  MONTH_VARS(MO,
     +                  Cash Expense Reserve Margin Capacity Purchase) =
     +                MONTH_VARS(MO,
     +                    Cash Expense Reserve Margin Capacity Purchase)
     +                +    MON_MDS_CL_CAP_PURCHASES(ASSET_CLASS,1,MO)
     +                +    MON_MDS_CL_CAP_PURCHASES(ASSET_CLASS,2,MO)
     +                +    MON_MDS_CL_CAP_PURCHASES(ASSET_CLASS,3,MO)
C
                  MONTH_VARS(MO,Cash Fossil Fuel) =
     +                    MONTH_VARS(MO,Cash Fossil Fuel) +
     +                    MON_MDS_CL_CLASS_FUEL_COST(ASSET_CLASS,1,MO) +
     +                    MON_MDS_CL_CLASS_FUEL_COST(ASSET_CLASS,2,MO) +
     +                    MON_MDS_CL_CLASS_FUEL_COST(ASSET_CLASS,3,MO)
C
                  MONTH_VARS(MO,Cash Variable OandM) =
     +                     MONTH_VARS(MO,Cash Variable OandM) +
     +                     MON_MDS_CL_CLASS_VAR_COST(ASSET_CLASS,1,MO) +
     +                     MON_MDS_CL_CLASS_VAR_COST(ASSET_CLASS,2,MO) +
     +                     MON_MDS_CL_CLASS_VAR_COST(ASSET_CLASS,3,MO)
C
                  MONTH_VARS(MO,Cash Fixed OandM) =
     +                   MONTH_VARS(MO,Cash Fixed OandM) +
     +                   MON_MDS_CL_CLASS_FIXED_COST(ASSET_CLASS,1,MO) +
     +                   MON_MDS_CL_CLASS_FIXED_COST(ASSET_CLASS,2,MO) +
     +                   MON_MDS_CL_CLASS_FIXED_COST(ASSET_CLASS,3,MO)
                  MONTH_VARS(MO,Cash BTL Expenses) =
     +                   MONTH_VARS(MO,Cash BTL Expenses) +
     +                   MON_MDS_CL_CLASS_PURCHASES(ASSET_CLASS,4,MO) +
     +                   MON_MDS_CL_CAP_PURCHASES(ASSET_CLASS,4,MO) +
     +                   MON_MDS_CL_CLASS_VAR_COST(ASSET_CLASS,4,MO) +
     +                   MON_MDS_CL_CLASS_FIXED_COST(ASSET_CLASS,4,MO) +
     +                   MON_MDS_NF_FUEL_LEASED_BC(ASSET_CLASS,4,MO) +
     +                   MON_MDS_NF_FUEL_OWNED_BC(ASSET_CLASS,4,MO) +
     +                   MON_MDS_CL_CLASS_FUEL_COST(ASSET_CLASS,4,MO)
               ENDDO
            ENDIF
         ENDIF
      RETURN
C***********************************************************************
      ENTRY RETURN_MONTHLY_CL_REVENUES(R_CLASS,MONTH_VARS)
C***********************************************************************
C
         RETURN_MONTHLY_CL_REVENUES = 1
         IF(.NOT. ALLOCATED(MON_MDS_CL_CLASS_PURCHASES)) RETURN
         IF(R_CLASS <= MAX_CAP_LIMITED_CLASS_ID_NUM) THEN
            IF(R_CLASS ==0) THEN
               ASSET_CLASS = 0
            ELSE
               ASSET_CLASS = ASSET_CLASS_POINTER(R_CLASS)
            ENDIF
            IF(ASSET_CLASS > 0 .OR. R_CLASS == 0) THEN
C
               DO MO = 0, 12
                  MONTH_VARS(MO,Adjustment Clause) =
     +                    MONTH_VARS(MO,Adjustment Clause)
     +                    + MON_MDS_CL_CLASS_PURCHASES(ASSET_CLASS,1,MO)
     +                    + MON_MDS_CL_CAP_PURCHASES(ASSET_CLASS,1,MO)
     +                    + MON_MDS_NF_FUEL_LEASED_BC(ASSET_CLASS,1,MO)
     +                    + MON_MDS_NF_FUEL_OWNED_BC(ASSET_CLASS,1,MO)
     +                    + MON_MDS_CL_CLASS_FUEL_COST(ASSET_CLASS,1,MO)
                  MONTH_VARS(MO,Secondary Sales) =
     +                      MONTH_VARS(MO,Secondary Sales)
     +                      + MON_MDS_CL_CLASS_REVENUE(ASSET_CLASS,1,MO)
     +                      + MON_MDS_CL_CLASS_REVENUE(ASSET_CLASS,2,MO)
     +                      + MON_MDS_CL_CLASS_REVENUE(ASSET_CLASS,3,MO)
                  MONTH_VARS(MO,Capacity Sales) =
     +                      MONTH_VARS(MO,Capacity Sales)
     +                      + MON_MDS_CL_CAP_REVENUE(ASSET_CLASS,1,MO)
     +                      + MON_MDS_CL_CAP_REVENUE(ASSET_CLASS,2,MO)
     +                      + MON_MDS_CL_CAP_REVENUE(ASSET_CLASS,3,MO)
                  MONTH_VARS(MO,BTL Monthly Other Income) =
     +                      MONTH_VARS(MO,BTL Monthly Other Income)
     +                      + MON_MDS_CL_CLASS_REVENUE(ASSET_CLASS,4,MO)
     +                      + MON_MDS_CL_CAP_REVENUE(ASSET_CLASS,4,MO)
                  MONTH_VARS(MO,ICAP Revenues) =
     +                       MONTH_VARS(MO,ICAP Revenues)
     +                       + MON_MDS_ICAP_REV_BY_CLASS(ASSET_CLASS,MO)
               ENDDO
            ENDIF
         ENDIF
      RETURN
C***********************************************************************
      ENTRY RETURN_MONTHLY_CL_CASH_REVENUES(R_CLASS,MONTH_VARS)
C***********************************************************************
C
         RETURN_MONTHLY_CL_CASH_REVENUES = 1
         IF(.NOT. ALLOCATED(MON_MDS_CL_CLASS_PURCHASES)) RETURN
         IF(R_CLASS <= MAX_CAP_LIMITED_CLASS_ID_NUM) THEN
            IF(R_CLASS ==0) THEN
               ASSET_CLASS = 0
            ELSE
               ASSET_CLASS = ASSET_CLASS_POINTER(R_CLASS)
            ENDIF
            IF(ASSET_CLASS > 0 .OR. R_CLASS == 0) THEN
C
               DO MO = 0, 12
                  MONTH_VARS(MO,Cash Adjustment Clause) =
     +                    MONTH_VARS(MO,Cash Adjustment Clause) +
     +                    MON_MDS_CL_CLASS_PURCHASES(ASSET_CLASS,1,MO) +
     +                    MON_MDS_CL_CAP_PURCHASES(ASSET_CLASS,1,MO) +
     +                    MON_MDS_NF_FUEL_LEASED_BC(ASSET_CLASS,1,MO) +
     +                    MON_MDS_NF_FUEL_OWNED_BC(ASSET_CLASS,1,MO) +
     +                    MON_MDS_CL_CLASS_FUEL_COST(ASSET_CLASS,1,MO)
                  MONTH_VARS(MO,Cash Secondary Sales) =
     +                      MONTH_VARS(MO,Cash Secondary Sales) +
     +                      MON_MDS_CL_CLASS_REVENUE(ASSET_CLASS,1,MO) +
     +                      MON_MDS_CL_CLASS_REVENUE(ASSET_CLASS,2,MO) +
     +                      MON_MDS_CL_CLASS_REVENUE(ASSET_CLASS,3,MO)
                  MONTH_VARS(MO,
     +                      Cash Income Reserve Margin Capacity Sales) =
     +                  MONTH_VARS(MO,
     +                      Cash Income Reserve Margin Capacity Sales)
     +                  + MON_MDS_CL_CAP_REVENUE(ASSET_CLASS,1,MO)
     +                  + MON_MDS_CL_CAP_REVENUE(ASSET_CLASS,2,MO)
     +                  + MON_MDS_CL_CAP_REVENUE(ASSET_CLASS,3,MO)
                  MONTH_VARS(MO,Cash BTL Revenues) =
     +                     MONTH_VARS(MO,Cash BTL Revenues) +
     +                     MON_MDS_CL_CLASS_REVENUE(ASSET_CLASS,4,MO) +
     +                     MON_MDS_CL_CAP_REVENUE(ASSET_CLASS,4,MO)
                  MONTH_VARS(MO,Cash ICAP Revenues) =
     +                       MONTH_VARS(MO,Cash ICAP Revenues)
     +                       + MON_MDS_ICAP_REV_BY_CLASS(ASSET_CLASS,MO)
               ENDDO
            ENDIF
         ENDIF
      RETURN
C***********************************************************************
      ENTRY GET_CL_EMISS_FOR_CLASS(R_EMISS_TYPE,R_CLASS)
C***********************************************************************
         GET_CL_EMISS_FOR_CLASS = 0
         IF(R_CLASS <= MAX_CAP_LIMITED_CLASS_ID_NUM) THEN
            IF(R_CLASS ==0) THEN
               ASSET_CLASS = 0
            ELSE
               ASSET_CLASS = ASSET_CLASS_POINTER(R_CLASS)
            ENDIF
            IF(ASSET_CLASS > 0 .OR. R_CLASS == 0) THEN
               GET_CL_EMISS_FOR_CLASS =
     +               CL_ANN_CLASS_EMISSIONS(R_EMISS_TYPE,ASSET_CLASS)
            ENDIF
         ENDIF
      RETURN
C***********************************************************************
      ENTRY GET_CL_EMISSIONS(R_CLASS,R_CLASS_CL_EMISSIONS)
C***********************************************************************
         R_CLASS_CL_EMISSIONS(1:NUMBER_OF_EMISSION_TYPES) = 0.
         IF(R_CLASS <= MAX_CAP_LIMITED_CLASS_ID_NUM) THEN
            IF(R_CLASS ==0) THEN
               ASSET_CLASS = 0
            ELSE
               ASSET_CLASS = ASSET_CLASS_POINTER(R_CLASS)
            ENDIF
            IF(ASSET_CLASS > 0 .OR. R_CLASS == 0) THEN
               R_CLASS_CL_EMISSIONS(1:NUMBER_OF_EMISSION_TYPES) =
     +               CL_ANN_CLASS_EMISSIONS(1:NUMBER_OF_EMISSION_TYPES,
     +                                                      ASSET_CLASS)
            ENDIF
         ENDIF
         GET_CL_EMISSIONS = R_CLASS_CL_EMISSIONS(1)
      RETURN
C***********************************************************************
      ENTRY RETURN_CL_INTRA_CLASS_REVENUES(R_CLASS,
     +                                     R_INTRA_BASE_REVENUES,
     +                                     R_INTRA_ADJ_REVENUES,
     +                                     R_INTRA_SALES_REVENUES,
     +                                     R_INTRA_OTHER_REVENUES,
     +                                     R_INTRA_COMPANY_NF_BURN)
C***********************************************************************
C
         R_INTRA_COMPANY_NF_BURN = 0.
         IF(R_CLASS <= MAX_INTRA_CLASS) THEN
            RETURN_CL_INTRA_CLASS_REVENUES = .TRUE.
            R_INTRA_BASE_REVENUES = R_INTRA_BASE_REVENUES +
     +                        INTRA_COMPANY_REVENUES(R_CLASS,1)/1000000.
            R_INTRA_ADJ_REVENUES = R_INTRA_ADJ_REVENUES +
     +                        INTRA_COMPANY_REVENUES(R_CLASS,2)/1000000.
            R_INTRA_SALES_REVENUES = R_INTRA_SALES_REVENUES +
     +                        INTRA_COMPANY_REVENUES(R_CLASS,3)/1000000.
            R_INTRA_OTHER_REVENUES = R_INTRA_OTHER_REVENUES +
     +                        INTRA_COMPANY_REVENUES(R_CLASS,0)/1000000.
            R_INTRA_COMPANY_NF_BURN =
     +                           INTRA_COMPANY_NF_BURN(R_CLASS)/1000000.

         ELSE
            RETURN_CL_INTRA_CLASS_REVENUES = .FALSE.
         ENDIF
      RETURN
C***********************************************************************
      ENTRY RETURN_CL_INTRA_EXPENSES(R_INTRA_FOSSIL_FUEL_EXPENSES,
     +                               R_INTRA_LEASED_NUCLEAR_FUEL,
     +                               R_INTRA_OWNED_NUC_FUEL_EXPENSES,
     +                               R_INTRA_PURCHASE_EXPENSES,
     +                               R_INTRA_NUC_OWN_BURN,
     +                               R_INTRA_NUC_LEASE_BURN)
C***********************************************************************
C
         RETURN_CL_INTRA_EXPENSES = .TRUE.
         R_INTRA_FOSSIL_FUEL_EXPENSES = R_INTRA_FOSSIL_FUEL_EXPENSES +
     +                               INTRA_FOSSIL_FUEL_EXPENSES/1000000.
         R_INTRA_LEASED_NUCLEAR_FUEL = R_INTRA_LEASED_NUCLEAR_FUEL +
     +                           INTRA_LEASED_NUC_FUEL_EXPENSES/1000000.
         R_INTRA_OWNED_NUC_FUEL_EXPENSES =
     +                            R_INTRA_OWNED_NUC_FUEL_EXPENSES +
     +                            INTRA_OWNED_NUC_FUEL_EXPENSES/1000000.
         R_INTRA_NUC_OWN_BURN = R_INTRA_NUC_OWN_BURN +
     +                                       INTRA_NUC_OWN_BURN/1000000.
         R_INTRA_NUC_OWN_BURN = R_INTRA_NUC_OWN_BURN +
     +                                       INTRA_NUC_OWN_BURN/1000000.
         R_INTRA_NUC_LEASE_BURN = R_INTRA_NUC_LEASE_BURN +
     +                                     INTRA_NUC_LEASE_BURN/1000000.
         R_INTRA_PURCHASE_EXPENSES = R_INTRA_PURCHASE_EXPENSES
     +                               + INTRA_PURCHASE_EXPENSES/1000000.
      RETURN
      ENTRY GET_BLOCK_CAP_FACTORS(R_LOWER_BOUND_CAP_FACTOR,
     +                            R_UPPER_BOUND_CAP_FACTOR,R_NBLOK2,
     +                            R_FACET_MAINTENANCE_RATE,
     +                            R_FUEL_INVENTORY_ID,
     +                            R_MMBTU_FUEL_BALANCE,
     +                            R_MAINTENANCE_RATE)
         DO I = 1, R_NBLOK2
!
            UNITNO = UNIT(I)
            R_LOWER_BOUND_CAP_FACTOR(I) =
     +                                   MINIMUM_CAPACITY_FACTOR(UNITNO)
            R_UPPER_BOUND_CAP_FACTOR(I) =
     +                                   MAXIMUM_CAPACITY_FACTOR(UNITNO)
!
         ENDDO
         DO UNITNO = 1, NUNITS
            IF(SHADOW_UNIT_NUMBER(UNITNO) /= 0) THEN
               FUEL_ID = R_FUEL_INVENTORY_ID(FUEL_SUPPLY_ID(UNITNO))
               IF(UNITNO > SHADOW_UNIT_NUMBER(UNITNO) .AND.
     +                          R_MMBTU_FUEL_BALANCE(FUEL_ID) > 0.) THEN
                  R_FACET_MAINTENANCE_RATE(UNITNO) = 1.0
               ELSEIF(UNITNO < SHADOW_UNIT_NUMBER(UNITNO) .AND.
     +                      R_MMBTU_FUEL_BALANCE(FUEL_ID) <= 0. D0) THEN
                  R_FACET_MAINTENANCE_RATE(UNITNO) = 1.0
               ELSE
                  R_FACET_MAINTENANCE_RATE(UNITNO) =
     +                                        R_MAINTENANCE_RATE(UNITNO)
               ENDIF
            ELSE
               R_FACET_MAINTENANCE_RATE(UNITNO) =
     +                                        R_MAINTENANCE_RATE(UNITNO)
            ENDIF
         ENDDO
         GET_BLOCK_CAP_FACTORS = .TRUE.
      RETURN
CC***********************************************************************
C      ENTRY SPECIAL_ID_NAME(R_NUNITS)
CC***********************************************************************
C         SPECIAL_ID_NAME = SPECIAL_UNIT_ID(R_NUNITS)
C      RETURN
CC***********************************************************************
C      ENTRY RETURN_UNITNM(R_NUNITS)
CC***********************************************************************
C         RETURN_UNITNM = UNITNM(R_NUNITS)
C      RETURN
C***********************************************************************
      ENTRY CLA_SPECIAL_ID_NAME(R_NUNITS,R_NAME)
C***********************************************************************
         R_NAME = SPECIAL_UNIT_ID(R_NUNITS)
         CLA_SPECIAL_ID_NAME = .TRUE.
      RETURN
C***********************************************************************
      ENTRY CLA_RETURN_UNITNM(R_NUNITS,R_NAME) ! character 20 used in tf_objt, fuelused, clreport
C***********************************************************************
         R_NAME = UNITNM(R_NUNITS)
         CLA_RETURN_UNITNM = .TRUE.
      RETURN
      END
C***********************************************************************
      REAL FUNCTION GET_CL_POOL_FRAC_OWN(R_NUNITS)
C***********************************************************************
      USE CL_UNITS_READ_DATA
      INTEGER (KIND=2) :: R_NUNITS
         GET_CL_POOL_FRAC_OWN = LOCAL_CL_POOL_FRAC_OWN(R_NUNITS)
      END FUNCTION
C***********************************************************************
      REAL FUNCTION GET_P_FUEL_DELIVERY(R_NUNITS)  !R4
C***********************************************************************
      USE ANNLCOMMON
      INTEGER (KIND=2) :: R_NUNITS
         GET_P_FUEL_DELIVERY = P_FUEL_DELIVERY_1(R_NUNITS)
      END FUNCTION
C***********************************************************************
       REAL FUNCTION  GET_P_FUEL_DELIVERY_2(R_NUNITS)   !R4
C***********************************************************************
      USE ANNLCOMMON
      INTEGER (KIND=2) :: R_NUNITS
         GET_P_FUEL_DELIVERY_2 = P_FUEL_DELIVERY_2(R_NUNITS)
      END FUNCTION
C***********************************************************************
       REAL FUNCTION  GET_P_FUEL_DELIVERY_3(R_NUNITS)  !R4
C***********************************************************************
      USE ANNLCOMMON
      INTEGER (KIND=2) :: R_NUNITS
         GET_P_FUEL_DELIVERY_3 = P_FUEL_DELIVERY_3(R_NUNITS)
      END FUNCTION
C***********************************************************************
      FUNCTION SPECIAL_ID_NAME(R_NUNITS)  ! character 20 used in margnobj and catawba
C***********************************************************************
C
      CHARACTER*20 SPECIAL_ID_NAME,RETURN_UNITNM,R_NAME
      LOGICAL*1 VOID_LOGICAL,CLA_SPECIAL_ID_NAME,CLA_RETURN_UNITNM
      INTEGER*2 R_NUNITS
         VOID_LOGICAL = CLA_SPECIAL_ID_NAME(R_NUNITS,R_NAME)  ! character 20 used in margnobj and catawba
         SPECIAL_ID_NAME = R_NAME
      RETURN
C***********************************************************************
      ENTRY RETURN_UNITNM(R_NUNITS) ! character 20 used in tf_objt, fuelused, clreport
C***********************************************************************
         VOID_LOGICAL = CLA_RETURN_UNITNM(R_NUNITS,R_NAME)
         RETURN_UNITNM = R_NAME
      RETURN
      END
C***********************************************************************
      FUNCTION CL_UNIQUE_RPT_STR(R_UNIT)
C***********************************************************************
C
         CHARACTER*5 CL_UNIQUE_RPT_STR,RPT_STR
         INTEGER*2 R_UNIT,CL_NUM
         INTEGER*4 UNIQUE_REPORT_VALUE_FOR_CL_UNIT
         IF(UNIQUE_REPORT_VALUE_FOR_CL_UNIT(R_UNIT) < 32000) THEN
            CL_NUM = UNIQUE_REPORT_VALUE_FOR_CL_UNIT(R_UNIT)
         ELSE
            CL_NUM = 32000
         ENDIF
         IF(CL_NUM <= 0) THEN
            RPT_STR = ' '
         ELSE
            WRITE(RPT_STR,'(I5)') CL_NUM
         ENDIF
         CL_UNIQUE_RPT_STR = RPT_STR
      RETURN
      END
C***********************************************************************
C
      FUNCTION CL_SCREEN_DATA()
C
C***********************************************************************
C DECLARATION FOR LOCAL VARIABLES
      INTEGER*2 SUNITS,CL_OPTIONS,M,S,
     +          RETURN_CL_OPTIONS_NO,PRODUCTION_DATA_POINTER(*),
     +          DELETE,TOTAL_ALL_OPTIONS,
     +          OPTIONS_COUNTER,PROD_PNTR_BY_CL_UNITS(:),
     +          PROD_POINTER,R_YEAR,UPDATE_CL_SCREEN_COSTS,
     +          R_MO,R_NUNITS,R_DATE,YR,R_MONTH
      LOGICAL*1   CL_SCREEN_DATA,READ_CL_SCREEN_DATA,
     +            IS_A_HARD_WIRED_UNIT(*),
     +            SCREEN_NOX_ACTIVE_FOR_UNIT,
     +            GET_SCREEN_NOX_CONTROL_FOR_UNIT,
     +            GET_SCREEN_SOX_CONTROL_FOR_UNIT,
     +            GET_SCREEN_CO2_CONTROL_FOR_UNIT,
     +            GET_SCREEN_HG_CONTROL_FOR_UNIT,
     +            GET_SCREEN_OTHER3_CONTROL_FOR_UNIT,
     +            R_SEASON_IS_NOX_SEASON,
     +            R_CALCULATE_NOX,
     +            YES_GSP_IS_ST_TG,
     +            GET_S_BLOCK_CAP_AND_HR,
     +            VECTOR_IS_VALUE,
     +            S_YES_MONTHLY_MUST_RUN
      REAL  RETURN_CL_SCREEN_FIXED_COST,RETURN_CL_SCREEN_VARI_COST,
     +      RETURN_CL_SCREEN_FUEL_COST,
     +      RETURN_CL_SCREEN_EMIS_COST,
     +      GET_CL_CO2_TON_PER_MWH,
     +      ESCALATED_VALUE,GET_VAR,FUEL_COMPONENT,
     +      OTHER_VARIABLE_COMPONENT/0/,
     +      RETURN_OTHER_VAR_COMPONENT,
     +      FUEL_MIX_FACTOR,
     +      EMIS_DISPATCH_1,
     +      EMIS_DISPATCH_2,
     +      EMIS_DISPATCH_3,
     +      EMIS_DISPATCH_4,
     +      EMIS_DISPATCH_5,
     +      TRANS_DISPATCH_EMIS_ADDER,
     +      TRANS_MRX_DISPATCH_EMIS_ADDER,
     +      TEMP_R4,
     +      TEMP_MO_VAL,
     +      R_NOX_MULT,
     +      R_SOX_MULT,
     +      R_CO2_MULT,
     +      R_HG_MULT,
     +      R_OTHER3_MULT,
     +      R_CO2_RETIREMENT_PRICE,
     +      GET_SCENARIO_CO2_PRICES
C
C DECLARATIONS FOR THE EXPANSION PLANT OPERATIONS FILE
C
      CHARACTER*20   S_UNITNM(:)
      CHARACTER*30   CO2_BASIN_NAME
      CHARACTER*1    LDTYPE(:)
      CHARACTER*2    CL_LOAD_TYPE,RESOURCE_TYPE(*),
     +               TEMP_STATE,
     +               UNIT_TYPE,
     +               UNIT_TYPE_CATEGORY
      CHARACTER*6  PRIM_FUEL_TYPE
      INTEGER*2      GENGRP,
     +               ONLIMO,OFLIMO,
     +               S_PFESCR(:),
     +               S_SFESCR(:),
     +               S_OMESCR(:),
     +               S_FIXED_COST_ESCALATOR(:),
     +               CL_AI_CAPACITY_ESCALATOR,
     +               CL_AI_ENERGY_ESCALATOR,
     +               CL_RESOURCE_ID,
     +               FUEL_SUPPLY_ID,
     +               EMISS_FUEL_EMISS_PTR,
     +               PRIM_FUEL_EMISS_PTR,
     +               PROD_PNTR/5000/, ! 030310.
     +               TIE_CONSTRAINT_GROUP, ! INT*2
     +               S_MONTHLY_CAPACITY_POINTER(:), ! INT*2
     +               S_ANNUAL_CL_FIXED_COST_ESC(:), ! INT*2
     +               SEC_FUEL_EMISS_PTR,
     +               EMISS_FUEL_ESCAL,
     +               NOX_SEASON_DATE(:),
     +               GET_BELONGS_TO_GROUP,
     +               ISEAS,
     +               STATE_2_GAS_REGION_LOOKUP,
     +               TEMP_I2,
     +               FIRST_RETIREMENT_YEAR,
     +               GET_S_RPS_PROGRAM_NUMBER,
     +               S_RPS_PROGRAM_NUMBER(:),
     +               R_RPS_PROGRAM
      INTEGER*8
     +               HESI_UNIT_ID_NUM,
     +               TRANS_BUS_ID,
     +               THERMAL_PARENT_ID,
     +               H2_UNIT_ID_NUM
      INTEGER*4
     +               ! H2_UNIT_ID_NUM, ! 032710. CHANGED TO I8
     +               POWERDAT_PLANT_ID
      REAL*4         CAP_FRAC_OWN,S_FUELMX(:),S_PBTUCT(:),
     +               S_SBTUCT(:),
     +               S_FUELADJ_IN(:),S_EFOR(:),
     +               S_FUELADJ(:),
     +               S_MNRATE(:,:),
     +               S_VCPMWH_IN(:),
     +               S_FIXED_COST_IN(:),
     +               DISPADJ,S_HR_FACTOR(:),
     +               S_INPUT_MW(:,:),
     +               S_CAP_PLANNING_FAC(:),
     +               S_COEFF(:,:),
     +               CL_AI_CAPACITY_RATE,
     +               CL_AI_ENERGY_RATE,
     +               P_SO2(:),
     +               P_NOX(:),
     +               P_PARTICULATES(:),
     +               CL_POOL_FRAC_OWN,
     +               P_EMIS_OTH2(:),
     +               P_EMIS_OTH3(:),
     +               DISPADJ2,
     +               P_NOX_BK2,
     +               EMISS_FUEL_COST,
     +               EMISS_BLENDING_RATE,
     +               S_ANNUAL_CL_FIXED_COST(:),
     +               MAINT_DAYS, !REAL
     +               NOX_VOM(:),
     +               NOX_FOM(:),
     +               SOX_VOM(:),
     +               SOX_FOM(:),
     +               CO2_VOM(:),
     +               CO2_FOM(:),
     +               HG_VOM(:),
     +               HG_FOM(:),
     +               OTHER3_VOM(:),
     +               OTHER3_FOM(:),
     +               GET_SCREEN_NOX_VOM,
     +               GET_SCREEN_NOX_FOM,
     +               GET_SCREEN_SOX_VOM,
     +               GET_SCREEN_SOX_FOM,
     +               GET_SCREEN_CO2_VOM,
     +               GET_SCREEN_CO2_FOM,
     +               GET_SCREEN_HG_VOM,
     +               GET_SCREEN_HG_FOM,
     +               GET_SCREEN_OTHER3_VOM,
     +               GET_SCREEN_OTHER3_FOM,
     +               LATITUDE,
     +               LONGITUDE,
     +               MW_INSIDE_FENCE,
     +               S_INTER_BLOCKS(:,:),
     +               MARKET_FLOOR,
     +               MARKET_CEILING,
     +               START_UP_COSTS_ESCALATION(:),
     +               RTEMP,
     +               R_BLOCK_CAPACITY(5),
     +               R_BLOCK_HEAT_RATE(5),
     +               A_HR,B_HR,INC_CAP,
     +               GET_S_CAP_PLANNING_FAC,
     +               GET_S_RPS_PERCENT
      INTEGER*2
     +               CAPACITY_MARKET_POINTER,
     +               RETROFIT_PROJECT_ID
       REAL*4        CAPACITY_MARKET_COIN_ADJ_FACT,
     +               S_RPS_PERCENT(:),
     +               CO2_PIPELINE_DISTANCE,
     +               CO2_RETRO_HEAT_MULT,
     +               CO2_RETRO_CAP_MULT
      CHARACTER*5
     +               CAPACITY_MARKET_TYPE,
     +               CAPACITY_MARKET_MONTH,
     +               CAPACITY_MARKET_EXP_COLLECT
      CHARACTER*20   CAPACITY_MARKET_COST_ASSIGN,
     +               STATE_PROV_NAME
      CHARACTER*36 THERMAL_GUID
      CHARACTER*1 APPLY_NOX_SEASON_DATE(:),
     +             THERMAL_AGGREGATED_UNIT
      CHARACTER*18 EXPENSE_ASSIGNMENT,EXPENSE_COLLECTION
      CHARACTER*10 SEC_FUEL_TYPE,EMISS_FUEL_TYPE
      CHARACTER (LEN=5) :: AGGREGATE_THIS_UNIT,
     +                     LINKED_BETTERMENT_OPTION
      CHARACTER (LEN=9) :: EMISSION_DATA_UNITS
      CHARACTER TEMP_APPLY_NOX_SEASON_DATE*5,
     +                     UNIT_ACTIVE*5,
     +                     REPORT_THIS_UNIT*5,
     +                     UTILITY_OWNED*15,
     +                     INTRA_COMPANY_TRANSACTION*3,
     +                     SPECIAL_UNIT_ID*20,
     +                     START_UP_LOGIC*9,
     +                     CONTRIBUTES_TO_SPIN*5,
     +                     MARKET_RESOURCE*6,
     +                     USE_POLY_HEAT_RATES*5,
     +                     WVPA_RATE_TRACKER*20,
     +                     WVPA_RES_TRACKER*20,
     +                     WVPA_FUEL_TRACKER*20,
     +                     MONTE_OR_FREQ*20,
     +                     WVPA_MEM_TRACKER*20,
     +                     ALLOW_DECOMMIT*5,
     +                     PRIMARY_FUEL_CATEGORY*20,
     +                     SECONDARY_FUEL_CATEGORY*20,
     +                     EMISSIONS_FUEL_CATEGORY*20,
     +                     RETIREMENT_CANDIDATE*20,
     +                     RETROFIT_CANDIDATE*20
      CHARACTER*6
     +                     BASECASE_PLANT_ID,
     +                     BASECASE_UNIT_ID,
     +                     BASECASE_MARKET_AREA_ID,
     +                     BASECASE_TRANS_AREA_ID,
     +                     BASECASE_PLANT_NERC_SUB_ID,
     +                     BASECASE_PLANT_OWNER_ID,
     +                     TEMP_PRIM_FUEL_TYPE_STR,
     +                     PRIMARY_MOVER_STR(:),
     +                     PRIM_FUEL_TYPE_STR
      CHARACTER*20 COUNTY,NEWGEN_UNIT_STATUS
      CHARACTER*6 STATE_PROVINCE,TEMP_CHAR6
      INTEGER*2
     +                     AI_CL_REMAINING_LIFE,
     +                     ASSET_CLASS_NUM,
     +                     ASSET_CLASS_VECTOR,
     +                     INTRA_COMPANY_CLASS_ID,
     +                     S_TRANSACTION_GROUP_ID(:),
     +                     MONTHLY_FUEL_INDEX,
     +                     DAY_TYPE_ID,
     +                     RETURN_S_TRANS_GROUP_ID,
     +                     S_PRIMARY_MOVER(:),
     +                     S_UNIT_GAS_REGION_INDEX(:),
     +                     GET_SCRN_UNIT_GAS_REGION_INDEX,
     +                     State_Index(:),
     +                     GET_SCREEN_STATE_INDEX,
     +                     GET_S_PRIMARY_MOVER,
     +                     FUEL_TYPE_2_PRIM_MOVER,
     +                     NOX_CONTROL_DATE(:),
     +                     SOX_CONTROL_DATE(:),
     +                     CO2_CONTROL_DATE(:),
     +                     HG_CONTROL_DATE(:),
     +                     OTHER3_CONTROL_DATE(:),
     +                     MONTHLY_MUST_RUN_VECTOR(:),
     +                     MONTHLY_DECOMMIT_VECTOR,
     +                     S_EMISSION_MARKET_LINK(:),
     +                     FT,GET_PRIMARY_MOVER,MO,
     +                     L_S,I,PM,
     +                     GET_MRX_EMISSION_MARKET_LINK,
     +                     STATE_ID_LOOKUP,
     +                     ST_TG,
     +                     BASE_PN_RECORDS,
     +                     PRIMARY_MOVER_INDEX_DB,
     +                     GET_S_PRIMARY_MOVER_INDEX
      REAL*4
     +                     DISPATCH_MULT,
     +                     EXCESS_ENERGY_SALES,
     +                     MINIMUM_CAPACITY_FACTOR,
     +                     MAXIMUM_CAPACITY_FACTOR,
     +                     AI_CL_TAX_LIFE,
     +                     AI_CL_ADR_LIFE,
     +                     RAMP_RATE,
     +                     RAMP_DOWN_RATE,
     +                     P_FUEL_DELIVERY(:),
     +                     P_FUEL_DELIVERY_2(:),
     +                     P_FUEL_DELIVERY_3(:),
     +                     START_UP_COSTS(:),
     +                     GET_S_START_UP_COSTS,
     +                     ESCAL_RATE,
     +                     MIN_DOWN_TIME(:),
     +                     GET_S_MIN_DOWN_TIME,
     +                     MIN_UP_TIME(:),
     +                     GET_S_MIN_UP_TIME,
     +                     S_FUEL_DELIVERY(:),
     +                     S_FUEL_DELIVERY_2(:),
     +                     S_FUEL_DELIVERY_3(:),
     +                     CONSTANT_POLY,
     +                     FIRST_POLY,
     +                     SECOND_POLY,
     +                     THIRD_POLY,
     +                     MIN_SPIN_CAP,
     +                     MAX_SPIN_CAP,
     +                     FOR_FREQUENCY,
     +                     FOR_DURATION,
     +                     WINTER_TOTAL_CAPACITY,
     +                     R_FUEL_DELIVERY_1,
     +                     R_FUEL_DELIVERY_2,
     +                     R_FUEL_DELIVERY_3,
     +                     GET_NEW_UNIT_FUEL_DELIVERY,
     +                     R_DELIVERY_COST,
     +                     SAVE_DELIVERY_COST/0./,
     +                     PUT_MRX_DELIVERY_COST,
     +                     RETURN_CL_SCREEN_EFOR,
     +                     R_MONTHLY(12),
     +                     NOX_CONTROL_PERCENT(:),
     +                     SOX_CONTROL_PERCENT(:),
     +                     CO2_CONTROL_PERCENT(:),
     +                     HG_CONTROL_PERCENT(:),
     +                     OTHER3_CONTROL_PERCENT(:),
     +                     R_NOX_CONTROL_PERCENT,
     +                     R_SOX_CONTROL_PERCENT,
     +                     R_CO2_CONTROL_PERCENT,
     +                     R_HG_CONTROL_PERCENT,
     +                     R_OTHER3_CONTROL_PERCENT,
     +                     EMERGENCY_CAPACITY,
     +                     EMERGENCY_HEATRATE,
     +                     FUEL_SCEN_MULT,
     +                     GET_SCENARIO_COAL_PRICES,
     +                     GET_SCENARIO_GAS_PRICES,
     +                     GET_SCENARIO_OIL_PRICES,
     +                     GET_SCENARIO_URANIUM_PRICES,
     +                     R_HEAT_RATE,
     +                     R_FUEL_COST,
     +                     ESCALATED_MONTHLY_VALUE,
     +                     START_UP_COST_ESCALATED_MONTHLY_VALUE,
     +                     RETURN_VALUE_FROM_ESCALATION_VECTOR
C DECLARATIONS FOR SCREENING VARIABLES
C
      REAL*4 AHR(:),HEAT_RATE_FACTOR/0./
C
C OPERATIONS FILE
      ALLOCATABLE :: S_FUELMX,S_PBTUCT,S_PFESCR,S_SBTUCT,
     +               S_RPS_PROGRAM_NUMBER,
     +               S_RPS_PERCENT,
     +               P_FUEL_DELIVERY,
     +               P_FUEL_DELIVERY_2,
     +               P_FUEL_DELIVERY_3,
     +               START_UP_COSTS,
     +               START_UP_COSTS_ESCALATION,
     +               MIN_DOWN_TIME,
     +               MIN_UP_TIME,
     +               S_FUEL_DELIVERY,
     +               S_FUEL_DELIVERY_2,
     +               S_FUEL_DELIVERY_3,
     +               APPLY_NOX_SEASON_DATE,
     +               S_PRIMARY_MOVER,
     +               S_UNIT_GAS_REGION_INDEX,
     +               State_Index,
     +               NOX_SEASON_DATE,
     +               NOX_CONTROL_PERCENT,
     +               PRIMARY_MOVER_STR,
     +               CO2_CONTROL_PERCENT,
     +               HG_CONTROL_PERCENT,
     +               OTHER3_CONTROL_PERCENT,
     +               NOX_CONTROL_DATE,
     +               CO2_CONTROL_DATE,
     +               HG_CONTROL_DATE,
     +               MONTHLY_MUST_RUN_VECTOR,
     +               OTHER3_CONTROL_DATE,
     +               SOX_CONTROL_PERCENT,
     +               SOX_CONTROL_DATE,
     +               SOX_VOM,
     +               SOX_FOM,
     +               NOX_VOM,
     +               NOX_FOM,
     +               CO2_VOM,
     +               CO2_FOM,
     +               HG_VOM,
     +               HG_FOM,
     +               OTHER3_VOM,
     +               OTHER3_FOM
      ALLOCATABLE :: S_SFESCR,S_FUELADJ_IN,S_FUELADJ,
     +               S_VCPMWH_IN,S_OMESCR,S_EFOR,
     +               S_MNRATE,
     +               S_INTER_BLOCKS
      ALLOCATABLE :: S_FIXED_COST_IN,S_FIXED_COST_ESCALATOR,
     +               S_MONTHLY_CAPACITY_POINTER
      ALLOCATABLE :: S_HR_FACTOR,S_INPUT_MW
      ALLOCATABLE :: S_CAP_PLANNING_FAC,S_COEFF,
     +               P_SO2,
     +               P_NOX,
     +               P_PARTICULATES,
     +               P_EMIS_OTH2,
     +               P_EMIS_OTH3
      ALLOCATABLE :: PROD_PNTR_BY_CL_UNITS
      ALLOCATABLE :: AHR,S_UNITNM,LDTYPE
      ALLOCATABLE :: S_ANNUAL_CL_FIXED_COST,
     +               S_TRANSACTION_GROUP_ID,
     +               S_EMISSION_MARKET_LINK
      ALLOCATABLE :: S_ANNUAL_CL_FIXED_COST_ESC
C
      SAVE
C OPERATIONS FILE
     +      S_FUELMX,S_PBTUCT,S_PFESCR,S_SBTUCT,
     +      S_RPS_PROGRAM_NUMBER,
     +      S_RPS_PERCENT,
     +      P_FUEL_DELIVERY,
     +      P_FUEL_DELIVERY_2,
     +      P_FUEL_DELIVERY_3,
     +      START_UP_COSTS,
     +      START_UP_COSTS_ESCALATION,
     +      MIN_DOWN_TIME,
     +      MIN_UP_TIME,
     +      S_FUEL_DELIVERY,
     +      S_FUEL_DELIVERY_2,
     +      S_FUEL_DELIVERY_3,
     +      APPLY_NOX_SEASON_DATE,
     +      S_PRIMARY_MOVER,
     +      S_UNIT_GAS_REGION_INDEX,
     +      State_Index,
     +      NOX_SEASON_DATE,
     +      NOX_CONTROL_PERCENT,
     +      PRIMARY_MOVER_STR,
     +      CO2_CONTROL_PERCENT,
     +      HG_CONTROL_PERCENT,
     +      OTHER3_CONTROL_PERCENT,
     +      NOX_CONTROL_DATE,
     +      CO2_CONTROL_DATE,
     +      HG_CONTROL_DATE,
     +      OTHER3_CONTROL_DATE,
     +      MONTHLY_MUST_RUN_VECTOR,
     +      SOX_CONTROL_PERCENT,
     +      SOX_CONTROL_DATE,
     +      SOX_VOM,
     +      SOX_FOM,
     +      NOX_VOM,
     +      NOX_FOM,
     +      CO2_VOM,
     +      CO2_FOM,
     +      HG_VOM,
     +      HG_FOM,
     +      OTHER3_VOM,
     +      OTHER3_FOM,
     +      S_SFESCR,S_FUELADJ_IN,S_FUELADJ,
     +      S_MNRATE,
     +      S_INTER_BLOCKS,
     +      S_VCPMWH_IN,S_OMESCR,S_EFOR,
     +      S_FIXED_COST_IN,S_FIXED_COST_ESCALATOR,
     +      S_MONTHLY_CAPACITY_POINTER,
     +      S_HR_FACTOR,S_INPUT_MW,
     +      S_CAP_PLANNING_FAC,S_COEFF,AHR,S_UNITNM,LDTYPE,
     +      P_SO2,
     +      P_NOX,
     +      P_PARTICULATES,
     +      P_EMIS_OTH2,
     +      P_EMIS_OTH3,
     +      S_ANNUAL_CL_FIXED_COST,
     +      S_TRANSACTION_GROUP_ID,
     +      S_EMISSION_MARKET_LINK,
     +      S_ANNUAL_CL_FIXED_COST_ESC,
C LOCAL VARIABLES
     +      PROD_PNTR_BY_CL_UNITS,SUNITS
C SPCapEx additions Nov. 2005
      CHARACTER (LEN=20)  :: TECH_TYPE
      LOGICAL (KIND=1) :: SP_CAPEX_ACTIVE,SPCapExOption
      CHARACTER (LEN=15),DIMENSION(155) :: CL_VARIABLES
      REAL (KIND=4) :: FIRST_YEAR_DECOMM_AVAIALABLE
      REAL (KIND=4) :: DECOMMISSIONING_BASE_YR_COST,
     +                 DECOMMISSIONING_COST_ESCALATION,
     +                 ANNUAL_ENERGY_PLANNING_FACTOR,
     +                 NAME_PLATE_CAPACITY,
     +                 FuelRatio(5),
     +                 BlendableFuelsPtr(4), ! 167
     +                 FuelTransportationCost(4),
     +                 BlendedEnthalpyUp,
     +                 BlendedEnthalpyLo,
     +                 BlendedSO2Up,                  ! 177
     +                 BettermentProjectID,
     +                 DECOM_CONTINUING_COST,
     +                 DECOM_CONTINUING_COST_ESCALATION,
     +                 EnrgPatternPointer, ! 181
     +                 EmissRedRate(5),
     +                 EmissMaxRate(5),
     +                 MaxEnergyLimit(3)
      CHARACTER*10 FUEL_BLENDING_IS
!
! END OF DATA DECLARATIONS
!
      CL_SCREEN_DATA = .TRUE.
C
C***********************************************************************
      ENTRY READ_CL_SCREEN_DATA(PRODUCTION_DATA_POINTER,RESOURCE_TYPE,
     +                                    CL_OPTIONS,TOTAL_ALL_OPTIONS,
     +                                    IS_A_HARD_WIRED_UNIT)
C***********************************************************************
         CALL GET_BASE_PN_RECORDS(BASE_PN_RECORDS)
         PROD_PNTR = MAX(PROD_PNTR,TOTAL_ALL_OPTIONS,
     +                    BASE_PN_RECORDS)
         IF(ALLOCATED(S_FUELMX))
     +         DEALLOCATE(
     +               S_FUELMX,
     +               S_PBTUCT,
     +               S_PFESCR,
     +               S_SBTUCT,
     +               S_RPS_PROGRAM_NUMBER,
     +               S_RPS_PERCENT,
     +               S_SFESCR,
     +               S_FUELADJ_IN,
     +               S_FUELADJ,
     +               S_MNRATE,
     +               S_INTER_BLOCKS,
     +               S_EFOR,
     +               S_VCPMWH_IN,
     +               S_OMESCR,
     +               S_FIXED_COST_IN,
     +               S_FIXED_COST_ESCALATOR,
     +               S_MONTHLY_CAPACITY_POINTER,
     +               S_HR_FACTOR,
     +               S_INPUT_MW,
     +               S_CAP_PLANNING_FAC,
     +               S_COEFF,
     +               P_SO2,
     +               P_NOX,
     +               P_PARTICULATES,
     +               P_EMIS_OTH2,
     +               P_EMIS_OTH3,
     +               AHR,
     +               PROD_PNTR_BY_CL_UNITS,
     +               S_UNITNM,
     +               LDTYPE,
     +               S_ANNUAL_CL_FIXED_COST,
     +               S_TRANSACTION_GROUP_ID,
     +               S_EMISSION_MARKET_LINK,
     +               S_ANNUAL_CL_FIXED_COST_ESC,
     +               P_FUEL_DELIVERY,
     +               P_FUEL_DELIVERY_2,
     +               P_FUEL_DELIVERY_3,
     +               START_UP_COSTS,
     +               START_UP_COSTS_ESCALATION,
     +               MIN_DOWN_TIME,
     +               MIN_UP_TIME,
     +               S_FUEL_DELIVERY,
     +               S_FUEL_DELIVERY_2,
     +               S_FUEL_DELIVERY_3,
     +               APPLY_NOX_SEASON_DATE,
     +               S_PRIMARY_MOVER,
     +               S_UNIT_GAS_REGION_INDEX,
     +               State_Index,
     +               NOX_SEASON_DATE,
     +               NOX_CONTROL_PERCENT,
     +               PRIMARY_MOVER_STR,
     +               CO2_CONTROL_PERCENT,
     +               HG_CONTROL_PERCENT,
     +               OTHER3_CONTROL_PERCENT,
     +               NOX_CONTROL_DATE,
     +               CO2_CONTROL_DATE,
     +               HG_CONTROL_DATE,
     +               OTHER3_CONTROL_DATE,
     +               MONTHLY_MUST_RUN_VECTOR,
     +               SOX_CONTROL_PERCENT,
     +               SOX_CONTROL_DATE,
     +               SOX_VOM,
     +               SOX_FOM,
     +               NOX_VOM,
     +               NOX_FOM,
     +               CO2_VOM,
     +               CO2_FOM,
     +               HG_VOM,
     +               HG_FOM,
     +               OTHER3_VOM,
     +               OTHER3_FOM)
C OPERATIONS FILE
         ALLOCATE(S_FUELMX(CL_OPTIONS))
         ALLOCATE(S_PBTUCT(CL_OPTIONS))
         ALLOCATE(S_PFESCR(CL_OPTIONS))
         ALLOCATE(S_SBTUCT(CL_OPTIONS))
         ALLOCATE(S_RPS_PROGRAM_NUMBER(CL_OPTIONS))
         ALLOCATE(S_RPS_PERCENT(CL_OPTIONS))
         ALLOCATE(S_SFESCR(CL_OPTIONS))
         ALLOCATE(S_FUELADJ_IN(CL_OPTIONS))
         ALLOCATE(S_MNRATE(CL_OPTIONS,12))
         ALLOCATE(S_INTER_BLOCKS(CL_OPTIONS,3))
         ALLOCATE(S_FUELADJ(CL_OPTIONS))
         ALLOCATE(S_EFOR(CL_OPTIONS))
         ALLOCATE(S_VCPMWH_IN(CL_OPTIONS))
         ALLOCATE(S_OMESCR(CL_OPTIONS))
         ALLOCATE(S_FIXED_COST_IN(CL_OPTIONS))
         ALLOCATE(S_FIXED_COST_ESCALATOR(CL_OPTIONS))
         ALLOCATE(S_MONTHLY_CAPACITY_POINTER(CL_OPTIONS))
         ALLOCATE(S_HR_FACTOR(CL_OPTIONS))
         ALLOCATE(S_INPUT_MW(2,CL_OPTIONS))
         ALLOCATE(S_CAP_PLANNING_FAC(CL_OPTIONS))
         ALLOCATE(S_COEFF(3,CL_OPTIONS),
     +               P_SO2(CL_OPTIONS),
     +               P_NOX(CL_OPTIONS),
     +               P_PARTICULATES(CL_OPTIONS),
     +               P_EMIS_OTH2(CL_OPTIONS),
     +               P_EMIS_OTH3(CL_OPTIONS))
         ALLOCATE(AHR(CL_OPTIONS))
         ALLOCATE(PROD_PNTR_BY_CL_UNITS(PROD_PNTR))
         ALLOCATE(S_UNITNM(CL_OPTIONS))
         ALLOCATE(LDTYPE(CL_OPTIONS))
         ALLOCATE(S_ANNUAL_CL_FIXED_COST(CL_OPTIONS))
         ALLOCATE(S_TRANSACTION_GROUP_ID(CL_OPTIONS))
         ALLOCATE(S_EMISSION_MARKET_LINK(CL_OPTIONS))
         ALLOCATE(S_ANNUAL_CL_FIXED_COST_ESC(CL_OPTIONS))
         ALLOCATE(P_FUEL_DELIVERY(CL_OPTIONS))
         ALLOCATE(START_UP_COSTS(CL_OPTIONS))
         ALLOCATE(START_UP_COSTS_ESCALATION(CL_OPTIONS))
         ALLOCATE(MIN_DOWN_TIME(CL_OPTIONS))
         ALLOCATE(MIN_UP_TIME(CL_OPTIONS))
         ALLOCATE(P_FUEL_DELIVERY_2(CL_OPTIONS))
         ALLOCATE(P_FUEL_DELIVERY_3(CL_OPTIONS))
         ALLOCATE(S_FUEL_DELIVERY(CL_OPTIONS))
         ALLOCATE(S_FUEL_DELIVERY_2(CL_OPTIONS))
         ALLOCATE(S_FUEL_DELIVERY_3(CL_OPTIONS))
         ALLOCATE(APPLY_NOX_SEASON_DATE(CL_OPTIONS),
     +            S_PRIMARY_MOVER(CL_OPTIONS),
     +            S_UNIT_GAS_REGION_INDEX(CL_OPTIONS),
     +            State_Index(CL_OPTIONS),
     +            NOX_SEASON_DATE(CL_OPTIONS),
     +            NOX_CONTROL_PERCENT(CL_OPTIONS),
     +            PRIMARY_MOVER_STR(CL_OPTIONS),
     +            CO2_CONTROL_PERCENT(CL_OPTIONS),
     +            HG_CONTROL_PERCENT(CL_OPTIONS),
     +            OTHER3_CONTROL_PERCENT(CL_OPTIONS),
     +            NOX_CONTROL_DATE(CL_OPTIONS),
     +            CO2_CONTROL_DATE(CL_OPTIONS),
     +            HG_CONTROL_DATE(CL_OPTIONS),
     +            OTHER3_CONTROL_DATE(CL_OPTIONS),
     +            MONTHLY_MUST_RUN_VECTOR(CL_OPTIONS),
     +            SOX_CONTROL_PERCENT(CL_OPTIONS),
     +            SOX_CONTROL_DATE(CL_OPTIONS),
     +            SOX_VOM(CL_OPTIONS),
     +            SOX_FOM(CL_OPTIONS),
     +            NOX_VOM(CL_OPTIONS),
     +            NOX_FOM(CL_OPTIONS),
     +            CO2_VOM(CL_OPTIONS),
     +            CO2_FOM(CL_OPTIONS),
     +            HG_VOM(CL_OPTIONS),
     +            HG_FOM(CL_OPTIONS),
     +            OTHER3_VOM(CL_OPTIONS),
     +            OTHER3_FOM(CL_OPTIONS))
C READ THE CORRESPONDING EXPANSION PLANT RECORDS
         S_UNIT_GAS_REGION_INDEX = 0
         SUNITS = 0
         S_INTER_BLOCKS = 0.0
         PROD_PNTR_BY_CL_UNITS = -1 ! 111413.
         DO OPTIONS_COUNTER = 1, TOTAL_ALL_OPTIONS
            IF(RESOURCE_TYPE(OPTIONS_COUNTER) /= 'CL' .OR.
     +                      IS_A_HARD_WIRED_UNIT(OPTIONS_COUNTER)) CYCLE
            SUNITS = SUNITS + 1
!
! 5/4/94. GAT. TAKEN-OUT FOR NOW.
!
C            IF(SUNITS > CL_OPTIONS) THEN
C               WRITE(4,*) "The total number of CL options in screening"
C               WRITE(4,*) "is inconsistent with the Options file"
C               WRITE(4,*) " "
C               WRITE(4,*) '*** line 6612 CLA_OBJT.FOR ***'
C               STOP 'See WARNING MESSAGES'
C            ENDIF
            PROD_PNTR_BY_CL_UNITS(
     +                PRODUCTION_DATA_POINTER(OPTIONS_COUNTER)) = SUNITS
!
! 03/17/04.
!
!            READ(13,REC=OPTIONS_COUNTER)
            READ(13,REC=PRODUCTION_DATA_POINTER(OPTIONS_COUNTER))
     +               DELETE,S_UNITNM(SUNITS),
     +               CL_LOAD_TYPE,
     +               EXPENSE_ASSIGNMENT,
     +               EXPENSE_COLLECTION,
     +               GENGRP,CAP_FRAC_OWN,
     +               ONLIMO,OFLIMO,
     +               S_FUELMX(SUNITS),
     +               S_PBTUCT(SUNITS),S_PFESCR(SUNITS),
     +               S_SBTUCT(SUNITS),
     +               S_SFESCR(SUNITS),
     +               S_FUELADJ_IN(SUNITS),
     +               S_EFOR(SUNITS),
     +               (S_MNRATE(SUNITS,M),M=1,12),
     +               S_VCPMWH_IN(SUNITS),S_OMESCR(SUNITS),
     +               S_FIXED_COST_IN(SUNITS),
     +               S_FIXED_COST_ESCALATOR(SUNITS),
     +               DISPADJ,S_HR_FACTOR(SUNITS),
     +               (S_INPUT_MW(M,SUNITS),M=1,2),
     +               S_CAP_PLANNING_FAC(SUNITS),
     +               (S_COEFF(M,SUNITS),M=1,3),
     +               CL_AI_CAPACITY_RATE,
     +               CL_AI_CAPACITY_ESCALATOR,
     +               CL_AI_ENERGY_RATE,
     +               CL_AI_ENERGY_ESCALATOR,
     +               P_SO2(SUNITS),
     +               P_NOX(SUNITS),
     +               P_PARTICULATES(SUNITS),
     +               CL_POOL_FRAC_OWN,
     +               P_EMIS_OTH2(SUNITS),
     +               P_EMIS_OTH3(SUNITS),
     +               DISPADJ2,
     +               CL_RESOURCE_ID,
     +               FUEL_SUPPLY_ID,
     +               P_NOX_BK2,
     +               SEC_FUEL_EMISS_PTR,
     +               EMISS_FUEL_COST,
     +               EMISS_FUEL_ESCAL,
     +               EMISS_FUEL_EMISS_PTR,
     +               EMISS_BLENDING_RATE,
     +               PRIM_FUEL_EMISS_PTR,
     +               TEMP_PRIM_FUEL_TYPE_STR,
!     +               PRIM_FUEL_TYPE, !CH*6
     +               SEC_FUEL_TYPE, !CH*10
     +               EMISS_FUEL_TYPE, !CH*10
     +               TIE_CONSTRAINT_GROUP, ! INT*2
     +               S_MONTHLY_CAPACITY_POINTER(SUNITS), ! INT*2
     +               S_ANNUAL_CL_FIXED_COST(SUNITS), ! REAL
     +               S_ANNUAL_CL_FIXED_COST_ESC(SUNITS), ! INT*2
     +               MAINT_DAYS, !REAL
     +                     DISPATCH_MULT,
     +                     EXCESS_ENERGY_SALES,
     +                     AI_CL_REMAINING_LIFE,
     +                     AI_CL_TAX_LIFE,
     +                     AI_CL_ADR_LIFE,
     +                     ASSET_CLASS_NUM,
     +                     ASSET_CLASS_VECTOR,
     +                     INTRA_COMPANY_CLASS_ID,
     +                     INTRA_COMPANY_TRANSACTION, !CH*3
     +                     SPECIAL_UNIT_ID,
     +                     MINIMUM_CAPACITY_FACTOR,
     +                     MAXIMUM_CAPACITY_FACTOR,
     +                     S_TRANSACTION_GROUP_ID(SUNITS),
     +                     DAY_TYPE_ID,
     +                     UNIT_ACTIVE,
     +                     BASECASE_PLANT_ID,
     +                     BASECASE_UNIT_ID,
     +                     BASECASE_MARKET_AREA_ID,
     +                     BASECASE_TRANS_AREA_ID,
     +                     BASECASE_PLANT_NERC_SUB_ID,
     +                     BASECASE_PLANT_OWNER_ID,
     +                     UTILITY_OWNED,  !CH*15
     +                     MONTHLY_FUEL_INDEX,
     +                     START_UP_COSTS(SUNITS),
     +                     START_UP_LOGIC,
     +                     RAMP_RATE,
     +                     MIN_DOWN_TIME(SUNITS),
     +                     REPORT_THIS_UNIT, ! CH*5
     +                     P_FUEL_DELIVERY(SUNITS),
     +                     P_FUEL_DELIVERY_2(SUNITS),
     +                     P_FUEL_DELIVERY_3(SUNITS),
     +                     MIN_UP_TIME(SUNITS),
     +                     HESI_UNIT_ID_NUM,
     +                     FOR_FREQUENCY,
     +                     FOR_DURATION,
     +                     WINTER_TOTAL_CAPACITY,
     +                     CONTRIBUTES_TO_SPIN, ! CH*5
     +                     H2_UNIT_ID_NUM,
     +                     POWERDAT_PLANT_ID,
     +                     TEMP_APPLY_NOX_SEASON_DATE, ! APPLY_NOX_SEASON_DATE(SUNITS),
     +                     NOX_SEASON_DATE(SUNITS),
     +                     RAMP_DOWN_RATE,
     +                     NOX_CONTROL_PERCENT(SUNITS),
     +                     NOX_CONTROL_DATE(SUNITS),
     +                     EMERGENCY_CAPACITY,
     +                     EMERGENCY_HEATRATE,
     +                     MARKET_RESOURCE, ! CH*6
     +                     PRIMARY_MOVER_STR(SUNITS),
     +                     COUNTY,
     +                     STATE_PROVINCE,
     +                     NOX_VOM(SUNITS),
     +                     NOX_FOM(SUNITS),
     +                     S_FUEL_DELIVERY(SUNITS),
     +                     S_FUEL_DELIVERY_2(SUNITS),
     +                     S_FUEL_DELIVERY_3(SUNITS),
     +                     CONSTANT_POLY,
     +                     FIRST_POLY,
     +                     SECOND_POLY,
     +                     THIRD_POLY,
     +                     USE_POLY_HEAT_RATES, ! CH*5
     +                     NEWGEN_UNIT_STATUS,
     +                     MONTHLY_MUST_RUN_VECTOR(SUNITS),
     +                     S_EMISSION_MARKET_LINK(SUNITS),
     +                     WVPA_RATE_TRACKER, ! CH*20
     +                     ALLOW_DECOMMIT, ! CH*5
     +                     MIN_SPIN_CAP,
     +                     MAX_SPIN_CAP,
     +                     WVPA_RES_TRACKER,  !CH*20
     +                     WVPA_FUEL_TRACKER, !CH*20
     +                     MONTE_OR_FREQ,     !CH*20
     +                     WVPA_MEM_TRACKER,  !CH*20
     +                     MONTHLY_DECOMMIT_VECTOR,
     +                     TRANS_BUS_ID,
     +                     SOX_CONTROL_PERCENT(SUNITS),
     +                     SOX_CONTROL_DATE(SUNITS),
     +                     SOX_VOM(SUNITS),
     +                     SOX_FOM(SUNITS),
     +                     LATITUDE,
     +                     LONGITUDE,
     +                     MW_INSIDE_FENCE,
     +                     S_INTER_BLOCKS(SUNITS,1),
     +                     S_INTER_BLOCKS(SUNITS,2),
     +                     S_INTER_BLOCKS(SUNITS,3),
     +                     FIRST_YEAR_DECOMM_AVAIALABLE,  ! 155
     +                     DECOMMISSIONING_BASE_YR_COST,
     +                     DECOM_CONTINUING_COST_ESCALATION,
     +                     ANNUAL_ENERGY_PLANNING_FACTOR,   ! 158
     +                     AGGREGATE_THIS_UNIT,   ! CH*5          ! 159
     +                     NAME_PLATE_CAPACITY,
     +                     FUEL_BLENDING_IS,   ! NO, FIXED BLEND, MODEL DETERMINED IF ONLY ONE FUEL ELSE USER OPTION
     +                     FuelRatio(1),
     +                     FuelRatio(2),
     +                     FuelRatio(3),         ! 164
     +                     FuelRatio(4),
     +                     FuelRatio(5),         ! 166
     +                     BlendableFuelsPtr(1), ! 167
     +                     BlendableFuelsPtr(2), ! 168
     +                     BlendableFuelsPtr(3),
     +                     BlendableFuelsPtr(4),
     +                     FuelTransportationCost(1),
     +                     FuelTransportationCost(2),  ! 172
     +                     FuelTransportationCost(3),
     +                     FuelTransportationCost(4),
     +                     BlendedEnthalpyUp,
     +                     BlendedEnthalpyLo,
     +                     BlendedSO2Up,                  ! 177
     +                     BettermentProjectID,
     +                     DECOM_CONTINUING_COST,
     +                     DECOM_CONTINUING_COST_ESCALATION,
     +                     EnrgPatternPointer, ! 181
     +                     EMISSION_DATA_UNITS, !CH*9
     +                     EmissRedRate(1),
     +                     EmissRedRate(2),
     +                     EmissRedRate(3),
     +                     EmissRedRate(4),              ! 186
     +                     EmissRedRate(5),
     +                     EmissMaxRate(1),
     +                     EmissMaxRate(2),
     +                     EmissMaxRate(3),
     +                     EmissMaxRate(4),
     +                     EmissMaxRate(5),
     +                     MaxEnergyLimit(1),
     +                     MaxEnergyLimit(2),
     +                     MaxEnergyLimit(3),
     +                     TECH_TYPE,
     +                     LINKED_BETTERMENT_OPTION, !CH*5
     +                     CO2_CONTROL_PERCENT(SUNITS),
     +                     HG_CONTROL_PERCENT(SUNITS),
     +                     OTHER3_CONTROL_PERCENT(SUNITS),
     +                     CO2_CONTROL_DATE(SUNITS),
     +                     HG_CONTROL_DATE(SUNITS),
     +                     OTHER3_CONTROL_DATE(SUNITS),
     +                     CO2_VOM(SUNITS),
     +                     CO2_FOM(SUNITS),
     +                     HG_VOM(SUNITS),
     +                     HG_FOM(SUNITS),
     +                     OTHER3_VOM(SUNITS),
     +                     OTHER3_FOM(SUNITS),  ! note there are missing variables that are not needed here. Dr.G 12/10/06
     +                     MARKET_FLOOR,
     +                     MARKET_CEILING,  ! 211
     +                     START_UP_COSTS_ESCALATION(SUNITS),  ! 212
     +                     CAPACITY_MARKET_TYPE,
     +                     CAPACITY_MARKET_MONTH,
     +                     CAPACITY_MARKET_POINTER,
     +                     CAPACITY_MARKET_COST_ASSIGN,
     +                     CAPACITY_MARKET_EXP_COLLECT,
     +                     CAPACITY_MARKET_COIN_ADJ_FACT,
     +                     PRIMARY_FUEL_CATEGORY,
     +                     SECONDARY_FUEL_CATEGORY, ! 220
     +                     EMISSIONS_FUEL_CATEGORY,
     +                     S_RPS_PERCENT(SUNITS),
     +                     RETIREMENT_CANDIDATE,
     +                     RETROFIT_CANDIDATE,
     +                     RETROFIT_PROJECT_ID,
     +                     CO2_BASIN_NAME,
     +                     CO2_PIPELINE_DISTANCE,
     +                     STATE_PROV_NAME, ! 228
     +                     CO2_RETRO_HEAT_MULT,
     +                     CO2_RETRO_CAP_MULT,
     +                     THERMAL_GUID,
     +                     THERMAL_PARENT_ID, ! 232
     +                     THERMAL_AGGREGATED_UNIT,
     +                     FIRST_RETIREMENT_YEAR,
     +                     UNIT_TYPE,
     +                     UNIT_TYPE_CATEGORY,
     +                     S_RPS_PROGRAM_NUMBER(SUNITS)
!!
! 5/8/02. Out because MRX addresses this.
!
!            IF(S_PBTUCT(SUNITS) < 0. .OR. S_SBTUCT(SUNITS) < 0.) THEN
!               WRITE(4,*) "Screening method is not active for"
!               WRITE(4,*) "units utilizing the fuel price file."
!               WRITE(4,*) "Unit =",S_UNITNM(SUNITS)
!               WRITE(4,*) " "
!            ENDIF
!
            CALL UPC(TEMP_PRIM_FUEL_TYPE_STR,PRIM_FUEL_TYPE_STR)
!
! 091309. COMPLETE REWRITE.
            TEMP_I2 = STATE_2_GAS_REGION_LOOKUP(STATE_PROVINCE)
            IF(YES_GSP_IS_ST_TG(TEMP_I2)) THEN
               TEMP_CHAR6 = STATE_PROVINCE
            ELSE
               TEMP_CHAR6 = STATE_PROVINCE(1:2)
            ENDIF
            S_UNIT_GAS_REGION_INDEX(SUNITS) =
     +                             STATE_2_GAS_REGION_LOOKUP(TEMP_CHAR6)
            TEMP_CHAR6 = State_Province(1:2)
            ST_TG = STATE_ID_LOOKUP(TEMP_CHAR6)
            State_Index(SUNITS) = ST_TG
!            TEMP_STATE = STATE_PROVINCE(1:2)
!            S_UNIT_GAS_REGION_INDEX(SUNITS) =
!     +                             STATE_2_GAS_REGION_LOOKUP(TEMP_STATE)
!     +                         STATE_2_GAS_REGION_LOOKUP(STATE_PROVINCE)
!            State_TG_Index(TRANS) = ST_TG
!            ST_TG = STATE_ID_LOOKUP(State_TG_Key)
!            State_TG_Index(TRANS) = ST_TG
!
            S_PRIMARY_MOVER(SUNITS) =
     +                        FUEL_TYPE_2_PRIM_MOVER(PRIM_FUEL_TYPE_STR)
!
! 10/03/02. FOR REGIONAL CONSOLIDATION. NOTE REASSIGNMENT.
!
            APPLY_NOX_SEASON_DATE(SUNITS) =
     +                                   TEMP_APPLY_NOX_SEASON_DATE(1:1)
            S_TRANSACTION_GROUP_ID(SUNITS) =
     +              GET_BELONGS_TO_GROUP(S_TRANSACTION_GROUP_ID(SUNITS))
!
            AHR(SUNITS) = (S_COEFF(1,SUNITS)*S_INPUT_MW(1,SUNITS) +
     +         (S_COEFF(2,SUNITS)+S_COEFF(3,SUNITS))*
     +         (S_INPUT_MW(2,SUNITS) - S_INPUT_MW(1,SUNITS))/2.)
     +         / S_INPUT_MW(2,SUNITS)
! 11/12/01.
            NOX_SEASON_DATE(SUNITS) = NOX_SEASON_DATE(SUNITS) + 10000
! 5/23/02.
            NOX_CONTROL_PERCENT(SUNITS) =
     +             MIN(100.,MAX(0.,1.-NOX_CONTROL_PERCENT(SUNITS)/100.))
            NOX_CONTROL_DATE(SUNITS) = NOX_CONTROL_DATE(SUNITS) + 10000
!
            SOX_CONTROL_PERCENT(SUNITS) =
     +             MIN(100.,MAX(0.,1.-SOX_CONTROL_PERCENT(SUNITS)/100.))
            SOX_CONTROL_DATE(SUNITS) = SOX_CONTROL_DATE(SUNITS) + 10000
!
            CO2_CONTROL_PERCENT(SUNITS) =
     +             MIN(100.,MAX(0.,1.-CO2_CONTROL_PERCENT(SUNITS)/100.))
            CO2_CONTROL_DATE(SUNITS) = CO2_CONTROL_DATE(SUNITS) + 10000
            HG_CONTROL_PERCENT(SUNITS) =
     +             MIN(100.,MAX(0.,1.-HG_CONTROL_PERCENT(SUNITS)/100.))
            HG_CONTROL_DATE(SUNITS) = HG_CONTROL_DATE(SUNITS) + 10000
            OTHER3_CONTROL_PERCENT(SUNITS) =
     +             MIN(100.,
     +                   MAX(0.,1.-OTHER3_CONTROL_PERCENT(SUNITS)/100.))
            OTHER3_CONTROL_DATE(SUNITS) =
     +                               OTHER3_CONTROL_DATE(SUNITS) + 10000
            LDTYPE(SUNITS) = CL_LOAD_TYPE(1:1)
!
         ENDDO
         READ_CL_SCREEN_DATA = .TRUE.
      RETURN
C***********************************************************************
      ENTRY GET_S_RPS_PROGRAM_NUMBER(PROD_POINTER)
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
         IF(L_S > 0) THEN
            GET_S_RPS_PROGRAM_NUMBER = S_RPS_PROGRAM_NUMBER(L_S)
         ELSE
            GET_S_RPS_PROGRAM_NUMBER = 0
         ENDIF
      RETURN
C***********************************************************************
      ENTRY GET_S_RPS_PERCENT(PROD_POINTER,R_YEAR)
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
         IF(S_RPS_PERCENT(L_S) < -0.0001) THEN
            GET_S_RPS_PERCENT =
     +            0.01*ESCALATED_MONTHLY_VALUE(GET_S_RPS_PERCENT,
     +                    ABS(INT2(S_RPS_PERCENT(L_S))),
     +                                           R_YEAR,INT2(1),INT2(1))
         ELSE
            GET_S_RPS_PERCENT = S_RPS_PERCENT(L_S)*0.01
         ENDIF
      RETURN
C***********************************************************************
      ENTRY GET_S_BLOCK_CAP_AND_HR(PROD_POINTER,
     +                             R_BLOCK_CAPACITY,
     +                             R_BLOCK_HEAT_RATE,
     +                             R_YEAR)
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
         R_BLOCK_CAPACITY = 0.
         R_BLOCK_HEAT_RATE = 0.
         IF(L_S > 0) THEN
            GET_S_BLOCK_CAP_AND_HR = .TRUE.
            IF(S_HR_FACTOR(L_S) < 0.) THEN
               HEAT_RATE_FACTOR =
     +              GET_VAR(S_HR_FACTOR(L_S),R_YEAR,S_UNITNM(L_S))
            ELSE
               HEAT_RATE_FACTOR = S_HR_FACTOR(L_S)
            ENDIF
!
            IF(S_INPUT_MW(2,L_S) - S_INPUT_MW(1,L_S) < 0.0001 .OR.
     +                                  S_INPUT_MW(1,L_S) < 0.0001) THEN
! ONE BLOCK SET TO R_BLOCK = 1
!               R_BLOCK_CAPACITY(1) = MAX(S_INPUT_MW(1,L_S),
!     +                                                S_INPUT_MW(2,L_S))
!               R_BLOCK_HEAT_RATE(1) = S_COEFF(1,L_S) * HEAT_RATE_FACTOR
!               R_BLOCK_CAPACITY(2) = 0.0
!               R_BLOCK_HEAT_RATE(2) = 0.0
! 081916. SWITCHED BLOCKS 1 AND 2 AROUND.
               R_BLOCK_CAPACITY(1) = 0.0
               R_BLOCK_HEAT_RATE(1) = 0.0
               R_BLOCK_CAPACITY(2) = MAX(S_INPUT_MW(1,L_S),
     +                                                S_INPUT_MW(2,L_S))
               R_BLOCK_HEAT_RATE(2) = S_COEFF(1,L_S) * HEAT_RATE_FACTOR
            ELSE
! TWO BLOCK
               IF(S_INPUT_MW(1,L_S) < 1.0) THEN
                  R_BLOCK_CAPACITY(1) = S_INPUT_MW(1,L_S) *
     +                                                 S_INPUT_MW(2,L_S)
               ELSE
                  R_BLOCK_CAPACITY(1) = S_INPUT_MW(1,L_S)
               ENDIF
               R_BLOCK_HEAT_RATE(1) = S_COEFF(1,L_S) * HEAT_RATE_FACTOR
               R_BLOCK_CAPACITY(2) = S_INPUT_MW(2,L_S)
               INC_CAP = S_INPUT_MW(2,L_S) - S_INPUT_MW(1,L_S)
               A_HR = (S_COEFF(3,L_S) - S_COEFF(2,L_S))/(2.*INC_CAP)
               B_HR = S_COEFF(3,L_S) - 2.* A_HR * INC_CAP
               R_BLOCK_HEAT_RATE(2) = (A_HR*INC_CAP + B_HR) *
     +                                                  HEAT_RATE_FACTOR
            ENDIF
!            IF(S_INTER_BLOCKS(L_S,1) < S_INPUT_MW(1,L_S) .OR.
!     +            S_INTER_BLOCKS(L_S,2) < S_INTER_BLOCKS(L_S,1) .OR.
!     +                   S_INPUT_MW(2,L_S) < S_INTER_BLOCKS(L_S,3)) THEN
! FIVE BLOCK
!               R_BLOCK_CAPACITY(1) = S_INPUT_MW(1,L_S)
!               R_BLOCK_CAPACITY(2) = S_INTER_BLOCKS(L_S,1)
!               R_BLOCK_CAPACITY(3) = S_INTER_BLOCKS(L_S,2)
!               R_BLOCK_CAPACITY(4) = S_INTER_BLOCKS(L_S,3)
!               R_BLOCK_CAPACITY(5) = S_INPUT_MW(2,L_S)
!
         ELSE
            GET_S_BLOCK_CAP_AND_HR = .FALSE.
         ENDIF
      RETURN
C***********************************************************************
      ENTRY GET_SCRN_UNIT_GAS_REGION_INDEX(PROD_POINTER)
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
         GET_SCRN_UNIT_GAS_REGION_INDEX =
     +                                 S_UNIT_GAS_REGION_INDEX(L_S)
      RETURN
C***********************************************************************
      ENTRY GET_SCREEN_STATE_INDEX(PROD_POINTER)
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
         GET_SCREEN_STATE_INDEX = State_Index(L_S)
      RETURN
C***********************************************************************
      ENTRY SCREEN_NOX_ACTIVE_FOR_UNIT(
!     +                          R_NUNITS,
     +                          PROD_POINTER,
     +                          R_DATE,
     +                          R_SEASON_IS_NOX_SEASON,
     +                          R_CALCULATE_NOX)
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
!
         SCREEN_NOX_ACTIVE_FOR_UNIT = .TRUE.
         IF(APPLY_NOX_SEASON_DATE(PROD_POINTER) == 'T') THEN
            IF(R_DATE >= NOX_SEASON_DATE(PROD_POINTER) .AND.
     +                                      R_SEASON_IS_NOX_SEASON) THEN
               R_CALCULATE_NOX = .TRUE.
            ELSE
               R_CALCULATE_NOX = .FALSE.
            ENDIF
         ENDIF
      RETURN
C***********************************************************************
      ENTRY GET_SCREEN_NOX_CONTROL_FOR_UNIT(
!     +                          R_NUNITS,
     +                          PROD_POINTER,
     +                          R_DATE,
     +                          R_NOX_CONTROL_PERCENT)
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
!
         GET_SCREEN_NOX_CONTROL_FOR_UNIT = .FALSE.
         R_NOX_CONTROL_PERCENT = 1.0
         IF(R_DATE >= NOX_CONTROL_DATE(L_S)) THEN
            GET_SCREEN_NOX_CONTROL_FOR_UNIT = .TRUE.
            R_NOX_CONTROL_PERCENT = NOX_CONTROL_PERCENT(L_S)
         ENDIF
      RETURN
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      ENTRY GET_SCREEN_CO2_CONTROL_FOR_UNIT(
!     +                          R_NUNITS,
     +                          PROD_POINTER,
     +                          R_DATE,
     +                          R_CO2_CONTROL_PERCENT)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
!
         GET_SCREEN_CO2_CONTROL_FOR_UNIT = .FALSE.
         R_CO2_CONTROL_PERCENT = 1.0
         IF(R_DATE >= CO2_CONTROL_DATE(L_S)) THEN
            GET_SCREEN_CO2_CONTROL_FOR_UNIT = .TRUE.
            R_CO2_CONTROL_PERCENT = CO2_CONTROL_PERCENT(L_S)
         ENDIF
      RETURN
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      ENTRY GET_SCREEN_HG_CONTROL_FOR_UNIT(
!     +                          R_NUNITS,
     +                          PROD_POINTER,
     +                          R_DATE,
     +                          R_HG_CONTROL_PERCENT)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
!
         GET_SCREEN_HG_CONTROL_FOR_UNIT = .FALSE.
         R_HG_CONTROL_PERCENT = 1.0
         IF(R_DATE >= HG_CONTROL_DATE(L_S)) THEN
            GET_SCREEN_HG_CONTROL_FOR_UNIT = .TRUE.
            R_HG_CONTROL_PERCENT = HG_CONTROL_PERCENT(L_S)
         ENDIF
      RETURN
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      ENTRY GET_SCREEN_OTHER3_CONTROL_FOR_UNIT(
!     +                          R_NUNITS,
     +                          PROD_POINTER,
     +                          R_DATE,
     +                          R_OTHER3_CONTROL_PERCENT)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
!
         GET_SCREEN_OTHER3_CONTROL_FOR_UNIT = .FALSE.
         R_OTHER3_CONTROL_PERCENT = 1.0
         IF(R_DATE >= OTHER3_CONTROL_DATE(L_S)) THEN
            GET_SCREEN_OTHER3_CONTROL_FOR_UNIT = .TRUE.
            R_OTHER3_CONTROL_PERCENT = OTHER3_CONTROL_PERCENT(L_S)
         ENDIF
      RETURN
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      ENTRY GET_SCREEN_SOX_CONTROL_FOR_UNIT(
!     +                          R_NUNITS,
     +                          PROD_POINTER,
     +                          R_DATE,
     +                          R_SOX_CONTROL_PERCENT)
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
!
         GET_SCREEN_SOX_CONTROL_FOR_UNIT = .FALSE.
         R_SOX_CONTROL_PERCENT = 1.0
         IF(R_DATE >= SOX_CONTROL_DATE(L_S)) THEN
            GET_SCREEN_SOX_CONTROL_FOR_UNIT = .TRUE.
            R_SOX_CONTROL_PERCENT = SOX_CONTROL_PERCENT(L_S)
         ENDIF
      RETURN
C***********************************************************************
      ENTRY GET_SCREEN_NOX_VOM(PROD_POINTER) ! R_NUNITS)  !R4
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
!
         GET_SCREEN_NOX_VOM = NOX_VOM(L_S)
      RETURN
C***********************************************************************
      ENTRY GET_SCREEN_NOX_FOM(PROD_POINTER) ! R_NUNITS)  !R4
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
!
         GET_SCREEN_NOX_FOM = NOX_FOM(L_S)
      RETURN
C***********************************************************************
      ENTRY GET_SCREEN_CO2_VOM(PROD_POINTER) ! R_NUNITS)  !R4
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
!
         GET_SCREEN_CO2_VOM = CO2_VOM(L_S)
      RETURN
C***********************************************************************
      ENTRY GET_SCREEN_CO2_FOM(PROD_POINTER) ! R_NUNITS)  !R4
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
!
         GET_SCREEN_CO2_FOM = CO2_FOM(L_S)
      RETURN
C***********************************************************************
      ENTRY GET_SCREEN_HG_VOM(PROD_POINTER) ! R_NUNITS)  !R4
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
!
         GET_SCREEN_HG_VOM = HG_VOM(L_S)
      RETURN
C***********************************************************************
      ENTRY GET_SCREEN_HG_FOM(PROD_POINTER) ! R_NUNITS)  !R4
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
!
         GET_SCREEN_HG_FOM = HG_FOM(L_S)
      RETURN
C***********************************************************************
      ENTRY GET_SCREEN_OTHER3_VOM(PROD_POINTER) ! R_NUNITS)  !R4
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
!
         GET_SCREEN_OTHER3_VOM = OTHER3_VOM(L_S)
      RETURN
C***********************************************************************
      ENTRY GET_SCREEN_OTHER3_FOM(PROD_POINTER) ! R_NUNITS)  !R4
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
!
         GET_SCREEN_OTHER3_FOM = OTHER3_FOM(L_S)
      RETURN
C***********************************************************************
      ENTRY GET_SCREEN_SOX_VOM(PROD_POINTER) ! R_NUNITS)  !R4
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
!
         GET_SCREEN_SOX_VOM = SOX_VOM(L_S)
      RETURN
C***********************************************************************
      ENTRY GET_SCREEN_SOX_FOM(PROD_POINTER) ! R_NUNITS)  !R4
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
!
         GET_SCREEN_SOX_FOM = SOX_FOM(L_S)
      RETURN
C***********************************************************************
      ENTRY GET_MRX_EMISSION_MARKET_LINK(PROD_POINTER)
C***********************************************************************
         GET_MRX_EMISSION_MARKET_LINK =
     +                              S_EMISSION_MARKET_LINK(PROD_POINTER)
      RETURN
C***********************************************************************
C***********************************************************************
      ENTRY S_YES_MONTHLY_MUST_RUN(PROD_POINTER,R_MONTH)
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
         S_YES_MONTHLY_MUST_RUN = .FALSE.
         IF(LDTYPE(L_S) == 'N' .OR.
     +                                LDTYPE(L_S) == 'M') THEN
            S_YES_MONTHLY_MUST_RUN = .TRUE.
         ELSEIF(MONTHLY_MUST_RUN_VECTOR(L_S) /= 0) THEN
            TEMP_R4 = GET_VAR(
     +             FLOAT(MONTHLY_MUST_RUN_VECTOR(L_S)),R_MONTH,
     +                                           S_UNITNM(L_S))
            IF(TEMP_R4 > 0.) THEN
               S_YES_MONTHLY_MUST_RUN = .TRUE.
            ENDIF
         ENDIF
      RETURN
C***********************************************************************
      ENTRY GET_S_CAP_PLANNING_FAC(PROD_POINTER,R_YEAR)
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
         IF(S_CAP_PLANNING_FAC(L_S) < 0.) THEN
            GET_S_CAP_PLANNING_FAC =
     +                  GET_VAR(S_CAP_PLANNING_FAC(L_S),
     +                                        R_YEAR,
     +                                           S_UNITNM(L_S))
         ELSE
            GET_S_CAP_PLANNING_FAC = S_CAP_PLANNING_FAC(L_S)
         ENDIF
      RETURN
C***********************************************************************
      ENTRY GET_S_START_UP_COSTS(R_YEAR,PROD_POINTER,R_MONTH)
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
         IF(START_UP_COSTS(L_S) < 0.) THEN
            GET_S_START_UP_COSTS =
     +                 START_UP_COST_ESCALATED_MONTHLY_VALUE(
     +                          INT2(ABS(START_UP_COSTS(L_S))),
     +                          R_YEAR)
         ELSE
!
            IF(START_UP_COSTS_ESCALATION(L_S) < 0.) THEN
               GET_S_START_UP_COSTS = 1.
               VECTOR_IS_VALUE = .FALSE.
               DO YR = R_YEAR ,1,-1
                 TEMP_I2 = INT2(START_UP_COSTS_ESCALATION(L_S))
                  ESCAL_RATE = RETURN_VALUE_FROM_ESCALATION_VECTOR(
     +                               YR,TEMP_I2,VECTOR_IS_VALUE,R_MONTH)
                  IF(VECTOR_IS_VALUE) THEN
                     GET_S_START_UP_COSTS =
     +                  GET_S_START_UP_COSTS * ESCAL_RATE
                     EXIT
                  ELSE
                     GET_S_START_UP_COSTS = GET_S_START_UP_COSTS *
     +                                           (1.0 + ESCAL_RATE/100.)
                  ENDIF
               ENDDO ! YR
               IF(.NOT. VECTOR_IS_VALUE) THEN
                  GET_S_START_UP_COSTS = GET_S_START_UP_COSTS *
     +                                      START_UP_COSTS(L_S)
               ENDIF
            ELSEIF(START_UP_COSTS_ESCALATION(L_S) > 0.) THEN
               ESCAL_RATE =  START_UP_COSTS_ESCALATION(L_S)/100.
               GET_S_START_UP_COSTS = START_UP_COSTS(L_S)
               DO YR = 1, R_YEAR
                  GET_S_START_UP_COSTS = GET_S_START_UP_COSTS *
     +                                                (1.0 + ESCAL_RATE)
               ENDDO
            ELSE
               GET_S_START_UP_COSTS = START_UP_COSTS(L_S)
            ENDIF
         ENDIF
      RETURN
C***********************************************************************
      ENTRY GET_S_MIN_DOWN_TIME(PROD_POINTER)
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
         GET_S_MIN_DOWN_TIME = MIN_DOWN_TIME(L_S)
      RETURN
C***********************************************************************
      ENTRY GET_S_MIN_UP_TIME(PROD_POINTER)
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
         GET_S_MIN_UP_TIME = MIN_UP_TIME(L_S)
      RETURN
C***********************************************************************
      ENTRY GET_NEW_UNIT_FUEL_DELIVERY(
     +                          PROD_POINTER,
     +                          R_FUEL_DELIVERY_1,
     +                          R_FUEL_DELIVERY_2,
     +                          R_FUEL_DELIVERY_3)
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
         R_FUEL_DELIVERY_1 = P_FUEL_DELIVERY(L_S)
         R_FUEL_DELIVERY_2 = P_FUEL_DELIVERY_2(L_S)
         R_FUEL_DELIVERY_3 = P_FUEL_DELIVERY_3(L_S)
         GET_NEW_UNIT_FUEL_DELIVERY = S_PBTUCT(L_S)
      RETURN
C***********************************************************************
      ENTRY RETURN_S_TRANS_GROUP_ID(PROD_POINTER)
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
         RETURN_S_TRANS_GROUP_ID = S_TRANSACTION_GROUP_ID(L_S)
      RETURN
C***********************************************************************
      ENTRY UPDATE_CL_SCREEN_COSTS(R_YEAR)
C***********************************************************************
C
         DO S = 1, SUNITS
            S_FIXED_COST_IN(S) = ESCALATED_VALUE(S_FIXED_COST_IN(S),
     +                                        S_FIXED_COST_ESCALATOR(S))
            S_ANNUAL_CL_FIXED_COST(S) =
     +                   ESCALATED_VALUE(S_ANNUAL_CL_FIXED_COST(S),
     +                                    S_ANNUAL_CL_FIXED_COST_ESC(S))
C
            S_PBTUCT(S) = ESCALATED_VALUE(S_PBTUCT(S),S_PFESCR(S))
            S_SBTUCT(S) = ESCALATED_VALUE(S_SBTUCT(S),S_SFESCR(S))
C
            S_VCPMWH_IN(S) = ESCALATED_VALUE(S_VCPMWH_IN(S),S_OMESCR(S))
            RTEMP = S_FUELADJ_IN(S)
            IF(RTEMP < 0.0) THEN
               RTEMP = GET_VAR(RTEMP,R_YEAR,S_UNITNM(S))
               IF(RTEMP < 0.) THEN
                  S_FUELADJ(S) = GET_VAR(RTEMP,ISEAS,S_UNITNM(S))
               ELSE
                  S_FUELADJ(S) = RTEMP
               ENDIF
            ELSE
               S_FUELADJ(S) = RTEMP
            ENDIF
!            S_FUELADJ(S) = ESCALATED_VALUE(S_FUELADJ(S),S_PFESCR(S))
!            VOID_INT2 = ESCALATE_FUEL_ADDER_VALUES(SAVE_YEAR,
!     +                                     FUELADJ,PFESCR,NUNITS,UNITNM)
         ENDDO
C
         UPDATE_CL_SCREEN_COSTS = SUNITS
      RETURN
C***********************************************************************
      ENTRY RETURN_CL_SCREEN_FIXED_COST(PROD_POINTER)
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
         RETURN_CL_SCREEN_FIXED_COST =
     +       S_FIXED_COST_IN(L_S) * (S_INPUT_MW(2,L_S)*1000.) +
     +       S_ANNUAL_CL_FIXED_COST(L_S) * 1000000.
      RETURN
C***********************************************************************
      ENTRY PUT_MRX_DELIVERY_COST(R_DELIVERY_COST)
C***********************************************************************
         SAVE_DELIVERY_COST = R_DELIVERY_COST
         PUT_MRX_DELIVERY_COST = R_DELIVERY_COST
      RETURN
C***********************************************************************
      ENTRY RETURN_CL_SCREEN_EFOR(PROD_POINTER,R_YEAR,R_MONTHLY)
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
!
         IF(S_EFOR(L_S) < 0.) THEN
            RETURN_CL_SCREEN_EFOR =
     +              GET_VAR(S_EFOR(L_S),R_YEAR,S_UNITNM(L_S))/100.
         ELSE
            RETURN_CL_SCREEN_EFOR = S_EFOR(L_S)/100.
         ENDIF
!
! 091210. MONTH.
!
         TEMP_R4 = 0.0
         R_MONTHLY = 0.0
         DO I = 1, 12
            IF(S_MONTHLY_CAPACITY_POINTER(L_S) < 0) THEN
               TEMP_MO_VAL = GET_VAR(FLOAT(
     +                                 S_MONTHLY_CAPACITY_POINTER(L_S)),
     +                                                  I,S_UNITNM(L_S))
            ELSE
               TEMP_MO_VAL = 1.0
            ENDIF
!            TEMP_R4 = TEMP_R4 + TEMP_MO_VAL *
!     +                            (1.0 - MIN(100.,S_MNRATE(L_S,I))/100.)
            TEMP_MO_VAL = TEMP_MO_VAL *
     +                            (1.0 - MIN(100.,S_MNRATE(L_S,I))/100.)
            R_MONTHLY(I) = TEMP_MO_VAL
            TEMP_R4 = TEMP_R4 + TEMP_MO_VAL
         ENDDO
         RETURN_CL_SCREEN_EFOR = 1.0 - (1.0 - RETURN_CL_SCREEN_EFOR) *
     +                                                      TEMP_R4/12.0
         RETURN_CL_SCREEN_EFOR =
     +                        MAX(0.0,MIN(RETURN_CL_SCREEN_EFOR,0.9999))
!
      RETURN
C***********************************************************************
      ENTRY GET_S_PRIMARY_MOVER_INDEX(PROD_POINTER)
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
         GET_S_PRIMARY_MOVER_INDEX =
     +                    PRIMARY_MOVER_INDEX_DB(PRIMARY_MOVER_STR(L_S))
         IF(GET_S_PRIMARY_MOVER_INDEX == 10 .AND.
     +                                   S_PRIMARY_MOVER(L_S) > 3 ) THEN
            GET_S_PRIMARY_MOVER_INDEX = 7
         ENDIF
      RETURN
C***********************************************************************
      ENTRY GET_S_PRIMARY_MOVER(PROD_POINTER)
C***********************************************************************
         IF(PROD_POINTER > PROD_PNTR) THEN
            WRITE(4,*)
     +             'MRX POINTER OUT OF RANGE WHEN FINDING PRIMARY MOVER'
         ENDIF
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
         IF(L_S < 1) THEN
            WRITE(4,*)
     +            'MRX POINTER OUT OF RANGE WHEN FINDING PRIMARY MOVER.'
            WRITE(4,*)
     +            'MAY BE DUE TO HARD-WIRED UNIT. 111413.'
         ENDIF
         GET_S_PRIMARY_MOVER = S_PRIMARY_MOVER(L_S)
      RETURN
C***********************************************************************
      ENTRY RETURN_CL_SCREEN_VARI_COST(PROD_POINTER,R_YEAR,R_MO)
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
C
         IF(S_HR_FACTOR(L_S) < 0.) THEN
            HEAT_RATE_FACTOR =
     +              GET_VAR(S_HR_FACTOR(L_S),R_YEAR,S_UNITNM(L_S))
         ELSE
            HEAT_RATE_FACTOR = S_HR_FACTOR(L_S)
         ENDIF
         IF(S_FUELMX(L_S) <= -2.) THEN
            FUEL_MIX_FACTOR =
     +                 GET_VAR(S_FUELMX(L_S),R_YEAR,S_UNITNM(L_S))
         ELSE
            FUEL_MIX_FACTOR = S_FUELMX(L_S)
         ENDIF
!
         FT = GET_PRIMARY_MOVER(L_S)
!
         IF(FT > 3 .OR. FT < 1) FT = 1
         MO = R_MO
!
         FUEL_SCEN_MULT = 1.0
         IF(FT == 1) THEN
            FUEL_SCEN_MULT = GET_SCENARIO_COAL_PRICES(R_YEAR,MO)
         ELSEIF(FT == 2) THEN
            FUEL_SCEN_MULT =  GET_SCENARIO_GAS_PRICES(R_YEAR,MO)
         ELSEIF(FT == 3) THEN
            FUEL_SCEN_MULT =  GET_SCENARIO_OIL_PRICES(R_YEAR,MO)
         ELSEIF(FT == 4) THEN
            FUEL_SCEN_MULT =  GET_SCENARIO_URANIUM_PRICES(R_YEAR,MO)
         ENDIF
!
         IF(SAVE_DELIVERY_COST == -999999.) THEN
            FUEL_COMPONENT = .001 * AHR(L_S) * HEAT_RATE_FACTOR *
     +         (ABS(FUEL_MIX_FACTOR) * S_PBTUCT(L_S) +
     +                      ABS(1.-FUEL_MIX_FACTOR) * S_SBTUCT(L_S))
         ELSE
            FUEL_COMPONENT = .001 * AHR(L_S) * HEAT_RATE_FACTOR *
     +                                                SAVE_DELIVERY_COST
         ENDIF
         OTHER_VARIABLE_COMPONENT =
     +                           S_VCPMWH_IN(L_S) + S_FUELADJ(L_S)
C
         RETURN_CL_SCREEN_VARI_COST =
     +                8.76*( FUEL_COMPONENT + OTHER_VARIABLE_COMPONENT )
C
      RETURN
C***********************************************************************
      ENTRY RETURN_OTHER_VAR_COMPONENT(PROD_POINTER)
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
         RETURN_OTHER_VAR_COMPONENT =
     +                           S_VCPMWH_IN(L_S) + S_FUELADJ(L_S)
      RETURN
C***********************************************************************
      ENTRY RETURN_CL_SCREEN_EMIS_COST(PROD_POINTER,R_YEAR,R_MO,
     +                                 R_NOX_MULT,R_SOX_MULT,
     +                                 R_CO2_MULT,R_HG_MULT,
     +                                 R_OTHER3_MULT,
     +                                 R_CO2_RETIREMENT_PRICE)
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)                      ! TMS 03/28/05 added to get proper unit reference
         I = S_EMISSION_MARKET_LINK(L_S)
C
         EMIS_DISPATCH_1 =
     +                    TRANS_MRX_DISPATCH_EMIS_ADDER(1,R_MO,R_YEAR,I)
         EMIS_DISPATCH_2 =
     +                    TRANS_MRX_DISPATCH_EMIS_ADDER(2,R_MO,R_YEAR,I)
         IF(R_CO2_RETIREMENT_PRICE > -999.0) THEN
            EMIS_DISPATCH_3 = R_CO2_RETIREMENT_PRICE *
     +                  GET_SCENARIO_CO2_PRICES(R_YEAR,R_MO)/2000.0
         ELSE ! INCLUDES CO2 SCENARIO MULT
            EMIS_DISPATCH_3 =
     +                    TRANS_MRX_DISPATCH_EMIS_ADDER(3,R_MO,R_YEAR,I)
         ENDIF
         EMIS_DISPATCH_4 =
     +                    TRANS_MRX_DISPATCH_EMIS_ADDER(4,R_MO,R_YEAR,I)
         EMIS_DISPATCH_5 =
     +                    TRANS_MRX_DISPATCH_EMIS_ADDER(5,R_MO,R_YEAR,I)
!
         TEMP_R4 =
     +            EMIS_DISPATCH_1 * MAX(P_SO2(L_S)*R_SOX_MULT,0.) +
     +            EMIS_DISPATCH_2 * MAX(P_NOX(L_S)*R_NOX_MULT,0.) +
     +            EMIS_DISPATCH_3 * MAX(P_PARTICULATES(L_S)*
     +                                             R_CO2_MULT,0.) +
     +            EMIS_DISPATCH_4 * MAX(P_EMIS_OTH2(L_S)*
     +                                              R_HG_MULT,0.) +
     +            EMIS_DISPATCH_5 * MAX(P_EMIS_OTH3(L_S)*
     +                                              R_OTHER3_MULT,0.)
        IF(S_HR_FACTOR(L_S) < 0.) THEN
            HEAT_RATE_FACTOR =
     +              GET_VAR(S_HR_FACTOR(L_S),R_YEAR,S_UNITNM(L_S))
         ELSE
            HEAT_RATE_FACTOR = S_HR_FACTOR(L_S)
         ENDIF
!         IF(S_FUELMX(L_S) <= -2.) THEN
!            FUEL_MIX_FACTOR =
!     +                 GET_VAR(S_FUELMX(L_S),R_YEAR,S_UNITNM(L_S))
!         ELSE
!            FUEL_MIX_FACTOR = S_FUELMX(L_S)
!         ENDIF
!         IF(SAVE_DELIVERY_COST == -999999.) THEN
!
         RETURN_CL_SCREEN_EMIS_COST =
     +                     .001 * AHR(L_S) * HEAT_RATE_FACTOR *
     +                                                           TEMP_R4
!
!     +         (ABS(FUEL_MIX_FACTOR) * S_PBTUCT(L_S) +
!     +                       ABS(1.-FUEL_MIX_FACTOR) * S_SBTUCT(L_S))
!         ELSE
!            FUEL_COMPONENT = .001 * AHR(L_S) * HEAT_RATE_FACTOR *
!     +                                                SAVE_DELIVERY_COST
!         ENDIF
C
!         RETURN_CL_SCREEN_EMIS_COST =  8.76* FUEL_COMPONENT
C
       RETURN
C***********************************************************************
      ENTRY GET_CL_CO2_TON_PER_MWH(
     +                          R_YEAR,
     +                          PROD_POINTER,
     +                          R_DATE)
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
         IF(S_HR_FACTOR(L_S) < 0.) THEN
            HEAT_RATE_FACTOR =
     +              GET_VAR(S_HR_FACTOR(L_S),R_YEAR,S_UNITNM(L_S))
         ELSE
            HEAT_RATE_FACTOR = S_HR_FACTOR(L_S)
         ENDIF
         IF(R_DATE >= CO2_CONTROL_DATE(L_S)) THEN
            GET_CL_CO2_TON_PER_MWH =
     +         MAX(P_PARTICULATES(L_S)*CO2_CONTROL_PERCENT(L_S),0.)
         ELSE
            GET_CL_CO2_TON_PER_MWH = MAX(P_PARTICULATES(L_S),0.)
         ENDIF
            GET_CL_CO2_TON_PER_MWH = GET_CL_CO2_TON_PER_MWH *
     +                                    HEAT_RATE_FACTOR *
     +                                       0.0000005 * AHR(L_S)
      RETURN
C***********************************************************************
      ENTRY RETURN_CL_SCREEN_FUEL_COST(PROD_POINTER,
     +                                 R_YEAR,
     +                                 R_HEAT_RATE,
     +                                 R_FUEL_COST)
C***********************************************************************
         L_S = PROD_PNTR_BY_CL_UNITS(PROD_POINTER)
C
         IF(S_HR_FACTOR(L_S) < 0.) THEN
            HEAT_RATE_FACTOR =
     +              GET_VAR(S_HR_FACTOR(L_S),R_YEAR,S_UNITNM(L_S))
         ELSE
            HEAT_RATE_FACTOR = S_HR_FACTOR(L_S)
         ENDIF
         IF(S_FUELMX(L_S) <= -2.) THEN
            FUEL_MIX_FACTOR =
     +                 GET_VAR(S_FUELMX(L_S),R_YEAR,S_UNITNM(L_S))
         ELSE
            FUEL_MIX_FACTOR = S_FUELMX(L_S)
         ENDIF
         R_HEAT_RATE = AHR(L_S) * HEAT_RATE_FACTOR
         IF(SAVE_DELIVERY_COST == -999999.) THEN
            R_FUEL_COST =
     +         (ABS(FUEL_MIX_FACTOR) * S_PBTUCT(L_S) +
     +                       ABS(1.-FUEL_MIX_FACTOR) * S_SBTUCT(L_S))
         ELSE
            R_FUEL_COST = SAVE_DELIVERY_COST
         ENDIF
         FUEL_COMPONENT = R_FUEL_COST * R_HEAT_RATE * .001
C
         RETURN_CL_SCREEN_FUEL_COST = FUEL_COMPONENT
!         RETURN_CL_SCREEN_FUEL_COST = 8.76* FUEL_COMPONENT
C
      RETURN
      END
C***********************************************************************
!      FUNCTION SCREEN_CAP_COST()
C***********************************************************************
C LOCAL VARIABLES
!      INTEGER*2   FUNITS,R_POINTER,SCREEN_CAP_COST,
!     +            R_YEAR,S,UPDATE_SCREEN_CAP_COSTS,I
!      LOGICAL*1   INIT_SCREEN_CAP_COST
!      REAL        RETURN_SCREEN_CAP_COST,ESCALATED_VALUE,
!     +            RETURN_RISK_ADJ_S_CAP_COST
C INIT VARIABLES
!      CHARACTER*2 RESOURCE_TYPE(*),S_RESOURCE_TYPE(:)
!      INTEGER*2   INVESTMENT_DATA_POINTER(*),
!     +            PRODUCTION_DATA_POINTER(*),
!     +            OPERATION_LIFE(*),LEAD_TIME(*),
!     +            R_CAP_COST_ESC(*),R_TOTAL_ALL_OPTIONS,
!     +            S_TOTAL_ALL_OPTIONS/0/
!      REAL CONSTRUCTION_COSTS(*),R_CCR_FOR_SCREENING(*),UNIT_CAP(*),
!     +         R_MRX_RISK_ADJUSTMENT(*)
C ANNUAL VARIABLES
!      INTEGER*2 S_CAP_COST_ESC(:),S_OP_LIFE(:),
!     +          RETURN_SCREEN_OP_LIFE
!      REAL  R_SCREN_CAP_COST,S_CCR(:),S_CAP_COST(:),
!     +      S_MRX_RISK_ADJUSTMENT(:)
C
!      ALLOCATABLE :: S_CAP_COST,S_CCR,S_CAP_COST_ESC,
!     +               S_OP_LIFE,
!     +               S_RESOURCE_TYPE,
!     +               S_MRX_RISK_ADJUSTMENT
C
!      SAVE S_CCR,S_CAP_COST,S_CAP_COST_ESC,S_RESOURCE_TYPE,
!     +         S_MRX_RISK_ADJUSTMENT,S_OP_LIFE
! END OF DATA DECLARATIONS
!      SCREEN_CAP_COST = 1
C
C***********************************************************************
!      ENTRY INIT_SCREEN_CAP_COST(UNIT_CAP,
!     +                        INVESTMENT_DATA_POINTER,
!     +                        PRODUCTION_DATA_POINTER,
!     +                        OPERATION_LIFE,
!     +                        LEAD_TIME,
!     +                        R_CAP_COST_ESC,
!     +                        CONSTRUCTION_COSTS,
!     +                        RESOURCE_TYPE,
!     +                        R_TOTAL_ALL_OPTIONS,
!     +                        R_CCR_FOR_SCREENING,
!     +                        R_MRX_RISK_ADJUSTMENT)
C***********************************************************************
!         IF(R_TOTAL_ALL_OPTIONS <= 0) RETURN
!         S_TOTAL_ALL_OPTIONS = R_TOTAL_ALL_OPTIONS
!         IF(ALLOCATED(S_CCR))
!     +         DEALLOCATE(
!     +            S_CCR,
!     +            S_OP_LIFE,
!     +            S_MRX_RISK_ADJUSTMENT,
!     +            S_CAP_COST,
!     +            S_CAP_COST_ESC,
!     +            S_RESOURCE_TYPE)
!         ALLOCATE(S_CCR(S_TOTAL_ALL_OPTIONS))
!         ALLOCATE(S_OP_LIFE(S_TOTAL_ALL_OPTIONS))
!         ALLOCATE(S_MRX_RISK_ADJUSTMENT(S_TOTAL_ALL_OPTIONS))
!         ALLOCATE(S_CAP_COST(S_TOTAL_ALL_OPTIONS))
!         ALLOCATE(S_CAP_COST_ESC(S_TOTAL_ALL_OPTIONS))
!         ALLOCATE(S_RESOURCE_TYPE(S_TOTAL_ALL_OPTIONS))
!         S_CCR = 0.
!         S_OP_LIFE = 99
!         S_MRX_RISK_ADJUSTMENT = 0.
!         S_CAP_COST = 0.
!         S_CAP_COST_ESC = 0.
!         DO FUNITS = 1, S_TOTAL_ALL_OPTIONS
!!            FUNITS = PRODUCTION_DATA_POINTER(I)
!C
!!            IF(INVESTMENT_DATA_POINTER(FUNITS) < 0) CYCLE
!C
!            S_CAP_COST(FUNITS) = CONSTRUCTION_COSTS(FUNITS)
!            S_CAP_COST_ESC(FUNITS) = R_CAP_COST_ESC(FUNITS)
!            S_CCR(FUNITS) = R_CCR_FOR_SCREENING(FUNITS)
!            S_OP_LIFE(FUNITS) = OPERATION_LIFE(FUNITS)
!            S_MRX_RISK_ADJUSTMENT(FUNITS) =
!     +                              R_MRX_RISK_ADJUSTMENT(FUNITS)
!            S_RESOURCE_TYPE(FUNITS) = RESOURCE_TYPE(FUNITS)
!         ENDDO
!         INIT_SCREEN_CAP_COST = .TRUE.
!      RETURN
C***********************************************************************
!      ENTRY RETURN_SCREEN_CAP_COST(R_POINTER,R_YEAR)
C***********************************************************************
!         IF(ALLOCATED(S_CCR)) THEN
!            RETURN_SCREEN_CAP_COST = S_CCR(R_POINTER) *
!     +                                             S_CAP_COST(R_POINTER)
!         ELSE
!            RETURN_SCREEN_CAP_COST = 0.0
!         ENDIF
!      RETURN
C***********************************************************************
!      ENTRY RETURN_SCREEN_OP_LIFE(R_POINTER,R_YEAR)
C***********************************************************************
!         IF(ALLOCATED(S_OP_LIFE)) THEN
!            IF(R_POINTER < 1 .OR. R_POINTER > S_TOTAL_ALL_OPTIONS) THEN
!               WRITE(4,*) 'In GRX, when accessing op life, index out of'
!               WRITE(4,*) 'range. Pointer = ',R_POINTER,R_YEAR
!            ENDIF
!            RETURN_SCREEN_OP_LIFE = S_OP_LIFE(R_POINTER)
!         ELSE
!            RETURN_SCREEN_OP_LIFE = 0.0
!         ENDIF
!      RETURN
C***********************************************************************
!      ENTRY RETURN_RISK_ADJ_S_CAP_COST(R_POINTER,R_YEAR)
C***********************************************************************
!         RETURN_RISK_ADJ_S_CAP_COST =
!     +            (S_CCR(R_POINTER)+S_MRX_RISK_ADJUSTMENT(R_POINTER)) *
!     +                                             S_CAP_COST(R_POINTER)
!      RETURN
C***********************************************************************
!      ENTRY UPDATE_SCREEN_CAP_COSTS(R_YEAR)
C***********************************************************************
!         DO S = 1 , S_TOTAL_ALL_OPTIONS
!            IF( .NOT. (S_RESOURCE_TYPE(S) == 'CL' .OR.
!     +                                  RESOURCE_TYPE(S) == 'EL')) CYCLE
C
!            S_CAP_COST(S) = ESCALATED_VALUE(S_CAP_COST(S),
!     +                                                S_CAP_COST_ESC(S))
!         ENDDO
!         UPDATE_SCREEN_CAP_COSTS = S_TOTAL_ALL_OPTIONS
!      RETURN
!      END
C***********************************************************************
      FUNCTION CAP_MARKET_MONTH_NO_INDEX(R_UNIT_STR)
C***********************************************************************
      INTEGER*2 CAP_MARKET_MONTH_NO_INDEX
      CHARACTER*5 R_UNIT_STR
! END DATA DECLARATIONS
         CAP_MARKET_MONTH_NO_INDEX = 1
         SELECT CASE(trim(R_UNIT_STR))
            CASE ('JAN')
               CAP_MARKET_MONTH_NO_INDEX = 1
            CASE ('FEB')
               CAP_MARKET_MONTH_NO_INDEX = 2
            CASE ('MAR')
               CAP_MARKET_MONTH_NO_INDEX = 3
            CASE ('APR')
               CAP_MARKET_MONTH_NO_INDEX = 4
            CASE ('MAY')
               CAP_MARKET_MONTH_NO_INDEX = 5
            CASE ('JUN')
               CAP_MARKET_MONTH_NO_INDEX = 6
            CASE ('JUL')
               CAP_MARKET_MONTH_NO_INDEX = 7
            CASE ('AUG')
               CAP_MARKET_MONTH_NO_INDEX = 8
            CASE ('SEP')
               CAP_MARKET_MONTH_NO_INDEX = 9
            CASE ('OCT')
               CAP_MARKET_MONTH_NO_INDEX = 10
            CASE ('NOT')
               CAP_MARKET_MONTH_NO_INDEX = 11
            CASE ('DEC')
               CAP_MARKET_MONTH_NO_INDEX = 12
            CASE ('MONTH')
               CAP_MARKET_MONTH_NO_INDEX = 13
         END SELECT
      RETURN
      END
C***********************************************************************
!
      FUNCTION PRIMARY_MOVER_INDEX_DB(R_UNIT_STR)
!
C***********************************************************************
      INTEGER*2 PRIMARY_MOVER_INDEX_DB
      CHARACTER*6 R_UNIT_STR
! END DATA DECLARATIONS
         PRIMARY_MOVER_INDEX_DB = 13
         SELECT CASE(trim(R_UNIT_STR))
            CASE ('CC')
               PRIMARY_MOVER_INDEX_DB = 1
            CASE ('FC')
               PRIMARY_MOVER_INDEX_DB = 2
            CASE ('GE')
               PRIMARY_MOVER_INDEX_DB = 3
            CASE ('GT')
               PRIMARY_MOVER_INDEX_DB = 4
            CASE ('HY')
               PRIMARY_MOVER_INDEX_DB = 5
            CASE ('IC')
               PRIMARY_MOVER_INDEX_DB = 6
            CASE ('NA')
               PRIMARY_MOVER_INDEX_DB = 7
            CASE ('NU')
               PRIMARY_MOVER_INDEX_DB = 8
            CASE ('SL')
               PRIMARY_MOVER_INDEX_DB = 9
            CASE ('ST')
               PRIMARY_MOVER_INDEX_DB = 10
            CASE ('WT')
               PRIMARY_MOVER_INDEX_DB = 11
            CASE ('ZZ')
               PRIMARY_MOVER_INDEX_DB = 12
            CASE ('BI')
               PRIMARY_MOVER_INDEX_DB = 14
            CASE ('LF')
               PRIMARY_MOVER_INDEX_DB = 15
            CASE ('BA')
               PRIMARY_MOVER_INDEX_DB = 16
            CASE ('DG')
               PRIMARY_MOVER_INDEX_DB = 17
            CASE ('OW')
               PRIMARY_MOVER_INDEX_DB = 18
            CASE ('HB')
               PRIMARY_MOVER_INDEX_DB = 19
            CASE (' ')
               PRIMARY_MOVER_INDEX_DB = 13
         END SELECT
      RETURN
      END
C***********************************************************************
c-----
      subroutine CheckO3P(c_0,C_1,C_2,C_3,x0,x1)
! Greg:  feel free to rename this as desired
!     determines whether cubic curve y=c0+c1*x+c2*x^2+c3*x^3 is monotonically
!     increasing (i.e., has positive 2nd derivative at the left endpoint x0);
!     if not, it linearizes the curve between the endpoints x0,x1.  The
!     curve's 1st derivative is s(x)=c1+2*c2*x+3*c3*x^2; the
!     curve's 2nd derivative is t(x)=2*c2+6*c3*x.  Note that for the curves
!     of interest here (heat input as y versus MW load output as x), we check
!     for the concave-upward property only at the left (minimal-load) point.
!     Attempts at simplifying the curve by merely zeroing c3, or by assigning
!     c3 to the value at which t0==0, both failed to approximate the curve.
!     notes by AGT on 20030728
      real*4 x0,x1,y0,y1,s0,s1,t0,C_0,C_1,C_2,C_3
      logical*1 MonotoneIncr
!
      s0=c_1+x0*(2.0*c_2+x0*3.0*c_3)
      s1=c_1+x1*(2.0*c_2+x1*3.0*c_3)
      t0=2.0*c_2+6.0*c_3*x0
      MonotoneIncr=(s0>0.0).and.(s1>0.0).and.(t0>0.0)
      if(.not.MonotoneIncr .and. x1 > x0) then ! linearize y(x) on the domain [x0,x1]
        y0=c_0+x0*(c_1+x0*(c_2+x0*c_3))
        y1=c_0+x1*(c_1+x1*(c_2+x1*c_3))
        c_1=(y1-y0)/(x1-x0)
        c_0= y1-c_1*x1
        c_2=0.0
        c_3=0.0
      end if
      RETURN
      end
C***********************************************************************
C
      FUNCTION FUEL_TYPE_2_PRIM_MOVER(R_PRIM_FUEL_TYPE_STR)
C
C***********************************************************************
      LOGICAL*1 LEGACY_PRIMARY_MOVER,GET_LEGACY_PRIMARY_MOVER
      INTEGER*2 FUEL_TYPE_2_PRIM_MOVER
      CHARACTER*6 R_PRIM_FUEL_TYPE_STR
!
! END DATA DECLARATIONS
!
            IF(             R_PRIM_FUEL_TYPE_STR == 'ANT   ' .OR.      ! Anthracite Coal
     +                      R_PRIM_FUEL_TYPE_STR == 'BC    ' .OR.      ! Beneficiated Coal
     +                      R_PRIM_FUEL_TYPE_STR == 'BIT   ' .OR.      ! Bituminous Coal
     +                      R_PRIM_FUEL_TYPE_STR == 'COL   ' .OR.      ! Coal
     +                      R_PRIM_FUEL_TYPE_STR == 'LIG   ' .OR.      ! Lignite Coal
     +                      R_PRIM_FUEL_TYPE_STR == 'SC    ' .OR.      ! Coal Based Synfuel
     +                      R_PRIM_FUEL_TYPE_STR == 'SUB   ' .OR.      ! Subbituminous Coal
     +                      R_PRIM_FUEL_TYPE_STR == 'WC    ' .OR.      ! Waste Coal
     +                      R_PRIM_FUEL_TYPE_STR == 'COAL  ' .OR.      ! Coal Fuel Category
     +                      R_PRIM_FUEL_TYPE_STR == 'C     ' ) THEN    ! Legacy Coal Fuel Category
               FUEL_TYPE_2_PRIM_MOVER = 1                         ! Coal
            ELSEIF(         R_PRIM_FUEL_TYPE_STR == 'BFG   ' .OR.      ! Blast Furnace Gas
     +                      R_PRIM_FUEL_TYPE_STR == 'COG   ' .OR.      ! Coke Oven Gas
     +                      R_PRIM_FUEL_TYPE_STR == 'LNG   ' .OR.      ! Liquefied Natural Gas
     +                      R_PRIM_FUEL_TYPE_STR == 'LPG   ' .OR.      ! Liquefied Petroleum Gas
     +                      R_PRIM_FUEL_TYPE_STR == 'NG    ' .OR.      ! Natural Gas
     +                      R_PRIM_FUEL_TYPE_STR == 'OG    ' .OR.      ! Other Gas
     +                      R_PRIM_FUEL_TYPE_STR == 'PG    ' .OR.      ! Propane
     +                      R_PRIM_FUEL_TYPE_STR == 'RG    ' .OR.      ! Refinery Gas
     +                      R_PRIM_FUEL_TYPE_STR == 'SGC   ' .OR.      ! Synthetic Natural Gas
     +                      R_PRIM_FUEL_TYPE_STR == 'SNG   ' .OR.      ! Synthetic Natural Gas
     +                      R_PRIM_FUEL_TYPE_STR == 'GAS   ' .OR.      ! Gas Fuel Category
     +                      R_PRIM_FUEL_TYPE_STR == 'G     ' ) THEN    ! Legacy Gas Fuel Category
               FUEL_TYPE_2_PRIM_MOVER = 2                          ! Gas
            ELSEIF(         R_PRIM_FUEL_TYPE_STR == 'COK   ' .OR.      ! Coker bi-product
     +                      R_PRIM_FUEL_TYPE_STR == 'CRU   ' .OR.      ! Crude Oil
     +                      R_PRIM_FUEL_TYPE_STR == 'CTO   ' .OR.      ! Coal Tar Oil
     +                      R_PRIM_FUEL_TYPE_STR == 'DFO   ' .OR.      ! Distillate Fuel Oil
     +                      R_PRIM_FUEL_TYPE_STR == 'DSL   ' .OR.      ! Diesel
     +                      R_PRIM_FUEL_TYPE_STR == 'FO1   ' .OR.      ! No. 1 Fuel Oil
     +                      R_PRIM_FUEL_TYPE_STR == 'FO2   ' .OR.      ! No. 2 Fuel Oil
     +                      R_PRIM_FUEL_TYPE_STR == 'FO3   ' .OR.      ! No. 3 Fuel Oil
     +                      R_PRIM_FUEL_TYPE_STR == 'FO4   ' .OR.      ! No. 4 Fuel Oil
     +                      R_PRIM_FUEL_TYPE_STR == 'FO5   ' .OR.      ! No. 5 Fuel Oil
     +                      R_PRIM_FUEL_TYPE_STR == 'FO6   ' .OR.      ! No. 6 Fuel Oil
     +                      R_PRIM_FUEL_TYPE_STR == 'JF    ' .OR.      ! Jet Fuel
     +                      R_PRIM_FUEL_TYPE_STR == 'KER   ' .OR.      ! Kerosene
     +                      R_PRIM_FUEL_TYPE_STR == 'OIL   ' .OR.      ! Oil
!     +                      R_PRIM_FUEL_TYPE_STR == 'PC    ' .OR.      ! Petroleum Coke
     +                      R_PRIM_FUEL_TYPE_STR == 'RFO   ' .OR.      ! Residual Fuel Oil
     +                      R_PRIM_FUEL_TYPE_STR == 'WO    ' .OR.      ! Waste Oil
     +                      R_PRIM_FUEL_TYPE_STR == 'FO    ' .OR.      ! Legacy Oil Fuel Category
     +                      R_PRIM_FUEL_TYPE_STR == 'O     ' ) THEN    ! Legacy Oil Fuel Category
               FUEL_TYPE_2_PRIM_MOVER = 3                          ! Oil
           ELSEIF(          R_PRIM_FUEL_TYPE_STR == 'URA   ' .OR.      ! Uranium
     +                      R_PRIM_FUEL_TYPE_STR == 'UR    ' .OR.      ! Nuclear Fuel Category
     +                      R_PRIM_FUEL_TYPE_STR == 'NUC   ' .OR.      ! Nuclear Fuel Category
     +                      R_PRIM_FUEL_TYPE_STR == 'NU    ' .OR.      ! Nuclear Fuel Category
     +                      R_PRIM_FUEL_TYPE_STR == 'N     ' ) THEN    ! Legacy Nuclear Fuel Category
               FUEL_TYPE_2_PRIM_MOVER = 4                          ! Nuclear
            ELSEIF(         R_PRIM_FUEL_TYPE_STR == 'WAT   ' ) THEN      ! Water
               FUEL_TYPE_2_PRIM_MOVER = 5                         ! Water
            ELSEIF(         R_PRIM_FUEL_TYPE_STR == 'MF    ' .OR.      ! Multifuel
     +                      R_PRIM_FUEL_TYPE_STR == 'OTH   ' .OR.      ! Other
     +                      R_PRIM_FUEL_TYPE_STR == 'PUR   ' .OR.      ! Purchased Steam
     +                      R_PRIM_FUEL_TYPE_STR == 'TDF   ' .OR.      ! Tires
     +                      R_PRIM_FUEL_TYPE_STR == 'WH    ' .OR.      ! Waste Heat
! 010912. MOVED PER KATHY.
     +                      R_PRIM_FUEL_TYPE_STR == 'PC    ' .OR.      ! Petroleum Coke
     +                      R_PRIM_FUEL_TYPE_STR == 'N/A   ' ) THEN    ! Not Available
               FUEL_TYPE_2_PRIM_MOVER = 6                         ! Other
            ELSEIF(         R_PRIM_FUEL_TYPE_STR == 'AB    ' .OR.      ! Agriculture Byproduct
     +                      R_PRIM_FUEL_TYPE_STR == 'BLQ   ' .OR.      ! Black Liquor
     +                      R_PRIM_FUEL_TYPE_STR == 'EFL   ' .OR.      ! E-Fuel
     +                      R_PRIM_FUEL_TYPE_STR == 'GEO   ' .OR.      ! Geothermal Steam
     +                      R_PRIM_FUEL_TYPE_STR == 'LFG   ' .OR.      ! Landfill Gas
     +                      R_PRIM_FUEL_TYPE_STR == 'MSB   ' .OR.      ! Municipal Solid Waste - Biogenic
     +                      R_PRIM_FUEL_TYPE_STR == 'MSN   ' .OR.      ! Municipal Solid Waste - Non-Biogenic
     +                      R_PRIM_FUEL_TYPE_STR == 'MSW   ' .OR.      ! Municipal Solid Waste
     +                      R_PRIM_FUEL_TYPE_STR == 'MTE   ' .OR.      ! Methane
     +                      R_PRIM_FUEL_TYPE_STR == 'MTH   ' .OR.      ! Methanol
     +                      R_PRIM_FUEL_TYPE_STR == 'OBG   ' .OR.      ! Biomass Gases
     +                      R_PRIM_FUEL_TYPE_STR == 'OBL   ' .OR.      ! Biomass Liquids
     +                      R_PRIM_FUEL_TYPE_STR == 'OBS   ' .OR.      ! Biomass Solids
     +                      R_PRIM_FUEL_TYPE_STR == 'REF   ' .OR.      ! Refuse
     +                      R_PRIM_FUEL_TYPE_STR == 'SLW   ' .OR.      ! Sludge Waste
     +                      R_PRIM_FUEL_TYPE_STR == 'WD    ' .OR.      ! Wood
     +                      R_PRIM_FUEL_TYPE_STR == 'WDL   ' .OR.      ! Wood Waste Liquids
     +                      R_PRIM_FUEL_TYPE_STR == 'WDS   ' ) THEN    ! Wood Waste Solids
               FUEL_TYPE_2_PRIM_MOVER = 7                         ! Renewable
            ELSEIF(         R_PRIM_FUEL_TYPE_STR == 'SUN   ' .OR.      ! Solar Thermal
     +                      R_PRIM_FUEL_TYPE_STR == 'PV    ' .OR.      ! Solar Photovaoltaic
     +                      R_PRIM_FUEL_TYPE_STR == 'SOL   ' ) THEN    ! Legacy Solar Renewable
               FUEL_TYPE_2_PRIM_MOVER = 8                         ! Solar Renewable
            ELSEIF(         R_PRIM_FUEL_TYPE_STR == 'WND   ' ) THEN    ! Wind
               FUEL_TYPE_2_PRIM_MOVER = 9                         ! Wind Renewable
            ELSEIF(         R_PRIM_FUEL_TYPE_STR == 'DSM   ' .OR.
     +                      R_PRIM_FUEL_TYPE_STR == 'EES   ' ) THEN    ! 022708.
               FUEL_TYPE_2_PRIM_MOVER = 10                         ! DSM AND ENERGY EFFICIENCY STANDARDS
            ELSEIF(         R_PRIM_FUEL_TYPE_STR == 'MWH  ' ) THEN    ! 052817
               FUEL_TYPE_2_PRIM_MOVER = 11                         ! BATTERY
            ELSEIF(         R_PRIM_FUEL_TYPE_STR == 'NA   ' ) THEN     ! NA RESERVED TO IGNORE
               FUEL_TYPE_2_PRIM_MOVER = 0
            ELSE
               IF(GET_LEGACY_PRIMARY_MOVER()) THEN
                  FUEL_TYPE_2_PRIM_MOVER = 6
               ELSE
                  FUEL_TYPE_2_PRIM_MOVER = 0
               ENDIF
            ENDIF
      RETURN
      END
C***************************************************************
      FUNCTION CL_CAPACITY_PLANNING_ADJUSTMENTS(R_YEAR,R_UNIT_NO,
     +                                          ST,SUBTRACT_IT)
     +                        RESULT(R_CL_CAPACITY_PLANNING_ADJUSTMENTS)
      use end_routine, only: end_program, er_message
C***************************************************************
C
      USE CLA_OBJT_ARRAYS
      INCLUDE 'SpinLib.MON'
      SAVE
      INCLUDE 'SIZECOM.MON'
      INCLUDE 'PRODCOM.MON'
      INCLUDE 'PROD2COM.MON'
C
      CHARACTER (LEN=2) :: GREEN_MRX_METHOD
      REAL (KIND=4) :: R_CL_CAPACITY_PLANNING_ADJUSTMENTS
      REAL (KIND=4) :: UNIT_CAPACITY,CAP_MW,VOID_REAL4,R_POINTR,
     +                 MONTH_MULT,FIRST_YEAR_CAPACITY
      INTEGER (KIND=2) :: UNIT_NO,R_UNIT_NO,YEAR_START,YEAR_END,R_YEAR,
     +                    ON_LINE_MONTH,TG,FT,
     +                    UNIT_OFF_YEAR,PT_YR,
     +                    LOCAL_POINTER,NG
      LOGICAL (KIND=4) :: SUBTRACT_IT
      CHARACTER (LEN=20) :: MONTH_NAME,LOCAL_NAME
      LOGICAL*1 RESURRECT_RETROFIT_UNIT
      INTEGER (KIND=4) :: ST
      INTEGER (KIND=2), PARAMETER :: MAX_NEWGEN_INDEX = 10
C FUNCTION DECLARATIONS
      INTEGER (KIND=2) :: PEAK_MONTH,GET_TRANS_GROUP_POSITION,
     +                    GET_NUMBER_OF_ACTIVE_GROUPS
      REAL (KIND=4) :: GET_CL_MW_FROM_POINTR,
     +                 GET_CLASS_PEAK_NET_DSM_FOR_CAP,
     +                 PLAN_FACTOR,GET_VAR
C
C BEGINING OF THE CAPACITY PLANNING SECTION
C
!
!      IF(CAP_PLANNING_FAC(R_UNIT_NO) < 0.) THEN
!         PLAN_FACTOR = GET_VAR(CAP_PLANNING_FAC(R_UNIT_NO),
!     +                                           YEAR,
!     +                                           UNITNM(R_UNIT_NO))
!      ELSE
!         PLAN_FACTOR = CAP_PLANNING_FAC(R_UNIT_NO)
!      ENDIF

! 032608.
      ON_LINE_MONTH = ONLINE(R_UNIT_NO) -
     +                                   100*INT(ONLINE(R_UNIT_NO)/100.)
      IF(.NOT. SUBTRACT_IT) THEN
         YEAR_START = R_YEAR - BASE_YEAR
         IF(YEAR_START < 1) THEN
            YEAR_START = 1
            ON_LINE_MONTH = 1
         ENDIF
!         ELSE
            IF(ON_LINE_MONTH > PEAK_MONTH(YEAR_START)) THEN
               WRITE(4,*) 'The on-line month, ',
     +                    TRIM(MONTH_NAME(ON_LINE_MONTH)),
     +                    ', for CL unit, ',TRIM(UNITNM(R_UNIT_NO))
               WRITE(4,"('&',A,I4,A)") ' is after the peak month in ',
     +                     R_YEAR,' of '//
     +           TRIM(MONTH_NAME(PEAK_MONTH(YEAR_START)))//'.'
               WRITE(4,*) "The capacity of this unit is not in ",
     +                    "the planning capacity for it's on-line year."
               WRITE(4,*)
!
C               TG=TRANSACTION_GROUP(R_UNIT_NO) ! TRANSACTION_GROUP FUNCTION REPLACED WITH THE ARRAY 11/02/06
               TG = TRANSACTION_GROUP_ID(R_UNIT_NO)
               TG = GET_TRANS_GROUP_POSITION(TG)
               FT= PRIMARY_MOVER(R_UNIT_NO)
               UNIT_CAPACITY = INPUT_MW(2,R_UNIT_NO)
               CAP_MW = UNIT_CAPACITY
               PT_YR = 1
               UNIT_NO = R_UNIT_NO
               IF(CAP_MW < 0.) THEN
                  CAP_MW = GET_CL_MW_FROM_POINTR(CAP_MW,PT_YR)
                  IF(CAP_MW < 0.)
     +                CAP_MW =
     +                   GET_CL_MW_FROM_POINTR(CAP_MW,PEAK_MONTH(PT_YR))
                  CAP_MW = MAX(0.,CAP_MW)
               ELSE
                  CAP_MW = MAX(0.,CAP_MW)
               ENDIF

               IF(MONTHLY_CAPACITY_POINTER(UNIT_NO) /= 0 .AND.
     +                           .NOT. CL_CAP_AREA_LINKED(UNIT_NO)) THEN
                  R_POINTR =
     +                     FLOAT(ABS(MONTHLY_CAPACITY_POINTER(UNIT_NO)))
                  MONTH_MULT = GET_CL_MW_FROM_POINTR(R_POINTR,
     +                                           PEAK_MONTH(PT_YR))
                  IF(MONTH_MULT > 2. .AND. CAP_MW /= 0.) THEN
                     CAP_MW = MONTH_MULT
                  ELSE
                     CAP_MW = MONTH_MULT * CAP_MW
                  ENDIF
               ELSEIF(MONTHLY_CAPACITY_POINTER(UNIT_NO) < 0 .AND.
     +                                 CL_CAP_AREA_LINKED(UNIT_NO)) THEN
                  LOCAL_NAME = UNITNM(UNIT_NO)
                  LOCAL_POINTER = ABS(MONTHLY_CAPACITY_POINTER(UNIT_NO))
                  CAP_MW = MIN(GET_CLASS_PEAK_NET_DSM_FOR_CAP(
     +                           PT_YR,LOCAL_NAME,LOCAL_POINTER),CAP_MW)
               ENDIF
               IF(CAP_PLANNING_FAC(R_UNIT_NO) < 0.) THEN
                  PLAN_FACTOR = GET_VAR(CAP_PLANNING_FAC(R_UNIT_NO),
     +                                           PT_YR,
     +                                           UNITNM(R_UNIT_NO))
               ELSE
                  PLAN_FACTOR = CAP_PLANNING_FAC(R_UNIT_NO)
               ENDIF
               CAP_MW = CAP_MW * CAP_FRAC_OWN(UNIT_NO) *
     +                                              PLAN_FACTOR * 0.01
!     +                                    CAP_PLANNING_FAC(UNIT_NO)/100.
               IF (FT > 0 .AND. FT < 7) THEN
                  CL_TG_AFTER_PEAK(TG,YEAR_START) =      ! MODIFIED 11/13/06 BY DR.G
     +                          CL_TG_AFTER_PEAK(TG,YEAR_START) + CAP_MW
                  CL_TG_AFTER_PEAK(0,YEAR_START) =
     +                           CL_TG_AFTER_PEAK(0,YEAR_START) + CAP_MW
               ENDIF
               YEAR_START = YEAR_START + 1
            ENDIF
!         ENDIF
         IF(OFF_LINE_YEAR(R_UNIT_NO) > LAST_STUDY_YEAR) THEN
            YEAR_END = LAST_STUDY_YEAR - BASE_YEAR
         ELSE
            YEAR_END = OFF_LINE_YEAR(R_UNIT_NO) - BASE_YEAR
            IF(YEAR_END < 1 .OR. R_UNIT_NO < 1 .OR. R_UNIT_NO
     +                                              > MAX_CL_UNITS) THEN
               WRITE(4,*) "The unit ",UNITNM(R_UNIT_NO)
               WRITE(4,*) "has an off-line year of ",
     +                                          OFF_LINE_YEAR(R_UNIT_NO)
               WRITE(4,*) "while the base year is ",BASE_YEAR
               WRITE(4,*) "First, check to make sure that the "
               WRITE(4,*) "Unit Production pointers in your "
               WRITE(4,*) "Capacity Options file are valid."
               WRITE(4,*) "If running Transact, make sure that the"
               WRITE(4,*) "resource options in your Expansion Plant"
               WRITE(4,*) "Operations file all have active"
               WRITE(4,*) "Transact Groups."
               WRITE(4,*) '*** line 3318 CLA_OBJT.FOR ***'
               er_message='See WARNING MESSAGES'
               call end_program(er_message)
            ENDIF
            IF(OFF_LINE_MONTH(R_UNIT_NO) < PEAK_MONTH(YEAR_END)) THEN
               WRITE(4,*) 'The off-line month, ',
     +                    TRIM(MONTH_NAME(OFF_LINE_MONTH(R_UNIT_NO))),
     +                    ', for CL unit, ',TRIM(UNITNM(R_UNIT_NO))
               WRITE(4,"('&',A,I4,A)")', is before the peak month in ',
     +                     OFF_LINE_YEAR(R_UNIT_NO),' of '//
     +          TRIM(MONTH_NAME(PEAK_MONTH(OFF_LINE_YEAR(R_UNIT_NO))))//
     +                                                               '.'
               WRITE(4,*) "The capacity of this unit is not in ",
     +                   "the planning capacity for it's off-line year."
               WRITE(4,*)
               YEAR_END = YEAR_END - 1
            ENDIF
         ENDIF
         UNIT_CAPACITY = INPUT_MW(2,R_UNIT_NO)
         UNIT_OFF_YEAR = OFF_LINE_YEAR(R_UNIT_NO) - BASE_YEAR
! 101309. VERY CONFUSING BUT CHANGED THIS LINE.
!         OFF_LINE_YEAR(R_UNIT_NO) = YEAR_END + BASE_YEAR
         UNIT_NO = R_UNIT_NO ! 4/11/95. GAT.
      ELSE !   GOTO 10
         UNIT_NO = R_UNIT_NO
         UNIT_CAPACITY = INPUT_MW(2,UNIT_NO)
         YEAR_START = R_YEAR - BASE_YEAR
         YEAR_END=MIN(LAST_STUDY_YEAR,OFF_LINE_YEAR(UNIT_NO))-BASE_YEAR
         IF(.NOT. GREEN_MRX_METHOD() == 'GX')
     +         OFLINE(UNIT_NO)=100*(R_YEAR-1900)+OFF_LINE_MONTH(UNIT_NO)
      ENDIF ! 10 CONTINUE
         DO PT_YR = YEAR_START, YEAR_END
C
!            CAP_MW = UNIT_CAPACITY             ! TMS 7/15/05 - leave in or capacity planning multiplier compounds.  This resets value every year
!            IF(PT_YR == YEAR_START .AND.
!     +                      ON_LINE_MONTH > PEAK_MONTH(YEAR_START)) THEN
!               CAP_MW = 0.0
!            ELSE
               CAP_MW = UNIT_CAPACITY                 ! TMS 7/15/05 - move out of loop since loop doesnt execute for units retiring in first year
!            ENDIF

            IF(CAP_MW < 0.) THEN
               CAP_MW = GET_CL_MW_FROM_POINTR(CAP_MW,PT_YR)
! ADDED PER JONES. 3/13/98. GAT.
               IF(CAP_MW < 0.)
     +                CAP_MW =
     +                   GET_CL_MW_FROM_POINTR(CAP_MW,PEAK_MONTH(PT_YR))
!
               CAP_MW = MAX(0.,CAP_MW)
            ELSE
C
C IF NO POINTER HAS BEEN SPECIFIED FOR THE PEAK MONTH
C
               CAP_MW = MAX(0.,CAP_MW)
            ENDIF

            IF(MONTHLY_CAPACITY_POINTER(UNIT_NO) /= 0 .AND.
     +                           .NOT. CL_CAP_AREA_LINKED(UNIT_NO)) THEN
               R_POINTR = FLOAT(ABS(MONTHLY_CAPACITY_POINTER(UNIT_NO)))
               MONTH_MULT = GET_CL_MW_FROM_POINTR(R_POINTR,
     +                                           PEAK_MONTH(PT_YR))
               IF(MONTH_MULT > 2. .AND. CAP_MW /= 0.) THEN
                  CAP_MW = MONTH_MULT
               ELSE
                  CAP_MW = MONTH_MULT * CAP_MW
               ENDIF
            ELSEIF(MONTHLY_CAPACITY_POINTER(UNIT_NO) < 0 .AND.
     +                                 CL_CAP_AREA_LINKED(UNIT_NO)) THEN
               LOCAL_NAME = UNITNM(UNIT_NO)
               LOCAL_POINTER = ABS(MONTHLY_CAPACITY_POINTER(UNIT_NO))
               CAP_MW = MIN(GET_CLASS_PEAK_NET_DSM_FOR_CAP(
     +                           PT_YR,LOCAL_NAME,LOCAL_POINTER),CAP_MW)
            ENDIF
C
C EFFECTIVE MW'S OF PLANNING CAPACITY
C
            IF(CAP_PLANNING_FAC(R_UNIT_NO) < 0.) THEN
               PLAN_FACTOR = GET_VAR(CAP_PLANNING_FAC(R_UNIT_NO),
     +                                                PT_YR,
     +                                                UNITNM(R_UNIT_NO))
            ELSE
               PLAN_FACTOR = CAP_PLANNING_FAC(R_UNIT_NO)
            ENDIF
            CAP_MW = CAP_MW * CAP_FRAC_OWN(UNIT_NO) *
     +                                              PLAN_FACTOR * 0.01
!     +                                    CAP_PLANNING_FAC(UNIT_NO)/100.
            IF(SUBTRACT_IT) CAP_MW = -CAP_MW
C
C THIS SECTION ADDS MW'S OF PLANNING CAPACITY
C
            IF(LDTYPE(UNIT_NO)=='M' .OR.
     +              LDTYPE(UNIT_NO)=='B' .OR. LDTYPE(UNIT_NO)=='N') THEN
               CL_ANN_CAP(1,PT_YR,ST) = CL_ANN_CAP(1,PT_YR,ST) + CAP_MW
               CL_ANN_CAP(2,PT_YR,ST) = CL_ANN_CAP(2,PT_YR,ST) + CAP_MW
               CL_ANN_CAP(3,PT_YR,ST) = CL_ANN_CAP(3,PT_YR,ST) + CAP_MW
            ELSE IF(LDTYPE(UNIT_NO) == 'C') THEN
               CL_ANN_CAP(2,PT_YR,ST) = CL_ANN_CAP(2,PT_YR,ST) + CAP_MW
               CL_ANN_CAP(3,PT_YR,ST) = CL_ANN_CAP(3,PT_YR,ST) + CAP_MW
            ELSE IF(LDTYPE(UNIT_NO) == 'D') THEN
               CL_ANNUAL_LOAD_REDUCTION(PT_YR) =
     +                        CL_ANNUAL_LOAD_REDUCTION(PT_YR) + CAP_MW
            ELSE
               CL_ANN_CAP(3,PT_YR,ST) = CL_ANN_CAP(3,PT_YR,ST) + CAP_MW
            ENDIF
! 01/11/02. FOR NEW TG RESERVE MARGIN REPORT.
! 072307. TRAP FOR 10 > FT > 6
C               TG=TRANSACTION_GROUP(R_UNIT_NO) ! TRANSACTION_GROUP FUNCTION REPLACED WITH THE ARRAY 11/02/06
            TG=TRANSACTION_GROUP_ID(UNIT_NO)
            TG = GET_TRANS_GROUP_POSITION(TG)
            FT= PRIMARY_MOVER(UNIT_NO)
            NG= NEWGEN_INDEX(UNIT_NO)
            IF(TG < 1 .OR. TG > GET_NUMBER_OF_ACTIVE_GROUPS()) THEN
               WRITE(4,*) "BAD TRANSACTION GROUP ID IN THERMAL UNITS",
     +                                                   UNITNM(UNIT_NO)
            ENDIF
            IF(NG > 10) NG = 1 ! 070609. PER DOUG.
            IF (FT > 0 .AND. FT < 7) THEN
               CL_TG_CAP(FT,TG,PT_YR,ST) =
     +                                CL_TG_CAP(FT,TG,PT_YR,ST) + CAP_MW
               CL_TG_CAP(0,TG,PT_YR,ST) =
     +                                 CL_TG_CAP(0,TG,PT_YR,ST) + CAP_MW
            ELSEIF(FT > 6) THEN ! 110807 FOR PAC: .OR. FT < 1) THEN
               CL_TG_CAP(6,TG,PT_YR,ST) =
     +                                CL_TG_CAP(6,TG,PT_YR,ST) + CAP_MW
               CL_TG_CAP(0,TG,PT_YR,ST) =
     +                                 CL_TG_CAP(0,TG,PT_YR,ST) + CAP_MW
            ENDIF
            IF (NG > 0 .AND. NG < MAX_NEWGEN_INDEX) THEN
               NEWGEN_CAP_BY_INDEX(NG,TG,PT_YR) =
     +                         NEWGEN_CAP_BY_INDEX(NG,TG,PT_YR) + CAP_MW
            ENDIF
!
            IF(PT_YR == YEAR_START) FIRST_YEAR_CAPACITY = ABS(CAP_MW)
         ENDDO
         IF(  (UNIT_OFF_YEAR <= STUDY_PERIOD .AND.
     +         OFF_LINE_MONTH(UNIT_NO) < PEAK_MONTH(UNIT_OFF_YEAR)) .OR.
     +         (UNIT_OFF_YEAR+1 <= STUDY_PERIOD .AND.
     +             OFF_LINE_MONTH(UNIT_NO) >
     +                                  PEAK_MONTH(UNIT_OFF_YEAR))) THEN
            IF (FT > 0 .AND. FT < 10) THEN ! 7) THEN
               IF(OFF_LINE_MONTH(UNIT_NO) >
     +                                   PEAK_MONTH(UNIT_OFF_YEAR)) THEN
                  CL_TG_RETIRE(TG,UNIT_OFF_YEAR+1) =
     +                         CL_TG_RETIRE(TG,UNIT_OFF_YEAR+1) + CAP_MW
                  CL_TG_RETIRE(0,UNIT_OFF_YEAR+1) =
     +                          CL_TG_RETIRE(0,UNIT_OFF_YEAR+1) + CAP_MW
               ELSE
                  CL_TG_RETIRE(TG,UNIT_OFF_YEAR) =
     +                           CL_TG_RETIRE(TG,UNIT_OFF_YEAR) + CAP_MW
                  CL_TG_RETIRE(0,UNIT_OFF_YEAR) =
     +                            CL_TG_RETIRE(0,UNIT_OFF_YEAR) + CAP_MW
               ENDIF
            ENDIF
         ENDIF
         R_CL_CAPACITY_PLANNING_ADJUSTMENTS = FIRST_YEAR_CAPACITY
      RETURN
C***************************************************************
      ENTRY RESURRECT_RETROFIT_UNIT(R_YEAR,R_UNIT_NO)
C***************************************************************
!
! IMPLICITLY ASSUMES 25 YEAR LIFE
!
         OFLINE(R_UNIT_NO) = 100*(R_YEAR + 25 - 1900) +
     +                                         OFF_LINE_MONTH(R_UNIT_NO)
         ONLINE(R_UNIT_NO) = 100*INT(ONLINE(R_UNIT_NO)/100.) +
     +            CO2_CONTROL_DATE(R_UNIT_NO) -
     +                      100*INT(CO2_CONTROL_DATE(R_UNIT_NO)/100.)
         RESURRECT_RETROFIT_UNIT = .TRUE.
      RETURN
      END
